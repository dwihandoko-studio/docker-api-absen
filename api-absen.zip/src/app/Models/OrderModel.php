<?php

namespace App\Models;

use CodeIgniter\Model;

class OrderModel extends Model
{
    protected $table = '_orders_tb_b';
    protected $primarykey = 'id';
    protected $secondKey = 'kode_transaksi';
    protected $allowedFields = ['id', 'kode_transaksi', 'jenis_order', 'total_harga', 'total_qty', 'status_order', 'user_id', 'created_at', 'updated_at'];
}
