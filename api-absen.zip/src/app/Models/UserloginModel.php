<?php

namespace App\Models;

use CodeIgniter\Model;

class UserloginModel extends Model
{
    protected $table = '_users_tb';
    protected $primarykey = 'id';
    protected $allowedFields = ['firsname', 'lastname', 'email', 'instansi_id', 'level'];
}
