<?php

namespace App\Models;

use CodeIgniter\Model;

class FotogaleryModel extends Model
{
    protected $table = '_foto_galery_tb_b';
    protected $primarykey = 'id';
    protected $allowedFields = ['foto_album_id', 'foto_title', 'foto_description', 'foto_featured_image', 'foto_is_active', 'foto_user_id', 'foto_created_at', 'foto_updated_at'];

    // protected function beforeInsert(array $data)
    // {
    //     $data = $this->urlCreate($data);
    //     return $data;
    // }

    // protected function beforeUpdate(array $data)
    // {
    //     $data = $this->urlCreate($data);
    //     return $data;
    // }

    // protected function urlCreate(array $data)
    // {
    //     if (isset($data['data']['album_url']))
    //         $data['data']['album_url'] = password_hash($data['data']['password'], PASSWORD_DEFAULT);

    //     return $data;
    // }
}
