<?php

namespace App\Models;

use CodeIgniter\Model;

class PaymentModel extends Model
{
    protected $table = '_payment_gateway_tb_b';
    protected $primarykey = 'id';
    protected $allowedFields = ['id', 'layanan_payment', 'payment_type', 'bank', 'group_payment', 'logo_payment', 'title_payment', 'nama_pemilik', 'no_rekening', 'cost_payment', 'no_urut', 'group_urut', 'status_payment', 'publish', 'favorite_payment', 'created_at', 'updated_at'];
}
