<?php

namespace App\Models;

use CodeIgniter\Model;

class UserProfilModel extends Model
{
    protected $table = '_profil_users_tb';
    protected $primarykey = 'id';
    protected $allowedFields = ['id', 'firsname', 'lastname', 'email', 'nik', 'kk', 'tempat_lahir', 'tgl_lahir', 'kode_alamat', 'jenis_kelamin', 'alamat', 'provinsi', 'kabupaten', 'kecamatan', 'kelurahan', 'role_user', 'agama', 'no_hp', 'profile_picture', 'is_penjual', 'created_at', 'updated_at'];
}
