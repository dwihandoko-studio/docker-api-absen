<?php

namespace App\Models;

use CodeIgniter\Model;

class ProductpublicModel extends Model
{
    protected $table = 'product_public';
    protected $primarykey = 'productId';
    protected $secondarykey = 'productId';
    protected $allowedFields = ['productId', 'categoryId', 'subCategoryId', 'productTitle', 'productDescription', 'productPriceSell', 'productWeight', 'productStatus', 'productUnlimited', 'productThumb', 'productImage', 'categoryName', 'subCategoryName', 'categoryKeySearch', 'subCategoryKeySearch', 'createdAt', 'updatedAt', 'titleToko','statusToko','idToko','productSatuan','productBarcode'];
}
