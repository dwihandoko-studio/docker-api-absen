<?php

namespace App\Models;

use CodeIgniter\Model;

class KeranjangModel extends Model
{
    protected $table = '_keranjang_tb_b';
    protected $primarykey = 'id';
    protected $secondKey = 'product_id';
    protected $allowedFields = ['id', 'product_id', 'qty', 'user_id', 'created_at', 'updated_at'];
}
