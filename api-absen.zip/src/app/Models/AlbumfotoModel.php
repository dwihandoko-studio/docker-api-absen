<?php

namespace App\Models;

use CodeIgniter\Model;

class AlbumfotoModel extends Model
{
    protected $table = '_album_tb_b';
    protected $primarykey = 'id';
    protected $allowedFields = ['album_opd', 'album_title', 'album_description', 'album_url', 'album_featured_image', 'album_is_active', 'album_user_id', 'album_created_at', 'album_updated_at'];
}
