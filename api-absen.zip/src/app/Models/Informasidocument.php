<?php

namespace App\Models;

use CodeIgniter\Model;

class InformasidocumentModel extends Model
{
    protected $table = '_informasi_document_tb_b';
    protected $primarykey = 'id';
    protected $allowedFields = ['document_opd', 'document_title', 'document_description', 'document_url', 'document_featured_image', 'document_is_active', 'document_user_id', 'document_created_at', 'document_updated_at'];
}
