<?php

namespace App\Models;

use CodeIgniter\Model;

class PromotionproductpublicModel extends Model
{
    protected $table = 'product_public';
    protected $primarykey = 'productId';
    protected $secondarykey = 'productId';
    protected $allowedFields = ['productId', 'categoryId', 'subCategoryId', 'productTitle', 'productDescription', 'productPrice', 'productWeight', 'productStatus', 'productUnlimited', 'productThumb', 'productImage', 'categoryName', 'subCategoryName', 'categoryKeySearch', 'subCategoryKeySearch', 'createdAt', 'updatedAt', 'deletedAt'];
}
