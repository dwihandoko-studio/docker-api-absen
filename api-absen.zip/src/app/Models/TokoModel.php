<?php

namespace App\Models;

use CodeIgniter\Model;

class TokoModel extends Model
{
    protected $table = '_toko_tb_b';
    protected $primarykey = 'id';
    protected $secondarykey = 'user_id';
    protected $allowedFields = ['id', 'toko_title', 'toko_description', 'toko_slogan', 'toko_status', 'toko_status_description', 'toko_url', 'toko_saldo', 'user_id', 'toko_featured_image', 'toko_created_at', 'toko_updated_at', 'toko_deleted_at', 'kab_id', 'prov_id', 'kec_id', 'alamat', 'available_pengiriman','last_active'];
}
