<?php

namespace App\Models;

use CodeIgniter\Model;

class OpdModel extends Model
{
    protected $table = '_opd_b_tb';
    protected $primarykey = 'id';
    protected $allowedFields = ['opd_title', 'opd_description', 'opd_is_active', 'opd_created_at', 'opd_updated_at'];
}
