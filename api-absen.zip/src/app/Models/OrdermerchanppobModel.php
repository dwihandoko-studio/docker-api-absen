<?php

namespace App\Models;

use CodeIgniter\Model;

class OrdermerchanppobModel extends Model
{
    protected $table = '_orders_ppob_merchan_tb_b';
    protected $primarykey = 'id';
    protected $secondKey = 'kode_transaksi';
    protected $allowedFields = ['id', 'kode_transaksi','product_id','harga_product','no_pelanggan', 'jenis_order', 'total_harga', 'total_qty', 'status_order','order_telah_selesai', 'user_id', 'created_at', 'updated_at'];
}
