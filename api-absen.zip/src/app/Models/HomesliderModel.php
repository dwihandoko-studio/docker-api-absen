<?php

namespace App\Models;

use CodeIgniter\Model;

class HomesliderModel extends Model
{
    protected $table = '_slider_tb_b';
    protected $primarykey = 'id';
    protected $allowedFields = ['slider_opd', 'slider_title', 'slider_description', 'slider_url', 'slider_featured_image', 'slider_is_active', 'slider_user_id', 'slider_created_at', 'slider_updated_at'];
}
