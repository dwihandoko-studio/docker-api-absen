<?php

namespace App\Models;

use CodeIgniter\Model;

class BeritaModel extends Model
{
    protected $table = '_berita_tb_b';
    protected $primarykey = 'id';
    protected $allowedFields = ['post_opd', 'post_category', 'post_user_id', 'post_title', 'post_description', 'post_url', 'post_trending', 'post_tag', 'post_featured_image', 'post_is_active', 'post_created_at', 'post_updated_at'];
}
