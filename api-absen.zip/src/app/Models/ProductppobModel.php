<?php

namespace App\Models;

use CodeIgniter\Model;

class ProductppobModel extends Model
{
    protected $table = '_daftar_produk_ppob_tb_b';
    protected $primarykey = 'id';
    protected $secondKey = 'kode_product';
    protected $allowedFields = ['id', 'group_product', 'category_product', 'kode_product', 'nama_product', 'nominal', 'harga', 'status_product', 'created_at', 'updated_at'];
}
