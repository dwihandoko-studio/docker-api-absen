<?php

namespace App\Models;

use CodeIgniter\Model;

class TopupModel extends Model
{
    protected $table = '_topup_tb_b';
    protected $primarykey = 'id';
    protected $secondKey = 'kode_transaksi';
    protected $allowedFields = ['id', 'kode_transaksi','user_id','jenis_topup','nominal', 'gross_amount', 'status_topup', 'created_at', 'updated_at'];
}
