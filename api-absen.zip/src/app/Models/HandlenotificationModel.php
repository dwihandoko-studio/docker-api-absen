<?php

namespace App\Models;

use CodeIgniter\Model;

class HandlenotificationModel extends Model
{
    protected $table = '_history_transaksi_pembayaran_tb_b';
    protected $primarykey = 'id';
    protected $allowedFields = ['order_id', 'status_transaksi', 'keterangan', 'created_at'];
}
