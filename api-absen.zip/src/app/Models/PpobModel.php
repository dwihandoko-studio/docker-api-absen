<?php

namespace App\Models;

use CodeIgniter\Model;

class PpobModel extends Model
{
    protected $table = '_alamat_kiriman_users_tb';
    protected $primarykey = 'id';
    protected $allowedFields = ['id', 'user_id', 'provinsi_id', 'kabupaten_id', 'kecamatan_id', 'detail_alamat', 'kode_pos', 'label_alamat', 'nama_penerima', 'nohp_penerima', 'is_utama', 'is_penjual', 'created_at', 'updated_at'];
}
