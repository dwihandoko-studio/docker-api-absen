<?php

namespace App\Models;

use CodeIgniter\Model;

class SliderhomeModel extends Model
{
    protected $table = '_slider_tb_b';
    protected $primarykey = 'id';
    protected $secondarykey = 'url';
    protected $allowedFields = ['slider_title', 'slider_description', 'slider_url', 'slider_featured_image', 'slider_is_active', 'slider_created_at', 'slider_updated_at'];
}
