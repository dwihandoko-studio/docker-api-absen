<?php

namespace App\Models;

use CodeIgniter\Model;

class BeritapublicModel extends Model
{
    protected $table = 'berita_public';
    protected $primarykey = 'id';
    protected $secondarykey = 'url';
    protected $allowedFields = ['opd_id', 'title', 'description', 'url', 'tags', 'image', 'active', 'created_at', 'updated_at', 'firsname', 'lastname', 'opd', 'nama_opd'];
}
