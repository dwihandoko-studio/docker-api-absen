<?php

namespace App\Models;

use CodeIgniter\Model;

class UserEmailModel extends Model
{
    protected $table = '_users_registrasi_token';
    protected $primarykey = 'id';
    protected $allowedFields = ['token', 'email', 'expired'];

    protected $beforeInsert = ['beforeInsert'];
    protected $beforeUpdate = ['beforeUpdate'];

    protected function beforeInsert(array $data)
    {
        $data = $this->tokenHash($data);
        return $data;
    }

    protected function beforeUpdate(array $data)
    {
        $data = $this->tokenHash($data);
        return $data;
    }

    protected function tokenHash(array $data)
    {
        if (isset($data['data']['token']))
            $data['data']['token'] = md5($data['data']['token']);

        return $data;
    }
}
