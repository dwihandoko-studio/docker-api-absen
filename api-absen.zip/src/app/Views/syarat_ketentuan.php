<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Welcome to CodeIgniter 4!</title>
    <meta name="description" content="The small framework with powerful features">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="/favicon.ico" />

    <!-- STYLES -->

    <style {csp-style-nonce}>
        * {
            transition: background-color 300ms ease, color 300ms ease;
        }

        *:focus {
            background-color: rgba(221, 72, 20, .2);
            outline: none;
        }

        html,
        body {
            color: rgba(33, 37, 41, 1);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji";
            font-size: 16px;
            margin: 0;
            padding: 0;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            text-rendering: optimizeLegibility;
        }

        header {
            background-color: rgba(247, 248, 249, 1);
            padding: .4rem 0 0;
        }

        .menu {
            padding: .4rem 2rem;
        }

        header ul {
            border-bottom: 1px solid rgba(242, 242, 242, 1);
            list-style-type: none;
            margin: 0;
            overflow: hidden;
            padding: 0;
            text-align: right;
        }

        header li {
            display: inline-block;
        }

        header li a {
            border-radius: 5px;
            color: rgba(0, 0, 0, .5);
            display: block;
            height: 44px;
            text-decoration: none;
        }

        header li.menu-item a {
            border-radius: 5px;
            margin: 5px 0;
            height: 38px;
            line-height: 36px;
            padding: .4rem .65rem;
            text-align: center;
        }

        header li.menu-item a:hover,
        header li.menu-item a:focus {
            background-color: rgba(221, 72, 20, .2);
            color: rgba(221, 72, 20, 1);
        }

        header .logo {
            float: left;
            height: 44px;
            padding: .4rem .5rem;
        }

        header .menu-toggle {
            display: none;
            float: right;
            font-size: 2rem;
            font-weight: bold;
        }

        header .menu-toggle button {
            background-color: rgba(221, 72, 20, .6);
            border: none;
            border-radius: 3px;
            color: rgba(255, 255, 255, 1);
            cursor: pointer;
            font: inherit;
            font-size: 1.3rem;
            height: 36px;
            padding: 0;
            margin: 11px 0;
            overflow: visible;
            width: 40px;
        }

        header .menu-toggle button:hover,
        header .menu-toggle button:focus {
            background-color: rgba(221, 72, 20, .8);
            color: rgba(255, 255, 255, .8);
        }

        header .heroe {
            margin: 0 auto;
            max-width: 1100px;
            padding: 1rem 1.75rem 1.75rem 1.75rem;
        }

        header .heroe h1 {
            font-size: 2.5rem;
            font-weight: 500;
        }

        header .heroe h2 {
            font-size: 1.5rem;
            font-weight: 300;
        }

        section {
            margin: 0 auto;
            max-width: 1100px;
            padding: 2.5rem 1.75rem 3.5rem 1.75rem;
        }

        section h1 {
            margin-bottom: 2.5rem;
        }

        section h2 {
            font-size: 120%;
            line-height: 2.5rem;
            padding-top: 1.5rem;
        }

        section pre {
            background-color: rgba(247, 248, 249, 1);
            border: 1px solid rgba(242, 242, 242, 1);
            display: block;
            font-size: .9rem;
            margin: 2rem 0;
            padding: 1rem 1.5rem;
            white-space: pre-wrap;
            word-break: break-all;
        }

        section code {
            display: block;
        }

        section a {
            color: rgba(221, 72, 20, 1);
        }

        section svg {
            margin-bottom: -5px;
            margin-right: 5px;
            width: 25px;
        }

        .further {
            background-color: rgba(247, 248, 249, 1);
            border-bottom: 1px solid rgba(242, 242, 242, 1);
            border-top: 1px solid rgba(242, 242, 242, 1);
        }

        .further h2:first-of-type {
            padding-top: 0;
        }

        footer {
            background-color: rgba(221, 72, 20, .8);
            text-align: center;
        }

        footer .environment {
            color: rgba(255, 255, 255, 1);
            padding: 2rem 1.75rem;
        }

        footer .copyrights {
            background-color: rgba(62, 62, 62, 1);
            color: rgba(200, 200, 200, 1);
            padding: .25rem 1.75rem;
        }

        @media (max-width: 559px) {
            header ul {
                padding: 0;
            }

            header .menu-toggle {
                padding: 0 1rem;
            }

            header .menu-item {
                background-color: rgba(244, 245, 246, 1);
                border-top: 1px solid rgba(242, 242, 242, 1);
                margin: 0 15px;
                width: calc(100% - 30px);
            }

            header .menu-toggle {
                display: block;
            }

            header .hidden {
                display: none;
            }

            header li.menu-item a {
                background-color: rgba(221, 72, 20, .1);
            }

            header li.menu-item a:hover,
            header li.menu-item a:focus {
                background-color: rgba(221, 72, 20, .7);
                color: rgba(255, 255, 255, .8);
            }
        }
    </style>
</head>

<body>

    <!-- HEADER: MENU + HEROE SECTION -->
    <header>

        <div class="menu">
            <ul>
                <li class="logo"><a href="https://kolingcrafted.com" target="_blank"><img height="44" title="KolingCrafted" alt="" src="https://kolingcrafted.com/logo.png"></a>
                </li>
                <li class="menu-toggle">
                    <button onclick="toggleMenu();">&#9776;</button>
                </li>
                <li class="menu-item hidden"><a href="https://kolingcrafted.com">Home</a></li>
                <li class="menu-item hidden"><a href="https://kolingcrafted.com/syaratketentuan">Syarat & Ketentuan</a></li>
                <li class="menu-item hidden"><a href="https://kolingcrafted.com/disclaimer">Disclaimer</a></li>
            </ul>
        </div>

    </header>

    <!-- CONTENT -->

    <section>

        <h1>Syarat &amp; Ketentuan</h1>

        <p>KolingCrafted (&quot;Kami&quot;) berupaya menghargai dan melindungi hak pribadi Anda sebagai pengguna situs kami.</p>

        <p>Kebijakan ini, termasuk Syarat-syarat Penggunaan, dan dokumen lain yang mengacu padanya menetapkan aturan dasar terkait bagaimana data pribadi yang Anda sediakan untuk kami, ataupun data yang kami kumpulkan dari Anda untuk kami proses. Bacalah keterangan berikut dengan saksama untuk memahami bagaimana kami memperlakukan informasi tersebut.</p>

        <p>Informasi yang dapat kami kumpulkan dari Anda.</p>

        <p>Kami berhak menarik dan mengolah data berikut tentang Anda :</p>

        <p>Informasi yang Anda berikan dari pengisian formulir di situs ini [daftar]. Kami juga berhak meminta informasi Anda pada kesempatan lain, misalnya saatAnda mengikuti promosi yang disponsori oleh arenatani, atau ketika Anda melaporkan masalah kepada kami.<br />
            Kami berhak menyimpan catatan atau rekaman korespondensi saat Anda menghubungi kami.<br />
            Untuk tujuan penelitian, kami berhak meminta Anda mengisi jajak pendapat (survey) meskipun Anda tidak harus menanggapinya.<br />
            Segala keterangan tentang penawaran atau transaksi dan juga pemenuhan pesanan Anda yang Anda lakukan melalui situs ini.<br />
            Segala keterangan tentang kunjungan Anda ke situs ini dan sumber yang Anda akses.<br />
            Alamat IP (Internet Protocol) dan Cookies</p>

        <p>Kami berhak mengumpulkan informasi tentang komputer Anda termasuk&mdash;jikatersedi&mdash;alamatIP, sistem operasi dan jenis browser demi keperluan administrasi sistem dan memberikan informasi kepada pengiklan kami. Data ini merupapakdata statistik tentang kerja dan pola browser pengguna, dan tidak bertujuan untuk mengidentifikasi individu manapun.</p>

        <p>Dengan alasan yang sama, kami juga berhak mengumpulkan informasi terkait penggunaan internet Anda secara umum melalui cookies yang tersimpan di hard drive komputer Anda. Cookies membantu kami untuk meningkatkan kinerja situs dan memberikan layanan terbaik untukpengguna situs kami, termasuk Anda. Dengan cookies, kami dapat :</p>

        <p>Memprediksi ukuran dan pola penggunaan pengunjung atau anggota layanan kami.<br />
            Menyimpan preferensi Anda dan menyesuaikan situs kami dengan minat dan kepentingan Anda.<br />
            Mempercepat pencarian.<br />
            Mengenali Anda pada kunjungan ke situs kami pada waktu lain.<br />
            Anda dapat menonaktifkan cookies dengan mengaturnya di setting browser Anda. Jika memilih opsi ini, beberapa bagian dari situs ini mungkin tidak bisa Anda akses. Sistem kami kemudian akan mengeluarkan cookies ketika Anda login ke situs kami.</p>

        <p>Penggunaan Informasi</p>

        <p>Informasi yang kami miliki tentang Anda akan kami gunakan dengan cara dan tujuan berikut :</p>

        <p>Memastikan bahwa isi situs kami tersaji dengan efektif bagi Anda dan komputer Anda.<br />
            Menghadirkan informasi produk atau layanan yang Anda minta dari kami atau yang kami anggap penting untuk Anda, dengan pertimbangan bahwa Anda telah menyetujui untuk kami hubungi terkait tujuan tersebut.<br />
            Melaksanakan kewajiban kami yang timbul sebagai akibat dari kontrak yang tercipta di antara Anda dengan kami.<br />
            Memungkinkan Anda mengikuti fitur interaktif layanan kami, sewaktu Anda mengkliknya/memilihnya.<br />
            Menginformasikan kepadaAnda tentang adanya perubahan dalam layanan kami.<br />
            Mengizinkan pihak ketiga yang terpilih untuk menggunakan data Anda dalam memberikan informasi terkait barang atau jasa yang Anda minati. Dalam hal ini, kami atau mereka dapat menghubungi Anda lewat pos atau telepon.<br />
            Pengungkapan informasi Anda</p>

        <p>Kami berhak mengungkap informasi pribadi Anda pada Pihak Ketiga jika :</p>

        <p>Kami membeli atau menjual bisnis atau aset, dan dalam hal ini kami berhak mengungkap data pribadi Anda kepada calon pembeli atau penjual dari bisnis atau aset tersebut.<br />
            arenatani. secara substansial atau keseluruhan diakuisisi asetnya oleh pihak ketiga; dalam hal ini, data pribadi yang dimiliki arenatani tentang pelanggan juga menjadi salah satu aset yang dialihkan.<br />
            Kami berkewajiban mengungkap atau membagi data pribadi Anda dalam upaya mematuhi kewajiban hukum atau dalam upaya memberlakukan ketentuan dalam Syarat-syarat Penggunaan (link here) dan perjanjian lain. Poin ini juga berlaku demi melindungi keselamatan, hak dan properti arenatani, pelanggan kami, atau pihak lain. Hal ini juga mencakup pertukaran informasi dengan perusahaan atau organisasi lain demi mencegah dan melindungi dari risiko penipuan dan pengurangan risiko kredit.<br />
            Hak Anda</p>

        <p>Anda berhak meminta kami untuk tidak mengolah data pribadi Anda untuk tujuan pemasaran. Kami akan menginformasikan kepadaAnda sebelum mengumpulkan data Anda jika hendak menggunakan data tersebut, atau jika bermaksud mengungkap data Anda kepada pihak ketiga demi tujuan itu.</p>

        <p>Situs kami juga berisi tautan (link) ke dan dari situs lain dan sumber lain yang disediakan oleh pihak ketiga. Jika Anda mengikuti link ke salah satusitus tersebut (atau situs manapun yang Anda klik), periksalah syarat-syarat penggunaan dan poin-poin dalamprivacy policy mereka yang mungkin berbeda dari syarat dan kebijakan kami, sebelum Anda menyerahkan data pribadi Anda. Kami tidak menanggung kewajiban apapun atau memegang tanggung jawab atas syarat dan kebijakan yang terdapat dalam link tersebut.</p>

        <p>Perubahan atas Kebijakan hak-pribadi/Privacy Policy Kami</p>

        <p>Jika di kemudian hari kami melakukan perubahan atas kebijakan hak pribadi kami, perubahan tersebut akan kami tempatkan di halaman ini. Berdasarkan pertimbangan yang tepat, kami mungkin juga akan menginformasikan perubahan tersebut kepada Anda via e-mail.</p>

        <p>Pihak yang dapat Dihubungi</p>

        <p>Kami menyambut baik pertanyaan, permintaan dan komentar Anda tentang kebijakan hak pribadi ini. Anda bisa menghubungi kami via e-mail di admin@kolingcrafted.com.</p>

    </section>

    <!-- FOOTER: DEBUG INFO + COPYRIGHTS -->

    <footer>

        <div class="copyrights">

            <p>&copy; <?= date('Y') ?> Kolingcrafted.com, supported by: Mecca Solution.</p>

        </div>

    </footer>

    <!-- SCRIPTS -->

    <script>
        function toggleMenu() {
            var menuItems = document.getElementsByClassName('menu-item');
            for (var i = 0; i < menuItems.length; i++) {
                var menuItem = menuItems[i];
                menuItem.classList.toggle("hidden");
            }
        }
    </script>

    <!-- -->

</body>

</html>