
<?php if (isset($absensi)) : ?>
<div id="print_rekap_data_absensi_pegawai">
    <div class="col-md-12" style="margin-bottom: 20px;">
        <div class="center">REKAP ABSEN PEGAWAI</div>
        <div class="row">
            <table>
                <tbody style="color:black;">
                    <tr>
                        <td width="10%">Nama</td>
                        <td width="5%" align="center">:</td>
                        <td width="30%"><?= $data_pegawais->nama; ?></td>
                        <td width="28%"></td>
                        <td width="11%" align="center"></td>
                        <td width="5%" align="center"></td>
                        <td width="11%" align="center"></td>

                    </tr>
                    <tr>
                        <td width="10%">NIP / NIK</td>
                        <td width="5%" align="center">:</td>
                        <td width="30%"><?= $data_pegawais->nip_sapk; ?></td>
                        <td width="28%"></td>
                        <td width="11%" align="center"></td>
                        <td width="5%" align="center"></td>
                        <td width="11%" align="center"></td>
                    </tr>
                    <tr>
                        <td width="10%">Instansi</td>
                        <td width="5%" align="center">:</td>
                        <td width="30%"><?= $data_pegawais->instansi . ' - ' . $data_pegawais->provinsi; ?></td>
                        <td width="28%" align="right"> Tanggal &nbsp;&nbsp;:&nbsp;&nbsp;</td>
                        <td width="11%" align="center"><?= date('d M Y', strtotime($tgl_awal_pilih)); ?></td>
                        <td width="5%" align="center">-</td>
                        <td width="11%" align="center"><?= date('d M Y', strtotime($tgl_akhir_pilih)); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th class="text-center" style="color: black; padding-top:2px;padding-bottom:2px;">No</th>
                <th class="text-center" width="15%" style="color: black;padding-top:2px;padding-bottom:2px;">Tanggal</th>
                <th class="text-center" style="color: black;padding-top:2px;padding-bottom:2px;">Hari</th>
                <th class="text-center" style="color: black;padding-top:2px;padding-bottom:2px;">Absen Datang</th>
                <th class="text-center" style="color: black;padding-top:2px;padding-bottom:2px;">Terlambat</th>
                <th class="text-center" style="color: black;padding-top:2px;padding-bottom:2px;">Absen Siang</th>
                <th class="text-center" style="color: black;padding-top:2px;padding-bottom:2px;">Absen Pulang</th>
                <th class="text-center" style="color: black;padding-top:2px;padding-bottom:2px;">Pulang Cepat</th>
                <th class="text-center" width="30%" style="color: black;padding-top:2px;padding-bottom:2px;">Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; ?>

            <?php foreach ($tanggalBulan as $tanggal) : ?>
                <tr>
                    <td style="color: black;padding-top:2px;padding-bottom:2px;" align="center"><?= $no; ?></td>
                    <td style="color: black;padding-top:2px;padding-bottom:2px;" align="center"><?= date('d-m-Y', strtotime($tanggal)); ?></td>

                    <?php $day = explode('-', $tanggal);
                    $day = $day[2] . "-" . $day[1] . "-" . $day[0];
                    $day = date('D', strtotime($day));

                    $dayList = array(
                        'Sun' => 'Minggu',
                        'Mon' => 'Senin',
                        'Tue' => 'Selasa',
                        'Wed' => 'Rabu',
                        'Thu' => 'Kamis',
                        'Fri' => 'Jum&#039;at',
                        'Sat' => 'Sabtu'
                    ); ?>
                    <td style="color: black;padding-top:2px;padding-bottom:2px;"><?= $dayList[$day]; ?></td>

                    <?php if (($dayList[$day] == 'Sabtu') || ($dayList[$day] == 'Minggu')) : ?>
                    <td colspan="6" align="center" bgcolor="black" style="color: white;padding-top:2px;padding-bottom:2px;">Libur Weekend</td>
                    <?php else :
                    ?>
                        <?php if ($hariLibur) : ?>
                            <?php foreach ($hariLibur as $lib) :
                                $libKeterangan = $lib['keterangan'];
                                if ($lib['libur'] == $tanggal) : ?>
                                    <td colspan="6" align="center" bgcolor="black" style="color: white;padding-top:2px;padding-bottom:2px;"><?= $libKeterangan; ?></td>
                                <?php else : ?>
                                    <?php

                                    if ($absensi) :
                                        $tanggalDiArray = array_column($absensi, 'tanggal');
                                        if ((array_search($tanggal, $tanggalDiArray) !== FALSE) && ($tanggalDiArray)) {
                                            $anInArray = 1;
                                        } else {
                                            $anInArray = 0;
                                        }
                                        if ($anInArray == 0) :
                                            $table_masuk = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                        <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                            $table_siang = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                            $table_pulang = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                                <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                            $table_keterangan = '<td bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">-</td>';
                                            echo $table_masuk;
                                            echo $table_siang;
                                            echo $table_pulang;
                                            echo $table_keterangan;
                                        else :
                                            $keyAbsen =  search($absensi, 'tanggal', $tanggal);
                                            foreach ($keyAbsen as $key => $value) { ?>

                                                <?php if ($value['jenis_alat_absen'] == 1) : ?>
                                                    <?php if (!in_array($value['tanggal'], $tanggalapel)) : ?>
                                                        <?php if ((date('N', strtotime($value['tanggal'])) != 5)) :
                                                            $lower_telatdtg = $awal_telatdtg;
                                                            $upper_telatdtg = $akhir_telatdtg;
                                                            $batas_jamdtg = $jam_jamdtg;
                                                            $lower_plgcepat = $awal_plgcepat;
                                                            $upper_plgcepat = $akhir_plgcepat;
                                                            $batas_jamplg = $akhir_jamplg;
                                                            $lower_siang = $jamSiangAwal;
                                                            $upper_siang = $jamSiangAkhir;
                                                            if (in_array($value['tanggal'], $ramadhanformatslash)) {
                                                                $lower_plgcepat = $jamPulangRamadhanAwal;
                                                                $upper_plgcepat = $jamPulangRamadhan;
                                                                $batas_jamplg = $jamPulangRamadhanAkhir;
                                                            }

                                                            $rawjamdtg = $value['jam_datang'];
                                                            $jamdtg = str_replace(':', '', $rawjamdtg);
                                                            $rawjamsiang = $value['jam_siang'];
                                                            $jamsiang = str_replace(':', '', $rawjamsiang);
                                                            $rawjamplg = $value['jam_pulang'];
                                                            $jamplg = str_replace(':', '', $rawjamplg);

                                                            if ($value['jam_datang'] == null) {
                                                                if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                                    $finalJamDatang = 0;
                                                                    $finalTelat = 0;
                                                                } else {
                                                                    $finalJamDatang = 1;
                                                                    $finalTelat = 0;
                                                                }
                                                            } else {
                                                                if ($jamdtg >= $batas_jamdtg && $jamdtg < $upper_telatdtg) {
                                                                    if ($jamdtg >= $batas_jamdtg && $jamdtg < $lower_telatdtg) {
                                                                        $finalJamDatang = $rawjamdtg;
                                                                        $finalTelat = 0;
                                                                    } else {
                                                                        if (!in_array($value['tanggal'], $tanggalintervensitelat)) {
                                                                            $finalJamDatang = $rawjamdtg;
                                                                            $finalTelat = 2;
                                                                        } else {
                                                                            $finalJamDatang = $rawjamdtg;
                                                                            $finalTelat = 1;
                                                                        }
                                                                    }
                                                                } else {
                                                                    if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                                        $finalJamDatang = 0;
                                                                        $finalTelat = 0;
                                                                    } else {
                                                                        $finalJamDatang = 1;
                                                                        $finalTelat = 0;
                                                                    }
                                                                }
                                                            }

                                                            if ($finalJamDatang == 0) {
                                                                $table_masuk = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                                            <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                                            } else if ($finalJamDatang == 1) {
                                                                $table_masuk = '<td align="center" bgcolor="yellow" colspan= "2" style="color: black;padding-top:2px;padding-bottom:2px;">Izin</td>';
                                                            } else {
                                                                if ($finalTelat == 0) {
                                                                    $table_masuk = '<td align="center" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamDatang . '</td>
                                                                <td align="center" style="color: black;padding-top:2px;padding-bottom:2px;"></td>';
                                                                    // } else if ($finalTelat == 1) {
                                                                    //     $table_masuk = '<td align="center">' . $finalJamDatang . '</td>
                                                                    //                         <td align="center">Izin Telat</td>';
                                                                } else {
                                                                    if ($finalTelat == 1) {
                                                                        $table_masuk = '<td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamDatang . '</td>
                                                                <td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">Izin Telat</td>';
                                                                    } else {
                                                                        $helpTelat = help_telat($value['jam_datang'], $setMasuk);
                                                                        $table_masuk = '<td align="center" bgcolor="orange" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamDatang . '</td>
                                                                <td align="center" bgcolor="orange" style="color: black;padding-top:2px;padding-bottom:2px;">' . $helpTelat . '</td>';
                                                                    }
                                                                }
                                                            }

                                                            if ($value['jam_siang'] == null) {
                                                                if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                                    $finalJamSiang = 0;
                                                                } else {
                                                                    $finalJamSiang = 1;
                                                                }
                                                            } else {
                                                                if ($jamsiang >= $lower_siang && $jamsiang < $upper_siang) {
                                                                    $finalJamSiang = $rawjamdtg;
                                                                } else {
                                                                    if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                                        $finalJamSiang = 0;
                                                                    } else {
                                                                        $finalJamSiang = 1;
                                                                    }
                                                                }
                                                            }

                                                            if ($finalJamSiang == 0) {
                                                                $table_siang = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                                            } else if ($finalJamSiang == 1) {
                                                                $table_siang = '<td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">Izin</td>';
                                                            } else {
                                                                $table_siang = '<td align="center" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamSiang . '</td>';
                                                            }

                                                            if ($value['jam_pulang'] == null) {
                                                                if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                                    $finalJamPulang = 0;
                                                                } else {
                                                                    $finalJamPulang = 1;
                                                                }
                                                            } else {
                                                                if ($jamplg <= $batas_jamplg && $jamplg > $lower_plgcepat) {
                                                                    if ($jamplg <= $batas_jamplg && $jamplg > $upper_plgcepat) {
                                                                        $finalJamPulang = $rawjamplg;
                                                                        $finalPulCep = 0;
                                                                    } else {
                                                                        if (!in_array($value['tanggal'], $tanggalintervensipulcep)) {
                                                                            $finalJamPulang = $rawjamplg;
                                                                            $finalPulCep = 2;
                                                                        } else {
                                                                            $finalJamPulang = $rawjamplg;
                                                                            $finalPulCep = 1;
                                                                        }
                                                                    }
                                                                } else {
                                                                    if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                                        $finalJamPulang = 0;
                                                                    } else {
                                                                        $finalJamPulang = 1;
                                                                    }
                                                                }
                                                            }

                                                            if ($finalJamPulang == 0) {
                                                                $table_pulang = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                                            <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                                            } else if ($finalJamPulang == 1) {
                                                                $table_pulang = '<td align="center" bgcolor="yellow" colspan= "2" style="color: black;padding-top:2px;padding-bottom:2px;">Izin</td>';
                                                            } else {
                                                                if ($finalPulCep == 0) {
                                                                    $table_pulang = '<td align="center" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamPulang . '</td>
                                                                <td align="center" style="padding-top:2px;padding-bottom:2px;"></td>';
                                                                    // } else if ($finalPulCep == 1) {
                                                                    //     $table_pulang = '<td align="center">' . $finalJamPulang . '</td>
                                                                    //                         <td align="center">Izin Pulcep</td>';
                                                                } else {
                                                                    if ($finalPulCep == 1) {
                                                                        $table_pulang = '<td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamPulang . '</td>
                                                                <td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">Izin Pulcep</td>';
                                                                    } else {
                                                                        $helpPulcep = help_pulang_cepat($value['jam_pulang'], $setPulang);
                                                                        $table_pulang = '<td align="center" bgcolor="orange" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamPulang . '</td>
                                                                <td align="center" bgcolor="orange" style="color: black;padding-top:2px;padding-bottom:2px;">' . $helpPulcep . '</td>';
                                                                    }
                                                                }
                                                            }
                                                            $table_keterangan = '<td style="color: black;padding-top:2px;padding-bottom:2px;">-</td>';
                                                        ?>


                                                        <?php else : ?>
                                                            <?php
                                                            $lower_telatdtg = $jamMasukJumat;
                                                            $upper_telatdtg = $jamMasukJumatAkhir;
                                                            $batas_jamdtg = $jamMasukJumatAwal;
                                                            $lower_plgcepat = $jamPulangJumatAwal;
                                                            $upper_plgcepat = $jamPulangJumat;
                                                            $batas_jamplg = $jamPulangJumatAkhir;
                                                            $lower_siang = $jamSiangAwal;
                                                            $upper_siang = $jamSiangAkhir;
                                                            if (in_array($value['tanggal'], $ramadhanformatslash)) {
                                                                $lower_plgcepat = $jamPulangJumatRamadhanAwal;
                                                                $upper_plgcepat = $jamPulangJumatRamadhan;
                                                                $batas_jamplg = $jamPulangJumatRamadhanAkhir;
                                                            }

                                                            $rawjamdtg = $value['jam_datang'];
                                                            $jamdtg = str_replace(':', '', $rawjamdtg);
                                                            $rawjamsiang = $value['jam_siang'];
                                                            $jamsiang = str_replace(':', '', $rawjamsiang);
                                                            $rawjamplg = $value['jam_pulang'];
                                                            $jamplg = str_replace(':', '', $rawjamplg);

                                                            if ($value['jam_datang'] == null) {
                                                                if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                                    $finalJamDatang = 0;
                                                                } else {
                                                                    $finalJamDatang = 1;
                                                                }
                                                            } else {
                                                                if ($jamdtg >= $batas_jamdtg && $jamdtg < $upper_telatdtg) {
                                                                    if ($jamdtg >= $batas_jamdtg && $jamdtg < $lower_telatdtg) {
                                                                        $finalJamDatang = $rawjamdtg;
                                                                        $finalTelat = 0;
                                                                    } else {
                                                                        if (!in_array($value['tanggal'], $tanggalintervensitelat)) {
                                                                            $finalJamDatang = $rawjamdtg;
                                                                            $finalTelat = 2;
                                                                        } else {
                                                                            $finalJamDatang = $rawjamdtg;
                                                                            $finalTelat = 1;
                                                                        }
                                                                    }
                                                                } else {
                                                                    if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                                        $finalJamDatang = 0;
                                                                        $finalTelat = 0;
                                                                    } else {
                                                                        $finalJamDatang = 1;
                                                                        $finalTelat = 0;
                                                                    }
                                                                }
                                                            }

                                                            if ($value['jam_siang'] == null) {
                                                                if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                                    $finalJamSiang = 0;
                                                                } else {
                                                                    $finalJamSiang = 1;
                                                                }
                                                            } else {
                                                                if ($jamsiang >= $lower_siang && $jamsiang < $upper_siang) {
                                                                    $finalJamSiang = $rawjamdtg;
                                                                } else {
                                                                    if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                                        $finalJamSiang = 0;
                                                                    } else {
                                                                        $finalJamSiang = 1;
                                                                    }
                                                                }
                                                            }

                                                            if ($value['jam_pulang'] == null) {
                                                                if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                                    $finalJamPulang = 0;
                                                                } else {
                                                                    $finalJamPulang = 1;
                                                                }
                                                            } else {
                                                                if ($jamplg <= $batas_jamplg && $jamplg > $lower_plgcepat) {
                                                                    if ($jamplg <= $batas_jamplg && $jamplg > $upper_plgcepat) {
                                                                        $finalJamPulang = $rawjamplg;
                                                                        $finalPulCep = 0;
                                                                    } else {
                                                                        if (!in_array($value['tanggal'], $tanggalintervensipulcep)) {
                                                                            $finalJamPulang = $rawjamplg;
                                                                            $finalPulCep = 2;
                                                                        } else {
                                                                            $finalJamPulang = $rawjamplg;
                                                                            $finalPulCep = 1;
                                                                        }
                                                                    }
                                                                } else {
                                                                    if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                                        $finalJamPulang = 0;
                                                                    } else {
                                                                        $finalJamPulang = 1;
                                                                    }
                                                                }
                                                            } ?>
                                                            <?php if ($finalJamDatang == 0) {
                                                                $table_masuk = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                                            <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                                            } else if ($finalJamDatang == 1) {
                                                                $table_masuk = '<td align="center" bgcolor="yellow" colspan= "2" style="color: black;padding-top:2px;padding-bottom:2px;">Izin</td>';
                                                            } else {
                                                                if ($finalTelat == 0) {
                                                                    $table_masuk = '<td align="center" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamDatang . '</td>
                                                                <td align="center" style="color: black;padding-top:2px;padding-bottom:2px;"></td>';
                                                                } else if ($finalTelat == 1) {
                                                                    $table_masuk = '<td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamDatang . '</td>
                                                                <td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">Izin Telat</td>';
                                                                } else {
                                                                    $helpTelat = help_telat($value['jam_datang'], $setMasuk);
                                                                    $table_masuk = '<td align="center" bgcolor="orange" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamDatang . '</td>
                                                                <td align="center" bgcolor="orange" style="color: black;padding-top:2px;padding-bottom:2px;">' . $helpTelat . '</td>';
                                                                }
                                                            } ?>

                                                            <?php if ($finalJamSiang == 0) {
                                                                $table_siang = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                                            } else if ($finalJamSiang == 1) {
                                                                $table_siang = '<td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">Izin</td>';
                                                            } else {
                                                                $table_siang = '<td align="center" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamSiang . '</td>';
                                                            } ?>

                                                            <?php if ($finalJamPulang == 0) {
                                                                $table_pulang = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                                            <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                                            } else if ($finalJamPulang == 1) {
                                                                $table_pulang = '<td align="center" bgcolor="yellow" colspan= "2" style="color: black;padding-top:2px;padding-bottom:2px;">Izin</td>';
                                                            } else {
                                                                if ($finalPulCep == 0) {
                                                                    $table_pulang = '<td align="center" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamPulang . '</td>
                                                                <td align="center" style="color: black;padding-top:2px;padding-bottom:2px;"></td>';
                                                                } else if ($finalPulCep == 1) {
                                                                    $table_pulang = '<td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamPulang . '</td>
                                                                <td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">Izin Pulcep</td>';
                                                                } else {
                                                                    $helpPulcep = help_pulang_cepat($value['jam_pulang'], $setPulang);
                                                                    $table_pulang = '<td align="center" bgcolor="orange" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamPulang . '</td>
                                                                <td align="center" bgcolor="orange" style="color: black;padding-top:2px;padding-bottom:2px;">' . $helpPulcep . '</td>';
                                                                }
                                                            }
                                                            $table_keterangan = '<td style="color: black;padding-top:2px;padding-bottom:2px;">-</td>';
                                                            ?>

                                                        <?php endif; ?>
                                                    <?php else : ?>
                                                    <?php endif; ?>
                                                <?php elseif ($value['jenis_alat_absen'] == 2) : ?>

                                                    <?php
                                                    if ($value['jam_datang'] != null) {
                                                        $jam_masuk = $value['jam_datang'];
                                                        $selMasuk = '<td align="center"colspan="2" bgcolor="green" style="color: black;padding-top:2px;padding-bottom:2px;">' . $jam_masuk . '</td>';
                                                    } else {
                                                        $selMasuk = '<td align="center" bgcolor="red" colspan="2" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                                    }
                                                    $table_masuk = $selMasuk;

                                                    if ($value['jam_siang'] != null) {
                                                        $jam_masuk_siang = $value['jam_siang'];
                                                        $selSiang = '<td align="center" bgcolor="green" style="color: black;padding-top:2px;padding-bottom:2px;">' . $jam_masuk_siang . '</td>';
                                                    } else {
                                                        $selSiang = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                                    }
                                                    $table_siang = $selSiang;

                                                    if ($value['jam_pulang'] != null) {
                                                        $jam_masuk_pulang = $value['jam_pulang'];
                                                        $selPulang = '<td align="center"colspan="2" bgcolor="green" style="color: black;padding-top:2px;padding-bottom:2px;">' . $jam_masuk_pulang . '</td>';
                                                    } else {
                                                        $selPulang = '<td align="center" bgcolor="red" colspan="2" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                                    }
                                                    $table_pulang = $selPulang;
                                                    $table_keterangan = '<td style="color: black;padding-top:2px;padding-bottom:2px;" bgcolor="green">Sedang dinas luar</td>';
                                                    ?>
                                                <?php endif; ?>
                                                <?php
                                                echo $table_masuk;
                                                echo $table_siang;
                                                echo $table_pulang;
                                                echo $table_keterangan;

                                                ?>
                                    <?php }
                                        endif;
                                    else :
                                        $table_masuk = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                        <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                        <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                        <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                        <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                        <td bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">-</td>';
                                        echo $table_masuk;
                                    endif;
                                    ?>
                                <?php endif; ?>
                                <?php endforeach;
                        else :
                            if ($absensi) :
                                $tanggalDiArray = array_column($absensi, 'tanggal');
                                if ((array_search($tanggal, $tanggalDiArray) !== FALSE) && ($tanggalDiArray)) {
                                    $anInArray = 1;
                                } else {
                                    $anInArray = 0;
                                }
                                // var_dump($absensi);
                                if ($anInArray == 0) :
                                    $table_masuk = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                        <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                    $table_siang = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                    $table_pulang = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                                <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                    $table_keterangan = '<td bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">-</td>';
                                    echo $table_masuk;
                                    echo $table_siang;
                                    echo $table_pulang;
                                    echo $table_keterangan;
                                else :
                                    $keyAbsen =  search($absensi, 'tanggal', $tanggal);
                                    foreach ($keyAbsen as $key => $value) { ?>

                                        <?php if ($value['jenis_alat_absen'] == 1) : ?>
                                            <?php if (!in_array($value['tanggal'], $tanggalapel)) : ?>
                                                <?php if ((date('N', strtotime($value['tanggal'])) != 5)) :
                                                    $lower_telatdtg = $awal_telatdtg;
                                                    $upper_telatdtg = $akhir_telatdtg;
                                                    $batas_jamdtg = $jam_jamdtg;
                                                    $lower_plgcepat = $awal_plgcepat;
                                                    $upper_plgcepat = $akhir_plgcepat;
                                                    $batas_jamplg = $akhir_jamplg;
                                                    $lower_siang = $jamSiangAwal;
                                                    $upper_siang = $jamSiangAkhir;
                                                    if (in_array($value['tanggal'], $ramadhanformatslash)) {
                                                        $lower_plgcepat = $jamPulangRamadhanAwal;
                                                        $upper_plgcepat = $jamPulangRamadhan;
                                                        $batas_jamplg = $jamPulangRamadhanAkhir;
                                                    }

                                                    $rawjamdtg = $value['jam_datang'];
                                                    $jamdtg = str_replace(':', '', $rawjamdtg);
                                                    $rawjamsiang = $value['jam_siang'];
                                                    $jamsiang = str_replace(':', '', $rawjamsiang);
                                                    $rawjamplg = $value['jam_pulang'];
                                                    $jamplg = str_replace(':', '', $rawjamplg);

                                                    if ($value['jam_datang'] == null) {
                                                        if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                            $finalJamDatang = 0;
                                                            $finalTelat = 0;
                                                        } else {
                                                            $finalJamDatang = 1;
                                                            $finalTelat = 0;
                                                        }
                                                    } else {
                                                        if ($jamdtg >= $batas_jamdtg && $jamdtg < $upper_telatdtg) {
                                                            if ($jamdtg >= $batas_jamdtg && $jamdtg < $lower_telatdtg) {
                                                                $finalJamDatang = $rawjamdtg;
                                                                $finalTelat = 0;
                                                            } else {
                                                                if (!in_array($value['tanggal'], $tanggalintervensitelat)) {
                                                                    $finalJamDatang = $rawjamdtg;
                                                                    $finalTelat = 2;
                                                                } else {
                                                                    $finalJamDatang = $rawjamdtg;
                                                                    $finalTelat = 1;
                                                                }
                                                            }
                                                        } else {
                                                            if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                                $finalJamDatang = 0;
                                                                $finalTelat = 0;
                                                            } else {
                                                                $finalJamDatang = 1;
                                                                $finalTelat = 0;
                                                            }
                                                        }
                                                    }

                                                    if ($finalJamDatang == 0) {
                                                        $table_masuk = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                                            <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                                    } else if ($finalJamDatang == 1) {
                                                        $table_masuk = '<td align="center" bgcolor="yellow" colspan= "2" style="color: black;padding-top:2px;padding-bottom:2px;">Izin</td>';
                                                    } else {
                                                        if ($finalTelat == 0) {
                                                            $table_masuk = '<td align="center" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamDatang . '</td>
                                                                <td align="center" style="color: black;padding-top:2px;padding-bottom:2px;"></td>';
                                                            // } else if ($finalTelat == 1) {
                                                            //     $table_masuk = '<td align="center">' . $finalJamDatang . '</td>
                                                            //                         <td align="center">Izin Telat</td>';
                                                        } else {
                                                            if ($finalTelat == 1) {
                                                                $table_masuk = '<td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamDatang . '</td>
                                                                <td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">Izin Telat</td>';
                                                            } else {
                                                                $helpTelat = help_telat($value['jam_datang'], $setMasuk);
                                                                $table_masuk = '<td align="center" bgcolor="orange" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamDatang . '</td>
                                                                <td align="center" bgcolor="orange" style="color: black;padding-top:2px;padding-bottom:2px;">' . $helpTelat . '</td>';
                                                            }
                                                        }
                                                    }

                                                    if ($value['jam_siang'] == null) {
                                                        if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                            $finalJamSiang = 0;
                                                        } else {
                                                            $finalJamSiang = 1;
                                                        }
                                                    } else {
                                                        if ($jamsiang >= $lower_siang && $jamsiang < $upper_siang) {
                                                            $finalJamSiang = $rawjamdtg;
                                                        } else {
                                                            if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                                $finalJamSiang = 0;
                                                            } else {
                                                                $finalJamSiang = 1;
                                                            }
                                                        }
                                                    }

                                                    if ($finalJamSiang == 0) {
                                                        $table_siang = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                                    } else if ($finalJamSiang == 1) {
                                                        $table_siang = '<td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">Izin</td>';
                                                    } else {
                                                        $table_siang = '<td align="center" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamSiang . '</td>';
                                                    }

                                                    if ($value['jam_pulang'] == null) {
                                                        if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                            $finalJamPulang = 0;
                                                        } else {
                                                            $finalJamPulang = 1;
                                                        }
                                                    } else {
                                                        if ($jamplg <= $batas_jamplg && $jamplg > $lower_plgcepat) {
                                                            if ($jamplg <= $batas_jamplg && $jamplg > $upper_plgcepat) {
                                                                $finalJamPulang = $rawjamplg;
                                                                $finalPulCep = 0;
                                                            } else {
                                                                if (!in_array($value['tanggal'], $tanggalintervensipulcep)) {
                                                                    $finalJamPulang = $rawjamplg;
                                                                    $finalPulCep = 2;
                                                                } else {
                                                                    $finalJamPulang = $rawjamplg;
                                                                    $finalPulCep = 1;
                                                                }
                                                            }
                                                        } else {
                                                            if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                                $finalJamPulang = 0;
                                                            } else {
                                                                $finalJamPulang = 1;
                                                            }
                                                        }
                                                    }

                                                    if ($finalJamPulang == 0) {
                                                        $table_pulang = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                                            <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                                    } else if ($finalJamPulang == 1) {
                                                        $table_pulang = '<td align="center" bgcolor="yellow" colspan= "2" style="color: black;padding-top:2px;padding-bottom:2px;">Izin</td>';
                                                    } else {
                                                        if ($finalPulCep == 0) {
                                                            $table_pulang = '<td align="center" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamPulang . '</td>
                                                                <td align="center" style="padding-top:2px;padding-bottom:2px;"></td>';
                                                            // } else if ($finalPulCep == 1) {
                                                            //     $table_pulang = '<td align="center">' . $finalJamPulang . '</td>
                                                            //                         <td align="center">Izin Pulcep</td>';
                                                        } else {
                                                            if ($finalPulCep == 1) {
                                                                $table_pulang = '<td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamPulang . '</td>
                                                                <td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">Izin Pulcep</td>';
                                                            } else {
                                                                $helpPulcep = help_pulang_cepat($value['jam_pulang'], $setPulang);
                                                                $table_pulang = '<td align="center" bgcolor="orange" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamPulang . '</td>
                                                                <td align="center" bgcolor="orange" style="color: black;padding-top:2px;padding-bottom:2px;">' . $helpPulcep . '</td>';
                                                            }
                                                        }
                                                    }
                                                    $table_keterangan = '<td style="padding-top:2px;padding-bottom:2px;">-</td>';
                                                ?>


                                                <?php else : ?>
                                                    <?php
                                                    $lower_telatdtg = $jamMasukJumat;
                                                    $upper_telatdtg = $jamMasukJumatAkhir;
                                                    $batas_jamdtg = $jamMasukJumatAwal;
                                                    $lower_plgcepat = $jamPulangJumatAwal;
                                                    $upper_plgcepat = $jamPulangJumat;
                                                    $batas_jamplg = $jamPulangJumatAkhir;
                                                    $lower_siang = $jamSiangAwal;
                                                    $upper_siang = $jamSiangAkhir;
                                                    if (in_array($value['tanggal'], $ramadhanformatslash)) {
                                                        $lower_plgcepat = $jamPulangJumatRamadhanAwal;
                                                        $upper_plgcepat = $jamPulangJumatRamadhan;
                                                        $batas_jamplg = $jamPulangJumatRamadhanAkhir;
                                                    }

                                                    $rawjamdtg = $value['jam_datang'];
                                                    $jamdtg = str_replace(':', '', $rawjamdtg);
                                                    $rawjamsiang = $value['jam_siang'];
                                                    $jamsiang = str_replace(':', '', $rawjamsiang);
                                                    $rawjamplg = $value['jam_pulang'];
                                                    $jamplg = str_replace(':', '', $rawjamplg);

                                                    if ($value['jam_datang'] == null) {
                                                        if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                            $finalJamDatang = 0;
                                                        } else {
                                                            $finalJamDatang = 1;
                                                        }
                                                    } else {
                                                        if ($jamdtg >= $batas_jamdtg && $jamdtg < $upper_telatdtg) {
                                                            if ($jamdtg >= $batas_jamdtg && $jamdtg < $lower_telatdtg) {
                                                                $finalJamDatang = $rawjamdtg;
                                                                $finalTelat = 0;
                                                            } else {
                                                                if (!in_array($value['tanggal'], $tanggalintervensitelat)) {
                                                                    $finalJamDatang = $rawjamdtg;
                                                                    $finalTelat = 2;
                                                                } else {
                                                                    $finalJamDatang = $rawjamdtg;
                                                                    $finalTelat = 1;
                                                                }
                                                            }
                                                        } else {
                                                            if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                                $finalJamDatang = 0;
                                                                $finalTelat = 0;
                                                            } else {
                                                                $finalJamDatang = 1;
                                                                $finalTelat = 0;
                                                            }
                                                        }
                                                    }

                                                    if ($value['jam_siang'] == null) {
                                                        if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                            $finalJamSiang = 0;
                                                        } else {
                                                            $finalJamSiang = 1;
                                                        }
                                                    } else {
                                                        if ($jamsiang >= $lower_siang && $jamsiang < $upper_siang) {
                                                            $finalJamSiang = $rawjamdtg;
                                                        } else {
                                                            if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                                $finalJamSiang = 0;
                                                            } else {
                                                                $finalJamSiang = 1;
                                                            }
                                                        }
                                                    }

                                                    if ($value['jam_pulang'] == null) {
                                                        if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                            $finalJamPulang = 0;
                                                        } else {
                                                            $finalJamPulang = 1;
                                                        }
                                                    } else {
                                                        if ($jamplg <= $batas_jamplg && $jamplg > $lower_plgcepat) {
                                                            if ($jamplg <= $batas_jamplg && $jamplg > $upper_plgcepat) {
                                                                $finalJamPulang = $rawjamplg;
                                                                $finalPulCep = 0;
                                                            } else {
                                                                if (!in_array($value['tanggal'], $tanggalintervensipulcep)) {
                                                                    $finalJamPulang = $rawjamplg;
                                                                    $finalPulCep = 2;
                                                                } else {
                                                                    $finalJamPulang = $rawjamplg;
                                                                    $finalPulCep = 1;
                                                                }
                                                            }
                                                        } else {
                                                            if (!in_array($value['tanggal'], $tanggalintervensibebas)) {
                                                                $finalJamPulang = 0;
                                                            } else {
                                                                $finalJamPulang = 1;
                                                            }
                                                        }
                                                    } ?>
                                                    <?php if ($finalJamDatang == 0) {
                                                        $table_masuk = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                                            <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                                    } else if ($finalJamDatang == 1) {
                                                        $table_masuk = '<td align="center" bgcolor="yellow" colspan= "2" style="color: black;padding-top:2px;padding-bottom:2px;">Izin</td>';
                                                    } else {
                                                        if ($finalTelat == 0) {
                                                            $table_masuk = '<td align="center" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamDatang . '</td>
                                                                <td align="center" style="color: black;padding-top:2px;padding-bottom:2px;"></td>';
                                                        } else if ($finalTelat == 1) {
                                                            $table_masuk = '<td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamDatang . '</td>
                                                                <td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">Izin Telat</td>';
                                                        } else {
                                                            $helpTelat = help_telat($value['jam_datang'], $setMasuk);
                                                            $table_masuk = '<td align="center" bgcolor="orange" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamDatang . '</td>
                                                                <td align="center" bgcolor="orange" style="color: black;padding-top:2px;padding-bottom:2px;">' . $helpTelat . '</td>';
                                                        }
                                                    } ?>

                                                    <?php if ($finalJamSiang == 0) {
                                                        $table_siang = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                                    } else if ($finalJamSiang == 1) {
                                                        $table_siang = '<td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">Izin</td>';
                                                    } else {
                                                        $table_siang = '<td align="center" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamSiang . '</td>';
                                                    } ?>

                                                    <?php if ($finalJamPulang == 0) {
                                                        $table_pulang = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                                            <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                                    } else if ($finalJamPulang == 1) {
                                                        $table_pulang = '<td align="center" bgcolor="yellow" colspan= "2" style="color: black;padding-top:2px;padding-bottom:2px;">Izin</td>';
                                                    } else {
                                                        if ($finalPulCep == 0) {
                                                            $table_pulang = '<td align="center" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamPulang . '</td>
                                                                <td align="center" style="color: black;padding-top:2px;padding-bottom:2px;"></td>';
                                                        } else if ($finalPulCep == 1) {
                                                            $table_pulang = '<td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamPulang . '</td>
                                                                <td align="center" bgcolor="yellow" style="color: black;padding-top:2px;padding-bottom:2px;">Izin Pulcep</td>';
                                                        } else {
                                                            $helpPulcep = help_pulang_cepat($value['jam_pulang'], $setPulang);
                                                            $table_pulang = '<td align="center" bgcolor="orange" style="color: black;padding-top:2px;padding-bottom:2px;">' . $finalJamPulang . '</td>
                                                                <td align="center" bgcolor="orange" style="color: black;padding-top:2px;padding-bottom:2px;">' . $helpPulcep . '</td>';
                                                        }
                                                    }
                                                    $table_keterangan = '<td style="color: black;padding-top:2px;padding-bottom:2px;">-</td>';
                                                    ?>

                                                <?php endif; ?>
                                            <?php else : ?>
                                            <?php endif; ?>
                                        <?php elseif ($value['jenis_alat_absen'] == 2) : ?>

                                            <?php
                                            if ($value['jam_datang'] != null) {
                                                $jam_masuk = $value['jam_datang'];
                                                $selMasuk = '<td align="center"colspan="2" bgcolor="green" style="color: black;padding-top:2px;padding-bottom:2px;">' . $jam_masuk . '</td>';
                                            } else {
                                                $selMasuk = '<td align="center" bgcolor="red" colspan="2" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                            }
                                            $table_masuk = $selMasuk;

                                            if ($value['jam_siang'] != null) {
                                                $jam_masuk_siang = $value['jam_siang'];
                                                $selSiang = '<td align="center" bgcolor="green" style="color: black;padding-top:2px;padding-bottom:2px;">' . $jam_masuk_siang . '</td>';
                                            } else {
                                                $selSiang = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                            }
                                            $table_siang = $selSiang;

                                            if ($value['jam_pulang'] != null) {
                                                $jam_masuk_pulang = $value['jam_pulang'];
                                                $selPulang = '<td align="center"colspan="2" bgcolor="green" style="color: black;padding-top:2px;padding-bottom:2px;">' . $jam_masuk_pulang . '</td>';
                                            } else {
                                                $selPulang = '<td align="center" bgcolor="red" colspan="2" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>';
                                            }
                                            $table_pulang = $selPulang;
                                            $table_keterangan = '<td style="color: black;padding-top:2px;padding-bottom:2px;" bgcolor="green">Sedang dinas luar</td>';
                                            ?>
                                        <?php endif; ?>
                                        <?php
                                        echo $table_masuk;
                                        echo $table_siang;
                                        echo $table_pulang;
                                        echo $table_keterangan;

                                        ?>
                        <?php }
                                endif;
                            else :
                                $table_masuk = '<td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                        <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                        <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                        <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                        <td align="center" bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;">x</td>
                                        <td bgcolor="red" style="color: black;padding-top:2px;padding-bottom:2px;"></td>';
                                echo $table_masuk;
                            endif;
                        endif;
                        ?>
                    <?php endif; ?>
                </tr>
                <?php $no++; ?>
            <?php endforeach; ?>
            </tr>
            <?php $no++; ?>
        </tbody>
    </table>
</div>
