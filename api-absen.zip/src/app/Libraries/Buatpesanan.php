<?php

namespace App\Libraries;
use App\Libraries\Uuid;

class Buatpesanan
{
  	private $_db;
  	function __construct()
    {
        helper(['text', 'array', 'filesystem']);
     	$this->_db      = \Config\Database::connect();
    }
  
  	private function _insertPesanan($data) {
      	$uuid = new Uuid();
      	$data['id'] = $uuid->v4();
      	$builder = $this->_db->table('_pesanan_tb_b');
      	$builder->insert($data);
      	return $data;
    }
  
  	private function _insertDetailPesanan($data) {
      	$uuid = new Uuid();
      	$data['id'] = $uuid->v4();
      	$builder = $this->_db->table('_detail_pesanan_tb_b');
      	$builder->insert($data);
      	return $data;
    }
  
  	private function _deleteFromCart($id) {
      	$builder = $this->_db->table('_keranjang_tb_b');
      	$builder->delete(['id' => $id]);
      	return $this->_db->affectedRows();
    }
  
  	public function createPesanan($data, $kodeTransaksi, $userId){
      	foreach($data->listProductCheckoutGroupByToko as $val) {
          	$items = json_decode(json_encode($val->productCheckout), true);
			$jumlahItem = array_sum(array_column($items, 'qty'));
          	$totalHargaPesanan = array_sum(array_column($items, 'totalHarga'));
          
          	$dataPesanan = [
              	'kode_transaksi' => $kodeTransaksi,
              	'toko_id' => $val->toko,
              	'user_id' => $userId,
              	'id_alamat_pengiriman' => $val->alamatPengiriman,
              	'code_pengiriman' => $val->selectedOngkir->code,
              	'service_pengiriman' => $val->selectedOngkir->service,
              	'etd_pengiriman' => $val->selectedOngkir->etd,
              	'cost_pengiriman' => $val->selectedOngkir->costValue,
              	'code_pengiriman' => $val->selectedOngkir->code,
              	'jumlah_item' => $jumlahItem,
              	'total_pesanan' => $totalHargaPesanan,
              	'status_pembayaran' => 0,
              	'status_pesanan' => 0,
              	'created_at' => date('Y-m-d H:i:s'),
            ];
          
          	$pesanan = $this->_insertPesanan($dataPesanan);
          	
          	foreach($val->productCheckout as $prod) {
              	$dataDetailPesanan = [
                  	'kode_transaksi' => $kodeTransaksi,
                  	'user_id' => $userId,
                  	'toko_id' => $pesanan['toko_id'],
                  	'pesanan_id' => $pesanan['id'],
                  	'product_id' => $prod->product->productId,
                  	'catatan' => $prod->catatan,
                  	'product_title' => $prod->product->productTitle,
                  	'product_price' => $prod->product->productPrice,
                  	'product_weight' => $prod->product->productWeight,
                  	'product_thumb' => $prod->product->productThumb,
                  	'qty_item' => $prod->qty,
                  	'total_harga' => $prod->totalHarga,
                  	'created_at' => date('Y-m-d H:i:s'),
                ];
              
              	$detailPesanan = $this->_insertDetailPesanan($dataDetailPesanan);
              	$this->_deleteFromCart($prod->product->id);
            }
        }
      	return true;
    }
  
  	private function _hasAnyProperties($object, array $properties) {
        return array_reduce(
            $properties,
            function ($acc, $property) use ($object) {
                return $acc || property_exists($object, $property);
            },
            false
        );
    }
  
}