<?php
// if (!defined('BASEPATH')) exit('No direct script access allowed');

namespace App\Libraries;


/**
 * UUID Class
 *
 * This implements the abilities to create UUID's for CodeIgniter.
 * Code has been borrowed from the followinf comments on php.net
 * and has been optimized for CodeIgniter use.
 * http://www.php.net/manual/en/function.uniqid.php#94959
 *
 * @category Libraries
 * @author Dan Storm
 * @link http://catalystcode.net/
 * @license GNU LPGL
 * @version 2.1 
 */


class Ongkirlib
{
  	private $_db;
  	function __construct()
    {
        helper(['text', 'array', 'filesystem']);
     	$this->_db      = \Config\Database::connect();
    }
  
  	private function _hasAnyProperties($object, array $properties) {
        return array_reduce(
            $properties,
            function ($acc, $property) use ($object) {
                return $acc || property_exists($object, $property);
            },
            false
        );
    }
  
  
    private function _send_json($url, $data, $layananPpob)
    {
      	if($layananPpob == "rajaongkir"){
        	$api_url = "https://pro.rajaongkir.com/api/". $url;
        }else if ($layananPpob == "none") {
          	$api_url = "https://pro.rajaongkir.com/api/";
        }else{
          	$api_url = "https://pro.rajaongkir.com/api/";
        }
      	$headers = [
          'key:' . getenv('rajaongkir.default.key'),
        ];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $api_url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 0);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 500);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
      	//curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        // $result = curl_exec($ch);
        // return $result;
        return $ch;
    }
  
  	public function getKurir($from, $to, $weight, $kurir){
      $url = "cost";
      //$request_data = [
      //  'origin' => $from,
      //  'originType' => "subdistrict",
      //  'destination' => $to,
      //  'destinationType' => "subdistrict",
      //  'weight' => $weight,
      //  'courier' => $courier
      //];
      $request_data = "origin=$from&originType=subdistrict&destination=$to&destinationType=subdistrict&weight=$weight&courier=$kurir";
      
      //var_dump($request_data);
      
      $add         = $this->_send_json($url, $request_data, "rajaongkir");
      $send_data         = curl_exec($add);
      $a =  json_decode($send_data);
      if($a->rajaongkir->status->code == 200 && $a->rajaongkir->status->description == "OK") {
        	return $a->rajaongkir;
      }else{
        	return null;
      }
    }
  
  	public function lacakPengiriman($kurir, $noResi){
      $url = "waybill";
      
      $request_data = "waybill=$noResi&courier=$kurir";
      
      //var_dump($request_data);
      
      $add         = $this->_send_json($url, $request_data, "rajaongkir");
      $send_data         = curl_exec($add);
      $a =  json_decode($send_data);
      if($a->rajaongkir->status->code == 200 && $a->rajaongkir->status->description == "OK") {
        	return $a->rajaongkir;
      }else{
        	return null;
      }
    }

    private function _inputHistoryPpob($data) {
      	$builderResponseTransaksiPpob = $this->_db->table('_history_transaksi_ppob_tb_b');
		return $builderResponseTransaksiPpob->insert($data);
    }
}
