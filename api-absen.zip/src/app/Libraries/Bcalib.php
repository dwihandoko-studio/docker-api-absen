<?php

namespace App\Libraries;
use App\Libraries\Uuid;

class Bcalib
{
  	var $options = ['timeout' => 3];
  	
    //private function _send_json($link)
    //{
     //   $options = [
     //           //'baseURI' => 'https://sandbox.bca.co.id'.$link,
     //           'timeout'  => 3
     //   ];
     //   $client = \Config\Services::curlrequest($options);
      
     // 	return $client;
    //}
  	private $_db;
  	function __construct()
    {
        helper(['text', 'array', 'filesystem']);
     	$this->_db      = \Config\Database::connect();
    }

  	
  
  	private function _auth(){
      $username = base64_encode(getenv('configurasibca.default.uid') . ":" . getenv('configurasibca.default.pin'));
      $client = \Config\Services::curlrequest($this->options);
      	$response = $client->request('POST', getenv('configurasibca.default.url').'/api/oauth/token', [
      		'headers' => [
                  'Authorization' => 'Basic ' . $username,
                  'Content-Type' => 'application/x-www-form-urlencoded',
            ],
          	'form_params' => [
                    'grant_type' => 'client_credentials'
            ],
            'connect_timeout' => 5,
                            	// 'body' => json_encode($data)
        ]);
      
      	if($response->getStatusCode() == 200 || $response->getStatusCode() == 201){
        	$dataRes = json_decode($response->getBody());
          	
          	//$db      = \Config\Database::connect();
          	$builder = $this->_db->table('auth_token_pihak_3');
          	$ac = $builder->where('pihak_3', 'bca')->get()->getRowObject();
          	if($ac) {
              $updateData = [
                'access_token' => $dataRes->access_token,
                'expired' => time() + $dataRes->expires_in,
                'token_type' => $dataRes->token_type,
                'scope' => $dataRes->scope,
                'updated_at' => date('Y-m-d H:i:s')
              ];
              $builder->where('pihak_3', 'bca')->update($updateData);
              
              return $dataRes->access_token;
            }else{
              $uuid = new Uuid();
              $insertData = [
                'id' => $uuid->v4(),
                'pihak_3' => 'bca',
                'access_token' => $dataRes->access_token,
                'expired' => time() + $dataRes->expires_in,
                'token_type' => $dataRes->token_type,
                'scope' => $dataRes->scope,
                'created_at' => date('Y-m-d H:i:s')
              ];
              $builder->insert($insertData);
              return $dataRes->access_token;
            }
        }else{
          	return false;
        }
      	
      	return $response;
    }
  
  	private function _generateSign($isoTime, $url, $auth_token, $methode, $bodyToHash = [])
    {
        $hash = hash("sha256", "");
        if (is_array($bodyToHash)) {
            ksort($bodyToHash);
            $encoderData = json_encode($bodyToHash, JSON_UNESCAPED_SLASHES);
            $hash = hash("sha256", $encoderData);
        }
      	$secret_key = getenv('configurasibca.default.secret');
        $stringToSign = $methode . ":" . $url . ":" . $auth_token . ":" . $hash . ":" . $isoTime;
        $auth_signature = hash_hmac('sha256', $stringToSign, $secret_key, false);

        return $auth_signature;
    }
  
  	public function getBalance() {
      $time = date('Y-m-d')."T".date('H:i:s');
      $timeFix = $time.".000+07:00";
      
      $url = "/banking/v3/corporates/".getenv('configurasibca.default.corporateid')."/accounts/".getenv('configurasibca.default.accountnumber');
      
      $builder = $this->_db->table('auth_token_pihak_3');
      $ac = $builder->where('pihak_3', 'bca')->get()->getRowObject();
      if($ac) {
        if(time() >= $ac->expired) {
          $accessToken = $this->_auth();
        }else{
          $accessToken = $ac->access_token;
        }
      }else{
        $accessToken = $this->_auth();
      }
      
      $signature = $this->_generateSign($timeFix, $url, $accessToken,"GET", null);
      if(!$signature)
        return false;
      $urlAction = getenv('configurasibca.default.url').$url;
      $token = "Bearer " . $accessToken;
      
      $clients = \Config\Services::curlrequest($this->options);
      $response = $clients->request('GET', $urlAction, [
            'headers' => [
              'Authorization' => $token,
              'X-BCA-Signature' => $signature,
              'X-BCA-Key' => getenv('configurasibca.default.key'),
              'X-BCA-Timestamp' => $timeFix,
              'Content-Type' => 'application/json',
            ],
            //'form_params' => [
            //  'RequestPayload' => $requestBody
            //],
            'connect_timeout' => 5,
            // 'body' => json_encode($data)
          ]);
      
      if($response->getStatusCode() == 200) {
        return json_decode($response->getBody());
      }else{
        return false;
      }
    }
  
  	public function getAccountStatement($ac, $start, $end) {
      $time = date('Y-m-d')."T".date('H:i:s');
      $timeFix = $time.".000+07:00";
      
      //https://sandbox.bca.co.id/banking/v3/corporates/BCAAPI2016/accounts/0201245680/statements?StartDate=2016-09-01&EndDate=2016-09-01
      
      $url = "/banking/v3/corporates/".getenv('configurasibca.default.corporateid')."/accounts/".getenv('configurasibca.default.accountnumber')."/statements?StartDate=".$start."&EndDate=".$end;
      
      //var_dump($url);die;
      
      $builder = $this->_db->table('auth_token_pihak_3');
      $ac = $builder->where('pihak_3', 'bca')->get()->getRowObject();
      if($ac) {
        if(time() >= $ac->expired) {
          $accessToken = $this->_auth();
        }else{
          $accessToken = $ac->access_token;
        }
      }else{
        $accessToken = $this->_auth();
      }
      
      $signature = $this->_generateSign($timeFix, $url, $accessToken,"GET", null);
      if(!$signature)
        return false;
      $urlAction = getenv('configurasibca.default.url').$url;
      
      //var_dump($signature);die;
      $token = "Bearer " . $accessToken;
      
      $data['url'] = $urlAction;
      $data['token'] = $token;
      $data['signature'] = $signature;
      $data['time'] = $timeFix;
      $data['key'] = getenv('configurasibca.default.key');
      
      //var_dump($data);die;
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL,$urlAction);
      curl_setopt($ch, CURLOPT_TIMEOUT, 0);
      curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
      curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 500);
      //curl_setopt($ch, CURLOPT_POST,false); 
      //curl_setopt($ch, CURLOPT_NOBODY,false);
      //curl_setopt($ch, CURLOPT_POSTFIELDS,0);  //Post Fields
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

      $headers = [
          'Authorization:' . $token,
              'X-BCA-Signature:' . $signature,
              'X-BCA-Key:' . getenv('configurasibca.default.key'),
              'X-BCA-Timestamp:' . $timeFix,
              'Content-Type: application/json'
      ];

      curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

      $server_output = curl_exec ($ch);

      curl_close ($ch);
      
      print  $server_output ;
      
      die;
      
      $clients = \Config\Services::curlrequest($this->options);
      $response = $clients->request('GET', $urlAction, [
            'headers' => [
              'Authorization' => $token,
              'X-BCA-Signature' => $signature,
              'X-BCA-Key' => getenv('configurasibca.default.key'),
              'X-BCA-Timestamp' => $timeFix,
              'Content-Type' => 'application/json',
            ],
            //'form_params' => [
            //  'RequestPayload' => $requestBody
            //],
            'connect_timeout' => 5,
            // 'body' => json_encode($data)
          ]);
      
      
      if($response->getStatusCode() == 200) {
        return json_decode($response->getBody());
      }else{
        return false;
      }
    }
  
  	public function fundTransfer($sourceAccountNumber, $transactionID, $referenceID, $amount, $beneficiaryAccountNumber, $remark1="", $remark2="", $currencyCode = "IDR") {
      $time = date('Y-m-d')."T".date('H:i:s');
      $timeFix = $time.".000+07:00";
      $date = date('Y-m-d H:i:s');
      
      //https://sandbox.bca.co.id/banking/v3/corporates/BCAAPI2016/accounts/0201245680/statements?StartDate=2016-09-01&EndDate=2016-09-01
      
      $url = "/banking/corporates/transfers";
      
      $builder = $this->_db->table('auth_token_pihak_3');
      $ac = $builder->where('pihak_3', 'bca')->get()->getRowObject();
      if($ac) {
        if(time() >= $ac->expired) {
          $accessToken = $this->_auth();
        }else{
          $accessToken = $ac->access_token;
        }
      }else{
        $accessToken = $this->_auth();
      }
      
      $requestBody = [
        'CorporateID' => getenv('configurasibca.default.corporateid'),
        'SourceAccountNumber' => strtolower(str_replace(' ', '', $sourceAccountNumber)),
        'TransactionID' => strtolower(str_replace(' ', '', $transactionID)),
        'TransactionDate' => $timeFix,
        'ReferenceID' => strtolower(str_replace(' ', '', $referenceID)),
        'CurrencyCode' => $currencyCode,
        'Amount' => $amount,
        'BeneficiaryAccountNumber' => strtolower(str_replace(' ', '', $beneficiaryAccountNumber)),
        'Remark1' => strtolower(str_replace(' ', '', $remark1)),
        'Remark2' => strtolower(str_replace(' ', '', $remark2)),
      ];
      
      ksort($requestBody);
      
      //var_dump($requestBody);die;
      
      $signature = $this->_generateSign($timeFix, $url, $accessToken,"POST", $requestBody);
      //var_dump($signature);die;
      if(!$signature)
        return false;
      $urlAction = getenv('configurasibca.default.url').$url;
      
      //var_dump($signature);die;
      $token = "Bearer " . $accessToken;
      
      $data['token'] = $token;
      $data['request'] = json_encode($requestBody);
      $data['signature'] = $signature;
      $data['time'] = $timeFix;
      $data['key'] = getenv('configurasibca.default.key');
      
      //var_dump($data);die;
      $encoderData = json_encode($requestBody, JSON_UNESCAPED_SLASHES);
      
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL,$urlAction);
      curl_setopt($ch, CURLOPT_TIMEOUT, 0);
      curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 500);
      curl_setopt($ch, CURLOPT_POSTFIELDS,$encoderData);  //Post Fields
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

      $headers = [
          'Authorization:' . $token,
              'X-BCA-Signature:' . $signature,
              'X-BCA-Key:' . getenv('configurasibca.default.key'),
              'X-BCA-Timestamp:' . $timeFix,
              'Content-Type: application/json'
      ];

      curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

      $server_output = curl_exec ($ch);

      curl_close ($ch);

      print  $server_output ;
      
      die;
      
      //$clients = \Config\Services::curlrequest($this->options);
      //try {
      //$response = $clients->request('POST', $urlAction, [
      //      'headers' => [
      //        'Authorization' => $token,
      //        'X-BCA-Signature' => $signature,
       //       'X-BCA-Key' => getenv('configurasibca.default.key'),
      //        'X-BCA-Timestamp' => $timeFix,
      //        'Content-Type' => 'application/json'
      //      ],
            //'form_params' => $requestBody,
      //      'connect_timeout' => 5,
      //      'body' => json_encode($requestBody),
      //    ]);
      //}
     // catch (\Exception\CURLRequest $e)
//{
   // die($e->getMessage());
//}
      
      
      if($response->getStatusCode() == 200) {
        return json_decode($response->getBody());
      }else{
        return false;
      }
    }
  
  public function testLink() {
    $urlPem = "https://api-cloud.lampungtengahkab.go.id/api/webpemkab/beritatag?tag=covid-19&page=1&perpage=6";
      	$ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$urlPem);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 500);
        //curl_setopt($ch, CURLOPT_POSTFIELDS,0);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        $headers = [
            'Authorization: Basic cmVzdGFwaS5oYW5kb2tvQGdtYWlsLmNvbTphZG1pbkAzMjE='
        ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $server_output = curl_exec ($ch);

        curl_close ($ch);
    var_dump($server_output);die;
  }
}