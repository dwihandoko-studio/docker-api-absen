<?php

namespace App\Libraries;
use App\Libraries\Uuid;

class Pesananlib
{
  	private $_db;
  	function __construct()
    {
        helper(['text', 'array', 'filesystem']);
     	$this->_db      = \Config\Database::connect();
    }
  
  	private function _hasAnyProperties($object, array $properties) {
        return array_reduce(
            $properties,
            function ($acc, $property) use ($object) {
                return $acc || property_exists($object, $property);
            },
            false
        );
    }
  
  	private function _getItemDetailPesanan($id) {
      	$builder = $this->_db->table('_detail_pesanan_tb_b');
      	$select = "_detail_pesanan_tb_b.id, _detail_pesanan_tb_b.kode_transaksi as kodeTransaksi, _detail_pesanan_tb_b.toko_id as tokoId, _detail_pesanan_tb_b.user_id as userId, _detail_pesanan_tb_b.pesanan_id as pesananId, _detail_pesanan_tb_b.product_id as productId, _detail_pesanan_tb_b.catatan, _detail_pesanan_tb_b.product_title as productTitle, _detail_pesanan_tb_b.product_price as productPrice, _detail_pesanan_tb_b.product_weight as productWeight, _detail_pesanan_tb_b.product_thumb as productThumb, _detail_pesanan_tb_b.qty_item as qtyItem, _detail_pesanan_tb_b.total_harga as totalHarga, _detail_pesanan_tb_b.created_at as createdAt";
      	
      	return $builder->select($select)->where('_detail_pesanan_tb_b.pesanan_id', $id)->orderBy('_detail_pesanan_tb_b.qty_item', 'desc')->get()->getResult();
    }
  
  	public function getDataDetailEcomPesananBaru($tokoId) {
      	return $this->_getDetailPesananBaru($tokoId);
    }
  
  	private function _getDetailPesananBaru($tokoId) {
      	$builder = $this->_db->table('_pesanan_tb_b');
        $select = "_pesanan_tb_b.id, _pesanan_tb_b.kode_transaksi as kodeTransaksi, _pesanan_tb_b.no_resi as noResi, _pesanan_tb_b.toko_id as idToko, _pesanan_tb_b.id_alamat_pengiriman as idAlamatPengiriman, _pesanan_tb_b.code_pengiriman as codePengiriman, _pesanan_tb_b.service_pengiriman as servicePengiriman, _pesanan_tb_b.etd_pengiriman as etdPengiriman, _pesanan_tb_b.cost_pengiriman as costPengiriman, _pesanan_tb_b.jumlah_item as totalJumlahItem, _pesanan_tb_b.total_pesanan as totalJumlahHargaPesanan, _pesanan_tb_b.status_pembayaran as statusPembayaran, _pesanan_tb_b.status_pesanan as statusPesanan, _pesanan_tb_b.created_at as createdAt, _pesanan_tb_b.updated_at as updatedAt, _pesanan_tb_b.updated_at_pembayaran as updatedAtPembayaran, _pesanan_tb_b.updated_at_transaksi as updatedAtTransaksi, _toko_tb_b.toko_title as titleToko, _toko_tb_b.user_id as tokoUserId, _toko_tb_b.toko_featured_image as imageToko, _toko_tb_b.alamat as alamatToko, _alamat_kiriman_users_tb.id as idAlamatPengiriman, _alamat_kiriman_users_tb.kecamatan_id as kecIdAlamatPengiriman, _alamat_kiriman_users_tb.detail_alamat as detailAlamatPengiriman, _alamat_kiriman_users_tb.kode_pos as kodePosAlamatPengiriman, _alamat_kiriman_users_tb.nama_penerima as namaPenerimaAlamatPengiriman, _alamat_kiriman_users_tb.nohp_penerima as nohpAlamatPengiriman, _profil_users_tb.id as userIdPembeli, _profil_users_tb.firsname as namaUserPembeli, _profil_users_tb.profile_picture as imageUserPembeli, _orders_tb_b.status_order as statusOrder, _orders_tb_b.jenis_order as jenisOrder, _orders_tb_b.total_harga as totalHargaOrder, _orders_tb_b.user_id as userIdPembeli";
        $dataPesanan = $builder->select($select)->join('_alamat_kiriman_users_tb', '_alamat_kiriman_users_tb.id = _pesanan_tb_b.id_alamat_pengiriman')->join('_toko_tb_b', '_toko_tb_b.id = _pesanan_tb_b.toko_id')->join('_profil_users_tb', '_profil_users_tb.id = _pesanan_tb_b.user_id')->join('_orders_tb_b', '_orders_tb_b.kode_transaksi = _pesanan_tb_b.kode_transaksi')->where("_pesanan_tb_b.toko_id = '$tokoId' AND _pesanan_tb_b.status_pembayaran = 1 AND _pesanan_tb_b.status_pesanan = 0 ")->orderBy('_pesanan_tb_b.created_at','desc')->get()->getResult();

        if(count($dataPesanan) > 0) {
          //var_dump($dataPesanan);die;
            $dataPesanans = [];
            foreach($dataPesanan as $val) {
              $val->itemDetailPesanan = $this->_getItemDetailPesanan($val->id);
              $dataPesanans[] = $val;
            }

            return $dataPesanans;
        }else {
            $data = [];
            return $data;
        }
    }
  
  	public function getDataDetailEcomPesananDiproses($tokoId) {
      	return $this->_getDetailPesananDiproses($tokoId);
    }
  
  	private function _getDetailPesananDiproses($tokoId) {
      	$builder = $this->_db->table('_pesanan_tb_b');
        $select = "_pesanan_tb_b.id, _pesanan_tb_b.kode_transaksi as kodeTransaksi, _pesanan_tb_b.no_resi as noResi, _pesanan_tb_b.toko_id as idToko, _pesanan_tb_b.id_alamat_pengiriman as idAlamatPengiriman, _pesanan_tb_b.code_pengiriman as codePengiriman, _pesanan_tb_b.service_pengiriman as servicePengiriman, _pesanan_tb_b.etd_pengiriman as etdPengiriman, _pesanan_tb_b.cost_pengiriman as costPengiriman, _pesanan_tb_b.jumlah_item as totalJumlahItem, _pesanan_tb_b.total_pesanan as totalJumlahHargaPesanan, _pesanan_tb_b.status_pembayaran as statusPembayaran, _pesanan_tb_b.status_pesanan as statusPesanan, _pesanan_tb_b.created_at as createdAt, _pesanan_tb_b.updated_at as updatedAt, _pesanan_tb_b.updated_at_pembayaran as updatedAtPembayaran, _pesanan_tb_b.updated_at_transaksi as updatedAtTransaksi, _toko_tb_b.toko_title as titleToko, _toko_tb_b.user_id as tokoUserId, _toko_tb_b.toko_featured_image as imageToko, _toko_tb_b.alamat as alamatToko, _alamat_kiriman_users_tb.id as idAlamatPengiriman, _alamat_kiriman_users_tb.kecamatan_id as kecIdAlamatPengiriman, _alamat_kiriman_users_tb.detail_alamat as detailAlamatPengiriman, _alamat_kiriman_users_tb.kode_pos as kodePosAlamatPengiriman, _alamat_kiriman_users_tb.nama_penerima as namaPenerimaAlamatPengiriman, _alamat_kiriman_users_tb.nohp_penerima as nohpAlamatPengiriman, _profil_users_tb.id as userIdPembeli, _profil_users_tb.firsname as namaUserPembeli, _profil_users_tb.profile_picture as imageUserPembeli, _orders_tb_b.status_order as statusOrder, _orders_tb_b.jenis_order as jenisOrder, _orders_tb_b.total_harga as totalHargaOrder, _orders_tb_b.user_id as userIdPembeli";
        $dataPesanan = $builder->select($select)->join('_alamat_kiriman_users_tb', '_alamat_kiriman_users_tb.id = _pesanan_tb_b.id_alamat_pengiriman')->join('_toko_tb_b', '_toko_tb_b.id = _pesanan_tb_b.toko_id')->join('_profil_users_tb', '_profil_users_tb.id = _pesanan_tb_b.user_id')->join('_orders_tb_b', '_orders_tb_b.kode_transaksi = _pesanan_tb_b.kode_transaksi')->where("_pesanan_tb_b.toko_id = '$tokoId' AND _pesanan_tb_b.status_pembayaran = 1 AND _pesanan_tb_b.status_pesanan = 1 ")->orderBy('_pesanan_tb_b.created_at','desc')->get()->getResult();

        if(count($dataPesanan) > 0) {
          //var_dump($dataPesanan);die;
            $dataPesanans = [];
            foreach($dataPesanan as $val) {
              $val->itemDetailPesanan = $this->_getItemDetailPesanan($val->id);
              $dataPesanans[] = $val;
            }

            return $dataPesanans;
        }else {
            $data = [];
            return $data;
        }
    }
  
  	public function getDataDetailEcomPesananDikirim($tokoId) {
      	return $this->_getDetailPesananDikirim($tokoId);
    }
  
  	private function _getDetailPesananDikirim($tokoId) {
      	$builder = $this->_db->table('_pesanan_tb_b');
        $select = "_pesanan_tb_b.id, _pesanan_tb_b.kode_transaksi as kodeTransaksi, _pesanan_tb_b.no_resi as noResi, _pesanan_tb_b.toko_id as idToko, _pesanan_tb_b.id_alamat_pengiriman as idAlamatPengiriman, _pesanan_tb_b.code_pengiriman as codePengiriman, _pesanan_tb_b.service_pengiriman as servicePengiriman, _pesanan_tb_b.etd_pengiriman as etdPengiriman, _pesanan_tb_b.cost_pengiriman as costPengiriman, _pesanan_tb_b.jumlah_item as totalJumlahItem, _pesanan_tb_b.total_pesanan as totalJumlahHargaPesanan, _pesanan_tb_b.status_pembayaran as statusPembayaran, _pesanan_tb_b.status_pesanan as statusPesanan, _pesanan_tb_b.created_at as createdAt, _pesanan_tb_b.updated_at as updatedAt, _pesanan_tb_b.updated_at_pembayaran as updatedAtPembayaran, _pesanan_tb_b.updated_at_transaksi as updatedAtTransaksi, _toko_tb_b.toko_title as titleToko, _toko_tb_b.user_id as tokoUserId, _toko_tb_b.toko_featured_image as imageToko, _toko_tb_b.alamat as alamatToko, _alamat_kiriman_users_tb.id as idAlamatPengiriman, _alamat_kiriman_users_tb.kecamatan_id as kecIdAlamatPengiriman, _alamat_kiriman_users_tb.detail_alamat as detailAlamatPengiriman, _alamat_kiriman_users_tb.kode_pos as kodePosAlamatPengiriman, _alamat_kiriman_users_tb.nama_penerima as namaPenerimaAlamatPengiriman, _alamat_kiriman_users_tb.nohp_penerima as nohpAlamatPengiriman, _profil_users_tb.id as userIdPembeli, _profil_users_tb.firsname as namaUserPembeli, _profil_users_tb.profile_picture as imageUserPembeli, _orders_tb_b.status_order as statusOrder, _orders_tb_b.jenis_order as jenisOrder, _orders_tb_b.total_harga as totalHargaOrder, _orders_tb_b.user_id as userIdPembeli";
        $dataPesanan = $builder->select($select)->join('_alamat_kiriman_users_tb', '_alamat_kiriman_users_tb.id = _pesanan_tb_b.id_alamat_pengiriman')->join('_toko_tb_b', '_toko_tb_b.id = _pesanan_tb_b.toko_id')->join('_profil_users_tb', '_profil_users_tb.id = _pesanan_tb_b.user_id')->join('_orders_tb_b', '_orders_tb_b.kode_transaksi = _pesanan_tb_b.kode_transaksi')->where("_pesanan_tb_b.toko_id = '$tokoId' AND _pesanan_tb_b.status_pembayaran = 1 AND _pesanan_tb_b.status_pesanan = 2 ")->orderBy('_pesanan_tb_b.created_at','desc')->get()->getResult();

        if(count($dataPesanan) > 0) {
          //var_dump($dataPesanan);die;
            $dataPesanans = [];
            foreach($dataPesanan as $val) {
              $val->itemDetailPesanan = $this->_getItemDetailPesanan($val->id);
              $dataPesanans[] = $val;
            }

            return $dataPesanans;
        }else {
            $data = [];
            return $data;
        }
    }
  
  	public function getDataDetailEcomPesananDetail($idPesanan) {
      	return $this->_getDetailPesananDetail($idPesanan);
    }
  
  	private function _getDetailPesananDetail($idPesanan) {
      	$builder = $this->_db->table('_pesanan_tb_b');
        $select = "_pesanan_tb_b.id, _pesanan_tb_b.kode_transaksi as kodeTransaksi, _pesanan_tb_b.no_resi as noResi, _pesanan_tb_b.toko_id as idToko, _pesanan_tb_b.id_alamat_pengiriman as idAlamatPengiriman, _pesanan_tb_b.code_pengiriman as codePengiriman, _pesanan_tb_b.service_pengiriman as servicePengiriman, _pesanan_tb_b.etd_pengiriman as etdPengiriman, _pesanan_tb_b.cost_pengiriman as costPengiriman, _pesanan_tb_b.jumlah_item as totalJumlahItem, _pesanan_tb_b.total_pesanan as totalJumlahHargaPesanan, _pesanan_tb_b.status_pembayaran as statusPembayaran, _pesanan_tb_b.status_pesanan as statusPesanan, _pesanan_tb_b.created_at as createdAt, _pesanan_tb_b.updated_at as updatedAt, _pesanan_tb_b.updated_at_pembayaran as updatedAtPembayaran, _pesanan_tb_b.updated_at_transaksi as updatedAtTransaksi, _toko_tb_b.toko_title as titleToko, _toko_tb_b.user_id as tokoUserId, _toko_tb_b.toko_featured_image as imageToko, _toko_tb_b.alamat as alamatToko, _alamat_kiriman_users_tb.id as idAlamatPengiriman, _alamat_kiriman_users_tb.kecamatan_id as kecIdAlamatPengiriman, _alamat_kiriman_users_tb.detail_alamat as detailAlamatPengiriman, _alamat_kiriman_users_tb.kode_pos as kodePosAlamatPengiriman, _alamat_kiriman_users_tb.nama_penerima as namaPenerimaAlamatPengiriman, _alamat_kiriman_users_tb.nohp_penerima as nohpAlamatPengiriman, _profil_users_tb.id as userIdPembeli, _profil_users_tb.firsname as namaUserPembeli, _profil_users_tb.profile_picture as imageUserPembeli, _orders_tb_b.status_order as statusOrder, _orders_tb_b.jenis_order as jenisOrder, _orders_tb_b.total_harga as totalHargaOrder, _orders_tb_b.user_id as userIdPembeli, ref_kecamatan.type as kabupatenKotaPengiriman, ref_kecamatan.city as kabupatenKotaNamePengiriman, ref_kecamatan.subdistrict_name as kecamatanNamePengiriman, ref_kecamatan.province as provinsiNamePengiriman";
        $dataPesanan = $builder->select($select)->join('_alamat_kiriman_users_tb', '_alamat_kiriman_users_tb.id = _pesanan_tb_b.id_alamat_pengiriman')->join('_toko_tb_b', '_toko_tb_b.id = _pesanan_tb_b.toko_id')->join('_profil_users_tb', '_profil_users_tb.id = _pesanan_tb_b.user_id')->join('_orders_tb_b', '_orders_tb_b.kode_transaksi = _pesanan_tb_b.kode_transaksi')->join('ref_kecamatan', 'ref_kecamatan.subdistrict_id = _alamat_kiriman_users_tb.kecamatan_id')->where("_pesanan_tb_b.id = '$idPesanan'")->get()->getRowObject();
        //AND _pesanan_tb_b.status_pembayaran = 1 AND _pesanan_tb_b.status_pesanan = 0 ")->orderBy('_pesanan_tb_b.created_at','desc')->get()->getResult();

        if($dataPesanan) {
          
              $dataPesanan->itemDetailPesanan = $this->_getItemDetailPesanan($dataPesanan->id);
              

            return $dataPesanan;
        }else {
            return false;
        }
    }
  
  	public function changeEcomPesananToProses($idPesanan) {
      	$builder = $this->_db->table('_pesanan_tb_b');
      	$dataUpdate = [
          	'status_pesanan' => 1,
          	'updated_at_transaksi' => date('Y-m-d H:i:s')
        ];
      	$builder->where('id', $idPesanan)->update($dataUpdate);
      
      	if($this->_db->affectedRows() > 0) {
      		return $this->_getDetailPesananDetail($idPesanan);
        }else {
          	return false;
        }
    }
  
  	public function changeEcomPesananToTolak($idPesanan) {
      	$builder = $this->_db->table('_pesanan_tb_b');
      	$dataUpdate = [
          	'status_pesanan' => 5,
          	'updated_at_transaksi' => date('Y-m-d H:i:s')
        ];
      	$builder->where('id', $idPesanan)->update($dataUpdate);
      
      	if($this->_db->affectedRows() > 0) {
      		return $this->_getDetailPesananDetail($idPesanan);
        }else {
          	return false;
        }
    }
  
  	public function changeEcomPesananToDikirim($idPesanan, $noResi) {
      	$builder = $this->_db->table('_pesanan_tb_b');
      	$dataUpdate = [
          	'status_pesanan' => 2,
          	'no_resi' => $noResi,
          	'updated_at_transaksi' => date('Y-m-d H:i:s')
        ];
      	$builder->where('id', $idPesanan)->update($dataUpdate);
      
      	if($this->_db->affectedRows() > 0) {
      		return $this->_getDetailPesananDetail($idPesanan);
        }else {
          	return false;
        }
    }
  
}