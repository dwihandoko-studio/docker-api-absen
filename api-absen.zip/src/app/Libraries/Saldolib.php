<?php

namespace App\Libraries;
use App\Libraries\Uuid;

class Saldolib
{
  	private $_db;
  	function __construct()
    {
        helper(['text', 'array', 'filesystem']);
     	$this->_db      = \Config\Database::connect();
    }
  
  	private function _getUser($userId) {
      	$builder = $this->_db->table('_profil_users_tb');
      	return $builder->select("saldo, point_reward as poinReward")->where('id', $userId)->get()->getRowObject();
    }
  
  	public function updateSaldo($saldo, $userId) {
      	$builder = $this->_db->table('_profil_users_tb');
      	$data = [
          	'saldo' => $saldo,
          	'update_at_transaksi' => date('Y-m-d H:i:s')
        ];
      	return $builder->where('id', $userId)->update($data);
    }
  
  	public function refundSaldo($saldo, $userId) {
      	$builder = $this->_db->table('_profil_users_tb');
      	$data = [
          	'saldo' => $saldo,
          	'update_at_transaksi' => date('Y-m-d H:i:s')
        ];
      	return $builder->where('id', $userId)->update($data);
    }
  
  	public function insertRiwayatSaldo($data){
      	$uuidsaldo = new Uuid();
      	$data['id'] = $uuidsaldo->v4();
      	$builder = $this->_db->table('_riwayat_saldo');
      	return $builder->insert($data);
    }
  
  	public function cekAlreadyRiwayatSaldo($kodeTransaksi, $userId, $jenisSaldo) {
      	$builder = $this->_db->table('_riwayat_saldo');
      	$where = [
          	'kode_transaksi' => $kodeTransaksi,
          	'user_id' => $userId,
          	'jenis_saldo' => $jenisSaldo
        ];
      	return $builder->where($where)->get()->getResult();
    }
}