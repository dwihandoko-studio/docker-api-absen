<?php

namespace App\Libraries;

// use \OAuth2\Storage\Pdo;
use \App\Libraries\CustomOauthStorage;

class Oauth
{
    var $server;

    function __construct()
    {
        $this->init();
    }

    public function init()
    {
        $dsn = getenv('database.default.DSN');
        $username = getenv('database.default.username');
        $password = getenv('database.default.password');

        $config = array(
            'access_lifetime'                => 1 * 3600,    // 7 days
            'refresh_token_lifetime'         => 1 * 15552000, // 1 days
            'always_issue_new_refresh_token' => true,
        );

        // $storage = new Pdo(['dsn' => $dsn, 'username' => $username, 'password' => $password]);
        $storage = new CustomOauthStorage(['dsn' => $dsn, 'username' => $username, 'password' => $password]);
        $this->server = new \OAuth2\Server($storage, $config);
        $this->server->addGrantType(new \OAuth2\GrantType\UserCredentials($storage));
        $this->server->addGrantType(new \OAuth2\GrantType\RefreshToken($storage, [
            'always_issue_new_refresh_token' => true,
            'unset_refresh_token_after_use'  => false
        ]));
        // $this->server->handleTokenRequest(\OAuth2\Request::createFromGlobals())->send();
    }
}
