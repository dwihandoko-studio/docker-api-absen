<?php

namespace App\Libraries\Capil;

class Niklib
{
  	private $_db;
  	function __construct()
    {
        helper(['text', 'array', 'filesystem']);
     	$this->_db      = \Config\Database::connect();
    }
  
  
    private function _send_json($val, $methode, $query)
    {
        $urlendpoint = "https://192.168.20.40/capil/" . $methode . ".php?" . $query . "=" . $val;
        
        //var_dump($urlendpoint);
        
    //     $curlHandle = curl_init($urlendpoint);
    //     curl_setopt($curlHandle, CURLOPT_CUSTOMREQUEST, "GET");
    //     // curl_setopt($curlHandle, CURLOPT_POSTFIELDS, $data);
    //     curl_setopt($curlHandle, CURLOPT_RETURNTRANSFER, true);
    //     // curl_setopt($curlHandle, CURLOPT_HTTPHEADER, array(
    //     //             'Content-Type: application/json',
    //     //             'Content-Length: ' . strlen($data))
    //     // );
    //     curl_setopt($curlHandle, CURLOPT_TIMEOUT, 30);
    //     curl_setopt($curlHandle, CURLOPT_CONNECTTIMEOUT, 30);
      
      
    //   	return $curlHandle;
      
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $urlendpoint);
        curl_setopt($ch, CURLOPT_TIMEOUT, 0);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 500);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        // $result = curl_exec($ch);
        // return $result;
        return $ch;
    }
  
  	public function cekNik($nik) {
      	$add         = $this->_send_json($nik, "alldata", "nik");
      	$send_data         = curl_exec($add);
      	
      	if($send_data != "false") {
      	    return json_decode($send_data);
      	}else{
      	    return false;
      	}
    }
  
}