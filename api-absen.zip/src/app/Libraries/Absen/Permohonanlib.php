<?php

namespace App\Libraries\Capil;
use App\Libraries\Uuid;

class Permohonanlib
{
  	private $_db;
  	private $_builder;
  	function __construct()
    {
        helper(['text', 'array', 'filesystem']);
     	$this->_db      = \Config\Database::connect();
     	$this->_builder = $this->_db->table('_permohonan_tb_b');
    }
    
    public function createPermohonan($jenisPermohonan, $userId) {
        $uuid = new Uuid();
        
        $kodePermohonan = $jenisPermohonan . "-" . TIME() . random_string('numeric', 4);
        
        $data = [
            'id' => $uuid->v4(),
            'user_id' => $userId,
            'kode_permohonan' => $kodePermohonan,
            'jenis_permohonan' => $jenisPermohonan,
            'status_permohonan' => 0,
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $this->_builder->insert($data);
        $eksekusi = $this->_db->affectedRows();
        
        if($eksekusi > 0){
            return $data['kode_permohonan'];
        } else {
            return null;
        }
    }
    
    private function _getDetailPermohonanKk($kodePermohonan) {
        $builder = $this->_db->table('_permohonan_kk_tb');
        $select = "id, user_id as userId, kode_permohonan as kodePermohonan, nik_pemohon as nikPemohon, kk_pemohon as kkPemohon, nama_pemohon as namaPemohon, keterangan, kecamatan, jenis_permohonan_kk as jenisPermohonanKk, lampiran_ktp as lampiranKtp, lampiran_kk as lampiranKk, lampiran_buku_nikah as lampiranBukuNikah, lampiran_formulir_kk as lampiranFormulirKk, lampiran_surat_keterangan_hapus as lampiranSuratKeteranganHapus, lampiran_surat_keterangan_tambah as lampiranSuratKeteranganTambah, lampiran_dokument_pendukung_lain as lampiranDokumentPendukungLain, created_at as createdAt, updated_at as updatedAt";
        return $builder->select($select)->where('kode_permohonan', $kodePermohonan)->get()->getRowObject();
    }
    
    private function _getDetailPermohonanAkteKelahiran($kodePermohonan) {
        $builder = $this->_db->table('_permohonan_akte_kelahiran_tb');
        $select = "id, user_id as userId, kode_permohonan as kodePermohonan, nik_pemohon as nikPemohon, kk_pemohon as kkPemohon, nama_pemohon as namaPemohon, nama_anak as namaAnak, nik_anak as nikAnak, tempat_lahir_anak as tempatLahirAnak, tgl_lahir_anak as tglLahirAnak, anak_ke as anakKe, jenis_kelamin_anak as jenisKelaminAnak, nama_ayah as namaAyah, nama_ibu as namaIbu, nama_saksi1 as namaSaksi1, nama_saksi2 as namaSaksi2, keterangan, kecamatan, jenis_permohonan_akte as jenisPermohonanAkte, lampiran_ktp as lampiranKtp, lampiran_kk as lampiranKk, lampiran_buku_nikah as lampiranBukuNikah, lampiran_formulir_akte as lampiranFormulirAkte, lampiran_surat_keterangan_lahir as lampiranSuratKeteranganLahir, lampiran_akta_lama as lampiranAktaLama, lampiran_dokument_pendukung_lain as lampiranDokumentPendukungLain, created_at as createdAt, updated_at as updatedAt";
        return $builder->select($select)->where('kode_permohonan', $kodePermohonan)->get()->getRowObject();
    }
    
    private function _getDetailPermohonanKia($kodePermohonan) {
        $builder = $this->_db->table('_permohonan_kia_tb');
        $select = "id, user_id as userId, kode_permohonan as kodePermohonan, nik_pemohon as nikPemohon, kk_pemohon as kkPemohon, nama_pemohon as namaPemohon, nama_anak as namaAnak, nik_anak as nikAnak, tempat_lahir_anak as tempatLahirAnak, tgl_lahir_anak as tglLahirAnak, jenis_kelamin_anak as jenisKelaminAnak, nama_ayah as namaAyah, nama_ibu as namaIbu, alamat, keterangan, kecamatan, lampiran_ktp as lampiranKtp, lampiran_kk as lampiranKk, lampiran_pas_foto as lampiranPasFoto, lampiran_dokument_pendukung_lain as lampiranDokumentPendukungLain, created_at as createdAt, updated_at as updatedAt";
        return $builder->select($select)->where('kode_permohonan', $kodePermohonan)->get()->getRowObject();
    }
    
    private function _getDetailPermohonanKtp($kodePermohonan) {
        $builder = $this->_db->table('_permohonan_ktp_tb');
        $select = "id, user_id as userId, kode_permohonan as kodePermohonan, nik_pemohon as nikPemohon, kk_pemohon as kkPemohon, nama_pemohon as namaPemohon, tempat_lahir as tempatLahir, tgl_lahir as tglLahir, jenis_kelamin as jenisKelamin, agama, pekerjaan, status_kawin as statusKawin, status_rekaman as statusRekaman, golongan_darah as golonganDarah, alamat, keterangan, kecamatan, lampiran_ktp as lampiranKtp, lampiran_kk as lampiranKk, lampiran_dokument_pendukung_lain as lampiranDokumentPendukungLain, created_at as createdAt, updated_at as updatedAt";
        return $builder->select($select)->where('kode_permohonan', $kodePermohonan)->get()->getRowObject();
    }
    
    private function _getDetailPermohonanCekNik($kodePermohonan) {
        $builder = $this->_db->table('_permohonan_cek_nik_tb');
        $select = "id, user_id as userId, kode_permohonan as kodePermohonan, nik_pemohon as nikPemohon, kk_pemohon as kkPemohon, nama_pemohon as namaPemohon, tgl_rekaman as tglRekaman, jenis_cek as jenisCek, keterangan, kecamatan, lampiran_ktp as lampiranKtp, lampiran_kk as lampiranKk, lampiran_dokument_pendukung_lain as lampiranDokumentPendukungLain, created_at as createdAt, updated_at as updatedAt";
        return $builder->select($select)->where('kode_permohonan', $kodePermohonan)->get()->getRowObject();
    }
    
    private function _getDetailPermohonanUpdateData($kodePermohonan) {
        $builder = $this->_db->table('_permohonan_update_data_tb');
        $select = "id, user_id as userId, kode_permohonan as kodePermohonan, kk_pemohon as kkPemohon, nik_suami as nikSuami, nama_suami as namaSuami, nik_istri as nikIstri, nama_istri as namaIstri, nik_anak1 as nikAnak1, nama_anak1 as namaAnak1, nik_anak2 as nikAnak2, nama_anak2 as namaAnak2, nik_anak3 as nikAnak3, nama_anak3 as namaAnak3, nik_anak4 as nikAnak4, nama_anak4 as namaAnak4, nik_anak5 as nikAnak5, nama_anak5 as namaAnak5, jumlah_anak as jumlahAnak, keterangan, kecamatan, lampiran_ktp as lampiranKtp, lampiran_kk as lampiranKk, lampiran_dokument_pendukung_lain as lampiranDokumentPendukungLain, created_at as createdAt, updated_at as updatedAt";
        return $builder->select($select)->where('kode_permohonan', $kodePermohonan)->get()->getRowObject();
    }
    
    private function _getDetailPermohonanAktePerceraian($kodePermohonan) {
        $builder = $this->_db->table('_permohonan_akte_perceraian_tb');
        $select = "id, user_id as userId, kode_permohonan as kodePermohonan, nik_pemohon as nikPemohon, kk_pemohon as kkPemohon, nama_pemohon as namaPemohon, alamat, tempat_lahir as tempatLahir, tgl_lahir as tglLahir, jenis_kelamin as jenisKelamin, keterangan, kecamatan, lampiran_ktp as lampiranKtp, lampiran_kk as lampiranKk, lampiran_akta_pernikahan as lampiranAktaPerkawinan, lampiran_formulir_akte as lampiranFormulirAkte, lampiran_surat_keterangan_cerai as lampiranSuratKeteranganCerai, lampiran_dokument_pendukung_lain as lampiranDokumentPendukungLain, created_at as createdAt, updated_at as updatedAt";
        return $builder->select($select)->where('kode_permohonan', $kodePermohonan)->get()->getRowObject();
    }
    
    private function _getDetailPermohonanAkteKematian($kodePermohonan) {
        $builder = $this->_db->table('_permohonan_akte_kematian_tb');
        $select = "id, user_id as userId, kode_permohonan as kodePermohonan, nik_pelapor as nikPelapor, kk_pelapor as kkPelapor, nama_pelapor as namaPelapor, alamat_pelapor as alamatPelapor, kecamatan, hubungan, nik_almarhum as nikAlmarhum, kk_almarhum as kkAlmarhum, nama_almarhum as namaAlmarhum, tempat_kematian as tempatkematian, tgl_kematian as tglKematian, waktu_kematian as waktuKematian, sebab_kematian as sebabKematian, jenis_kelamin_almarhum as jenisKelaminAlmarhum, saksi_1 as saksi1, saksi_2 as saksi2, keterangan, lampiran_ktp as lampiranKtp, lampiran_kk as lampiranKk, lampiran_formulir_akte as lampiranFormulirAkte, lampiran_surat_keterangan_kematian as lampiranSuratKeteranganKematian, lampiran_dokument_pendukung_lain as lampiranDokumentPendukungLain, created_at as createdAt, updated_at as updatedAt";
        return $builder->select($select)->where('kode_permohonan', $kodePermohonan)->get()->getRowObject();
    }
    
    private function _getDetailPermohonanAktePerkawinan($kodePermohonan) {
        $builder = $this->_db->table('_permohonan_akte_perkawinan_tb');
        $select = "id, user_id as userId, kode_permohonan as kodePermohonan, nik_suami as nikSuami, kk_suami as kkSuami, nama_suami as namaSuami, agama_suami as agamaSuami, alamat_suami as alamatSuami, nik_istri as nikIstri, kk_istri as kkIstri, nama_istri as namaIstri, agama_istri as agamaIstri, alamat_istri as alamatIstri, kecamatan, nama_pemuka_agama as namaPemukaAgama, tempat_perkawinan as tempatPerkawinan, tgl_perkawinan as tglPerkawinan, agama_kepercayaan as agamaKepercayaan, saksi_1 as saksi1, saksi_2 as saksi2, keterangan, lampiran_ktp as lampiranKtp, lampiran_kk as lampiranKk, lampiran_foto_gandeng as lampiranFotoGandeng, lampiran_surat_keterangan_perkawinan as lampiranSuratKeteranganPerkawinan, lampiran_akte_kelahiran_suami as lampiranAkteKelahiranSuami, lampiran_akte_kelahiran_istri as lampiranAkteKelahiranIstri, lampiran_dokument_pendukung_lain as lampiranDokumentPendukungLain, created_at as createdAt, updated_at as updatedAt";
        return $builder->select($select)->where('kode_permohonan', $kodePermohonan)->get()->getRowObject();
    }
    
    private function _getDetailPermohonanSuratPindah($kodePermohonan) {
        $builder = $this->_db->table('_permohonan_surat_pindah_tb a');
        $select = "a.id, a.user_id as userId, a.kode_permohonan as kodePermohonan, a.nik_pemohon as nikPemohon, a.kk_pemohon as kkPemohon, a.nama_pemohon as namaPemohon, a.alamat_saat_ini as alamatSaatIni, a.alamat_tujuan as alamatTujuan, a.provinsi_tujuan as idProvinsiTujuan, a.kabupaten_tujuan as idKabupatenTujuan, a.kecamatan_tujuan as idKecamatanTujuan, a.kelurahan_tujuan as idKelurahanTujuan, a.alasan_pindah as alasanPindah, a.jumlah_anggota as jumlahAnggota, a.keterangan, a.kecamatan, a.lampiran_ktp as lampiranKtp, a.lampiran_kk as lampiranKk, a.lampiran_formulir_pindah as lampiranFormulirPindah, a.lampiran_dokument_pendukung_lain as lampiranDokumentPendukungLain, a.created_at as createdAt, a.updated_at as updatedAt, b.provinsi as provinsiTujuan, c.kabupaten as kabupatenTujuan, d.kecamatan as kecamatanTujuan, e.kelurahan as kelurahanTujuan";
        return $builder->select($select)->join('ref_tbl_provinsi b','b.id = a.provinsi_tujuan')->join('ref_tbl_kabupaten c','c.id=a.kabupaten_tujuan')->join('ref_tbl_kecamatan d', 'd.id=a.kecamatan_tujuan')->join('ref_tbl_kelurahan e', 'e.id=a.kelurahan_tujuan')->where('kode_permohonan', $kodePermohonan)->get()->getRowObject();
    }
    
    public function getDetailPermohonananKk($kodePermohonan){
        $select = "_permohonan_tb_b.id as idPermohonan, _permohonan_tb_b.user_id as userId, _permohonan_tb_b.kode_permohonan as kodePermohonan, _permohonan_tb_b.jenis_permohonan as jenisPermohonan, _permohonan_tb_b.status_permohonan as statusPermohonan, _permohonan_tb_b.type_file as typeFile, _permohonan_tb_b.file_lampiran as fileLampiran, _permohonan_tb_b.keterangan_tolak as keteranganTolak, _permohonan_tb_b.keterangan_selesai as keteranganSelesai, _permohonan_tb_b.created_at as createdAt, _permohonan_tb_b.updated_at as updatedAt, _permohonan_tb_b.updated_to_prosses as updatedToProsses, _permohonan_tb_b.updated_to_batal as updatedToBatal, _permohonan_tb_b.updated_to_selesai as updatedToSelesai";
        $where = "kode_permohonan = '$kodePermohonan'";
        $permohonan = $this->_builder->select($select)
                        ->where($where)->get()->getRowObject();
        if($permohonan){
            $permohonan->detailPermohonanKk = $this->_getDetailPermohonanKk($permohonan->kodePermohonan);
            
            return $permohonan;
        } else {
            return null;
        }
    }
    
    public function getDetailPermohonananAkteKelahiran($kodePermohonan){
        $select = "_permohonan_tb_b.id as idPermohonan, _permohonan_tb_b.user_id as userId, _permohonan_tb_b.kode_permohonan as kodePermohonan, _permohonan_tb_b.jenis_permohonan as jenisPermohonan, _permohonan_tb_b.status_permohonan as statusPermohonan, _permohonan_tb_b.type_file as typeFile, _permohonan_tb_b.file_lampiran as fileLampiran, _permohonan_tb_b.keterangan_tolak as keteranganTolak, _permohonan_tb_b.keterangan_selesai as keteranganSelesai, _permohonan_tb_b.created_at as createdAt, _permohonan_tb_b.updated_at as updatedAt, _permohonan_tb_b.updated_to_prosses as updatedToProsses, _permohonan_tb_b.updated_to_batal as updatedToBatal, _permohonan_tb_b.updated_to_selesai as updatedToSelesai";
        $where = "kode_permohonan = '$kodePermohonan'";
        $permohonan = $this->_builder->select($select)
                        ->where($where)->get()->getRowObject();
        if($permohonan){
            $permohonan->detailPermohonanAkteKelahiran = $this->_getDetailPermohonanAkteKelahiran($permohonan->kodePermohonan);
            
            return $permohonan;
        } else {
            return null;
        }
    }
    
    public function getDetailPermohonananKia($kodePermohonan){
        $select = "_permohonan_tb_b.id as idPermohonan, _permohonan_tb_b.user_id as userId, _permohonan_tb_b.kode_permohonan as kodePermohonan, _permohonan_tb_b.jenis_permohonan as jenisPermohonan, _permohonan_tb_b.status_permohonan as statusPermohonan, _permohonan_tb_b.type_file as typeFile, _permohonan_tb_b.file_lampiran as fileLampiran, _permohonan_tb_b.keterangan_tolak as keteranganTolak, _permohonan_tb_b.keterangan_selesai as keteranganSelesai, _permohonan_tb_b.created_at as createdAt, _permohonan_tb_b.updated_at as updatedAt, _permohonan_tb_b.updated_to_prosses as updatedToProsses, _permohonan_tb_b.updated_to_batal as updatedToBatal, _permohonan_tb_b.updated_to_selesai as updatedToSelesai";
        $where = "kode_permohonan = '$kodePermohonan'";
        $permohonan = $this->_builder->select($select)
                        ->where($where)->get()->getRowObject();
        if($permohonan){
            $permohonan->detailPermohonanKia = $this->_getDetailPermohonanKia($permohonan->kodePermohonan);
            
            return $permohonan;
        } else {
            return null;
        }
    }
    
    public function getDetailPermohonananKtp($kodePermohonan){
        $select = "_permohonan_tb_b.id as idPermohonan, _permohonan_tb_b.user_id as userId, _permohonan_tb_b.kode_permohonan as kodePermohonan, _permohonan_tb_b.jenis_permohonan as jenisPermohonan, _permohonan_tb_b.status_permohonan as statusPermohonan, _permohonan_tb_b.type_file as typeFile, _permohonan_tb_b.file_lampiran as fileLampiran, _permohonan_tb_b.keterangan_tolak as keteranganTolak, _permohonan_tb_b.keterangan_selesai as keteranganSelesai, _permohonan_tb_b.created_at as createdAt, _permohonan_tb_b.updated_at as updatedAt, _permohonan_tb_b.updated_to_prosses as updatedToProsses, _permohonan_tb_b.updated_to_batal as updatedToBatal, _permohonan_tb_b.updated_to_selesai as updatedToSelesai";
        $where = "kode_permohonan = '$kodePermohonan'";
        $permohonan = $this->_builder->select($select)
                        ->where($where)->get()->getRowObject();
        if($permohonan){
            $permohonan->detailPermohonanKtp = $this->_getDetailPermohonanKtp($permohonan->kodePermohonan);
            
            return $permohonan;
        } else {
            return null;
        }
    }
    
    public function getDetailPermohonananCekNik($kodePermohonan){
        $select = "_permohonan_tb_b.id as idPermohonan, _permohonan_tb_b.user_id as userId, _permohonan_tb_b.kode_permohonan as kodePermohonan, _permohonan_tb_b.jenis_permohonan as jenisPermohonan, _permohonan_tb_b.status_permohonan as statusPermohonan, _permohonan_tb_b.type_file as typeFile, _permohonan_tb_b.file_lampiran as fileLampiran, _permohonan_tb_b.keterangan_tolak as keteranganTolak, _permohonan_tb_b.keterangan_selesai as keteranganSelesai, _permohonan_tb_b.created_at as createdAt, _permohonan_tb_b.updated_at as updatedAt, _permohonan_tb_b.updated_to_prosses as updatedToProsses, _permohonan_tb_b.updated_to_batal as updatedToBatal, _permohonan_tb_b.updated_to_selesai as updatedToSelesai";
        $where = "kode_permohonan = '$kodePermohonan'";
        $permohonan = $this->_builder->select($select)
                        ->where($where)->get()->getRowObject();
        if($permohonan){
            $permohonan->detailPermohonanCekNik = $this->_getDetailPermohonanCekNik($permohonan->kodePermohonan);
            
            return $permohonan;
        } else {
            return null;
        }
    }
    
    public function getDetailPermohonananUpdateData($kodePermohonan){
        $select = "_permohonan_tb_b.id as idPermohonan, _permohonan_tb_b.user_id as userId, _permohonan_tb_b.kode_permohonan as kodePermohonan, _permohonan_tb_b.jenis_permohonan as jenisPermohonan, _permohonan_tb_b.status_permohonan as statusPermohonan, _permohonan_tb_b.type_file as typeFile, _permohonan_tb_b.file_lampiran as fileLampiran, _permohonan_tb_b.keterangan_tolak as keteranganTolak, _permohonan_tb_b.keterangan_selesai as keteranganSelesai, _permohonan_tb_b.created_at as createdAt, _permohonan_tb_b.updated_at as updatedAt, _permohonan_tb_b.updated_to_prosses as updatedToProsses, _permohonan_tb_b.updated_to_batal as updatedToBatal, _permohonan_tb_b.updated_to_selesai as updatedToSelesai";
        $where = "kode_permohonan = '$kodePermohonan'";
        $permohonan = $this->_builder->select($select)
                        ->where($where)->get()->getRowObject();
        if($permohonan){
            $permohonan->detailPermohonanUpdateData = $this->_getDetailPermohonanUpdateData($permohonan->kodePermohonan);
            
            return $permohonan;
        } else {
            return null;
        }
    }
    
    public function getDetailPermohonananAktePerceraian($kodePermohonan){
        $select = "_permohonan_tb_b.id as idPermohonan, _permohonan_tb_b.user_id as userId, _permohonan_tb_b.kode_permohonan as kodePermohonan, _permohonan_tb_b.jenis_permohonan as jenisPermohonan, _permohonan_tb_b.status_permohonan as statusPermohonan, _permohonan_tb_b.type_file as typeFile, _permohonan_tb_b.file_lampiran as fileLampiran, _permohonan_tb_b.keterangan_tolak as keteranganTolak, _permohonan_tb_b.keterangan_selesai as keteranganSelesai, _permohonan_tb_b.created_at as createdAt, _permohonan_tb_b.updated_at as updatedAt, _permohonan_tb_b.updated_to_prosses as updatedToProsses, _permohonan_tb_b.updated_to_batal as updatedToBatal, _permohonan_tb_b.updated_to_selesai as updatedToSelesai";
        $where = "kode_permohonan = '$kodePermohonan'";
        $permohonan = $this->_builder->select($select)
                        ->where($where)->get()->getRowObject();
        if($permohonan){
            $permohonan->detailPermohonanAktePerceraian = $this->_getDetailPermohonanAktePerceraian($permohonan->kodePermohonan);
            
            return $permohonan;
        } else {
            return null;
        }
    }
    
    public function getDetailPermohonananAkteKematian($kodePermohonan){
        $select = "_permohonan_tb_b.id as idPermohonan, _permohonan_tb_b.user_id as userId, _permohonan_tb_b.kode_permohonan as kodePermohonan, _permohonan_tb_b.jenis_permohonan as jenisPermohonan, _permohonan_tb_b.status_permohonan as statusPermohonan, _permohonan_tb_b.type_file as typeFile, _permohonan_tb_b.file_lampiran as fileLampiran, _permohonan_tb_b.keterangan_tolak as keteranganTolak, _permohonan_tb_b.keterangan_selesai as keteranganSelesai, _permohonan_tb_b.created_at as createdAt, _permohonan_tb_b.updated_at as updatedAt, _permohonan_tb_b.updated_to_prosses as updatedToProsses, _permohonan_tb_b.updated_to_batal as updatedToBatal, _permohonan_tb_b.updated_to_selesai as updatedToSelesai";
        $where = "kode_permohonan = '$kodePermohonan'";
        $permohonan = $this->_builder->select($select)
                        ->where($where)->get()->getRowObject();
        if($permohonan){
            $permohonan->detailPermohonanAkteKematian = $this->_getDetailPermohonanAkteKematian($permohonan->kodePermohonan);
            
            return $permohonan;
        } else {
            return null;
        }
    }
    
    public function getDetailPermohonananAktePerkawinan($kodePermohonan){
        $select = "_permohonan_tb_b.id as idPermohonan, _permohonan_tb_b.user_id as userId, _permohonan_tb_b.kode_permohonan as kodePermohonan, _permohonan_tb_b.jenis_permohonan as jenisPermohonan, _permohonan_tb_b.status_permohonan as statusPermohonan, _permohonan_tb_b.type_file as typeFile, _permohonan_tb_b.file_lampiran as fileLampiran, _permohonan_tb_b.keterangan_tolak as keteranganTolak, _permohonan_tb_b.keterangan_selesai as keteranganSelesai, _permohonan_tb_b.created_at as createdAt, _permohonan_tb_b.updated_at as updatedAt, _permohonan_tb_b.updated_to_prosses as updatedToProsses, _permohonan_tb_b.updated_to_batal as updatedToBatal, _permohonan_tb_b.updated_to_selesai as updatedToSelesai";
        $where = "kode_permohonan = '$kodePermohonan'";
        $permohonan = $this->_builder->select($select)
                        ->where($where)->get()->getRowObject();
        if($permohonan){
            $permohonan->detailPermohonanAktePerkawinan = $this->_getDetailPermohonanAktePerkawinan($permohonan->kodePermohonan);
            
            return $permohonan;
        } else {
            return null;
        }
    }
    
    public function getDetailPermohonananSuratPindah($kodePermohonan){
        $select = "_permohonan_tb_b.id as idPermohonan, _permohonan_tb_b.user_id as userId, _permohonan_tb_b.kode_permohonan as kodePermohonan, _permohonan_tb_b.jenis_permohonan as jenisPermohonan, _permohonan_tb_b.status_permohonan as statusPermohonan, _permohonan_tb_b.type_file as typeFile, _permohonan_tb_b.file_lampiran as fileLampiran, _permohonan_tb_b.keterangan_tolak as keteranganTolak, _permohonan_tb_b.keterangan_selesai as keteranganSelesai, _permohonan_tb_b.created_at as createdAt, _permohonan_tb_b.updated_at as updatedAt, _permohonan_tb_b.updated_to_prosses as updatedToProsses, _permohonan_tb_b.updated_to_batal as updatedToBatal, _permohonan_tb_b.updated_to_selesai as updatedToSelesai";
        $where = "kode_permohonan = '$kodePermohonan'";
        $permohonan = $this->_builder->select($select)
                        ->where($where)->get()->getRowObject();
        if($permohonan){
            $permohonan->detailPermohonanSuratPindah = $this->_getDetailPermohonanSuratPindah($permohonan->kodePermohonan);
            
            return $permohonan;
        } else {
            return null;
        }
    }
    
    public function getPermohonanUser($userId, $status, $limit, $start) {
        $select = "_permohonan_tb_b.id as idPermohonan, _permohonan_tb_b.user_id as userId, _permohonan_tb_b.kode_permohonan as kodePermohonan, _permohonan_tb_b.jenis_permohonan as jenisPermohonan, _permohonan_tb_b.status_permohonan as statusPermohonan, _permohonan_tb_b.type_file as typeFile, _permohonan_tb_b.file_lampiran as fileLampiran, _permohonan_tb_b.keterangan_tolak as keteranganTolak, _permohonan_tb_b.keterangan_selesai as keteranganSelesai, _permohonan_tb_b.created_at as createdAt, _permohonan_tb_b.updated_at as updatedAt, _permohonan_tb_b.updated_to_prosses as updatedToProsses, _permohonan_tb_b.updated_to_batal as updatedToBatal, _permohonan_tb_b.updated_to_selesai as updatedToSelesai";
        $where = "user_id = '$userId' AND status_permohonan = $status";
        $permohonans = $this->_builder->select($select)
                        ->where($where)->orderBy('_permohonan_tb_b.created_at','desc')->limit($limit, $start)->get()->getResult();
        $findAll = $this->_builder->where($where)->get()->getResult();
        $totalResult = count($findAll);
        //var_dump($permohonans);die;
        if(count($permohonans) > 0) {
            $results = [];
            foreach ($permohonans as $val) {
                if($val->jenisPermohonan == "KK") {
                    $detailKk = $this->_getDetailPermohonanKk($val->kodePermohonan);
                    $result['idPermohonan'] = $val->idPermohonan;
                    $result['userId'] = $val->userId;
                    $result['kodePermohonan'] = $val->kodePermohonan;
                    $result['jenisPermohonan'] = $val->jenisPermohonan;
                    $result['statusPermohonan'] = $val->statusPermohonan;
                    $result['typeFile'] = $val->typeFile;
                    $result['fileLampiran'] = $val->fileLampiran;
                    $result['keteranganTolak'] = $val->keteranganTolak;
                    $result['keteranganSelesai'] = $val->keteranganSelesai;
                    $result['createdAt'] = $val->createdAt;
                    $result['updatedAt'] = $val->updatedAt;
                    $result['updatedToProsses'] = $val->updatedToProsses;
                    $result['updatedToBatal'] = $val->updatedToBatal;
                    $result['updatedToSelesai'] = $val->updatedToSelesai;
                    $result['detailPermohonanKk'] = $detailKk;
                    
                    $results[] = $result;
                } else if ($val->jenisPermohonan == "AKTAKEL"){
                    $detailKelahiran = $this->_getDetailPermohonanAkteKelahiran($val->kodePermohonan);
                    $result['idPermohonan'] = $val->idPermohonan;
                    $result['userId'] = $val->userId;
                    $result['kodePermohonan'] = $val->kodePermohonan;
                    $result['jenisPermohonan'] = $val->jenisPermohonan;
                    $result['statusPermohonan'] = $val->statusPermohonan;
                    $result['typeFile'] = $val->typeFile;
                    $result['fileLampiran'] = $val->fileLampiran;
                    $result['keteranganTolak'] = $val->keteranganTolak;
                    $result['keteranganSelesai'] = $val->keteranganSelesai;
                    $result['createdAt'] = $val->createdAt;
                    $result['updatedAt'] = $val->updatedAt;
                    $result['updatedToProsses'] = $val->updatedToProsses;
                    $result['updatedToBatal'] = $val->updatedToBatal;
                    $result['updatedToSelesai'] = $val->updatedToSelesai;
                    $result['detailPermohonanAkteKelahiran'] = $detailKelahiran;
                    
                    $results[] = $result;
                } else if ($val->jenisPermohonan == "KIA"){
                    $detailKia = $this->_getDetailPermohonanKia($val->kodePermohonan);
                    $result['idPermohonan'] = $val->idPermohonan;
                    $result['userId'] = $val->userId;
                    $result['kodePermohonan'] = $val->kodePermohonan;
                    $result['jenisPermohonan'] = $val->jenisPermohonan;
                    $result['statusPermohonan'] = $val->statusPermohonan;
                    $result['typeFile'] = $val->typeFile;
                    $result['fileLampiran'] = $val->fileLampiran;
                    $result['keteranganTolak'] = $val->keteranganTolak;
                    $result['keteranganSelesai'] = $val->keteranganSelesai;
                    $result['createdAt'] = $val->createdAt;
                    $result['updatedAt'] = $val->updatedAt;
                    $result['updatedToProsses'] = $val->updatedToProsses;
                    $result['updatedToBatal'] = $val->updatedToBatal;
                    $result['updatedToSelesai'] = $val->updatedToSelesai;
                    $result['detailPermohonanKia'] = $detailKia;
                    
                    $results[] = $result;
                } else if ($val->jenisPermohonan == "KTP"){
                    $detailKtp = $this->_getDetailPermohonanKtp($val->kodePermohonan);
                    $result['idPermohonan'] = $val->idPermohonan;
                    $result['userId'] = $val->userId;
                    $result['kodePermohonan'] = $val->kodePermohonan;
                    $result['jenisPermohonan'] = $val->jenisPermohonan;
                    $result['statusPermohonan'] = $val->statusPermohonan;
                    $result['typeFile'] = $val->typeFile;
                    $result['fileLampiran'] = $val->fileLampiran;
                    $result['keteranganTolak'] = $val->keteranganTolak;
                    $result['keteranganSelesai'] = $val->keteranganSelesai;
                    $result['createdAt'] = $val->createdAt;
                    $result['updatedAt'] = $val->updatedAt;
                    $result['updatedToProsses'] = $val->updatedToProsses;
                    $result['updatedToBatal'] = $val->updatedToBatal;
                    $result['updatedToSelesai'] = $val->updatedToSelesai;
                    $result['detailPermohonanKtp'] = $detailKtp;
                    
                    $results[] = $result;
                } else if ($val->jenisPermohonan == "CEKNIK"){
                    $detailNik = $this->_getDetailPermohonanCekNik($val->kodePermohonan);
                    $result['idPermohonan'] = $val->idPermohonan;
                    $result['userId'] = $val->userId;
                    $result['kodePermohonan'] = $val->kodePermohonan;
                    $result['jenisPermohonan'] = $val->jenisPermohonan;
                    $result['statusPermohonan'] = $val->statusPermohonan;
                    $result['typeFile'] = $val->typeFile;
                    $result['fileLampiran'] = $val->fileLampiran;
                    $result['keteranganTolak'] = $val->keteranganTolak;
                    $result['keteranganSelesai'] = $val->keteranganSelesai;
                    $result['createdAt'] = $val->createdAt;
                    $result['updatedAt'] = $val->updatedAt;
                    $result['updatedToProsses'] = $val->updatedToProsses;
                    $result['updatedToBatal'] = $val->updatedToBatal;
                    $result['updatedToSelesai'] = $val->updatedToSelesai;
                    $result['detailPermohonanCekNik'] = $detailNik;
                    
                    $results[] = $result;
                } else if ($val->jenisPermohonan == "UPDATEDATA"){
                    $detailUpdate = $this->_getDetailPermohonanUpdateData($val->kodePermohonan);
                    $result['idPermohonan'] = $val->idPermohonan;
                    $result['userId'] = $val->userId;
                    $result['kodePermohonan'] = $val->kodePermohonan;
                    $result['jenisPermohonan'] = $val->jenisPermohonan;
                    $result['statusPermohonan'] = $val->statusPermohonan;
                    $result['typeFile'] = $val->typeFile;
                    $result['fileLampiran'] = $val->fileLampiran;
                    $result['keteranganTolak'] = $val->keteranganTolak;
                    $result['keteranganSelesai'] = $val->keteranganSelesai;
                    $result['createdAt'] = $val->createdAt;
                    $result['updatedAt'] = $val->updatedAt;
                    $result['updatedToProsses'] = $val->updatedToProsses;
                    $result['updatedToBatal'] = $val->updatedToBatal;
                    $result['updatedToSelesai'] = $val->updatedToSelesai;
                    $result['detailPermohonanUpdateData'] = $detailUpdate;
                    
                    $results[] = $result;
                } else if ($val->jenisPermohonan == "AKTACER"){
                    $detailCerai = $this->_getDetailPermohonanAktePerceraian($val->kodePermohonan);
                    $result['idPermohonan'] = $val->idPermohonan;
                    $result['userId'] = $val->userId;
                    $result['kodePermohonan'] = $val->kodePermohonan;
                    $result['jenisPermohonan'] = $val->jenisPermohonan;
                    $result['statusPermohonan'] = $val->statusPermohonan;
                    $result['typeFile'] = $val->typeFile;
                    $result['fileLampiran'] = $val->fileLampiran;
                    $result['keteranganTolak'] = $val->keteranganTolak;
                    $result['keteranganSelesai'] = $val->keteranganSelesai;
                    $result['createdAt'] = $val->createdAt;
                    $result['updatedAt'] = $val->updatedAt;
                    $result['updatedToProsses'] = $val->updatedToProsses;
                    $result['updatedToBatal'] = $val->updatedToBatal;
                    $result['updatedToSelesai'] = $val->updatedToSelesai;
                    $result['detailPermohonanAktePerceraian'] = $detailCerai;
                    
                    $results[] = $result;
                } else if ($val->jenisPermohonan == "AKTAKEMATIAN"){
                    $detailWafat = $this->_getDetailPermohonanAkteKematian($val->kodePermohonan);
                    $result['idPermohonan'] = $val->idPermohonan;
                    $result['userId'] = $val->userId;
                    $result['kodePermohonan'] = $val->kodePermohonan;
                    $result['jenisPermohonan'] = $val->jenisPermohonan;
                    $result['statusPermohonan'] = $val->statusPermohonan;
                    $result['typeFile'] = $val->typeFile;
                    $result['fileLampiran'] = $val->fileLampiran;
                    $result['keteranganTolak'] = $val->keteranganTolak;
                    $result['keteranganSelesai'] = $val->keteranganSelesai;
                    $result['createdAt'] = $val->createdAt;
                    $result['updatedAt'] = $val->updatedAt;
                    $result['updatedToProsses'] = $val->updatedToProsses;
                    $result['updatedToBatal'] = $val->updatedToBatal;
                    $result['updatedToSelesai'] = $val->updatedToSelesai;
                    $result['detailPermohonanAkteKematian'] = $detailWafat;
                    
                    $results[] = $result;
                } else if ($val->jenisPermohonan == "AKTAKAWIN"){
                    $detailKawin = $this->_getDetailPermohonanAktePerkawinan($val->kodePermohonan);
                    $result['idPermohonan'] = $val->idPermohonan;
                    $result['userId'] = $val->userId;
                    $result['kodePermohonan'] = $val->kodePermohonan;
                    $result['jenisPermohonan'] = $val->jenisPermohonan;
                    $result['statusPermohonan'] = $val->statusPermohonan;
                    $result['typeFile'] = $val->typeFile;
                    $result['fileLampiran'] = $val->fileLampiran;
                    $result['keteranganTolak'] = $val->keteranganTolak;
                    $result['keteranganSelesai'] = $val->keteranganSelesai;
                    $result['createdAt'] = $val->createdAt;
                    $result['updatedAt'] = $val->updatedAt;
                    $result['updatedToProsses'] = $val->updatedToProsses;
                    $result['updatedToBatal'] = $val->updatedToBatal;
                    $result['updatedToSelesai'] = $val->updatedToSelesai;
                    $result['detailPermohonanAktePerkawinan'] = $detailKawin;
                    
                    $results[] = $result;
                } else if ($val->jenisPermohonan == "SRTPINDAH"){
                    $detailPindah = $this->_getDetailPermohonanSuratPindah($val->kodePermohonan);
                    $result['idPermohonan'] = $val->idPermohonan;
                    $result['userId'] = $val->userId;
                    $result['kodePermohonan'] = $val->kodePermohonan;
                    $result['jenisPermohonan'] = $val->jenisPermohonan;
                    $result['statusPermohonan'] = $val->statusPermohonan;
                    $result['typeFile'] = $val->typeFile;
                    $result['fileLampiran'] = $val->fileLampiran;
                    $result['keteranganTolak'] = $val->keteranganTolak;
                    $result['keteranganSelesai'] = $val->keteranganSelesai;
                    $result['createdAt'] = $val->createdAt;
                    $result['updatedAt'] = $val->updatedAt;
                    $result['updatedToProsses'] = $val->updatedToProsses;
                    $result['updatedToBatal'] = $val->updatedToBatal;
                    $result['updatedToSelesai'] = $val->updatedToSelesai;
                    $result['detailPermohonanSuratPindah'] = $detailPindah;
                    
                    $results[] = $result;
                }else{
                    
                }
            }
            
            $data = [
                'totalResult' => $totalResult,
                'result' => $results,
            ];
            
            return $data;
        } else {
            return null;
        }
    }
    
    private function _getDataPermohonanReturn($kodePermohonan)
    {
        $kode = explode("-", $kodePermohonan);
            
        if($kode[0] == "KK"){
            return $this->getDetailPermohonananKk($kodePermohonan);
        }else if($kode[0] == "AKTAKEL") {
            return $this->getDetailPermohonananAkteKelahiran($kodePermohonan);
        }else if($kode[0] == "KIA") {
            return $this->getDetailPermohonananKia($kodePermohonan);
        }else if($kode[0] == "KTP") {
            return $this->getDetailPermohonananKtp($kodePermohonan);
        }else if($kode[0] == "CEKNIK") {
            return $this->getDetailPermohonananCekNik($kodePermohonan);
        }else if($kode[0] == "UPDATEDATA") {
            return $this->getDetailPermohonananUpdateData($kodePermohonan);
        }else if($kode[0] == "AKTACER") {
            return $this->getDetailPermohonananAktePerceraian($kodePermohonan);
        }else if($kode[0] == "AKTAKEMATIAN") {
            return $this->getDetailPermohonananAkteKematian($kodePermohonan);
        }else if($kode[0] == "AKTAKAWIN") {
            $result = $permohonanLib->getDetailPermohonananAktePerkawinan($kodePermohonan);
        }else if($kode[0] == "SRTPINDAH") {
            return $this->getDetailPermohonananSuratPindah($kodePermohonan);
        }else {
            return $this->getDetailPermohonananSuratPindah($kodePermohonan);
        }
    }
    
    public function changeToTolak($userId, $pemohon, $kodePermohonan, $keterangan)
    {
        $date = date('Y-m-d H:i:s');
        $dataUpdate = [
            'keterangan_tolak' => $keterangan,
            'status_permohonan' => 3,
            'user_confirm_batal' => $userId,
            'updated_to_batal' => $date,
            'updated_at' => $date
        ];
        
        $this->_builder->where('kode_permohonan', $kodePermohonan)->update($dataUpdate);
      
      	if($this->_db->affectedRows() > 0) {
      	    return $this->_getDataPermohonanReturn($kodePermohonan);
        }else {
          	return false;
        }
    }
    
    public function changeToProses($userId, $pemohon, $kodePermohonan)
    {
        $date = date('Y-m-d H:i:s');
        $dataUpdate = [
            'status_permohonan' => 1,
            'user_confirm_proses' => $userId,
            'updated_to_prosses' => $date,
            'updated_at' => $date
        ];
        
        $this->_builder->where('kode_permohonan', $kodePermohonan)->update($dataUpdate);
      
      	if($this->_db->affectedRows() > 0) {
      	    return $this->_getDataPermohonanReturn($kodePermohonan);
        }else {
          	return false;
        }
    }
    
    public function changeToSelesai($userId, $pemohon, $kodePermohonan, $keterangan="Sudah selesai", $newNamelampiran=null, $typeFile = 0)
    {
        $date = date('Y-m-d H:i:s');
        $dataUpdate = [
            'status_permohonan' => 2,
            'keterangan_selesai' => $keterangan,
            'user_confrim_selesai' => $userId,
            'updated_to_selesai' => $date,
            'updated_at' => $date
        ];
        
        if($newNamelampiran != null) {
            $dataUpdate['file_lampiran'] = $newNamelampiran;
            $dataUpdate['type_file'] = $typeFile;
        }
        
        $this->_builder->where('kode_permohonan', $kodePermohonan)->update($dataUpdate);
      
      	if($this->_db->affectedRows() > 0) {
      	    return $this->_getDataPermohonanReturn($kodePermohonan);
        }else {
          	return false;
        }
    }
    
    public function getDokumentSelesai($userId)
    {
        $select = "id, kode_permohonan as kodePermohonan, jenis_permohonan as jenisPermohonan, type_file as typeFile, file_lampiran as fileLampiran, updated_to_selesai as tanggal";
        $where = "user_id = '$userId' AND status_permohonan = 2 AND file_lampiran IS NOT NULL";
        return $this->_builder->select($select)->where($where)->orderBy('updated_to_selesai', 'desc')->get()->getResult();
    }
}
  