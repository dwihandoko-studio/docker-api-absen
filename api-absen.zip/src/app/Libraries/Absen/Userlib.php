<?php

namespace App\Libraries\Absen;

class Userlib
{
  	private $_db;
  	function __construct()
    {
        helper(['text', 'array', 'filesystem']);
     	$this->_db      = \Config\Database::connect();
    }
    
    public function cekUser($instansiInduk, $nik, $email, $nohp) {
        $builder = $this->_db->table('_profil_users_tb');
        $where= "instansi_induk = '$instansiInduk' AND (nik = '$nik' OR no_hp = '$nohp' OR email = '$email')";
        return $builder->where($where)->countAllResults();
    }
    
    public function getUser($userId) 
    {
        $builder = $this->_db->table('_profil_users_tb');
        $where= "id = '$userId'";
        return $builder->where($where)->get()->getRowObject();
    }
}
  