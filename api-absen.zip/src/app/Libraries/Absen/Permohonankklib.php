<?php

namespace App\Libraries\Capil;
use App\Libraries\Uuid;

class Permohonankklib
{
  	private $_db;
  	private $_builder;
  	function __construct()
    {
        helper(['text', 'array', 'filesystem']);
     	$this->_db      = \Config\Database::connect();
     	$this->_builder = $this->_db->table('_permohonan_kk_tb');
    }
    
    public function getPermohonanUser($userId) {
        $select = "_permohonan_tb_b.id as idPermohonan, _permohonan_tb_b.kode_permohonan as kodePermohonan, _permohonan_tb_b.jenis_permohonan as jenisPermohonan, _permohonan_tb_b.status_permohonan as statusPermohonan, _permohonan_tb_b.type_file as typeFile, _permohonan_tb_b.file_lampiran as fileLampiran, _permohonan_tb_b.created_at as createdAt, _permohonan_tb_b.updated_at as updatedAt, _permohonan_tb_b.updated_to_prosses as updatedToProsses, _permohonan_tb_b.updated_to_batal as updatedToBatal, _permohonan_tb_b.updated_to_selesai as updatedToSelesai";
        $where = "user_id = '$userId'";
        return $this->_builder->select($select)
                    ->join('_permohonan_kk_tb', '_permohonan_kk_tb.kode_permohonan = _permohonan_tb_b.kode_permohonan')
                        ->where($where)->orderBy('_permohonan_tb_b.created_at','desc')->get()->getResult();
                        
    }
}
  