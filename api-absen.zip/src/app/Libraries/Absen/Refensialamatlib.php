<?php

namespace App\Libraries\Absen;

class Refensialamatlib
{
  	private $_db;
  	function __construct()
    {
        helper(['text', 'array', 'filesystem']);
     	$this->_db      = \Config\Database::connect();
    }
    
    public function getInsertKelurahan($id=""){
        $url = "https://dev.farizdotid.com/api/daerahindonesia/kelurahan?id_kecamatan=".$id;
	    $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 0);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 500);
        // curl_setopt($ch, CURLOPT_POSTFIELDS,$encoderData);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        
        $server_output = curl_exec ($ch);

        curl_close ($ch);

        $data = json_decode($server_output);
        $s = $data->kelurahan;
    
        foreach ($s as $val) {
            $dataInsert = [
              'id'=> (string)$val->id,
              'id_kecamatan'=> $val->id_kecamatan,
              'kelurahan'=> $val->nama,
            ];
    
            $builders = $this->_db->table('ref_tbl_kelurahan');
            $inserted = $builders->ignore(true)->insert($dataInsert);
            print_r($val->nama);
        }
        
        return $s;
    }
    
    public function provinsi($id="") {
        $builder = $this->_db->table('ref_tbl_provinsi');
        $builder->select("id, provinsi");
        if($id != "") {
            $where= "id = '$id'";
            $builder->where($where);
        }
        
        return $builder->orderBy('provinsi', 'ASC')->get()->getResult();
    }
    
    public function kabupaten($id="") {
        $builder = $this->_db->table('ref_tbl_kabupaten');
        $builder->select("id, id_provinsi as idProvinsi, kabupaten");
        if($id != "") {
            $where= "id_provinsi = '$id'";
            $builder->where($where);
        }
        
        return $builder->orderBy('kabupaten', 'ASC')->get()->getResult();
    }
    
    public function kecamatan($id="") {
        $builder = $this->_db->table('ref_tbl_kecamatan');
        $builder->select("id, id_kabupaten as idKabupaten, kecamatan");
        if($id != "") {
            $where= "id_kabupaten = '$id'";
            $builder->where($where);
        }
        
        return $builder->orderBy('kecamatan', 'ASC')->get()->getResult();
    }
    
    public function kelurahan($id="") {
        $builder = $this->_db->table('ref_tbl_kelurahan');
        $builder->select("id, id_kecamatan as idKecamatan, kelurahan");
        if($id != "") {
            $where= "id_kecamatan = '$id'";
            $builder->where($where);
        }
        
        return $builder->orderBy('kelurahan', 'ASC')->get()->getResult();
    }
}
  