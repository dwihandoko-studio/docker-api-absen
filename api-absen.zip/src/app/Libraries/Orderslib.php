<?php

namespace App\Libraries;
use App\Libraries\Uuid;

class Orderslib
{
  	private $_db;
  	function __construct()
    {
        helper(['text', 'array', 'filesystem']);
     	$this->_db      = \Config\Database::connect();
    }
  
  	private function _hasAnyProperties($object, array $properties) {
        return array_reduce(
            $properties,
            function ($acc, $property) use ($object) {
                return $acc || property_exists($object, $property);
            },
            false
        );
    }
  
  	private function _getDataOrder($kodeTransaksi){
      	$builder = $this->_db->table('_orders_tb_b');
      	$select = "_orders_tb_b.id, _orders_tb_b.kode_transaksi as kodeTransaksi, _orders_tb_b.jenis_order as jenisOrder, _orders_tb_b.total_harga as totalHarga, _orders_tb_b.total_qty as totalQty, _orders_tb_b.status_order as statusOrder, _orders_tb_b.user_id as userId, _orders_tb_b.created_at as createdAt, _orders_tb_b.updated_at as updatedAt, _profil_users_tb.firsname as userName, _profil_users_tb.no_hp as userNoHp, _profil_users_tb.email as userEmail, _profil_users_tb.saldo as userSaldo, _profil_users_tb.point_reward as userPoinReward";
      	return $builder->select($select)->join('_profil_users_tb','_profil_users_tb.id = _orders_tb_b.user_id')->where('_orders_tb_b.kode_transaksi', $kodeTransaksi)->get()->getRowObject();
    }
  
  	private function _getDetail($orderId, $jenisOrder) {
      
      	if($jenisOrder == "POBPUB") {
          
      		$builder = $this->_db->table('_details_order_ppob_tb_b');
          	$select = "_details_order_ppob_tb_b.id as id, _details_order_ppob_tb_b.order_id  as orderId, _details_order_ppob_tb_b.product_id as productId, _details_order_ppob_tb_b.harga_product as hargaProduct, _details_order_ppob_tb_b.no_pelanggan as noPelanggan, _details_order_ppob_tb_b.jenis_ppob as jenisPpob, _details_order_ppob_tb_b.order_telah_selesai as orderTelahSelesai, _details_order_ppob_tb_b.tanggal_order as tanggalOrder, _details_order_ppob_tb_b.created_at as createdAt, _details_order_ppob_tb_b.updated_at as updatedAt, _details_order_ppob_tb_b.user_id_pembeli as userIdPembeli, _profil_users_tb.firsname as userName, _profil_users_tb.no_hp as userNoHp, _profil_users_tb.email as userEmail, _profil_users_tb.saldo as userSaldo, _profil_users_tb.point_reward as userPoinReward, _daftar_produk_ppob_tb_b.layanan_ppob as layananPpob, _daftar_produk_ppob_tb_b.group_product as groupProduct, _daftar_produk_ppob_tb_b.category_product as categoryProduct, _daftar_produk_ppob_tb_b.kode_product as kodeProduct, _daftar_produk_ppob_tb_b.nama_product as namaProduct, _daftar_produk_ppob_tb_b.title_product as titleProduct, _daftar_produk_ppob_tb_b.nominal as nominalProduct, _daftar_produk_ppob_tb_b.harga as productHargaFromTable, _daftar_produk_ppob_tb_b.poin as poinProduct, _daftar_produk_ppob_tb_b.status_product as statusProduct";
          	return $builder->select($select)->join('_profil_users_tb','_profil_users_tb.id = _details_order_ppob_tb_b.user_id_pembeli')->join('_daftar_produk_ppob_tb_b','_daftar_produk_ppob_tb_b.id = _details_order_ppob_tb_b.product_id')->where('_details_order_ppob_tb_b.order_id', $orderId)->get()->getResult();
          
        } else if ($jenisOrder == "POBTAG") {
          
          	$builder = $this->_db->table('_details_order_tagihan_tb_b');
          	$select = "_details_order_tagihan_tb_b.id, _details_order_tagihan_tb_b.order_id as orderId, _details_order_tagihan_tb_b.jenis_tagihan as jenisTagihan, _details_order_tagihan_tb_b.periode, _details_order_tagihan_tb_b.no_pelanggan as noPelanggan, _details_order_tagihan_tb_b.nama_pelanggan as namaPelanggan, _details_order_tagihan_tb_b.periode_tahun as periodeTahun, _details_order_tagihan_tb_b.periode_bulan as periodeBulan, _details_order_tagihan_tb_b.nominal as nominal, _details_order_tagihan_tb_b.kode_inquiry as kodeInquiry, _details_order_tagihan_tb_b.biaya_admin as biayaAdmin, _details_order_tagihan_tb_b.poin_transaksi as poinTransaksi, _details_order_tagihan_tb_b.order_telah_selesai as orderTelahSelesai, _details_order_tagihan_tb_b.created_at as createdAt, _details_order_tagihan_tb_b.updated_at as updatedAt, _details_order_tagihan_tb_b.user_id_pembeli as userIdPembeli, _details_order_tagihan_tb_b.layanan_ppob as layananPpob, _profil_users_tb.firsname as userName, _profil_users_tb.no_hp as userNoHp, _profil_users_tb.email as userEmail, _profil_users_tb.saldo as userSaldo, _profil_users_tb.point_reward as userPoinReward";
          	return $builder->select($select)->join('_profil_users_tb','_profil_users_tb.id = _details_order_tagihan_tb_b.user_id_pembeli')->where('_details_order_tagihan_tb_b.order_id', $orderId)->get()->getResult();
        } else {
          	$data=[];
          	return $data;
        }
    }
  
  	private function _getDetailWithKodeTransaksi($kodeTransaksi, $jenisOrder) {
      	//$buil = $this->_db->table('_orders_tb_b')->select("distinct(id)")->where('kode_transaksi', $kodeTransaksi);
          //->get()->getRowObject();
      	
      
      	if($jenisOrder == "POBPUB") {
          
      		$builder = $this->_db->table('_details_order_ppob_tb_b');
          	$select = "_details_order_ppob_tb_b.id as id, _details_order_ppob_tb_b.order_id  as orderId, _details_order_ppob_tb_b.product_id as productId, _details_order_ppob_tb_b.harga_product as hargaProduct, _details_order_ppob_tb_b.no_pelanggan as noPelanggan, _details_order_ppob_tb_b.jenis_ppob as jenisPpob, _details_order_ppob_tb_b.order_telah_selesai as orderTelahSelesai, _details_order_ppob_tb_b.tanggal_order as tanggalOrder, _details_order_ppob_tb_b.created_at as createdAt, _details_order_ppob_tb_b.updated_at as updatedAt, _details_order_ppob_tb_b.user_id_pembeli as userIdPembeli, _profil_users_tb.firsname as userName, _profil_users_tb.no_hp as userNoHp, _profil_users_tb.email as userEmail, _profil_users_tb.saldo as userSaldo, _profil_users_tb.point_reward as userPoinReward, _daftar_produk_ppob_tb_b.layanan_ppob as layananPpob, _daftar_produk_ppob_tb_b.group_product as groupProduct, _daftar_produk_ppob_tb_b.category_product as categoryProduct, _daftar_produk_ppob_tb_b.kode_product as kodeProduct, _daftar_produk_ppob_tb_b.nama_product as namaProduct, _daftar_produk_ppob_tb_b.title_product as titleProduct, _daftar_produk_ppob_tb_b.nominal as nominalProduct, _daftar_produk_ppob_tb_b.harga as productHargaFromTable, _daftar_produk_ppob_tb_b.poin as poinProduct, _daftar_produk_ppob_tb_b.status_product as statusProduct, _orders_tb_b.kode_transaksi as kodeTransaksi, _orders_tb_b.jenis_order as jenisOrder, _orders_tb_b.total_harga as totalHarga, _orders_tb_b.total_qty as totalQty, _orders_tb_b.status_order as statusOrder, _orders_tb_b.created_at as orderCreatedAt, _orders_tb_b.updated_at as orderUpdatedAt";
          	return $builder->select($select)->join('_profil_users_tb','_profil_users_tb.id = _details_order_ppob_tb_b.user_id_pembeli')->join('_daftar_produk_ppob_tb_b','_daftar_produk_ppob_tb_b.id = _details_order_ppob_tb_b.product_id')->join('_orders_tb_b','_orders_tb_b.id = _details_order_ppob_tb_b.order_id')->where("_details_order_ppob_tb_b.order_id = (SELECT id FROM _orders_tb_b WHERE kode_transaksi = '$kodeTransaksi')")->orderBy('_details_order_ppob_tb_b.created_at','desc')->get()->getResult();
          
        } else if ($jenisOrder == "POBTAG") {
          
          	$builder = $this->_db->table('_details_order_tagihan_tb_b');
          	$select = "_details_order_tagihan_tb_b.id, _details_order_tagihan_tb_b.order_id as orderId, _details_order_tagihan_tb_b.jenis_tagihan as jenisTagihan, _details_order_tagihan_tb_b.periode, _details_order_tagihan_tb_b.no_pelanggan as noPelanggan, _details_order_tagihan_tb_b.nama_pelanggan as namaPelanggan, _details_order_tagihan_tb_b.periode_tahun as periodeTahun, _details_order_tagihan_tb_b.periode_bulan as periodeBulan, _details_order_tagihan_tb_b.nominal as nominal, _details_order_tagihan_tb_b.kode_inquiry as kodeInquiry, _details_order_tagihan_tb_b.biaya_admin as biayaAdmin, _details_order_tagihan_tb_b.poin_transaksi as poinTransaksi, _details_order_tagihan_tb_b.order_telah_selesai as orderTelahSelesai, _details_order_tagihan_tb_b.created_at as createdAt, _details_order_tagihan_tb_b.updated_at as updatedAt, _details_order_tagihan_tb_b.user_id_pembeli as userIdPembeli, _details_order_tagihan_tb_b.layanan_ppob as layananPpob, _profil_users_tb.firsname as userName, _profil_users_tb.no_hp as userNoHp, _profil_users_tb.email as userEmail, _profil_users_tb.saldo as userSaldo, _profil_users_tb.point_reward as userPoinReward, _orders_tb_b.kode_transaksi as kodeTransaksi, _orders_tb_b.jenis_order as jenisOrder, _orders_tb_b.total_harga as totalHarga, _orders_tb_b.total_qty as totalQty, _orders_tb_b.status_order as statusOrder, _orders_tb_b.created_at as orderCreatedAt, _orders_tb_b.updated_at as orderUpdatedAt";
          	return $builder->select($select)->join('_profil_users_tb','_profil_users_tb.id = _details_order_tagihan_tb_b.user_id_pembeli')->join('_orders_tb_b','_orders_tb_b.id = _details_order_tagihan_tb_b.order_id')->where("_details_order_tagihan_tb_b.order_id = (SELECT id FROM _orders_tb_b WHERE kode_transaksi = '$kodeTransaksi')")->orderBy('_details_order_tagihan_tb_b.created_at','desc')->get()->getResult();
        
        } else if ($jenisOrder == "ECOMPUB") {
          	//var_dump($kodeTransaksi);die;
          	$builder = $this->_db->table('_pesanan_tb_b');
          	$select = "_pesanan_tb_b.id, _pesanan_tb_b.kode_transaksi as kodeTransaksi, _pesanan_tb_b.no_resi as noResi, _pesanan_tb_b.toko_id as idToko, _pesanan_tb_b.id_alamat_pengiriman as idAlamatPengiriman, _pesanan_tb_b.code_pengiriman as codePengiriman, _pesanan_tb_b.service_pengiriman as servicePengiriman, _pesanan_tb_b.etd_pengiriman as etdPengiriman, _pesanan_tb_b.cost_pengiriman as costPengiriman, _pesanan_tb_b.jumlah_item as totalJumlahItem, _pesanan_tb_b.total_pesanan as totalJumlahHargaPesanan, _pesanan_tb_b.status_pembayaran as statusPembayaran, _pesanan_tb_b.status_pesanan as statusPesanan, _pesanan_tb_b.created_at as createdAt, _pesanan_tb_b.updated_at as updatedAt, _pesanan_tb_b.updated_at_pembayaran as updatedAtPembayaran, _pesanan_tb_b.updated_at_transaksi as updatedAtTransaksi, _toko_tb_b.toko_title as titleToko, _toko_tb_b.user_id as tokoUserId, _toko_tb_b.toko_featured_image as imageToko, _toko_tb_b.alamat as alamatToko, _alamat_kiriman_users_tb.id as idAlamatPengiriman, _alamat_kiriman_users_tb.kecamatan_id as kecIdAlamatPengiriman, _alamat_kiriman_users_tb.detail_alamat as detailAlamatPengiriman, _alamat_kiriman_users_tb.kode_pos as kodePosAlamatPengiriman, _alamat_kiriman_users_tb.nama_penerima as namaPenerimaAlamatPengiriman, _alamat_kiriman_users_tb.nohp_penerima as nohpAlamatPengiriman, _profil_users_tb.id as userIdPembeli, _profil_users_tb.firsname as namaUserPembeli, _orders_tb_b.status_order as statusOrder, _orders_tb_b.jenis_order as jenisOrder, _orders_tb_b.total_harga as totalHargaOrder, _orders_tb_b.user_id as userIdPembeli";
          	$dataPesanan = $builder->select($select)->join('_alamat_kiriman_users_tb', '_alamat_kiriman_users_tb.id = _pesanan_tb_b.id_alamat_pengiriman')->join('_toko_tb_b', '_toko_tb_b.id = _pesanan_tb_b.toko_id')->join('_profil_users_tb', '_profil_users_tb.id = _pesanan_tb_b.user_id')->join('_orders_tb_b', '_orders_tb_b.kode_transaksi = _pesanan_tb_b.kode_transaksi')->where("_pesanan_tb_b.kode_transaksi = '$kodeTransaksi' ")->orderBy('_pesanan_tb_b.created_at','desc')->get()->getResult();
          
          	if(count($dataPesanan) > 0) {
              	//var_dump($dataPesanan);die;
              	$dataPesanans = [];
              	foreach($dataPesanan as $val) {
                  	$val->itemDetailPesanan = $this->_getItemDetailPesanan($val->id);
                  	$dataPesanans[] = $val;
                }
              
              	return $dataPesanans;
            }else {
              	$data = [];
              	return $data;
            }
        } else {
          	$data=[];
          	return $data;
        }
    }
  
  	private function _getItemDetailPesanan($id) {
      	$builder = $this->_db->table('_detail_pesanan_tb_b');
      	$select = "_detail_pesanan_tb_b.id, _detail_pesanan_tb_b.kode_transaksi as kodeTransaksi, _detail_pesanan_tb_b.toko_id as tokoId, _detail_pesanan_tb_b.user_id as userId, _detail_pesanan_tb_b.pesanan_id as pesananId, _detail_pesanan_tb_b.product_id as productId, _detail_pesanan_tb_b.catatan, _detail_pesanan_tb_b.product_title as productTitle, _detail_pesanan_tb_b.product_price as productPrice, _detail_pesanan_tb_b.product_weight as productWeight, _detail_pesanan_tb_b.product_thumb as productThumb, _detail_pesanan_tb_b.qty_item as qtyItem, _detail_pesanan_tb_b.total_harga as totalHarga, _detail_pesanan_tb_b.created_at as createdAt";
      	
      	return $builder->select($select)->where('_detail_pesanan_tb_b.pesanan_id', $id)->orderBy('_detail_pesanan_tb_b.qty_item', 'desc')->get()->getResult();
    }
  
  	public function updateOrderToSukses($kodeTransaksi) {
      	$builder = $this->_db->table('_orders_tb_b');
      	$data = [
          	'status_order' => 2,
          	'updated_at' => date('Y-m-d H:i:s')
        ];
      	$builder->where('kode_transaksi', $kodeTransaksi)->update($data);
      
      	$a = explode('-', $kodeTransaksi);
      	$detail = $this->_getDetailWithKodeTransaksi($kodeTransaksi, $a[1]);
      	if($a[1] == "POBPUB") {
          	$this->_updateDetailOrderToSukses($kodeTransaksi, '_details_order_ppob_tb_b');
        } else if($a[1] == "POBTAG") {
          	$this->_updateDetailOrderToSukses($kodeTransaksi, '_details_order_tagihan_tb_b');
        } else {
          	//$this->updateDetailOrderToSukses($orderId, '_pesanan_tb_b');
        }
      	
      	return $this->_db->affectedRows();
    }
  
  	private function _updateDetailOrderToSukses($orderId, $table) {
      	$builder = $this->_db->table($table);
      	$data = [
          	'order_telah_selesai' => 2,
          	'updated_at' => date('Y-m-d H:i:s')
        ];
      	$builder->where('order_id', $orderId)->update($data);
      	return $this->_db->affectedRows();
    }
  
  	public function updateOrderToProses($kodeTransaksi) {
      	$builder = $this->_db->table('_orders_tb_b');
      	$data = [
          	'status_order' => 1,
          	'updated_at' => date('Y-m-d H:i:s')
        ];
      	$builder->where('kode_transaksi', $kodeTransaksi)->update($data);
      	return $this->_db->affectedRows();
    }
  
  	public function updateOrderToGagal($kodeTransaksi) {
      	$builder = $this->_db->table('_orders_tb_b');
      	$data = [
          	'status_order' => 3,
          	'updated_at' => date('Y-m-d H:i:s')
        ];
      	$builder->where('kode_transaksi', $kodeTransaksi)->update($data);
      	return $this->_db->affectedRows();
    }
  
  	public function updatePesananToPayment($kodeTransaksi) {
      	$builder = $this->_db->table('_pesanan_tb_b');
      	$data = [
          	'status_pembayaran' => 1,
          	'status_pesanan' => 0,
          	'updated_at_pembayaran' => date('Y-m-d H:i:s')
        ];
      	$builder->where('kode_transaksi', $kodeTransaksi)->update($data);
      	return $this->_db->affectedRows();
    }
  	
  	public function getDataDetailTransaksi($kodeTransaksi){
      	$a = explode('-', $kodeTransaksi);
      	
      	return $this->_getDetailWithKodeTransaksi($kodeTransaksi, $a[1]);
    }
  
  	public function getDataDetailEcomTransaksiDiproses($kodeTransaksi) {
      	return $this->_getDetailPesananDiproses($kodeTransaksi);
    }
  
  	private function _getDetailPesananDiproses($kodeTransaksi) {
      	$builder = $this->_db->table('_pesanan_tb_b');
        $select = "_pesanan_tb_b.id, _pesanan_tb_b.kode_transaksi as kodeTransaksi, _pesanan_tb_b.no_resi as noResi, _pesanan_tb_b.toko_id as idToko, _pesanan_tb_b.id_alamat_pengiriman as idAlamatPengiriman, _pesanan_tb_b.code_pengiriman as codePengiriman, _pesanan_tb_b.service_pengiriman as servicePengiriman, _pesanan_tb_b.etd_pengiriman as etdPengiriman, _pesanan_tb_b.cost_pengiriman as costPengiriman, _pesanan_tb_b.jumlah_item as totalJumlahItem, _pesanan_tb_b.total_pesanan as totalJumlahHargaPesanan, _pesanan_tb_b.status_pembayaran as statusPembayaran, _pesanan_tb_b.status_pesanan as statusPesanan, _pesanan_tb_b.created_at as createdAt, _pesanan_tb_b.updated_at as updatedAt, _pesanan_tb_b.updated_at_pembayaran as updatedAtPembayaran, _pesanan_tb_b.updated_at_transaksi as updatedAtTransaksi, _toko_tb_b.toko_title as titleToko, _toko_tb_b.user_id as tokoUserId, _toko_tb_b.toko_featured_image as imageToko, _toko_tb_b.alamat as alamatToko, _alamat_kiriman_users_tb.id as idAlamatPengiriman, _alamat_kiriman_users_tb.kecamatan_id as kecIdAlamatPengiriman, _alamat_kiriman_users_tb.detail_alamat as detailAlamatPengiriman, _alamat_kiriman_users_tb.kode_pos as kodePosAlamatPengiriman, _alamat_kiriman_users_tb.nama_penerima as namaPenerimaAlamatPengiriman, _alamat_kiriman_users_tb.nohp_penerima as nohpAlamatPengiriman, _profil_users_tb.id as userIdPembeli, _profil_users_tb.firsname as namaUserPembeli, _orders_tb_b.status_order as statusOrder, _orders_tb_b.jenis_order as jenisOrder, _orders_tb_b.total_harga as totalHargaOrder, _orders_tb_b.user_id as userIdPembeli";
        $dataPesanan = $builder->select($select)->join('_alamat_kiriman_users_tb', '_alamat_kiriman_users_tb.id = _pesanan_tb_b.id_alamat_pengiriman')->join('_toko_tb_b', '_toko_tb_b.id = _pesanan_tb_b.toko_id')->join('_profil_users_tb', '_profil_users_tb.id = _pesanan_tb_b.user_id')->join('_orders_tb_b', '_orders_tb_b.kode_transaksi = _pesanan_tb_b.kode_transaksi')->where("_pesanan_tb_b.kode_transaksi = '$kodeTransaksi' AND _pesanan_tb_b.status_pembayaran = 1 AND _pesanan_tb_b.status_pesanan < 2 ")->orderBy('_pesanan_tb_b.created_at','desc')->get()->getResult();

        if(count($dataPesanan) > 0) {
          //var_dump($dataPesanan);die;
            $dataPesanans = [];
            foreach($dataPesanan as $val) {
              $val->itemDetailPesanan = $this->_getItemDetailPesanan($val->id);
              $dataPesanans[] = $val;
            }

            return $dataPesanans;
        }else {
            $data = [];
            return $data;
        }
    }
  
  	public function getDataDetailEcomTransaksiDikirim($kodeTransaksi) {
      	return $this->_getDetailPesananDikirim($kodeTransaksi);
    }
  
  	private function _getDetailPesananDikirim($kodeTransaksi) {
      	$builder = $this->_db->table('_pesanan_tb_b');
        $select = "_pesanan_tb_b.id, _pesanan_tb_b.kode_transaksi as kodeTransaksi, _pesanan_tb_b.no_resi as noResi, _pesanan_tb_b.toko_id as idToko, _pesanan_tb_b.id_alamat_pengiriman as idAlamatPengiriman, _pesanan_tb_b.code_pengiriman as codePengiriman, _pesanan_tb_b.service_pengiriman as servicePengiriman, _pesanan_tb_b.etd_pengiriman as etdPengiriman, _pesanan_tb_b.cost_pengiriman as costPengiriman, _pesanan_tb_b.jumlah_item as totalJumlahItem, _pesanan_tb_b.total_pesanan as totalJumlahHargaPesanan, _pesanan_tb_b.status_pembayaran as statusPembayaran, _pesanan_tb_b.status_pesanan as statusPesanan, _pesanan_tb_b.created_at as createdAt, _pesanan_tb_b.updated_at as updatedAt, _pesanan_tb_b.updated_at_pembayaran as updatedAtPembayaran, _pesanan_tb_b.updated_at_transaksi as updatedAtTransaksi, _toko_tb_b.toko_title as titleToko, _toko_tb_b.user_id as tokoUserId, _toko_tb_b.toko_featured_image as imageToko, _toko_tb_b.alamat as alamatToko, _alamat_kiriman_users_tb.id as idAlamatPengiriman, _alamat_kiriman_users_tb.kecamatan_id as kecIdAlamatPengiriman, _alamat_kiriman_users_tb.detail_alamat as detailAlamatPengiriman, _alamat_kiriman_users_tb.kode_pos as kodePosAlamatPengiriman, _alamat_kiriman_users_tb.nama_penerima as namaPenerimaAlamatPengiriman, _alamat_kiriman_users_tb.nohp_penerima as nohpAlamatPengiriman, _profil_users_tb.id as userIdPembeli, _profil_users_tb.firsname as namaUserPembeli, _orders_tb_b.status_order as statusOrder, _orders_tb_b.jenis_order as jenisOrder, _orders_tb_b.total_harga as totalHargaOrder, _orders_tb_b.user_id as userIdPembeli";
        $dataPesanan = $builder->select($select)->join('_alamat_kiriman_users_tb', '_alamat_kiriman_users_tb.id = _pesanan_tb_b.id_alamat_pengiriman')->join('_toko_tb_b', '_toko_tb_b.id = _pesanan_tb_b.toko_id')->join('_profil_users_tb', '_profil_users_tb.id = _pesanan_tb_b.user_id')->join('_orders_tb_b', '_orders_tb_b.kode_transaksi = _pesanan_tb_b.kode_transaksi')->where("_pesanan_tb_b.kode_transaksi = '$kodeTransaksi' AND _pesanan_tb_b.status_pembayaran = 1 AND _pesanan_tb_b.status_pesanan = 2 ")->orderBy('_pesanan_tb_b.created_at','desc')->get()->getResult();

        if(count($dataPesanan) > 0) {
          //var_dump($dataPesanan);die;
            $dataPesanans = [];
            foreach($dataPesanan as $val) {
              $val->itemDetailPesanan = $this->_getItemDetailPesanan($val->id);
              $dataPesanans[] = $val;
            }

            return $dataPesanans;
        }else {
            $data = [];
            return $data;
        }
    }
  
  	public function getDataDetailEcomTransaksiSelesai($kodeTransaksi) {
      	return $this->_getDetailPesananSelesai($kodeTransaksi);
    }
  
  	private function _getDetailPesananSelesai($kodeTransaksi) {
      	$builder = $this->_db->table('_pesanan_tb_b');
        $select = "_pesanan_tb_b.id, _pesanan_tb_b.kode_transaksi as kodeTransaksi, _pesanan_tb_b.no_resi as noResi, _pesanan_tb_b.toko_id as idToko, _pesanan_tb_b.id_alamat_pengiriman as idAlamatPengiriman, _pesanan_tb_b.code_pengiriman as codePengiriman, _pesanan_tb_b.service_pengiriman as servicePengiriman, _pesanan_tb_b.etd_pengiriman as etdPengiriman, _pesanan_tb_b.cost_pengiriman as costPengiriman, _pesanan_tb_b.jumlah_item as totalJumlahItem, _pesanan_tb_b.total_pesanan as totalJumlahHargaPesanan, _pesanan_tb_b.status_pembayaran as statusPembayaran, _pesanan_tb_b.status_pesanan as statusPesanan, _pesanan_tb_b.created_at as createdAt, _pesanan_tb_b.updated_at as updatedAt, _pesanan_tb_b.updated_at_pembayaran as updatedAtPembayaran, _pesanan_tb_b.updated_at_transaksi as updatedAtTransaksi, _toko_tb_b.toko_title as titleToko, _toko_tb_b.user_id as tokoUserId, _toko_tb_b.toko_featured_image as imageToko, _toko_tb_b.alamat as alamatToko, _alamat_kiriman_users_tb.id as idAlamatPengiriman, _alamat_kiriman_users_tb.kecamatan_id as kecIdAlamatPengiriman, _alamat_kiriman_users_tb.detail_alamat as detailAlamatPengiriman, _alamat_kiriman_users_tb.kode_pos as kodePosAlamatPengiriman, _alamat_kiriman_users_tb.nama_penerima as namaPenerimaAlamatPengiriman, _alamat_kiriman_users_tb.nohp_penerima as nohpAlamatPengiriman, _profil_users_tb.id as userIdPembeli, _profil_users_tb.firsname as namaUserPembeli, _orders_tb_b.status_order as statusOrder, _orders_tb_b.jenis_order as jenisOrder, _orders_tb_b.total_harga as totalHargaOrder, _orders_tb_b.user_id as userIdPembeli";
        $dataPesanan = $builder->select($select)->join('_alamat_kiriman_users_tb', '_alamat_kiriman_users_tb.id = _pesanan_tb_b.id_alamat_pengiriman')->join('_toko_tb_b', '_toko_tb_b.id = _pesanan_tb_b.toko_id')->join('_profil_users_tb', '_profil_users_tb.id = _pesanan_tb_b.user_id')->join('_orders_tb_b', '_orders_tb_b.kode_transaksi = _pesanan_tb_b.kode_transaksi')->where("_pesanan_tb_b.kode_transaksi = '$kodeTransaksi' AND _pesanan_tb_b.status_pembayaran = 1 AND _pesanan_tb_b.status_pesanan = 2 ")->orderBy('_pesanan_tb_b.created_at','desc')->get()->getResult();

        if(count($dataPesanan) > 0) {
          //var_dump($dataPesanan);die;
            $dataPesanans = [];
            foreach($dataPesanan as $val) {
              $val->itemDetailPesanan = $this->_getItemDetailPesanan($val->id);
              $dataPesanans[] = $val;
            }

            return $dataPesanans;
        }else {
            $data = [];
            return $data;
        }
    }
  
}