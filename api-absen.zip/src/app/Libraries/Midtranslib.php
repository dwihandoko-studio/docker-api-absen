<?php

namespace App\Libraries;
use App\Libraries\Uuid;

class Midtranslib
{
  	var $options = ['timeout' => 3];
  	
    //private function _send_json($link)
    //{
     //   $options = [
     //           //'baseURI' => 'https://sandbox.bca.co.id'.$link,
     //           'timeout'  => 3
     //   ];
     //   $client = \Config\Services::curlrequest($options);
      
     // 	return $client;
    //}
  	private $_db;
  	function __construct()
    {
        helper(['text', 'array', 'filesystem']);
     	$this->_db      = \Config\Database::connect();
    }

  	
  	public function bankTransferBca($data) {
      $time = date('Y-m-d')."T".date('H:i:s');
      $timeFix = $time.".000+07:00";
      $date = date('Y-m-d H:i:s');
      
      $url = "https://api.sandbox.midtrans.com/v2/charge";
      
      $token = "Basic " . getenv('configurasimidtrans.default.key');
      $encoderData = json_encode($data, JSON_UNESCAPED_SLASHES);
      
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL,$url);
      curl_setopt($ch, CURLOPT_TIMEOUT, 0);
      curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 500);
      curl_setopt($ch, CURLOPT_POSTFIELDS,$encoderData);  //Post Fields
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
     
      $headers = [
          	'Authorization:' . $token,
			'Accept: application/json',
          	'Content-Type: application/json'
      ];

      curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

      $server_output = curl_exec ($ch);

      curl_close ($ch);

      return json_decode($server_output);
    }
}