<?php
// if (!defined('BASEPATH')) exit('No direct script access allowed');

namespace App\Libraries;


/**
 * UUID Class
 *
 * This implements the abilities to create UUID's for CodeIgniter.
 * Code has been borrowed from the followinf comments on php.net
 * and has been optimized for CodeIgniter use.
 * http://www.php.net/manual/en/function.uniqid.php#94959
 *
 * @category Libraries
 * @author Dan Storm
 * @link http://catalystcode.net/
 * @license GNU LPGL
 * @version 2.1 
 */


class Ppoblib
{
  	private $_db;
  	function __construct()
    {
        helper(['text', 'array', 'filesystem']);
     	$this->_db      = \Config\Database::connect();
    }
  
  	private function _hasAnyProperties($object, array $properties) {
        return array_reduce(
            $properties,
            function ($acc, $property) use ($object) {
                return $acc || property_exists($object, $property);
            },
            false
        );
    }
  
  
    private function _send_json($data, $layananPpob)
    {
      	if($layananPpob == "rajabiller"){
        	$api_url = "https://rajabiller.fastpay.co.id/transaksi/json.php";
        }else if ($layananPpob == "none") {
          	$api_url = "https://rajabiller.fastpay.co.id/transaksi/json.php";
        }else{
          	$api_url = "https://rajabiller.fastpay.co.id/transaksi/json.php";
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $api_url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 0);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 500);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        // $result = curl_exec($ch);
        // return $result;
        return $ch;
    }
  
  	public function datatransaksi($start, $end, $idTransaksi = "", $idProduct = "", $idpel = "", $limit = ""){
      $request_data = [
        'method' => 'rajabiller.datatransaksi',
        'uid' => getenv('ppob.default.uid'),
        'pin' => getenv('ppob.default.pin'),
        'tgl1' => $start,
        'tgl2' => $end,
        'id_transaksi' => $idTransaksi,
        'id_produk' => $idProduct,
        'idpel' => $idpel,
        'limit' => $limit
      ];
      
      $add         = $this->_send_json($request_data, "rajabiller");
      $send_data         = curl_exec($add);
      return json_decode($send_data);
    }
  
  	public function cetakulang($ref) {
      $request_data = [
            'method' => 'rajabiller.cu',
            'uid' => getenv('ppob.default.uid'),
            'pin' => getenv('ppob.default.pin'),
            'ref1' => "",
        	'ref2' => $ref
        ];
        $add         = $this->_send_json($request_data, "rajabiller");
        $send_data         = curl_exec($add);
      	return json_decode($send_data);
    }
  
  	public function infoProductHarga($kode, $layananPpob){
      	if($layananPpob == "rajabiller"){
            $request_data = [
                'method' => 'rajabiller.info_produk',
                'uid' => getenv('ppob.default.uid'),
                'pin' => getenv('ppob.default.pin'),
                'kode_produk' => $kode
            ];
          
          	try {
                $add         = $this->_send_json($request_data, "rajabiller");
                $send_data         = curl_exec($add);
                //var_dump($send_data);die;
                $respon = json_decode($send_data);

                if($respon->STATUS_PRODUK == "AKTIF") {
                    $data=[
                        'respon_code' => 200,
                      	'harga' => $respon->HARGA,
                      	'admin' => $respon->ADMIN,
                      	'komisi' => $respon->KOMISI,
                      	'product' => $respon->PRODUK,
                        'message' => "Produk tersedia",
                    ];
                    return $data;
                } else {
                  	$data=[
                        'respon_code' => 400,
                        'message' => "Gagal, Produk sedang gangguan / tidak tersedia",
                    ];
                    return $data;
                }
            } catch (\Throwable $th) {
              	$data=[
                    'respon_code' => 300,
                    'message' => "Terjadi Kesalahan internal.",
                ];
              	return $data;
            }
        } else {
          	$data=[
                'respon_code' => 600,
                'message' => "Biller tidak tersedia",
            ];
          	return $data;
        }
    }
  
  	public function infoProduct($kode, $layananPpob){
      	if($layananPpob == "rajabiller"){
            $request_data = [
                'method' => 'rajabiller.info_produk',
                'uid' => getenv('ppob.default.uid'),
                'pin' => getenv('ppob.default.pin'),
                'kode_produk' => $kode
            ];
          
          	try {
                $add         = $this->_send_json($request_data, "rajabiller");
                $send_data         = curl_exec($add);
                //var_dump($send_data);die;
                $respon = json_decode($send_data);

                if($respon->STATUS_PRODUK == "AKTIF") {
                    $data=[
                        'respon_code' => 200,
                        'message' => "Produk tersedia",
                    ];
                    return $data;
                } else {
                  	$data=[
                        'respon_code' => 400,
                        'message' => "Gagal, Produk sedang gangguan / tidak tersedia",
                    ];
                    return $data;
                }
            } catch (\Throwable $th) {
              	$data=[
                    'respon_code' => 300,
                    'message' => "Terjadi Kesalahan internal.",
                ];
              	return $data;
            }
        } else {
          	$data=[
                'respon_code' => 600,
                'message' => "Biller tidak tersedia",
            ];
          	return $data;
        }
    }
  
  	public function plnPascaBayarInquiry($idPelanggan = "", $kodeTransaksi = "", $layananPpob= "rajabiller"){
      	//$id = "172130091197";
      	if($layananPpob == "rajabiller"){
            $request_data = [
                'method' => 'rajabiller.inq',
                'uid' => getenv('ppob.default.uid'),
                'pin' => getenv('ppob.default.pin'),
                'idpel1' => $idPelanggan,
              	'idpel2' => "",
              	'idpel3' => "",
    			'kode_produk' => "PLNPASCH",
    			'ref1' => $kodeTransaksi
            ];
          
          	//$add         = $this->_send_json($request_data, "rajabiller");
            //$send_data         = curl_exec($add);
            //var_dump($send_data);die;
            //$respon = json_decode($send_data);
          
          	//return $respon;
          
          	try {
                $add         = $this->_send_json($request_data, "rajabiller");
                $send_data         = curl_exec($add);
                //var_dump($send_data);die;
                $respon = json_decode($send_data);
              
              	$builderLog = $this->_db->table('log_eksekusi_ppob');
              	$dataLog = [
                  	'log' => $send_data,
                  	'created_at' => date('Y-m-d H:i:s'),
                ];
          		$builderLog->insert($dataLog);

              	if($respon->STATUS == "00"){
                  	$bulanTahun = $respon->PERIODE;
                  	$jumlahBulanTagihan= explode(",",$bulanTahun);
                    $tahun = substr($jumlahBulanTagihan[0],0,4);
                    $bulan = substr($jumlahBulanTagihan[0],4,2);
                  	
                  	if(count($jumlahBulanTagihan) > 1) {
                      	$data=[
                          	'respon_code' => 201,
                          	'id_pelanggan' => $respon->IDPEL1,
                            'kode_product' => $respon->KODE_PRODUK,
                            'nama_pelanggan' => $respon->NAMA_PELANGGAN,
                          	'periode' => $respon->PERIODE,
                          	'jumlah_bulan' => count($jumlahBulanTagihan),
                            'periode_tahun' => $tahun,
                            'periode_bulan' => $bulan,
                            'nominal' => (int)$respon->NOMINAL,
                            'kode_inquiry' => $respon->REF2,
                            'sisa_saldo_admin' => $respon->SISA_SALDO,
                        	'message' => "Tagihan Anda Mengalami Tunggakkan di bulan sebelumnya.",
                        ];
                      
                      	return $data;
                    }
                  	
                  
                  	$data=[
                      	'id_pelanggan' => $respon->IDPEL1,
                      	'kode_product' => $respon->KODE_PRODUK,
                      	'nama_pelanggan' => $respon->NAMA_PELANGGAN,
                      	'periode' => $respon->PERIODE,
                      	'jumlah_bulan' => count($jumlahBulanTagihan),
                      	'periode_tahun' => $tahun,
                      	'periode_bulan' => $bulan,
                      	'nominal' => (int)$respon->NOMINAL,
                      	'kode_inquiry' => $respon->REF2,
                      	'sisa_saldo_admin' => $respon->SISA_SALDO,
                      	'respon_code' => 200,
                        'message' => "Proses inquiry tagihan berhasil.",
                    ];
                  	return $data;
            	} else if($respon->STATUS == "34") {
                    $data=[
                        'respon_code' => 400,
                        'message' => "Tagihan Anda Sudah Terbayar.",
                    ];
                    return $data;
                } else if($respon->STATUS == "06"){
                  	$data=[
                        'respon_code' => 400,
                        'message' => "ID Pelanggan Yang Anda Masukkan Salah, Mohon Teliti Kembali.",
                    ];
                    return $data;
                } else if($respon->STATUS == "" && $respon->KET == "JSON INQ"){
                  	$data=[
                        'respon_code' => 500,
                        'message' => "Field Wajib Diisi.",
                    ];
                  	return $data;
                }
            } catch (\Throwable $th) {
              	$data=[
                    'respon_code' => 300,
                    'message' => "Terjadi Kesalahan internal.",
                ];
              	return $data;
            }
        } else {
          	$data=[
                'respon_code' => 600,
                'message' => "Biller tidak tersedia",
            ];
          	return $data;
        }
    }
  
  	public function plnPascaBayarPayment($idPelanggan = "", $kodeTransaksi = "", $nominal = "", $responRef2OnInquiry = "", $layananPpob = "rajabiller", $dataInputRiwayatPpob){
      	//$id = "172130091197";
      	if($layananPpob == "rajabiller"){
            $request_data = [
                'method' => 'rajabiller.paydetail',
                'uid' => getenv('ppob.default.uid'),
                'pin' => getenv('ppob.default.pin'),
                'idpel1' => $idPelanggan,
              	'idpel2' => "",
              	'idpel3' => "",
    			'kode_produk' => "PLNPASCH",
              	'nominal' => $nominal,
    			'ref1' => $kodeTransaksi,
              	'ref2' => $responRef2OnInquiry,
              	'ref3' => ""
            ];
          
          	$add         = $this->_send_json($request_data, "rajabiller");
            $send_data         = curl_exec($add);
            //var_dump($send_data);die;
            $respon = json_decode($send_data);
          
          	try {
                $add         = $this->_send_json($request_data, $layananPpob);
                $send_data         = curl_exec($add);

                $respon         = json_decode($send_data);
              
              	$builderLog = $this->_db->table('log_eksekusi_ppob');
              	$dataLog = [
                  	'log' => $send_data,
                  	'created_at' => date('Y-m-d H:i:s'),
                ];
          		$builderLog->insert($dataLog);
              
              	if(isset($respon->error)) {
          		//if($this->_hasAnyProperties($respon, ['error'])) {
                  	$data = [
                      'respon_code' => 600,
                      'message' => $respon->error,
                    ];
                  	return $data;
                }
              
              	if ($respon->STATUS == "00" || $respon->STATUS == "" || $respon->STATUS == "35" || $respon->STATUS == "68") {
                  	$ket = $respon->NAMA_PELANGGAN . ";" . $respon->IDPEL1 . ";" . $respon->URL_STRUK;
                  	$data = [
                        'respon_code' => 200,
                      	'response_status' => $respon->KET,
                      	'no_resi' => $respon->REF2,
                        'id_transaksi' => $respon->REF2,
                      	'nama_pelanggan' => $respon->NAMA_PELANGGAN,
                        'no_pelanggan' => $respon->IDPEL1,
                        'kode_product' => $respon->KODE_PRODUK,
                        'status_transaksi' => $respon->KET,
                        'keterangan' => $ket,
                        'periode' => $respon->PERIODE,
                      	'url_struk' => $respon->URL_STRUK,
                      	'tegangan' => $respon->DETAIL['SUBSCRIBERSEGMENTATION'] . ";" . $respon->DETAIL['POWERCONSUMINGCATEGORY'],
                      	'SLALWBP1' => $respon->SLALWBP1,
                      	'SAHLWBP1' => $respon->SAHLWBP1,
                      	'SAHLWBP2' => $respon->SAHLWBP2,
                      	'SAHLWBP3' => $respon->SAHLWBP3,
                      	'SAHLWBP4' => $respon->SAHLWBP4,
                    ];
                  
                  	$dataInputHistoryPpob = $dataInputRiwayatPpob;
                    $dataInputHistoryPpob['id_transaksi'] = $respon->REF2;
                    $dataInputHistoryPpob['kode_product'] = $respon->KODE_PRODUK;
                    $dataInputHistoryPpob['status_transaksi'] = $respon->KET;
                    $dataInputHistoryPpob['keterangan'] = $ket;
                    $dataInputHistoryPpob['sn'] = $respon->URL_STRUK;

                    $this->_inputHistoryPpob($dataInputHistoryPpob);

                    return $data;
                }else{
                    //$dupTransaksi = explode(' ', $respon->KET);
                    //if($respon->STATUS_TRX == "GAGAL" && $dupTransaksi[4] == "duplikat"){
                    //    $data = [
                    //      'respon_code' => 500,
                    //      'message' => "Duplikat. Transaksi sudah pernah terjadi dengan nominal sama dihari ini",
                    //    ];
                    //    return $data;
                    //}
                  	$a = $respon->KET;

                    if (strpos($a, 'sedang diproses') !== false) {
                      	$ket = $respon->NAMA_PELANGGAN . ";" . $respon->IDPEL1 . ";" . $respon->URL_STRUK;
                        $data = [
                            'respon_code' => 200,
                          	'response_status' => $respon->KET,
                            'no_resi' => $respon->REF2,
                            'id_transaksi' => $respon->REF2,
                            'nama_pelanggan' => $respon->NAMA_PELANGGAN,
                            'no_pelanggan' => $respon->IDPEL1,
                            'kode_product' => $respon->KODE_PRODUK,
                            'status_transaksi' => $respon->KET,
                            'keterangan' => $ket,
                            'periode' => $respon->PERIODE,
                            'url_struk' => $respon->URL_STRUK,
                            'tegangan' => $respon->DETAIL['SUBSCRIBERSEGMENTATION'] . ";" . $respon->DETAIL['POWERCONSUMINGCATEGORY'],
                            'SLALWBP1' => $respon->SLALWBP1,
                            'SAHLWBP1' => $respon->SAHLWBP1,
                            'SAHLWBP2' => $respon->SAHLWBP2,
                            'SAHLWBP3' => $respon->SAHLWBP3,
                            'SAHLWBP4' => $respon->SAHLWBP4,
                        ];
                      	$dataInputHistoryPpob = $dataInputRiwayatPpob;
                        $dataInputHistoryPpob['id_transaksi'] = $respon->REF2;
                        $dataInputHistoryPpob['kode_product'] = $respon->KODE_PRODUK;
                        $dataInputHistoryPpob['status_transaksi'] = $respon->KET;
                        $dataInputHistoryPpob['keterangan'] = $ket;
                        $dataInputHistoryPpob['sn'] = $respon->URL_STRUK;

                        $this->_inputHistoryPpob($dataInputHistoryPpob);
                      
                      	return $data;
                    }
                  
                  
                    $data = [
                        'respon_code' => 400,
                      	'message' => "Wrong",
                    //    'id_transaksi' => $respon->REF2,
                    //    'no_pelanggan' => $respon->NO_HP,
                    //    'kode_product' => $respon->KODE_PRODUK,
                    //    'status_transaksi' => $respon->STATUS_TRX,
                    //    'keterangan' => $respon->KET,
                    //    'sn' => $respon->SN,
                    ];

                    return $data;
                }
            	return $data;
            } catch (\Throwable $th) {
                $data = [
                  'respon_code' => 400,
                  'message' => "Terjadi kesalahan dalam proses transaksi",
                ];
                return $data;
            }
        } else {
          	$data=[
                'respon_code' => 600,
                'message' => "Biller tidak tersedia",
            ];
          	return $data;
        }
    }
  
  	public function plnprabayar($nominal, $idPelanggan, $kodeTransaksi, $layananPpob, $dataInputRiwayatPpob) {
      	if($layananPpob == "rajabiller"){
            $request_data = [
                'method' => 'rajabiller.beli',
                'uid' => 'SP27505',
                'pin' => '885294',
                'nominal' => $nominal,
                'idpel' => $idPelanggan,
                'kode_produk' => 'PLNPRAH',
                'ref1' => $kodeTransaksi,
            ];
          
          //$add         = $this->_send_json($request_data, $layananPpob);
            //    $send_data         = curl_exec($add);

             //   $respon         = json_decode($send_data);
          
          //var_dump($respon);die;
          
          	try {
                $add         = $this->_send_json($request_data, $layananPpob);
                $send_data         = curl_exec($add);

                $respon         = json_decode($send_data);
              
              	$builderLog = $this->_db->table('log_eksekusi_ppob');
              	$dataLog = [
                  	'log' => $send_data,
                  	'created_at' => date('Y-m-d H:i:s'),
                ];
          		$builderLog->insert($dataLog);
              	
              	//if(!$respon->error) {
          		if(isset($respon->error)) {
          		//if($this->_hasAnyProperties($respon, ['error'])) {
                  	$data = [
                      'respon_code' => 600,
                      'message' => $respon->error,
                    ];
                  	return $data;
                }
          
          		
              	
                  	//$newDupTransaksi = explode(' ');
          		//var_dump($respon);
          		//var_dump(json_decode($send_data));
          		//die;
                if($respon->STATUS == "XX"){
                  $dupTransaksi = explode(', ', $respon->KET);
                  $data = [
                    'respon_code' => 500,
                    'message' => "Duplikat. Transaksi sudah pernah terjadi dengan " . $dupTransaksi[3],
                  ];
                  return $data;
                }
              
              	if ($respon->STATUS == "00" || $respon->STATUS == "" || $respon->STATUS == "35" || $respon->STATUS == "68" || $respon->KET == "TRANSAKSI SUKSES") {
                  	$ket = $respon->NAMA_PELANGGAN . ";" . $respon->IDPEL1 . ";" . $respon->URL_STRUK . ";" . $respon->DETAIL->SUBSCRIBERSEGMENTATION . ";" . $respon->DETAIL->POWERCONSUMINGCATEGORY . ";" . $respon->DETAIL->PURCHASEDKWHUNIT;
                  	$data = [
                        'respon_code' => 200,
                      	'no_resi' => $respon->IDPEL2,
                        'id_transaksi' => $respon->REF2,
                      	'nama_pelanggan' => $respon->NAMA_PELANGGAN,
                        'no_pelanggan' => $respon->IDPEL1,
                        'kode_product' => $respon->KODE_PRODUK,
                        'status_transaksi' => $respon->KET,
                        'keterangan' => $ket,
                      	'response_status' => $respon->KET,
                        'sn' => $respon->DETAIL->TOKEN,
                      	'url_struk' => $respon->URL_STRUK,
                      	'tegangan' => $respon->DETAIL->SUBSCRIBERSEGMENTATION . "/" . $respon->DETAIL->POWERCONSUMINGCATEGORY . "/" . $respon->DETAIL->PURCHASEDKWHUNIT,
                    ];
                  
                  	$dataInputHistoryPpob = $dataInputRiwayatPpob;
                  	$dataInputHistoryPpob['id_transaksi'] = $respon->REF2;
                    $dataInputHistoryPpob['kode_product'] = $respon->KODE_PRODUK;
                    $dataInputHistoryPpob['status_transaksi'] = $respon->KET;
                    $dataInputHistoryPpob['keterangan'] = $ket;
                    $dataInputHistoryPpob['sn'] = $data['sn'];
                                          
                    $this->_inputHistoryPpob($dataInputHistoryPpob);

                    return $data;
                }else{
                  	$a = $respon->KET;

                    if (strpos($a, 'sedang diproses') !== false) {
                      	$ket = $respon->NAMA_PELANGGAN . ";" . $respon->IDPEL1 . ";" . $respon->URL_STRUK . ";" . $respon->DETAIL->SUBSCRIBERSEGMENTATION . ";" . $respon->DETAIL->POWERCONSUMINGCATEGORY . ";" . $respon->DETAIL->PURCHASEDKWHUNIT;
                        $data = [
                            'respon_code' => 200,
                          	'response_status' => $respon->KET,
                            'no_resi' => $respon->IDPEL2,
                            'id_transaksi' => $respon->REF2,
                            'nama_pelanggan' => $respon->NAMA_PELANGGAN,
                            'no_pelanggan' => $respon->IDPEL1,
                            'kode_product' => $respon->KODE_PRODUK,
                            'status_transaksi' => $respon->KET,
                            'keterangan' => $ket,
                            'sn' => $respon->DETAIL->TOKEN,
                            'url_struk' => $respon->URL_STRUK,
                            'tegangan' => $respon->DETAIL->SUBSCRIBERSEGMENTATION . "/" . $respon->DETAIL->POWERCONSUMINGCATEGORY . "/" . $respon->DETAIL->PURCHASEDKWHUNIT,
                        ];

                        $dataInputHistoryPpob = $dataInputRiwayatPpob;
                        $dataInputHistoryPpob['id_transaksi'] = $respon->REF2;
                        $dataInputHistoryPpob['kode_product'] = $respon->KODE_PRODUK;
                        $dataInputHistoryPpob['status_transaksi'] = $respon->KET;
                        $dataInputHistoryPpob['keterangan'] = $ket;
                        $dataInputHistoryPpob['sn'] = $data['sn'];

                        $this->_inputHistoryPpob($dataInputHistoryPpob);

                        return $data;
                    }
                  
                  	
                    
                  
                    $data = [
                        'respon_code' => 300,
                      	'response_status' => $respon->KET,
                      	'no_resi' => $respon->REF2,
                        'id_transaksi' => $respon->REF2,
                        'no_pelanggan' => $respon->IDPEL1,
                      	'nama_pelanggan' => $respon->NAMA_PELANGGAN,
                        'no_pelanggan' => $respon->IDPEL1,
                        'status_transaksi' => $respon->STATUS,
                        'keterangan' => $respon->KET,
                      	'kode_product' => $respon->KODE_PRODUK,
                        'sn' => $respon->DETAIL->TOKEN,
                      	'url_struk' => $respon->URL_STRUK,
                      	'tegangan' => $respon->DETAIL->SUBSCRIBERSEGMENTATION . "/" . $respon->DETAIL->POWERCONSUMINGCATEGORY,
                    ];

                    return $data;
                }
            	return $data;
            } catch (\Throwable $th) {
                $data = [
                  'respon_code' => 400,
                  'message' => "Terjadi kesalahan dalam proses transaksi",
                ];
                return $data;
            }
        }else{
          	$data = [
              'respon_code' => 600,
              'message' => "Biller tidak tersedia",
            ];
          	return $data;
        }
    }

    public function pulsa($kode, $noHp, $ref1, $layananPpob, $dataInputRiwayatPpob)
    {
        
      	if($layananPpob == "rajabiller"){
          	$request_data = [
                'method' => 'rajabiller.pulsa',
                'uid' => 'SP27505',
                'pin' => '885294',
                'no_hp' => $noHp,
                'kode_produk' => $kode,
                'ref1' => $ref1,
            ];
      	
            try {
                $add         = $this->_send_json($request_data, $layananPpob);
                $send_data         = curl_exec($add);

                //var_dump($send_data);

                $respon         = json_decode($send_data);
              
              	$builderLog = $this->_db->table('log_eksekusi_ppob');
              	$dataLog = [
                  	'log' => $send_data,
                  	'created_at' => date('Y-m-d H:i:s'),
                ];
          		$builderLog->insert($dataLog);

                if ($respon->STATUS == "00" || $respon->STATUS == "" || $respon->STATUS == "35" || $respon->STATUS == "68") {
                    $data = [
                        'respon_code' => 200,
                      	'no_resi' => $respon->REF2,
                        'id_transaksi' => $respon->REF2,
                        'no_pelanggan' => $respon->NO_HP,
                        'kode_product' => $respon->KODE_PRODUK,
                        'status_transaksi' => $respon->STATUS_TRX,
                        'keterangan' => $respon->KET,
                        'sn' => $respon->SN,
                      	'response_status' => $respon->KET,
                    ];
                  	
                  	$dataInputHistoryPpob = $dataInputRiwayatPpob;
                  	$dataInputHistoryPpob['id_transaksi'] = $respon->REF2;
                    $dataInputHistoryPpob['kode_product'] = $respon->KODE_PRODUK;
                    $dataInputHistoryPpob['status_transaksi'] = $respon->STATUS_TRX;
                    $dataInputHistoryPpob['keterangan'] = $respon->KET;
                    $dataInputHistoryPpob['sn'] = $respon->SN;
                                          
                    $this->_inputHistoryPpob($dataInputHistoryPpob);

                    return $data;

                }else{
                  	if($respon->STATUS_TRX == "GAGAL" || $respon->STATUS == "18"){
                      	$messageGagal = explode('. ', $respon->KET);
                      	$data = [
                          'respon_code' => 600,
                          'message' => $messageGagal[1],
                        ];
                        return $data;
                    }
                    $dupTransaksi = explode(' ', $respon->KET);
                    if($respon->STATUS_TRX == "GAGAL" && $dupTransaksi[4] == "duplikat"){
                        $data = [
                          'respon_code' => 500,
                          'message' => "Duplikat. Transaksi sudah pernah terjadi dengan nominal sama dihari ini",
                        ];
                        return $data;
                    }
                    $data = [
                        'respon_code' => 300,
                        'id_transaksi' => $respon->REF2,
                        'no_pelanggan' => $respon->NO_HP,
                        'kode_product' => $respon->KODE_PRODUK,
                        'status_transaksi' => $respon->STATUS_TRX,
                        'keterangan' => $respon->KET,
                        'sn' => $respon->SN,
                      	'response_status' => $respon->KET,
                    ];
                  
                  	$dataInputHistoryPpob = $dataInputRiwayatPpob;
                  	$dataInputHistoryPpob['id_transaksi'] = $respon->REF2;
                    $dataInputHistoryPpob['kode_product'] = $respon->KODE_PRODUK;
                    $dataInputHistoryPpob['status_transaksi'] = $respon->STATUS_TRX;
                    $dataInputHistoryPpob['keterangan'] = $respon->KET;
                    $dataInputHistoryPpob['sn'] = $respon->SN;
                                          
                    $this->_inputHistoryPpob($dataInputHistoryPpob);

                    return $data;
                }
            } catch (\Throwable $th) {
                $data = [
                  'respon_code' => 400,
                  'message' => "Terjadi kesalahan dalam proses transaksi",
                ];
                return $data;
            }
        } else {
          	$data = [
              'respon_code' => 600,
              'message' => "Biller tidak tersedia",
            ];
          	return $data;
        }

    }
  
  	public function paketData($kode, $noHp, $ref1, $layananPpob, $dataInputRiwayatPpob)
    {
        
      	if($layananPpob == "rajabiller"){
          	$request_data = [
                'method' => 'rajabiller.pulsa',
                'uid' => 'SP27505',
                'pin' => '885294',
                'no_hp' => $noHp,
                'kode_produk' => $kode,
                'ref1' => $ref1,
            ];
      	
            try {
                $add         = $this->_send_json($request_data, $layananPpob);
                $send_data         = curl_exec($add);

                $builderLog = $this->_db->table('log_eksekusi_ppob');
              	$dataLog = [
                  	'log' => $send_data,
                  	'created_at' => date('Y-m-d H:i:s'),
                ];
          		$builderLog->insert($dataLog);

                $respon         = json_decode($send_data);

                if ($respon->STATUS == "00" || $respon->STATUS == "" || $respon->STATUS == "35" || $respon->STATUS == "68") {
                    $data = [
                        'respon_code' => 200,
                      	'no_resi' => $respon->REF2,
                        'id_transaksi' => $respon->REF2,
                        'no_pelanggan' => $respon->NO_HP,
                        'kode_product' => $respon->KODE_PRODUK,
                        'status_transaksi' => $respon->STATUS_TRX,
                        'keterangan' => $respon->KET,
                        'sn' => $respon->SN,
                      	'response_status' => $respon->KET,
                    ];
                  
                  	$dataInputHistoryPpob = $dataInputRiwayatPpob;
                  	$dataInputHistoryPpob['id_transaksi'] = $respon->REF2;
                    $dataInputHistoryPpob['kode_product'] = $respon->KODE_PRODUK;
                    $dataInputHistoryPpob['status_transaksi'] = $respon->STATUS_TRX;
                    $dataInputHistoryPpob['keterangan'] = $respon->KET;
                    $dataInputHistoryPpob['sn'] = $respon->SN;
                                          
                    $this->_inputHistoryPpob($dataInputHistoryPpob);

                    return $data;

                } else {
                  	if($respon->STATUS_TRX == "GAGAL" || $respon->STATUS == "18"){
                      	$messageGagal = explode('. ', $respon->KET);
                      	$data = [
                          'respon_code' => 600,
                          'message' => $messageGagal[1],
                        ];
                        return $data;
                    }
                  
                    $dupTransaksi = explode(' ', $respon->KET);
                    if($respon->STATUS_TRX == "GAGAL" && $dupTransaksi[4] == "duplikat"){
                        $data = [
                          'status_code' => 500,
                          'message' => "Duplikat. Transaksi sudah pernah terjadi dengan nominal sama dihari ini",
                        ];
                        return $data;
                    }
                    $data = [
                        'respon_code' => 300,
                        'id_transaksi' => $respon->REF2,
                        'no_pelanggan' => $respon->NO_HP,
                        'kode_product' => $respon->KODE_PRODUK,
                        'status_transaksi' => $respon->STATUS_TRX,
                        'keterangan' => $respon->KET,
                        'sn' => $respon->SN,
                      	'response_status' => $respon->KET,
                    ];
                  
                  	$dataInputHistoryPpob = $dataInputRiwayatPpob;
                  	$dataInputHistoryPpob['id_transaksi'] = $respon->REF2;
                    $dataInputHistoryPpob['kode_product'] = $respon->KODE_PRODUK;
                    $dataInputHistoryPpob['status_transaksi'] = $respon->STATUS_TRX;
                    $dataInputHistoryPpob['keterangan'] = $respon->KET;
                    $dataInputHistoryPpob['sn'] = $respon->SN;
                                          
                    $this->_inputHistoryPpob($dataInputHistoryPpob);

                    return $data;
                }
            } catch (\Throwable $th) {
                $data = [
                  'respon_code' => 400,
                  'message' => "Terjadi kesalahan dalam proses transaksi",
                ];
                return $data;
            }
        }else{
          	$data = [
              'respon_code' => 600,
              'message' => "Biller tidak tersedia",
            ];
          	return $data;
        }

    }

    private function _inputHistoryPpob($data) {
      	$builderResponseTransaksiPpob = $this->_db->table('_history_transaksi_ppob_tb_b');
		return $builderResponseTransaksiPpob->insert($data);
    }
}
