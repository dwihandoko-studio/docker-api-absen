<?php

namespace App\Libraries;
use App\Libraries\Uuid;

class Poinlib
{
  	private $_db;
  	function __construct()
    {
        helper(['text', 'array', 'filesystem']);
     	$this->_db      = \Config\Database::connect();
    }
  
  	private function _getUser($userId) {
      	$builder = $this->_db->table('_profil_users_tb');
      	return $builder->select("saldo, point_reward as poinReward")->where('id', $userId)->get()->getRowObject();
    }
  
  	public function updatePoin($poin, $userId) {
      	$builder = $this->_db->table('_profil_users_tb');
      	$data = [
          	'point_reward' => $poin,
          	'update_at_transaksi' => date('Y-m-d H:i:s')
        ];
      	return $builder->where('id', $userId)->update($data);
    }
  
  	public function refundPoin($poin, $userId) {
      	$builder = $this->_db->table('_profil_users_tb');
      	$data = [
          	'point_reward' => $poin,
          	'update_at_transaksi' => date('Y-m-d H:i:s')
        ];
      	return $builder->where('id', $userId)->update($data);
    }
  
  	public function insertRiwayatPoin($data){
      	$uuid = new Uuid();
      	$data['id'] = $uuid->v4();
      	$builder = $this->_db->table('_riwayat_poin');
      	return $builder->insert($data);
    }
  
  	public function cekAlreadyRiwayatPoint($kodeTransaksi, $userId, $jenisPoin) {
      	$builder = $this->_db->table('_riwayat_poin');
      	$where = [
          	'kode_transaksi' => $kodeTransaksi,
          	'user_id' => $userId,
          	'jenis_poin' => $jenisPoin
        ];
      	return $builder->where($where)->get()->getResult();
    }
}