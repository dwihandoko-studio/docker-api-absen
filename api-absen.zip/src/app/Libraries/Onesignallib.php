<?php

namespace App\Libraries;
use App\Libraries\Uuid;

class Onesignallib
{
  	var $options = ['timeout' => 3];
  	
    //private function _send_json($link)
    //{
     //   $options = [
     //           //'baseURI' => 'https://sandbox.bca.co.id'.$link,
     //           'timeout'  => 3
     //   ];
     //   $client = \Config\Services::curlrequest($options);
      
     // 	return $client;
    //}
  	private $_db;
  	function __construct()
    {
        helper(['text', 'array', 'filesystem']);
     	$this->_db      = \Config\Database::connect();
    }

  	
  	public function pushNotifToUser($data) {
      $time = date('Y-m-d')."T".date('H:i:s');
      $timeFix = $time.".000+07:00";
      $date = date('Y-m-d H:i:s');
      
      $url = "https://onesignal.com/api/v1/notifications";
      
      $token = "Basic " . getenv('configurasionesignal.default.key');
      $dataSend = [
        'app_id' => getenv('configurasionesignal.default.id'),
        //'include_player_ids' => $data['player_id'],
        //'filters' => array(
        //  array("field" => "tag", "key" => "user_id", "relation" => "=", "value" => $data['send_to'])
          //array("operator" => "OR"),
          //array("field" => "amount_spent", "relation" => "=", "value" => "0")
        //),
        'filters' => [
            [
              "field" => "tag", 
              "key" => "user_id", 
              "relation" => "=", 
              "value" => $data['send_to']
            ]
          	//,
            //["operator" => "OR"
            //],
            //["field" => "amount_spent", 
            // "relation" => "=", 
            // "value" => "0"
            //]
        ],
        'headings' => [
          'en' => $data['title']
        ],
        'contents' => [
          'en' => $data['content']
        ],
        'data' => [
          'id' => $data['app_url']
        ],
        'android_sound' => 'notif',
        'android_led_color' => 'FFFF00FF',
        'small_icon' => 'ic_stat_onesignal_default',
        'large_icon' => null,
        'android_accent_color' => "FF0c3c64",
        'android_group' => 'slamdung',
        'android_channel_id' => "1e7b77e3-b737-403e-ba8d-5ee6b1f22bc5",
      ];
      //$encoderData = json_encode($dataSend, JSON_UNESCAPED_SLASHES);
      $encoderData = json_encode($dataSend);
      
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL,$url);
      curl_setopt($ch, CURLOPT_TIMEOUT, 0);
      curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 500);
      curl_setopt($ch, CURLOPT_POSTFIELDS,$encoderData);  //Post Fields
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
     
      $headers = [
          	'Authorization:' . $token,
			'Accept: application/json',
          	'Content-Type: application/json; charset=utf-8'
      ];

      curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

      $server_output = curl_exec ($ch);

      curl_close ($ch);
      
      //print $server_output;die;

      return json_decode($server_output);
    }
    
    public function pushNotifToAdmin($data) {
      $time = date('Y-m-d')."T".date('H:i:s');
      $timeFix = $time.".000+07:00";
      $date = date('Y-m-d H:i:s');
      
      $url = "https://onesignal.com/api/v1/notifications";
      
      $token = "Basic " . getenv('configurasionesignal.default.key');
      $dataSend = [
        'app_id' => getenv('configurasionesignal.default.id'),
        //'include_player_ids' => $data['player_id'],
        //'filters' => array(
        //  array("field" => "tag", "key" => "user_id", "relation" => "=", "value" => $data['send_to'])
          //array("operator" => "OR"),
          //array("field" => "amount_spent", "relation" => "=", "value" => "0")
        //),
        'filters' => [
            [
              "field" => "tag", 
              "key" => "admin", 
              "relation" => "=", 
              "value" => $data['send_to']
            ]
          	//,
            //["operator" => "OR"
            //],
            //["field" => "amount_spent", 
            // "relation" => "=", 
            // "value" => "0"
            //]
        ],
        'headings' => [
          'en' => $data['title']
        ],
        'contents' => [
          'en' => $data['content']
        ],
        'data' => [
          'id' => $data['app_url']
        ],
        'android_sound' => 'notif',
        'android_led_color' => 'FFFF00FF',
        'small_icon' => 'ic_stat_onesignal_default',
        'large_icon' => null,
        'android_accent_color' => "FF0c3c64",
        'android_group' => 'slamdung',
        'android_channel_id' => "1e7b77e3-b737-403e-ba8d-5ee6b1f22bc5",
      ];
      //$encoderData = json_encode($dataSend, JSON_UNESCAPED_SLASHES);
      $encoderData = json_encode($dataSend);
      
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL,$url);
      curl_setopt($ch, CURLOPT_TIMEOUT, 0);
      curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 500);
      curl_setopt($ch, CURLOPT_POSTFIELDS,$encoderData);  //Post Fields
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
     
      $headers = [
          	'Authorization:' . $token,
			'Accept: application/json',
          	'Content-Type: application/json; charset=utf-8'
      ];

      curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

      $server_output = curl_exec ($ch);

      curl_close ($ch);
      
      //print $server_output;die;

      return json_decode($server_output);
    }
}