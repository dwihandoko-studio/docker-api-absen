<?php

namespace App\Libraries;
use App\Libraries\Uuid;

class Notificationlib
{
  	var $options = ['timeout' => 3];
  	
    //private function _send_json($link)
    //{
     //   $options = [
     //           //'baseURI' => 'https://sandbox.bca.co.id'.$link,
     //           'timeout'  => 3
     //   ];
     //   $client = \Config\Services::curlrequest($options);
      
     // 	return $client;
    //}
  	private $_db;
  	function __construct()
    {
        helper(['text', 'array', 'filesystem']);
     	$this->_db      = \Config\Database::connect();
    }

  	
  	public function send($data) {
      $date = date('Y-m-d H:i:s');
      
      $builder = $this->_db->table('_riwayat_notification_system');
      $uuid = new Uuid();
      $id = $uuid->v4();
      
      $dataCreate = [
        'id' => $id,
        'kode_absen' => $data['id_absen'],
        'title' => $data['title'],
        'description' => $data['description'],
        'send_from' => $data['send_from'],
        'send_to' => $data['send_to'],
        'action_page' => $data['action_page'],
        'action_api' => $data['action_api'],
        'created_at' => $date
      ];
      return $builder->insert($dataCreate);
    }
  
  	public function view($user_id) {
      $date = date('Y-m-d H:i:s');
      
      $builder = $this->_db->table('_riwayat_notification_system');
      
      $dataView = [
        'status_view' => 1
      ];
      return $builder->where('send_to',$user_id)->update($dataView);
    }
  
  	public function read($user_id, $kode_permohonan) {
      $date = date('Y-m-d H:i:s');
      
      $builder = $this->_db->table('_riwayat_notification_system');
      
      $where = [
        'kode_permohonan' => $kode_permohonan,
        'send_to' => $user_id
        
      ];
      
      $whereS = [
        'kode_permohonan' => $kode_permohonan,
        'send_to' => $user_id
        
      ];
      
      $dataNotif = $builder->where($whereS)->get()->getRowObject();
      
      if($dataNotif) {
        	if($dataNotif->status_read == 0) {
              	$dataRead = [
                  'status_view' => 1,
                  'status_read' => 1,
                  'updated_at' => $date
                ];

                return $builder->where($where)->update($dataRead);
            } else {
              	return true;
            }
      }else{
        	return false;
      }
        	
      
      
    }
}