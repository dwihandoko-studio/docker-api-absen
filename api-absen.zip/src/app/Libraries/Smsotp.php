<?php
// if (!defined('BASEPATH')) exit('No direct script access allowed');

namespace App\Libraries;


/**
 * UUID Class
 *
 * This implements the abilities to create UUID's for CodeIgniter.
 * Code has been borrowed from the followinf comments on php.net
 * and has been optimized for CodeIgniter use.
 * http://www.php.net/manual/en/function.uniqid.php#94959
 *
 * @category Libraries
 * @author Dan Storm
 * @link http://catalystcode.net/
 * @license GNU LPGL
 * @version 2.1 
 */


class Smsotp
{
  	private $_db;
  	function __construct()
    {
        helper(['text', 'array', 'filesystem']);
     	$this->_db      = \Config\Database::connect();
    }
  
  
    private function _send_json($noHp, $content)
    {
      	//if($layananPpob == "rajabiller"){
        	$urlendpoint = "http://sms114.xyz/sms/api_sms_otp_send_json.php";
      		$callbackurl = "https://dev-api.kolingcrafted.com/handlesmsotp/adsmedia";
        //}else if ($layananPpob == "none") {
        //  	$api_url = "https://rajabiller.fastpay.co.id/transaksi/json.php";
        //}else{
        //  	$api_url = "https://rajabiller.fastpay.co.id/transaksi/json.php";
        //}
      
      	$senddata = array(
            'apikey' => getenv('smsotp.default.key'),  
            'callbackurl' => $callbackurl, 
            'datapacket'=>array()
        );

        // create detail data json 
        // data 1
        $number=$noHp;
        $message=$content;
        array_push($senddata['datapacket'],array(
            'number' => trim($number),
            'message' => $message
        ));
        // sending  
        $data=json_encode($senddata);
        $curlHandle = curl_init($urlendpoint);
        curl_setopt($curlHandle, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curlHandle, CURLOPT_POSTFIELDS, $data);
        curl_setopt($curlHandle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curlHandle, CURLOPT_HTTPHEADER, array(
                    'Content-Type: application/json',
                    'Content-Length: ' . strlen($data))
        );
        curl_setopt($curlHandle, CURLOPT_TIMEOUT, 30);
        curl_setopt($curlHandle, CURLOPT_CONNECTTIMEOUT, 30);
      
      
      	return $curlHandle;
      
        //$ch = curl_init();
        //curl_setopt($ch, CURLOPT_URL, $api_url);
        //curl_setopt($ch, CURLOPT_TIMEOUT, 0);
        //curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 500);
        //curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        //curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        //curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        //curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        // $result = curl_exec($ch);
        // return $result;
        return $ch;
    }
  
  	public function sendOtp($noHp, $content) {
      	$add         = $this->_send_json($noHp, $content);
      	$send_data         = curl_exec($add);
      	return json_decode($send_data);
    }
  
  	public function datatransaksi($start, $end, $idTransaksi = "", $idProduct = "", $idpel = "", $limit = ""){
      $request_data = [
        'method' => 'rajabiller.datatransaksi',
        'uid' => getenv('ppob.default.uid'),
        'pin' => getenv('ppob.default.pin'),
        'tgl1' => $start,
        'tgl2' => $end,
        'id_transaksi' => $idTransaksi,
        'id_produk' => $idProduct,
        'idpel' => $idpel,
        'limit' => $limit
      ];
      
      $add         = $this->_send_json($request_data, "rajabiller");
      $send_data         = curl_exec($add);
      return json_decode($send_data);
    }
}