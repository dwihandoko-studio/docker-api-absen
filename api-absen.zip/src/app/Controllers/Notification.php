<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
//use App\Libraries\Uuid;
use App\Libraries\Notificationlib;

class Notification extends ResourceController
{
    //protected $modelName = 'App\Models\OrdermerchanppobModel';
    protected $format = 'json';
  	private $_db;

    var $folderImage = 'profile';

    function __construct()
    {
        helper(['form', 'text', 'array', 'fotourl', 'filesystem']);
      	$this->_db      = \Config\Database::connect();
    }

  	public function index() {
      	$per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 20;
        $start = (int) htmlspecialchars($this->request->getGet('start'), true) ? (int) htmlspecialchars($this->request->getGet('start'), true) : 0;
      	
      
      	if(!$this->request->getGet('user'))
          	return $this->fail('User cant Null'); 

      	$userId = htmlspecialchars($this->request->getGet('user'), true);
      	$builder = $this->_db->table('_riwayat_notification_system');
      
        if (!$this->request->getGet('keyword')) {
            $where = [
                'send_to' => $userId
            ];
          	
          	$builder->select('_riwayat_notification_system.id as id, _riwayat_notification_system.kode_transaksi as kodeTransaksi, _riwayat_notification_system.title as title, _riwayat_notification_system.description as description, _riwayat_notification_system.send_to as userId, _riwayat_notification_system.status_view as statusView, _riwayat_notification_system.status_read as statusRead, _riwayat_notification_system.created_at as createdAt, _riwayat_notification_system.action_page as actionPage, _riwayat_notification_system.action_api as actionApi');
          	//$builder->join('_daftar_produk_ppob_tb_b', '_daftar_produk_ppob_tb_b.id = _orders_ppob_merchan_tb_b.product_id');
            $data['result'] = $builder->where($where)->orderBy('_riwayat_notification_system.status_read', 'asc')->orderBy('_riwayat_notification_system.created_at', 'desc')->get($per_page, $start)->getResult();
            // $data['result'] = $this->model->findAll($per_page, $start);
            $data['total_result'] = $builder->where($where)->countAllResults();
        } else {
            $keyword = htmlspecialchars($this->request->getGet('keyword'), true);

            $where = [
                'send_to' => $userId,
              	'kode_transaksi' => $keyword
            ];
          	$builder->select('_riwayat_notification_system.id as id, _riwayat_notification_system.kode_transaksi as kodeTransaksi, _riwayat_notification_system.title as title, _riwayat_notification_system.description as description, _riwayat_notification_system.send_to as userId, _riwayat_notification_system.status_view as statusView, _riwayat_notification_system.status_read as statusRead, _riwayat_notification_system.created_at as createdAt, _riwayat_notification_system.action_page as actionPage, _riwayat_notification_system.action_api as actionApi');
            $data['result'] = $builder->where($where)->orderBy('_riwayat_notification_system.status_read', 'asc')->orderBy('_riwayat_notification_system.created_at', 'desc')->get($per_page, $start)->getResult();
            $data['total_result'] = $builder->where($where)->countAllResults();
        }


        // $data['result'] = $this->model->findAll($per_page, $start);
        // $data['total_result'] = $this->model->countAllResults();
        if ($data['total_result'] > 0) {
            // $data['page'] = $pag;
            $data['total_page'] = ceil($data['total_result'] / $per_page);
            return $this->respond($data);
        } else {
            return $this->respondNoContent('Tidak ada content.');
        }
      
      	
      	//$select = "coalesce(_riwayat_notification_system.id, _permohonan_ktp.id, _permohonan_akte.id, _permohonan_update_data.id, _permohonan_cek_nik.id) as id, coalesce(_permohonan_kk.nik, _permohonan_ktp.nik, _permohonan_akte.nik, _permohonan_update_data.nik, _permohonan_cek_nik.nik) as nik, coalesce(_permohonan_kk.kk, _permohonan_ktp.kk, _permohonan_akte.kk, _permohonan_update_data.kk, _permohonan_cek_nik.kk) as kk,coalesce(_permohonan_kk.nama, _permohonan_ktp.nama, _permohonan_akte.nama, _permohonan_update_data.nama, _permohonan_cek_nik.nama) as nama, coalesce(_permohonan_kk.status_permohonan, _permohonan_ktp.status_permohonan, _permohonan_akte.status_permohonan, _permohonan_update_data.status_permohonan, _permohonan_cek_nik.status_permohonan) as status_permohonan, coalesce(_permohonan_kk.created_at, _permohonan_ktp.created_at, _permohonan_akte.created_at, _permohonan_update_data.created_at, _permohonan_cek_nik.created_at) as created_at, coalesce(_permohonan_kk.jenis_permohonan, _permohonan_ktp.jenis_permohonan, _permohonan_akte.jenis_permohonan, _permohonan_update_data.jenis_permohonan, _permohonan_cek_nik.jenis_permohonan) as jenis_permohonan";
        	//$from = "((select id, nik, nama, status_permohonan, created_at, jenis_permohonan from _permohonan_kk) union (select id, nik, nama, status_permohonan, created_at, jenis_permohonan from _permohonan_ktp) union (select id, nik, nama, status_permohonan, created_at, jenis_permohonan from _permohonan_akte) union (select id, nik, nama, status_permohonan, created_at, jenis_permohonan from _permohonan_update_data) union (select id, nik, nama, status_permohonan, created_at, jenis_permohonan from _permohonan_cek_nik)) as c";
          	
      	//$builderGet->select('_orders_ppob_merchan_tb_b.kode_transaksi as kodeTransaksi, _orders_ppob_merchan_tb_b.jenis_order as jenisOrder, _orders_ppob_merchan_tb_b.product_id as productId, _orders_ppob_merchan_tb_b.no_pelanggan as noPelanggan, _orders_ppob_merchan_tb_b.order_telah_selesai as orderTelahSelesai, _orders_ppob_merchan_tb_b.total_harga as totalHarga, _orders_ppob_merchan_tb_b.status_order as statusOrder, _orders_ppob_merchan_tb_b.user_id as userId, _daftar_produk_ppob_tb_b.kode_product as kodeProduct, _daftar_produk_ppob_tb_b.nama_product as namaProduct, _daftar_produk_ppob_tb_b.nominal as nominal, _daftar_produk_ppob_tb_b.harga as harga, _toko_tb_b.toko_saldo as saldoToko, _toko_tb_b.margin_ppob_merchan as marginPpob');
        //$builderGet->join('_daftar_produk_ppob_tb_b', '_daftar_produk_ppob_tb_b.id = _orders_ppob_merchan_tb_b.product_id');
        //$builderGet->join('_toko_tb_b', '_toko_tb_b.user_id = _orders_ppob_merchan_tb_b.user_id');
        //$hasilGet = $builderGet->where('kode_transaksi', $kodeTransaksi)->get()->getRowObject();
      
    }
  
  	public function viewed() {
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            // 'userId' => 'required|min_length[3]|max_length[50]',
            'userId' => 'required'
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          $userId = htmlspecialchars($this->request->getVar('userId'), true);
          //$kodeTransaksi = htmlspecialchars($this->request->getVar('kodeTransaksi'), true);
          $view = new Notificationlib();
          $view->view($userId);
          return $this->respond("OK");
        }
    }
  
  	public function readed() {
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            'kodeTransaksi' => 'required',
            'userId' => 'required'
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          $userId = htmlspecialchars($this->request->getVar('userId'), true);
          $kodeTransaksi = htmlspecialchars($this->request->getVar('kodeTransaksi'), true);
          $view = new Notificationlib();
          $view->read($userId,$kodeTransaksi);
          return $this->respond("OK");
        }
    }
  
}
