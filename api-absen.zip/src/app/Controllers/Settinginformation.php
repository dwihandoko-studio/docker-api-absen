<?php

namespace App\Controllers;

class Syaratketentuan extends BaseController
{
    public function index()
    {
        // $data['testing'] = _create_name_foto('WhatsApp Image 2020-05-05 at 22.05.57.jpeg');
        return view('syarat_ketentuan');
    }

    //--------------------------------------------------------------------

}
