<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Ppoblib;
use App\Libraries\Buatpesanan;

class Order extends ResourceController
{
    protected $modelName = 'App\Models\OrderModel';
    protected $format = 'json';

    var $folderImage = 'profile';
  	private $_db;

    function __construct()
    {
        helper(['form', 'text', 'array', 'fotourl', 'filesystem']);
      	$this->_db      = \Config\Database::connect();
    }

    public function index()
    {

        // return $this->respondNoContent('Tidak ada content.');
        if (!$this->request->getGet('userId')) {
            return $this->respondNoContent('Tidak ada content.');
        } else {
            $userId = htmlspecialchars($this->request->getGet('userId'), true);

            $db      = \Config\Database::connect();
            $builder = $db->table('keranjang_view');
            $hasil = $builder->where('userId', $userId)->orderBy('createdAt', 'desc')->get();

            $data['result'] = $hasil->getResult();
            $data['total_result'] = count($data['result']);

            // $where = [
            //     'userId' => $userId
            // ];
            // $data['result'] = $this->model->where($where)->orderBy('createdAt', 'desc')->findAll();
            // // $data['result'] = $this->model->findAll($per_page, $start);
            // $data['total_result'] = $this->model->where($where)->countAllResults();
        }

        if ($data['total_result'] > 0) {
            return $this->respond($data);
        } else {
            return $this->respondNoContent('Tidak ada content.');
        }
    }

    public function create()
    {
        $rules = [
            // 'userId' => 'required|min_length[3]|max_length[50]',
            'userId' => 'required',
            'idProduct' => 'required',
            'qty' => 'required',
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
            $uuid = new Uuid();

            $data = [
                'id' => $uuid->v4(),
                'user_id' => htmlspecialchars($this->request->getVar('userId'), true),
                'product_id' => htmlspecialchars($this->request->getVar('idProduct'), true),
                'qty' => htmlspecialchars($this->request->getVar('qty'), true),
                'created_at' => date('Y-m-d H:i:s'),
            ];

            try {
                $user_id = $this->model->insert($data);
            } catch (\Throwable $th) {
                return $this->fail($th);
            }
            return $this->respondCreated($data);
        }
    }

    public function show($id = null)
    {
        $data = $this->model->find($id);
        if ($data) {
            return $this->respond($data);
        } else {
            return $this->failNotFound('Item not found');
        }
    }

    public function update($id = null)
    {
        $oldData = $this->model->find($id);
        $rules = [
            // 'id' => 'required|min_length[3]|max_length[50]',
            // 'lastname' => 'required|min_length[3]|max_length[50]',
            // 'email' => 'required|valid_email|is_unique[_users_tb.email]',
            'id' => 'required',
            'qty' => 'required',
            // 'password' => 'required|min_length[6]',
            // 'password_confirm' => 'matches[password]',
        ];

        if (!$this->validate($rules)) {
            return $this->failValidationError($this->validator->getError());
        } else {
            $data = [
                'id' => htmlspecialchars($id, true),
                'qty' => htmlspecialchars($this->request->getVar('qty'), true),
                'updated_at' => date('Y-m-d H:i:s'),
            ];

            try {
                $this->model->save($data);
                // unset($data['password']);
            } catch (\Throwable $th) {
                return $this->fail($th);
                // return $this->failNotFound('gagal simpan database');
            }
            return $this->respond($data);
        }
    }

    public function delete($id = null)
    {
        $data = $this->model->find($id);
        if ($data) {
            try {
                $this->model->delete($id);
                $dat['status'] = "deleted";
                $dat['message'] = "Item data berhasil di hapus.";
                $dat['description'] = "Product berhasil di hapus dari keranjang";
                $dat['data'] = $data;
                return $this->respondDeleted($dat);
            } catch (\Throwable $th) {
                return $this->fail($th);
            }
        } else {
            return $this->failNotFound('Item not found');
        }
    }

    public function add()
    {
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            // 'userId' => 'required|min_length[3]|max_length[50]',
            'userId' => 'required',
            'jenisOrder' => 'required',
            'totalHarga' => 'required',
            'totalQty' => 'required',
            'jenisOrder' => 'required',
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
            if (htmlspecialchars($this->request->getVar('jenisOrder'), true) == "ecommerce") {
                $uuid = new Uuid();
                $userId = htmlspecialchars($this->request->getVar('userId'), true);

                $kodeTransaksi = "MA-ECOMPUB-" . TIME() . random_string('numeric', 4);
                $id = $uuid->v4();
				$pesanan = htmlspecialchars($this->request->getVar('pesanan'), true);
              	$pesanans = json_decode($pesanan);
              	//echo $pesanan;
              
              	//return $this->respond($pesanans);
              	
              	//var_dump($pesanans);
              //var_dump(json_encode($pesanans));die;
              	
                $data = [
                    'id' => $id,
                    'kode_transaksi' => $kodeTransaksi,
                    'user_id' => $userId,
                    'jenis_order' => htmlspecialchars($this->request->getVar('jenisOrder'), true),
                    'total_qty' => htmlspecialchars($this->request->getVar('totalQty'), true),
                    'total_harga' => htmlspecialchars($this->request->getVar('totalHarga'), true),
                    'status_order' => 0,
                    'created_at' => date('Y-m-d H:i:s'),
                ];

                try {
                    $user_id = $this->model->insert($data);
                  	$user_id = true;
                    if ($user_id) {
                      	$buatPesanan = new Buatpesanan();
                      	$a = $buatPesanan->createPesanan($pesanans, $kodeTransaksi, $userId);
                      
                      
                      	if($a) {
                          return $this->respondCreated($data);
                        }else{
                          return $this->respondNoContent("Gagal membuat pesanan");
                        }
                      
                      
                        //$itemsProduct = explode(",", htmlspecialchars($this->request->getVar('itemsProduct'), true));
                        //$hargasProduct = explode(",", htmlspecialchars($this->request->getVar('hargasProduct'), true));
                        //$qtysProduct = explode(",", htmlspecialchars($this->request->getVar('qtysProduct'), true));
                        //$pengirimansProduct = explode(",", htmlspecialchars($this->request->getVar('pengirimansProduct'), true));
                        //$jenisPengirimansProduct = explode(",", htmlspecialchars($this->request->getVar('jenisPengirimansProduct'), true));
                        //$hargaPengirimansProduct = explode(",", htmlspecialchars($this->request->getVar('hargaPengirimansProduct'), true));


                        //foreach ($itemsProduct as $key => $value) {
                        //    $builder = $this->_db->table('_details_order_commerce_tb_b');
                        //    $uuidNew = new Uuid();
                        //    $dataOrder = [
                        //        'id' => $uuidNew->v4(),
                        //        'order_id' => $id,
                        //        'product_id' => $value,
                        //        'alamat_shippping_id' => htmlspecialchars($this->request->getVar('alamatPengiriman'), true),
                        //        'harga_product' => $hargasProduct[$key],
                        //        'qty_product' => $qtysProduct[$key],
                        //        'jasa_pengiriman' => $pengirimansProduct[$key],
                        //        'jenis_pengiriman' => $jenisPengirimansProduct[$key],
                        //        'harga_ongkir' => $hargaPengirimansProduct[$key],
                        //        'order_telah_sampai' => 0,
                        //        'kode_pengiriman' => "",
                        //        'user_id_pembeli' => $userId,
                        //        'created_at' => date('Y-m-d H:i:s'),
                        //    ];
                        //    $detailOrder = $builder->insert($dataOrder);
                        //    if ($detailOrder) {
                        //        $data['items_product'][] = $detailOrder;
                        //    } else {
                        //       $this->model->delete($id);
                        //        return $this->fail('Failed Created Orders');
                        //    }
                        //}
                    }
                } catch (\Throwable $th) {
                    return $this->fail($th);
                }
                
            } else if (htmlspecialchars($this->request->getVar('jenisOrder'), true) == "ppob") {
              	if(!$this->request->getVar('noPelanggan'))
                  	return $this->fail("no pelanggan required.");
              	$productId = htmlspecialchars($this->request->getVar('idProduct'), true);
              	$noPelanggan = htmlspecialchars($this->request->getVar('noPelanggan'), true);
              	
              	$builderGetProduct = $this->_db->table('_daftar_produk_ppob_tb_b');
              	$where = [
                  'id' => $productId
                ];
              	$dataRequestGetProduct = $builderGetProduct->where($where)->get()->getRowObject();
        		if ($dataRequestGetProduct) {
                  $newPpob = new Ppoblib();
                  $cekAvailableProduct = $newPpob->infoProduct($dataRequestGetProduct->kode_product, $dataRequestGetProduct->layanan_ppob);
                  
                  if($cekAvailableProduct['respon_code'] != 200) {
                    $responFailedNotAvailable['message'] = "Gagal, Produk sedang gangguan / tidak tersedia";
                    return $this->respond($responFailedNotAvailable);
                  }
                }
              
              	$builderCekTransaksiDup = $this->_db->table('_details_order_ppob_tb_b');
              	//$whereCekDup = [
                //  'product_id' => $productId,
                //  'no_pelanggan' => $noPelanggan,
                //  'tanggal_order' => date('Y-m-d')
                //];
              	$tglOrderCekDup = date('Y-m-d');
              
              	$whereCekDup = "product_id = '$productId' AND no_pelanggan = '$noPelanggan' AND tanggal_order = '$tglOrderCekDup'";
              
              	$dataRequestCekTransaksiDup = $builderCekTransaksiDup->where($whereCekDup)->get()->getRowObject();
              
              	if($dataRequestCekTransaksiDup){
                  	$builderCekTransaksiDupStatus = $this->_db->table('_orders_tb_b');
                  	$whereCekTransaksiDupStatus = "id = '$dataRequestCekTransaksiDup->order_id' AND (status_order < 3)";
                  	
                  	$dataRequestCekTransaksiDupStatus = $builderCekTransaksiDupStatus->where($whereCekTransaksiDupStatus)->get()->getRowObject();
                  	
                  	if($dataRequestCekTransaksiDupStatus){
                      	if($dataRequestCekTransaksiDupStatus->status_order == 0){
                          	$responFailedDuplikatTransaksi['message'] = "Anda hari ini sudah melakukan transaksi ke no ini dengan status belum terbayar.\nSilahkan cek di riwayat transaksi";
                        	return $this->respond($responFailedDuplikatTransaksi);
                        }
                      	if($dataRequestCekTransaksiDupStatus->status_order == 1){
                          	$responFailedDuplikatTransaksi['message'] = "Anda hari ini sudah melakukan transaksi ke no ini dengan status sedang diproses.\nSilahkan cek di riwayat transaksi";
                        	return $this->respond($responFailedDuplikatTransaksi);
                        }
                      	if($dataRequestCekTransaksiDupStatus->status_order == 2){
                          	$responFailedDuplikatTransaksi['message'] = "Anda hari ini sudah melakukan transaksi ke no ini dengan nominal yang sama.\nSilahkan cek di riwayat transaksi";
                        	return $this->respond($responFailedDuplikatTransaksi);
                        }
                    }
                }	
              
                $uuid = new Uuid();
                $userId = htmlspecialchars($this->request->getVar('userId'), true);

                $kodeTransaksi = "MA-POBPUB-" . TIME() . random_string('numeric', 4);
                $id = $uuid->v4();

                $data = [
                    'id' => $id,
                    'kode_transaksi' => $kodeTransaksi,
                    'user_id' => $userId,
                    'jenis_order' => htmlspecialchars($this->request->getVar('jenisOrder'), true),
                    'total_qty' => htmlspecialchars($this->request->getVar('totalQty'), true),
                    'total_harga' => htmlspecialchars($this->request->getVar('totalHarga'), true),
                    'status_order' => 0,
                    'created_at' => date('Y-m-d H:i:s'),
                ];

                try {
                    $user_id = $this->model->insertData($data, false);
                    // var_dump($user_id);
                    if ($user_id > 0) {
                        // $itemsProduct = explode(",", htmlspecialchars($this->request->getVar('kodeProduct'), true));
                        // $hargasProduct = explode(",", htmlspecialchars($this->request->getVar('hargasProduct'), true));
                        // $qtysProduct = explode(",", htmlspecialchars($this->request->getVar('qtysProduct'), true));
                        // $pengirimansProduct = explode(",", htmlspecialchars($this->request->getVar('pengirimansProduct'), true));
                        // $jenisPengirimansProduct = explode(",", htmlspecialchars($this->request->getVar('jenisPengirimansProduct'), true));
                        // $hargaPengirimansProduct = explode(",", htmlspecialchars($this->request->getVar('hargaPengirimansProduct'), true));

                        // foreach ($itemsProduct as $key => $value) {
                        $builder = $this->_db->table('_details_order_ppob_tb_b');
                        $uuidNew = new Uuid();
                        $dataOrder = [
                            'id' => $uuidNew->v4(),
                            'order_id' => $id,
                            'product_id' => htmlspecialchars($this->request->getVar('idProduct'), true),
                            'harga_product' => htmlspecialchars($this->request->getVar('hargaProduct'), true),
                            'no_pelanggan' => $noPelanggan,
                            'jenis_ppob' => htmlspecialchars($this->request->getVar('jenis'), true),
                            'order_telah_selesai' => 0,
                            'user_id_pembeli' => $userId,
                          	'tanggal_order' => date('Y-m-d'),
                            'created_at' => date('Y-m-d H:i:s'),
                        ];
                        $builder->insert($dataOrder);
                        $detailOrder = $this->_db->affectedRows();

                        if ($detailOrder > 0) {
                            $data['items_product'] = $dataOrder;
                        } else {
                            $this->model->delete($id);
                            return $this->fail('Failed Created Orders');
                        }
                        // }
                    }
                } catch (\Throwable $th) {
                    return $this->fail($th);
                }
                return $this->respondCreated($data);
            } else {
                return $this->fail('Failed Created Orders');
            }
        }
    }
  
  	public function addtagihan()
    {
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            // 'userId' => 'required|min_length[3]|max_length[50]',
            'userId' => 'required',
            'jenisTagihan' => 'required',
          	'jenisOrder' => 'required',
            'noPelanggan' => 'required',
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
            if (htmlspecialchars($this->request->getVar('jenisTagihan'), true) == "plnpascabayar") {
              	
              	$builderGetProduct = $this->_db->table('_daftar_produk_ppob_tb_b');
              	$where = [
                  'category_product' => "plnpascabayar",
                  'status_product' => 1,
                ];
              	$dataRequestGetProduct = $builderGetProduct->where($where)->orderBy('updated_at','desc')->get()->getRowObject();
        		if ($dataRequestGetProduct) {
                    $userId = htmlspecialchars($this->request->getVar('userId'), true);
                    $noPelanggan = htmlspecialchars($this->request->getVar('noPelanggan'), true);

                    $kodeTransaksi = "MA-POBTAG-" . TIME() . random_string('numeric', 4);

                    $newPpob = new Ppoblib();
                    $createInquiryTagihan = $newPpob->plnPascaBayarInquiry($noPelanggan, $kodeTransaksi, $dataRequestGetProduct->layanan_ppob);
                  
                  	if($createInquiryTagihan['respon_code'] == 200 || $createInquiryTagihan['respon_code'] == 201) {
                      	$jumlahTagihan = $createInquiryTagihan['nominal'] + ($createInquiryTagihan['jumlah_bulan'] * $dataRequestGetProduct->markup_harga);
                        $uuid = new Uuid();
                
                        $id = $uuid->v4();

                        $data = [
                            'id' => $id,
                            'kode_transaksi' => $kodeTransaksi,
                            'user_id' => $userId,
                            'jenis_order' => htmlspecialchars($this->request->getVar('jenisOrder'), true),
                            'total_qty' => 1,
                            'total_harga' => $jumlahTagihan,
                            'status_order' => 0,
                            'created_at' => date('Y-m-d H:i:s'),
                        ];
                      
                      	try {
                            $user_id = $this->model->insertData($data, false);
                            if ($user_id > 0) {

                                $builder = $this->_db->table('_details_order_tagihan_tb_b');
                                $uuidNew = new Uuid();
                                $dataOrder = [
                                    'id' => $uuidNew->v4(),
                                    'order_id' => $id,
                                    'jenis_tagihan' => htmlspecialchars($this->request->getVar('jenisTagihan'), true),
                                    'periode' => $createInquiryTagihan['periode'],
                                    'no_pelanggan' => $createInquiryTagihan['id_pelanggan'],
                                    'nama_pelanggan' => $createInquiryTagihan['nama_pelanggan'],
                                  	'periode_tahun' => $createInquiryTagihan['periode_tahun'],
                                  	'periode_bulan' => $createInquiryTagihan['periode_bulan'],
                                  	'nominal' => $createInquiryTagihan['nominal'],
                                  	'kode_inquiry' => $createInquiryTagihan['kode_inquiry'],
                                  	'biaya_admin' => ($createInquiryTagihan['jumlah_bulan'] * $dataRequestGetProduct->markup_harga),
                                    'order_telah_selesai' => 0,
                                  	'poin_transaksi' => (int)$dataRequestGetProduct->poin,
                                    'user_id_pembeli' => $userId,
                                  	'layanan_ppob' => $dataRequestGetProduct->layanan_ppob,
                                    'created_at' => date('Y-m-d H:i:s'),
                                ];
                                $builder->insert($dataOrder);
                                $detailOrder = $this->_db->affectedRows();

                                if ($detailOrder > 0) {
                                    $data['items_tagihan'] = $dataOrder;
                                  	$data['jenis_tagihan'] = $dataOrder['jenis_tagihan'];
                                } else {
                                    $this->model->delete($id);
                                    return $this->fail('Failed Created Orders');
                                }
                                // }
                            }
                        } catch (\Throwable $th) {
                            return $this->fail($th);
                        }
                        return $this->respondCreated($data);
                    }else{
                      	$responFailedNotAvailable['message'] = $createInquiryTagihan['message'];
                        return $this->respond($responFailedNotAvailable);
                    }
                  
                }else{
                  	$responFailedNotAvailable['message'] = "Gagal, Produk sedang gangguan / tidak tersedia";
                    return $this->respond($responFailedNotAvailable);
                }
            }else{
              	$responFailedNotAvailable['message'] = "Tagihan masih dalam perbaikan.";
                return $this->fail($responFailedNotAvailable);
            }
        }
    }
}
