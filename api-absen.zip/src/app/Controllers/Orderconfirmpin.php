<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Ppoblib;
use App\Libraries\Orderslib;
use App\Libraries\Saldolib;
use App\Libraries\Poinlib;

class Orderconfirmpin extends ResourceController
{
    protected $modelName = 'App\Models\OrdermerchanppobModel';
    protected $format = 'json';

    var $folderImage = 'profile';
  	private $_db;

    function __construct()
    {
        helper(['form', 'text', 'array', 'fotourl', 'filesystem']);
      	$this->_db = \Config\Database::connect();
    }
  	
  	public function confirmpin() {
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            // 'userId' => 'required|min_length[3]|max_length[50]',
            'userId' => 'required',
            'kodeTransaksi' => 'required',
            'pin' => 'required',
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          $userId = htmlspecialchars($this->request->getVar('userId'), true);
          $kodeTransaksi = htmlspecialchars($this->request->getVar('kodeTransaksi'), true);
          
          $builder = $this->_db->table('_profil_users_tb');
          $hasil = $builder->where('id', $userId)->get()->getRowObject();
          
          if($hasil) {
              if($hasil->pin_transaksi_saldo == htmlspecialchars($this->request->getVar('pin'), true)) {
                  $getOrder = new Orderslib();
                  $orders = $getOrder->getDataDetailTransaksi($kodeTransaksi);

                  if(count($orders) > 0) {
                    
                      $order = $orders[0];
                    
                      if((int)$order->statusOrder != 0){
                          if((int)$order->statusOrder == 1){
                              $res['message'] = "Order sudah dibayar dan sudah dalam proses.";
                              return $this->respondCreated($res);
                          } else if((int)$order->statusOrder == 2){
                              $res['message'] = "Order sudah dibayar dan sudah success.";
                              return $this->respondCreated($res);
                          } else {
                              $res['message'] = "Order telah gagal / dibatalkan.";
                              return $this->respondCreated($res);
                          }
                      }
                    
                      
                      if($order->jenisOrder == "ppob") {
                          if((int)$order->totalHarga > (int)$order->userSaldo){
                            $res['message'] = "Saldo anda tidak mencukupi";
                            return $this->respondCreated($res); 
                          }
                        
                          if($order->categoryProduct == "pulsa") {
                              $statusLib = new Orderslib();
                              $statusLib->updateOrderToProses($kodeTransaksi);
                            
                              $oldSaldo = (int)$order->userSaldo;
                              $newSaldo = $oldSaldo - (int)$order->totalHarga;
                            
                              $updateSaldo = new Saldolib();
                              $updateSaldo->updateSaldo($newSaldo, $order->userIdPembeli);

                              $dataRiwayatSaldo=[
                                  'user_id' => $order->userIdPembeli,
                                  'kode_transaksi' => $kodeTransaksi,
                                  'jenis_saldo' => 'kredit',
                                  'jenis_guna' => 'Pembayaran',
                                  'saldo_old' => $oldSaldo,
                                  'saldo_new' => $newSaldo,
                                  'saldo_perubahan' => (int)$order->totalHarga,
                                  'keterangan' => "pembelian " . $order->categoryProduct . " " . $order->groupProduct . " " . $order->nominalProduct . " (" . $kodeTransaksi . ")",
                                  'created_at' => date('Y-m-d H:i:s')
                              ];

                              if((int)$order->totalHarga > 0) {
                                  $updateSaldo->insertRiwayatSaldo($dataRiwayatSaldo);
                              }

                              $dataInputHistoryPpob = [
                                'user_id' => $order->userIdPembeli,
                                'layanan_ppob' => $order->layananPpob,
                                'order_id' => $kodeTransaksi,
                                'created_at' => date('Y-m-d H:i:s')
                              ];

                              $newPpob = new Ppoblib();

                              $responTransaksiPpob = $newPpob->pulsa($order->kodeProduct, $order->noPelanggan, $kodeTransaksi, $order->layananPpob, $dataInputHistoryPpob);
                              if($responTransaksiPpob['respon_code'] == 600){
                                  $statusLib = new Orderslib();
                                  $statusLib->updateOrderToGagal($kodeTransaksi);
                                  

                                  $updateSaldo->refundSaldo($oldSaldo, $order->userIdPembeli);

                                  $dataRiwayatRefundSaldo = [
                                    'user_id' => $order->userIdPembeli,
                                    'kode_transaksi' => $kodeTransaksi,
                                    'jenis_saldo' => 'debit',
                                    'jenis_guna' => 'Refund Saldo',
                                    'saldo_old' => $newSaldo,
                                    'saldo_new' => $oldSaldo,
                                    'saldo_perubahan' => (int)$order->totalHarga,
                                    'keterangan' => "Pengembalian dari gagal transaksi " . $order->categoryProduct . " " . $order->groupProduct . " " . $order->nominalProduct . " (" . $kodeTransaksi . ")",
                                    'created_at' => date('Y-m-d H:i:s')
                                  ];
                                  $updateSaldo->insertRiwayatSaldo($dataRiwayatRefundSaldo);

                                  $res['message'] = $responTransaksiPpob['message'];
                                  return $this->respondCreated($res);
                              }
                            
                              if($responTransaksiPpob['respon_code'] == 500){
                                  $statusLib = new Orderslib();
                                  $statusLib->updateOrderToGagal($kodeTransaksi);
                                  

                                  $updateSaldo->refundSaldo($oldSaldo, $order->userIdPembeli);

                                  $dataRiwayatRefundSaldo = [
                                    'user_id' => $order->userIdPembeli,
                                    'kode_transaksi' => $kodeTransaksi,
                                    'jenis_saldo' => 'debit',
                                    'jenis_guna' => 'Refund Saldo',
                                    'saldo_old' => $newSaldo,
                                    'saldo_new' => $oldSaldo,
                                    'saldo_perubahan' => (int)$order->totalHarga,
                                    'keterangan' => "Pengembalian dari gagal transaksi " . $order->categoryProduct . " " . $order->groupProduct . " " . $order->nominalProduct . " (" . $kodeTransaksi . ")",
                                    'created_at' => date('Y-m-d H:i:s')
                                  ];
                                  $updateSaldo->insertRiwayatSaldo($dataRiwayatRefundSaldo);

                                  $res['message'] = "Duplikat Transaksi..!! \n\nTransaksi ke nomor ini sudah pernah terjadi";
                                  return $this->respondCreated($res); 
                              }
                              
                              $uuids = new Uuid();
                              $uuid = $uuids->v4();
                            
                              $responDataForCallBack = [
                                  'id' => $uuid,
                                  'orderId' => $kodeTransaksi,
                                  'noResi' => $responTransaksiPpob['no_resi'],
                                  'noPelanggan' => $responTransaksiPpob['no_pelanggan'],
                                  'nominal' => $order->nominalProduct,
                                  'statusTransaksi' => $responTransaksiPpob['status_transaksi'],
                                  'produk' => $order->groupProduct,
                                  'jenisProduk' => $order->categoryProduct,
                                  'harga' => $order->totalHarga,
                                  'biayaAdmin' => "0",
                                  'sisaSaldo' => $newSaldo,
                                  'sn' => $responTransaksiPpob['sn'],
                                  'poinTransaksi' => $order->poinProduct,
                                  'keterangan' => $responTransaksiPpob['keterangan'],
                                  'jenisTransaksi' => "pulsa",
                                  'created_at' => date('Y-m-d H:i:s'),
                              	  'transaksiSukses' => "0",
                              ];
                                  	
                              if($responTransaksiPpob['respon_code'] == 200){
                                  
                                  
                                  $builderInputStruk = $this->_db->table('_riwayat_struk_pembeli_pembayaran');
                                  $builderInputStruk->insert($responDataForCallBack);

                                  if($responTransaksiPpob['sn'] != "") {
                                  //$abc = $responTransaksiPpob['response_status'];
                                  //if (strpos(strtolower($abc), 'sedang diproses') == false) {
                                    $oldPointReward = (int) $order->userPoinReward;
                                    $newPointReward = $oldPointReward + (int) $order->poinProduct;

                                    $dataRiwayatPoin=[
                                      'user_id' => $order->userIdPembeli,
                                      'kode_transaksi' => $kodeTransaksi,
                                      'jenis_poin' => 'debit',
                                      'jenis_guna' => 'Pembayaran',
                                      'poin_old' => $oldPointReward,
                                      'poin_new' => $newPointReward,
                                      'poin_perubahan' => (int) $order->poinProduct,
                                      'keterangan' => "pembelian " . $order->categoryProduct . " " . $order->groupProduct . " " . $order->titleProduct . " (" . $kodeTransaksi . ")",
                                      'created_at' => date('Y-m-d H:i:s')
                                    ];

                                    if((int) $order->poinProduct > 0){
                                      $poinUpdate = new Poinlib();
                                      $poinUpdate->updatePoin($newPointReward, $order->userIdPembeli);
                                      
                                      $newstatusLib = new Orderslib();
                                      $newstatusLib->updateOrderToSukses($kodeTransaksi);

                                      $poinUpdate->insertRiwayatPoin($dataRiwayatPoin);
                                      
                                      $responDataForCallBack['transaksiSukses'] = "1";
                                    }
                                  }
                              }

                              return $this->respond($responDataForCallBack);
                            
                          } else if($order->categoryProduct == "paket/data") {
                              $statusLib = new Orderslib();
                              $statusLib->updateOrderToProses($kodeTransaksi);
                            
                              $oldSaldo = (int)$order->userSaldo;
                              $newSaldo = $oldSaldo - (int)$order->totalHarga;
                            
                              $updateSaldo = new Saldolib();
                              $updateSaldo->updateSaldo($newSaldo, $order->userIdPembeli);

                              $dataRiwayatSaldo=[
                                  'user_id' => $order->userIdPembeli,
                                  'kode_transaksi' => $kodeTransaksi,
                                  'jenis_saldo' => 'kredit',
                                  'jenis_guna' => 'Pembayaran',
                                  'saldo_old' => $oldSaldo,
                                  'saldo_new' => $newSaldo,
                                  'saldo_perubahan' => (int)$order->totalHarga,
                                  'keterangan' => "pembelian " . $order->categoryProduct . " " . $order->groupProduct . " " . $order->titleProduct . " (" . $kodeTransaksi . ")",
                                  'created_at' => date('Y-m-d H:i:s')
                              ];

                              if((int)$order->totalHarga > 0) {
                                  $updateSaldo->insertRiwayatSaldo($dataRiwayatSaldo);
                              }

                              $dataInputHistoryPpob = [
                                'user_id' => $order->userIdPembeli,
                                'layanan_ppob' => $order->layananPpob,
                                'order_id' => $kodeTransaksi,
                                'created_at' => date('Y-m-d H:i:s')
                              ];

                              $newPpob = new Ppoblib();

                              $responTransaksiPpob = $newPpob->paketData($order->kodeProduct, $order->noPelanggan, $kodeTransaksi, $order->layananPpob, $dataInputHistoryPpob);
                              if($responTransaksiPpob['respon_code'] == 600){
                                  $statusLib = new Orderslib();
                                  $statusLib->updateOrderToGagal($kodeTransaksi);
                                  

                                  $updateSaldo->refundSaldo($oldSaldo, $order->userIdPembeli);

                                  $dataRiwayatRefundSaldo = [
                                    'user_id' => $order->userIdPembeli,
                                    'kode_transaksi' => $kodeTransaksi,
                                    'jenis_saldo' => 'debit',
                                    'jenis_guna' => 'Refund Saldo',
                                    'saldo_old' => $newSaldo,
                                    'saldo_new' => $oldSaldo,
                                    'saldo_perubahan' => (int)$order->totalHarga,
                                    'keterangan' => "Pengembalian dari gagal transaksi " . $order->categoryProduct . " " . $order->groupProduct . " " . $order->titleProduct . " (" . $kodeTransaksi . ")",
                                    'created_at' => date('Y-m-d H:i:s')
                                  ];
                                  $updateSaldo->insertRiwayatSaldo($dataRiwayatRefundSaldo);

                                  $res['message'] = $responTransaksiPpob['message'];
                                  return $this->respondCreated($res);
                              }
                            
                              if($responTransaksiPpob['respon_code'] == 500){
                                  $statusLib = new Orderslib();
                                  $statusLib->updateOrderToGagal($kodeTransaksi);
                                  

                                  $updateSaldo->refundSaldo($oldSaldo, $order->userIdPembeli);

                                  $dataRiwayatRefundSaldo = [
                                    'user_id' => $order->userIdPembeli,
                                    'kode_transaksi' => $kodeTransaksi,
                                    'jenis_saldo' => 'debit',
                                    'jenis_guna' => 'Refund Saldo',
                                    'saldo_old' => $newSaldo,
                                    'saldo_new' => $oldSaldo,
                                    'saldo_perubahan' => (int)$order->totalHarga,
                                    'keterangan' => "Pengembalian dari gagal transaksi " . $order->categoryProduct . " " . $order->groupProduct . " " . $order->titleProduct . " (" . $kodeTransaksi . ")",
                                    'created_at' => date('Y-m-d H:i:s')
                                  ];
                                  $updateSaldo->insertRiwayatSaldo($dataRiwayatRefundSaldo);

                                  $res['message'] = "Duplikat Transaksi..!! \n\nTransaksi ke nomor ini sudah pernah terjadi";
                                  return $this->respondCreated($res); 
                              }
                              
                              $uuids = new Uuid();
                              $uuid = $uuids->v4();
                            
                              $responDataForCallBack = [
                                  'id' => $uuid,
                                  'orderId' => $kodeTransaksi,
                                  'noResi' => $responTransaksiPpob['no_resi'],
                                  'noPelanggan' => $responTransaksiPpob['no_pelanggan'],
                                  'kuota' => $order->titleProduct,
                                  'paketData' => $order->namaProduct,
                                  'statusTransaksi' => $responTransaksiPpob['status_transaksi'],
                                  'produk' => $order->groupProduct,
                                  'jenisProduk' => $order->categoryProduct,
                                  'harga' => $order->totalHarga,
                                  'biayaAdmin' => "0",
                                  'sisaSaldo' => $newSaldo,
                                  'sn' => $responTransaksiPpob['sn'],
                                  'poinTransaksi' => $order->poinProduct,
                                  'keterangan' => $responTransaksiPpob['keterangan'],
                                  'jenisTransaksi' => "paketdata",
                                  'created_at' => date('Y-m-d H:i:s'),
                                  'transaksiSukses' => "0",
                              ];
                                  	
                              if($responTransaksiPpob['respon_code'] == 200){
                                  //$responDataForCallBack['transaksiSukses'] = "1";
                                  
                                  $builderInputStruk = $this->_db->table('_riwayat_struk_pembeli_pembayaran');
                                  $builderInputStruk->insert($responDataForCallBack);

                                  if($responTransaksiPpob['sn'] != "") {
                                  //$abc = $responTransaksiPpob['response_status'];
                                  //if (strpos(strtolower($abc), 'sedang diproses') == false) {
                                    $oldPointReward = (int) $order->userPoinReward;
                                    $newPointReward = $oldPointReward + (int) $order->poinProduct;
                                    

                                    $dataRiwayatPoin=[
                                      'user_id' => $order->userIdPembeli,
                                      'kode_transaksi' => $kodeTransaksi,
                                      'jenis_poin' => 'debit',
                                      'jenis_guna' => 'Pembayaran',
                                      'poin_old' => $oldPointReward,
                                      'poin_new' => $newPointReward,
                                      'poin_perubahan' => (int) $order->poinProduct,
                                      'keterangan' => "pembelian " . $order->categoryProduct . " " . $order->groupProduct . " " . $order->titleProduct . " (" . $kodeTransaksi . ")",
                                      'created_at' => date('Y-m-d H:i:s')
                                    ];

                                    if((int) $order->poinProduct > 0){
                                      $poinUpdate = new Poinlib();
                                      $poinUpdate->updatePoin($newPointReward, $order->userIdPembeli);
                                      
                                      $newstatusLib = new Orderslib();
                                      $newstatusLib->updateOrderToSukses($kodeTransaksi);

                                      $poinUpdate->insertRiwayatPoin($dataRiwayatPoin);
                                      
                                      $responDataForCallBack['transaksiSukses'] = "1";
                                    }
                                  }
                              }

                              return $this->respond($responDataForCallBack);
                            
                          } else if($order->categoryProduct == "plnprabayar") {
                            
                              $statusLib = new Orderslib();
                              $statusLib->updateOrderToProses($kodeTransaksi);
                            
                              $oldSaldo = (int)$order->userSaldo;
                              $newSaldo = $oldSaldo - (int)$order->totalHarga;
                            
                              $updateSaldo = new Saldolib();
                              $updateSaldo->updateSaldo($newSaldo, $order->userIdPembeli);

                              $dataRiwayatSaldo=[
                                  'user_id' => $order->userIdPembeli,
                                  'kode_transaksi' => $kodeTransaksi,
                                  'jenis_saldo' => 'kredit',
                                  'jenis_guna' => 'Pembayaran',
                                  'saldo_old' => $oldSaldo,
                                  'saldo_new' => $newSaldo,
                                  'saldo_perubahan' => (int)$order->totalHarga,
                                  'keterangan' => "pembelian " . $order->namaProduct . " " . $order->noPelanggan . " " . " (" . $kodeTransaksi . ")",
                                  'created_at' => date('Y-m-d H:i:s')
                              ];

                              if((int)$order->totalHarga > 0) {
                                  $updateSaldo->insertRiwayatSaldo($dataRiwayatSaldo);
                              }

                              $dataInputHistoryPpob = [
                                'user_id' => $order->userIdPembeli,
                                'layanan_ppob' => $order->layananPpob,
                                'order_id' => $kodeTransaksi,
                                'created_at' => date('Y-m-d H:i:s')
                              ];

                              $newPpob = new Ppoblib();

                              $responTransaksiPpob = $newPpob->plnprabayar($order->nominalProduct, $order->noPelanggan, $kodeTransaksi,$order->layananPpob, $dataInputHistoryPpob);
                              if($responTransaksiPpob['respon_code'] == 600){
                                  $statusLib = new Orderslib();
                                  $statusLib->updateOrderToGagal($kodeTransaksi);
                                  

                                  $updateSaldo->refundSaldo($oldSaldo, $order->userIdPembeli);

                                  $dataRiwayatRefundSaldo = [
                                    'user_id' => $order->userIdPembeli,
                                    'kode_transaksi' => $kodeTransaksi,
                                    'jenis_saldo' => 'debit',
                                    'jenis_guna' => 'Refund Saldo',
                                    'saldo_old' => $newSaldo,
                                    'saldo_new' => $oldSaldo,
                                    'saldo_perubahan' => (int)$order->totalHarga,
                                    'keterangan' => "Pengembalian dari gagal transaksi " . $order->namaProduct . " " . $order->noPelanggan . " " . " (" . $kodeTransaksi . ")",
                                    'created_at' => date('Y-m-d H:i:s')
                                  ];
                                  $updateSaldo->insertRiwayatSaldo($dataRiwayatRefundSaldo);

                                  $res['message'] = $responTransaksiPpob['message'];
                                  return $this->respondCreated($res);
                              }
                            
                              if($responTransaksiPpob['respon_code'] == 500){
                                  $statusLib = new Orderslib();
                                  $statusLib->updateOrderToGagal($kodeTransaksi);
                                  

                                  $updateSaldo->refundSaldo($oldSaldo, $order->userIdPembeli);

                                  $dataRiwayatRefundSaldo = [
                                    'user_id' => $order->userIdPembeli,
                                    'kode_transaksi' => $kodeTransaksi,
                                    'jenis_saldo' => 'debit',
                                    'jenis_guna' => 'Refund Saldo',
                                    'saldo_old' => $newSaldo,
                                    'saldo_new' => $oldSaldo,
                                    'saldo_perubahan' => (int)$order->totalHarga,
                                    'keterangan' => "Pengembalian dari gagal transaksi " . $order->namaProduct . " " . $order->noPelanggan . " " . " (" . $kodeTransaksi . ")",
                                    'created_at' => date('Y-m-d H:i:s')
                                  ];
                                  $updateSaldo->insertRiwayatSaldo($dataRiwayatRefundSaldo);

                                  $res['message'] = "Duplikat Transaksi..!! \n\nTransaksi ke nomor ini sudah pernah terjadi";
                                  return $this->respondCreated($res); 
                              }
                              
                              $uuids = new Uuid();
                              $uuid = $uuids->v4();
                            
                              $responDataForCallBack = [
                                  'id' => $uuid,
                                  'orderId' => $kodeTransaksi,
                                  'noResi' => $responTransaksiPpob['no_resi'],
                                  'noPelanggan' => $responTransaksiPpob['no_pelanggan'],
                                  'namaPelanggan' => $responTransaksiPpob['nama_pelanggan'],
                                  'nominal' => $order->nominalProduct,
                                  'statusTransaksi' => $responTransaksiPpob['status_transaksi'],
                                  'produk' => $order->namaProduct,
                                  'jenisProduk' => $order->categoryProduct,
                                  'harga' => $order->totalHarga,
                                  'biayaAdmin' => "0",
                                  'sisaSaldo' => $newSaldo,
                                  'sn' => $responTransaksiPpob['sn'],
                                  'poinTransaksi' => $order->poinProduct,
                                  'keterangan' => $responTransaksiPpob['keterangan'],
                                  'jenisTransaksi' => "plnprabayar",
                                  'tegangan' => $responTransaksiPpob['tegangan'],
                                  'urlStruk' => $responTransaksiPpob['url_struk'],
                                  'created_at' => date('Y-m-d H:i:s'),
                              	  'transaksiSukses' => "0",
                              ];
                                  	
                              if($responTransaksiPpob['respon_code'] == 200){
                                  //$responDataForCallBack['transaksiSukses'] = "1";
                                  
                                  $builderInputStruk = $this->_db->table('_riwayat_struk_pembeli_pembayaran');
                                  $builderInputStruk->insert($responDataForCallBack);

                                  if($responTransaksiPpob['sn'] != "") {
                                  //$abc = $responTransaksiPpob['response_status'];
                                  //if (strpos(strtolower($abc), 'sedang diproses') == false) {
                                    $oldPointReward = (int) $order->userPoinReward;
                                    $newPointReward = $oldPointReward + (int) $order->poinProduct;

                                    $dataRiwayatPoin=[
                                      'user_id' => $order->userIdPembeli,
                                      'kode_transaksi' => $kodeTransaksi,
                                      'jenis_poin' => 'debit',
                                      'jenis_guna' => 'Pembayaran',
                                      'poin_old' => $oldPointReward,
                                      'poin_new' => $newPointReward,
                                      'poin_perubahan' => (int) $order->poinProduct,
                                      'keterangan' => "pembelian " . $order->namaProduct . " " . $order->noPelanggan . " " . " (" . $kodeTransaksi . ")",
                                      'created_at' => date('Y-m-d H:i:s')
                                    ];

                                    if((int) $order->poinProduct > 0){
                                      $poinUpdate = new Poinlib();
                                      $poinUpdate->updatePoin($newPointReward, $order->userIdPembeli);
                                      
                                      $newstatusLib = new Orderslib();
                                      $newstatusLib->updateOrderToSukses($kodeTransaksi);

                                      $poinUpdate->insertRiwayatPoin($dataRiwayatPoin);
                                      
                                      $responDataForCallBack['transaksiSukses'] = "1";
                                    }
                                  }
                              }

                              return $this->respond($responDataForCallBack);
                          } else {
                              //transaksi ppob lainnya
                              return $this->fail("Confirmation Failed");
                          }
                      } else if ($order->jenisOrder == "tagihan") {
                          if((int)$order->totalHarga > (int)$order->userSaldo){
                              $res['message'] = "Saldo anda tidak mencukupi";
                              return $this->respondCreated($res); 
                          }
                        
                          if($order->jenisTagihan == "plnpascabayar") {
                              $statusLib = new Orderslib();
                              $statusLib->updateOrderToProses($kodeTransaksi);
                            
                              $oldSaldo = (int)$order->userSaldo;
                              $newSaldo = $oldSaldo - (int)$order->totalHarga;
                            
                              $updateSaldo = new Saldolib();
                              $updateSaldo->updateSaldo($newSaldo, $order->userIdPembeli);

                              $dataRiwayatSaldo=[
                                  'user_id' => $order->userIdPembeli,
                                  'kode_transaksi' => $kodeTransaksi,
                                  'jenis_saldo' => 'kredit',
                                  'jenis_guna' => 'Pembayaran',
                                  'saldo_old' => $oldSaldo,
                                  'saldo_new' => $newSaldo,
                                  'saldo_perubahan' => (int)$order->totalHarga,
                                  'keterangan' => "pembayaran " . $order->jenisTagihan . " " . $order->noPelanggan . " " . $order->namaPelanggan . " (" . $kodeTransaksi . ")",
                                  'created_at' => date('Y-m-d H:i:s')
                              ];

                              if((int)$order->totalHarga > 0) {
                                  $updateSaldo->insertRiwayatSaldo($dataRiwayatSaldo);
                              }

                              $dataInputHistoryPpob = [
                                'user_id' => $order->userIdPembeli,
                                'layanan_ppob' => $order->layananPpob,
                                'order_id' => $kodeTransaksi,
                                'created_at' => date('Y-m-d H:i:s')
                              ];

                              $newPpob = new Ppoblib();

                              $responTransaksiPpob = $newPpob->plnPascaBayarPayment($order->noPelanggan, $kodeTransaksi, $order->nominal, $order->kodeInquiry, $order->layananPpob, $dataInputHistoryPpob);
                            
                              if($responTransaksiPpob['respon_code'] == 600){
                                  $statusLib = new Orderslib();
                                  $statusLib->updateOrderToGagal($kodeTransaksi);
                                  

                                  $updateSaldo->refundSaldo($oldSaldo, $order->userIdPembeli);

                                  $dataRiwayatRefundSaldo = [
                                    'user_id' => $order->userIdPembeli,
                                    'kode_transaksi' => $kodeTransaksi,
                                    'jenis_saldo' => 'debit',
                                    'jenis_guna' => 'Refund Saldo',
                                    'saldo_old' => $newSaldo,
                                    'saldo_new' => $oldSaldo,
                                    'saldo_perubahan' => (int)$order->totalHarga,
                                    'keterangan' => "Pengembalian dari gagal transaksi " . $order->jenisTagihan . " " . $order->noPelanggan . " " . $order->namaPelanggan . " (" . $kodeTransaksi . ")",
                                    'created_at' => date('Y-m-d H:i:s')
                                  ];
                                  $updateSaldo->insertRiwayatSaldo($dataRiwayatRefundSaldo);

                                  $res['message'] = $responTransaksiPpob['message'];
                                  return $this->respondCreated($res);
                              }
                            
                              if($responTransaksiPpob['respon_code'] == 500){
                                  $statusLib = new Orderslib();
                                  $statusLib->updateOrderToGagal($kodeTransaksi);
                                  

                                  $updateSaldo->refundSaldo($oldSaldo, $order->userIdPembeli);

                                  $dataRiwayatRefundSaldo = [
                                    'user_id' => $order->userIdPembeli,
                                    'kode_transaksi' => $kodeTransaksi,
                                    'jenis_saldo' => 'debit',
                                    'jenis_guna' => 'Refund Saldo',
                                    'saldo_old' => $newSaldo,
                                    'saldo_new' => $oldSaldo,
                                    'saldo_perubahan' => (int)$order->totalHarga,
                                    'keterangan' => "Pengembalian dari gagal transaksi " . $order->jenisTagihan . " " . $order->noPelanggan . " " . $order->namaPelanggan . " (" . $kodeTransaksi . ")",
                                    'created_at' => date('Y-m-d H:i:s')
                                  ];
                                  $updateSaldo->insertRiwayatSaldo($dataRiwayatRefundSaldo);

                                  $res['message'] = "Duplikat Transaksi..!! \n\nTransaksi ke nomor ini sudah pernah terjadi";
                                  return $this->respondCreated($res); 
                              }
                              
                              $uuids = new Uuid();
                              $uuid = $uuids->v4();
                            
                              $responDataForCallBack = [
                                  'id' => $uuid,
                                  'orderId' => $kodeTransaksi,
                                  'noResi' => $responTransaksiPpob['no_resi'],
                                  'noPelanggan' => $responTransaksiPpob['no_pelanggan'],
                                  'namaPelanggan' => $responTransaksiPpob['nama_pelanggan'],
                                  'nominal' => $order->nominal,
                                  'statusTransaksi' => $responTransaksiPpob['status_transaksi'],
                                  'produk' => "Tagihan PLN Pascabayar",
                                  'jenisProduk' => $responTransaksiPpob['periode'],
                                  'harga' => $order->totalHarga,
                                  'biayaAdmin' => "0",
                                  'sisaSaldo' => $newSaldo,
                                  'sn' => $responTransaksiPpob['periode'],
                                  'poinTransaksi' => $order->poinTransaksi,
                                  'keterangan' => $responTransaksiPpob['keterangan'],
                                  'jenisTransaksi' => "plnpascabayar",
                                  'tegangan' => $responTransaksiPpob['tegangan'],
                                  'urlStruk' => $responTransaksiPpob['url_struk'],
                                  'created_at' => date('Y-m-d H:i:s'),
                              	  'transaksiSukses' => "0",
                              ];
                                  	
                              if($responTransaksiPpob['respon_code'] == 200){
                                  //$responDataForCallBack['transaksiSukses'] = "1";
                                  
                                  $builderInputStruk = $this->_db->table('_riwayat_struk_pembeli_pembayaran');
                                  $builderInputStruk->insert($responDataForCallBack);

                                  if($responTransaksiPpob['sn'] != "") {
                                  //$abc = $responTransaksiPpob['response_status'];
                                  //if (strpos(strtolower($abc), 'sedang diproses') == false) {
                                    $oldPointReward = (int) $order->userPoinReward;
                                    $newPointReward = $oldPointReward + (int) $order->poinTransaksi;

                                    $dataRiwayatPoin=[
                                      'user_id' => $order->userIdPembeli,
                                      'kode_transaksi' => $kodeTransaksi,
                                      'jenis_poin' => 'debit',
                                      'jenis_guna' => 'Pembayaran',
                                      'poin_old' => $oldPointReward,
                                      'poin_new' => $newPointReward,
                                      'poin_perubahan' => (int) $order->poinTransaksi,
                                      'keterangan' => "pembayaran " . $order->jenisTagihan . " " . $order->noPelanggan . " " . $order->namaPelanggan . " (" . $kodeTransaksi . ")",
                                      'created_at' => date('Y-m-d H:i:s')
                                    ];

                                    if((int) $order->poinTransaksi > 0){
                                      $poinUpdate = new Poinlib();
                                      $poinUpdate->updatePoin($newPointReward, $order->userIdPembeli);
                                      
                                      $newstatusLib = new Orderslib();
                                      $newstatusLib->updateOrderToSukses($kodeTransaksi);

                                      $poinUpdate->insertRiwayatPoin($dataRiwayatPoin);
                                      
                                      $responDataForCallBack['transaksiSukses'] = "1";
                                    }
                                  }
                              }

                              return $this->respond($responDataForCallBack);
                          } else {
                            	return $this->fail("Tagihan belum tersedia");
                          }
                      } else if ($order->jenisOrder == "ecommerce") {
                          $builderEcom = $this->_db->table('_orders_tb_b');
                          $detailOrderEcoms = $builderEcom->where('kode_transaksi', $kodeTransaksi)->get()->getRowObject();
                        
                          if((int)$detailOrderEcoms->total_harga > (int)$hasil->saldo){
                              $res['message'] = "Saldo anda tidak mencukupi";
                              return $this->respondCreated($res); 
                          }
                        
                          $statusLib = new Orderslib();
                          $statusLib->updateOrderToProses($kodeTransaksi);

                          $oldSaldo = (int)$hasil->saldo;
                          $newSaldo = $oldSaldo - (int)$detailOrderEcoms->total_harga;

                          $updateSaldo = new Saldolib();
                          $updateSaldo->updateSaldo($newSaldo, $hasil->id);

                          $dataRiwayatSaldo=[
                            'user_id' => $hasil->id,
                            'kode_transaksi' => $kodeTransaksi,
                            'jenis_saldo' => 'kredit',
                            'jenis_guna' => 'Pembayaran',
                            'saldo_old' => $oldSaldo,
                            'saldo_new' => $newSaldo,
                            'saldo_perubahan' => (int)$detailOrderEcoms->total_harga,
                            'keterangan' => "pembayaran belanja barang (" . $kodeTransaksi . ")",
                            'created_at' => date('Y-m-d H:i:s')
                          ];

                          if((int)$detailOrderEcoms->total_harga > 0) {
                            $updateSaldo->insertRiwayatSaldo($dataRiwayatSaldo);
                          }
                        
                          $statusPaymentLib = new Orderslib();
                          $statusPaymentLib->updatePesananToPayment($kodeTransaksi);
                        
                          $responDataForCallBack = [
                            'jenisTransaksi' => "ecommerce",
                            'transaksiSukses' => "1",
                          ];
                        
                          return $this->respond($responDataForCallBack); 
                        
                      } else {
                        	//untuk ecommerce
                          $res['message'] = "jenis order tidak terdaftar";
                          return $this->respondCreated($res);
                      }
                    
                  } else {
                    	return $this->respondNoContent("Order tidak ditemukan, mungkin sudah di hapus.");
                  }
                
              } else {
                  $res['message'] = "Pin Transaksi Anda Salah";
                  return $this->respondCreated($res);
              }
            
          } else {
            	return $this->fail("Confirmation Failed.");
          }
          
        }
    }
  
  public function testcontroller() {
    if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
    
    $rules = [
          	'id' => 'required',
      		//'nominal' => 'required',
      		//'ref2' => 'required'
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
    
    $newPpob = new Ppoblib();
          $textString = htmlspecialchars($this->request->getVar('id'), true);
          //$nominal = htmlspecialchars($this->request->getVar('nominal'), true);
          //$ref2 = htmlspecialchars($this->request->getVar('ref2'), true);
    //$textString = "PLNPRAH20";
    //$string = substr($textString, 0,7);
    $cekAvailableProduct = $newPpob->plnPascaBayarInquiry($textString,"rajabiller", "");
    //$bayarTagihanListrik = $newPpob->plnPascaBayarPayment($textString, "PPOB-MERC-1234151234", $nominal, $ref2, $layananPpob= "rajabiller");
          //$cekAvailableProduct = $newPpob->cetakulang("MRTPOB-MERC-15987676811753");
    //var_dump($bayarTagihanListrik);
          return $this->respond($cekAvailableProduct);
        }
  }
}
