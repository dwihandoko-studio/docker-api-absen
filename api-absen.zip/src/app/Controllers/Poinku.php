<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Notificationlib;

class Poinku extends ResourceController
{
    protected $modelName = 'App\Models\TransaksiModel';
    protected $format = 'json';

    var $folderImage = 'profile';
  	private $_db;

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
      	$this->_db = \Config\Database::connect();
    }

    public function index()
    {
      	if (!$this->request->getGet('user')) {
            return $this->respondNoContent('Tidak ada content.');
        }else{
      		$per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
        	$start = (int) htmlspecialchars($this->request->getGet('start'), true) ? (int) htmlspecialchars($this->request->getGet('start'), true) : 0;
          	$userId = htmlspecialchars($this->request->getGet('user'), true);
          
          	$where=[
              'id' => $userId,
            ];
          
          	$select = "id, point_reward as poin";
          
          	$builder = $this->_db->table('_profil_users_tb');
          
          	$user = $builder->select($select)->where($where)->get()->getRowObject();
          
          	//var_dump($user);
          
          	if($user) {
              
              	$builderPoin = $this->_db->table('_riwayat_poin');
              	$selectPoin = "id, user_id as userId, jenis_poin as jenisPoin, jenis_guna as jenisGuna, poin_old as poinOld, poin_new as poinNew, poin_perubahan as poinPerubahan, keterangan, created_at as createdAt";
              	$riwayatPoin = $builderPoin->select($selectPoin)->where('user_id', $user->id)->orderBy('created_at', 'desc')->get()->getResult();
              	
              	$data['poin'] = $user->poin;
              	$data['riwayatPoin'] = $riwayatPoin;
              
              	return $this->respond($data);
            }else{
              	return $this->responNoContent('Tidak ada content.');
            }
        }
    }
}