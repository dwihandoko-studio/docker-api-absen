<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;

class Productgudang extends ResourceController
{
    //protected $modelName = 'App\Models\ProductpublicModel';
    protected $format = 'json';

    var $folderImage = 'product';

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
      	$this->_db      = \Config\Database::connect();
    }

    public function index()
    {
        $per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
        $pag = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

        if ($pag == 1) {
            $start = 0;
        } else {
            $start = (($pag - 1) * $per_page);
        }

		if (!$this->request->getGet('keyword')){
            if (!$this->request->getGet('category') and !$this->request->getGet('subcategory')) {
                $where = "product_gudang_tb_b.is_active = 1";
            } else {
                if (!$this->request->getGet('category')){
                    $subcat = htmlspecialchars($this->request->getGet('subcategory'), true);
                    $where = "product_gudang_tb_b.sub_category_id = '$subcat' AND product_gudang_tb_b.is_active = 1";
                }else{
                    if (!$this->request->getGet('subcategory')){
                        $cat = htmlspecialchars($this->request->getGet('category'), true);
                        $where = "product_gudang_tb_b.category_id = '$cat' AND product_gudang_tb_b.is_active = 1";
                    }else{
                        //$cat = htmlspecialchars($this->request->getGet('category'), true);
                        $subcat = htmlspecialchars($this->request->getGet('subcategory'), true);
                        $where = "product_gudang_tb_b.sub_category_id = '$subcat' AND product_gudang_tb_b.is_active = 1";
                    }
                }
            }
        }else{
          	$keyword = htmlspecialchars($this->request->getGet('keyword'), true);
          	if (!$this->request->getGet('category') and !$this->request->getGet('subcategory')) {
                $where = "product_gudang_tb_b.nama LIKE '%$keyword%' AND product_gudang_tb_b.is_active = 1";
            } else {
                if (!$this->request->getGet('category')){
                    $subcat = htmlspecialchars($this->request->getGet('subcategory'), true);
                    $where = "product_gudang_tb_b.nama LIKE '%$keyword%' AND product_gudang_tb_b.sub_category= '$subcat' AND product_gudang_tb_b.is_active = 1";
                }else{
                    if (!$this->request->getGet('subcategory')){
                        $cat = htmlspecialchars($this->request->getGet('category'), true);
                        $where = "product_gudang_tb_b.nama LIKE '%$keyword%' AND product_gudang_tb_b.category= '$cat' AND product_gudang_tb_b.is_active = 1";
                    }else{
                        //$cat = htmlspecialchars($this->request->getGet('category'), true);
                        $subcat = htmlspecialchars($this->request->getGet('subcategory'), true);
                        $where = "product_gudang_tb_b.nama LIKE '%$keyword%' AND product_gudang_tb_b.sub_category= '$subcat' AND product_gudang_tb_b.is_active = 1";
                    }
                }
            }
        }
		
      	$select = "product_gudang_tb_b.id as productId, product_gudang_tb_b.nama as productName, product_gudang_tb_b.satuan as productSatuan, product_gudang_tb_b.stok as productStok, product_gudang_tb_b.hpp as productHpp, product_gudang_tb_b.harga_toko as hargaToko, product_gudang_tb_b.harga_toko_2 as hargaToko2, product_gudang_tb_b.harga_toko_3 as hargaToko3, product_gudang_tb_b.discount_rp as discountRp, product_gudang_tb_b.point_rp as pointRp, product_gudang_tb_b.jenis as jenis, product_gudang_tb_b.stok_min as stokMin, product_gudang_tb_b.jenis_point as jenisPoint, product_gudang_tb_b.gambar as picture, product_gudang_tb_b.gambar2 as picture2, product_gudang_tb_b.gambar3 as picture3, product_gudang_tb_b.berat, product_gudang_tb_b.panjang, product_gudang_tb_b.lebar, product_gudang_tb_b.supplier, product_gudang_tb_b.kode_barcode as kodeBarcode, product_gudang_tb_b.margin_toko as marginToko, product_gudang_tb_b.tgl_terakhir_beli as tglTerakhirBeli, product_gudang_tb_b.tgl_terakhir_jual as tglTerakhirJual, product_gudang_tb_b.sudah_ppn as sudahPpn, product_gudang_tb_b.nilai_ppn as nilaiPpn, product_gudang_tb_b.expired, product_gudang_tb_b.ket as keterangan, product_gudang_tb_b.harga_terakhir as hargaTerakhir, product_gudang_tb_b.stok_rusak as stokRusak, product_gudang_tb_b.minimal_margin as minimalMargin, product_gudang_tb_b.rak, product_gudang_tb_b.shelving, product_gudang_tb_b.max_panjang as maxPanjang, product_gudang_tb_b.created_at as createdAt, _category_tb_b.id as categoryId, _category_tb_b.category_name as categoryName, _sub_category_tb_b.id as subCategoryId, _sub_category_tb_b.sub_category_name as subCategoryName";
		$allData = $this->_db->table('product_gudang_tb_b')->select($select)->join('_category_tb_b', '_category_tb_b.id = product_gudang_tb_b.category_id')->join('_sub_category_tb_b', '_sub_category_tb_b.id = product_gudang_tb_b.sub_category_id')->where($where)->orderBy('category_name', 'asc')->limit($per_page, $start)->get();
      	
      	$countAllData = $this->_db->table('product_gudang_tb_b')->where($where)->countAllResults();
      
        if(count($allData->getResult()) > 0) {
          $data['result'] = $allData->getResult();
          $data['total_result'] = $countAllData;
          $data['page'] = $pag;
          $data['total_page'] = ceil($data['total_result'] / $per_page);
          return $this->respond($data);
        }else{
          return $this->respondNoContent('Tidak ada content.');
        }
    }

    public function category(){
      $select = "id as categoryId, category_name as categoryName, key_search as keySearch";
      $cat = $this->_db->table('_category_tb_b')->select($select)->where(['is_active' => 1])->orderBy('category_name', 'asc')->get()->getResult();
      
      if(count($cat) > 0) {
        $data['result'] = $cat;
        $data['total_result'] = count($cat);
        return $this->respond($data);
      }else{
        return $this->respondNoContent('Tidak ada content.');
      }
    }
  
  	public function subcategory(){
      if (!$this->request->getGet('category')) {
        $where = [
          'is_active' => 1
        ];
      }else{
        $catId = htmlspecialchars($this->request->getGet('category'), true);
        $where = [
          'category_id' => $catId,
          'is_active' => 1
        ];
      }
      $select = "id as subCategoryId, category_id as categoryId, sub_category_name as subCategoryName, key_search as keySearch";
      
      $cat = $this->_db->table('_sub_category_tb_b')->select($select)->where($where)->orderBy('sub_category_name', 'asc')->get()->getResult();
      
      if(count($cat) > 0) {
        $data['result'] = $cat;
        $data['total_result'] = count($cat);
        return $this->respond($data);
      }else{
        return $this->respondNoContent('Tidak ada content.');
      }
    }
}
