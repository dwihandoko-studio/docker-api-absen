<?php

namespace App\Controllers;
use App\Libraries\Ppoblib;
use App\Libraries\Orderslib;

class Testemail extends BaseController
{
  	private $_db;
  	function __construct()
    {
        helper(['text', 'array', 'filesystem']);
     	$this->_db      = \Config\Database::connect();
    }

  	
  	public function index() {
      
      $builder = $this->_db->table('log_eksekusi_ppob');
      $a = $builder->where("id", 43)->get()->getRowObject();
      
      $b = json_decode($a->log);
      
      echo $b->REF1;
      echo "<br>";
      echo $b->DETAIL->TOKEN;
      echo "<br><br>";
      
      var_dump($b);die;
      
      
      
      
      
      
      $getOrder = new Orderslib();
      $a = $getOrder->getDataDetailTransaksi("MA-POBTAG-16028379177128");
      var_dump($a);die;
      //$time = date('Y-m-d')."T".date('H:i:s');
      //$timeFix = $time.".000+07:00";
      $date = date('Y-m-d H:i:s');
      
      //$where = "group_product = 'TELKOMSEL' AND category_product = 'pulsa'";
      $where = "group_product LIKE '%SMART%'";
      //$where = "kode_product = 'SDG25BDH'";
      //$where = "group_product = 'SMARTFREN'";
      
      $tableSelec = $this->_db->table('_daftar_produk_ppob_tb_b')->where($where)->get()->getResult();
      
      foreach($tableSelec as $datProv) {

        $newPpob = new Ppoblib();
        $cekAvailableProduct = $newPpob->infoProductHarga($datProv->kode_product, $datProv->layanan_ppob);
        
        //var_dump($cekAvailableProduct);
        //	echo "<br><br><br>";
        
        if($cekAvailableProduct['respon_code'] == 200) {
          	$builder = $this->_db->table('_daftar_produk_ppob_tb_b');
          	if($datProv->harga_beli != (int)$cekAvailableProduct['harga']) {
              	$newHarga = (int)$cekAvailableProduct['harga'] + (int)$datProv->markup_harga;
                $data= [
                    'title_product' => $cekAvailableProduct['product'],
                    'harga_beli' => (int)$cekAvailableProduct['harga'],
                  	'harga' => $newHarga,
                  	'status_product' => 1,
                  	'updated_at' => date('Y-m-d H:i:s')
                ];
              
              	$builder->where('id', $datProv->id)->update($data);
            }
          	var_dump($cekAvailableProduct);
        	echo "<br><br><br>";
		}else{
          	echo "gagal Load <br>";
        }
        
        
        
        
      
        //$url = "https://pro.rajaongkir.com/api/subdistrict?city=".$datProv->city_id;
        
        //$url = "https://pro.rajaongkir.com/api/subdistrict?city=1";

        //$token = "Basic " . getenv('configurasimidtrans.default.key');
        //$encoderData = json_encode($data, JSON_UNESCAPED_SLASHES);

        //$ch = curl_init();
        //curl_setopt($ch, CURLOPT_URL,$url);
        //curl_setopt($ch, CURLOPT_TIMEOUT, 0);
        //curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 500);
        //curl_setopt($ch, CURLOPT_POSTFIELDS,$encoderData);  //Post Fields
        //curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        //curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        //curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        //$headers = [
        //      'key: aadcff7aea0870ee1399dd6cb554e4d1',
        //      'Accept: application/json',
        //      'Content-Type: application/json'
        //];

        //curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        //$server_output = curl_exec ($ch);

        //curl_close ($ch);



        //$data = json_decode($server_output);
      	//var_dump($data);die;
        //$i = 0;
        //$a = $data->rajaongkir->results;
        //if($i == 100){
          //$builder = $this->_db->table('ref_kecamatan');

          //foreach ($a as $kab) {
          //  $dataInsert = [
          //    'subdistrict_id'=> $kab->subdistrict_id,
          //    'province_id'=> $kab->province_id,
          //    'province'=> $kab->province,
          //    'city_id'=> $kab->city_id,
          //    'city'=> $kab->city,
          //    'type'=> $kab->type,
          //    'subdistrict_name'=> $kab->subdistrict_name,
          //    'created_at'=> $date
          //  ];


           // $builder->insert($dataInsert);
           // echo "berhasil input ==> " . $kab->subdistrict_name . '<br>';
          //}

          //echo "jumlah semua data => " . count($a);
        //}
       // echo "jumlah kecamatan => " .count($a) . "<br>";
      }
    }
  
    public function indexOld()
    {
      
        
//$email = \Config\Services::email();

                      	//$email->setFrom('admin-silat@lampungtengahkab.go.id', 'Yestore Commerce');
                  //      $email->setFrom('admin@moroarto.com', 'PT. MORO ARTO GLOBALINDO');
                  //      $email->setTo('restapi.handoko@gmail.com');

                  //      $email->setSubject('Aktivasi Akun MoroArto');
                  //      $email->setMessage('https://help.moroarto.com<br>Hubungi Kami');

                  //      if ($email->send()) {
                  //          echo "Kode OTP telah di kirim. Silahkan cek inbox atau spam.";
                  //      } else {
                   //       var_dump($this->fail($email->printDebugger()));
                            //return ;
                   //     }

        
        // var_dump($altClient);
       // die;
    }
  

    //--------------------------------------------------------------------

}


