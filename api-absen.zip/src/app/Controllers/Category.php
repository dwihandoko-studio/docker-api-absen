<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;

class Category extends ResourceController
{
    //protected $modelName = 'App\Models\ProductpublicModel';
    protected $format = 'json';

    var $folderImage = 'product';

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
      	$this->_db      = \Config\Database::connect();
    }
  
  	public function index()
    { 
        $select = "id as categoryId, category_name as categoryName, key_search as keySearch";
        $cat = $this->_db->table('_category_tb_b')->select($select)->where(['is_active' => 1])->orderBy('category_name', 'asc')->get()->getResult();

        if(count($cat) > 0) {
          $data['result'] = $cat;
          $data['total_result'] = count($cat);
          return $this->respond($data);
        }else{
          return $this->respondNoContent('Tidak ada content.');
        }
    }
}