<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;

class Payment extends ResourceController
{
    protected $modelName = 'App\Models\PaymentModel';
    protected $format = 'json';

    var $folderImage = 'profile';
  	private $_db;

    function __construct()
    {
        helper(['form', 'text', 'array', 'fotourl', 'filesystem']);
      	$this->_db = \Config\Database::connect();
    }

    public function index()
    {
        $select = "id, layanan_payment as layananPayment, payment_type as paymentType, bank, group_payment as groupPayment, logo_payment as logoPayment, title_payment as titlePayment, nama_pemilik as namaPemilik, no_rekening as noRekening, cost_payment as costPayment, no_urut as noUrut, group_urut as groupUrut, status_payment as statusPayment, favorite_payment as favoritePayment, created_at as createdAt, updated_at as updatedAt";

        $where = [
            'publish' => 1,
        ];
        $data['listPayment'] = $this->model->select($select)->where($where)->orderBy('no_urut', 'asc')->findAll();
        // // $data['result'] = $this->model->findAll($per_page, $start);
        $data['total_result'] = $this->model->where($where)->countAllResults();
        // }

        if ($data['total_result'] > 0) {
            return $this->respond($data);
        } else {
            return $this->respondNoContent('Tidak ada content.');
        }
    }

    public function buatpayment()
    {
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            // 'userId' => 'required|min_length[3]|max_length[50]',
            'userId' => 'required',
            'kodeTransaksi' => 'required',
            'paymentId' => 'required',
          	'paymentFor' => 'required',
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
			$kodeTransaksi = htmlspecialchars($this->request->getVar('kodeTransaksi'), true);
          	$userId = htmlspecialchars($this->request->getVar('userId'), true);
          	$jenisPembayaran = htmlspecialchars($this->request->getVar('paymentFor'), true);
          	$idPaymentGateway = htmlspecialchars($this->request->getVar('paymentId'), true);
          
          	if($jenisPembayaran == "topup") {
                $builder = $this->_db->table('_topup_tb_b');

                $where = [
                    'kode_transaksi' => $kodeTransaksi,
                    'user_id' => $userId,
                ];

                $dataTopup = $builder->where($where)->get()->getRowObject();
              
              	if($dataTopup) {
                  	$builderPayment = $this->_db->table('_payment_gateway_tb_b');
                  	$dataPay = $builderPayment->where('id', $idPaymentGateway)->get()->getRowObject();
                  
                  	if($dataPay) {
                      	$cek = $this->_checkPayment($kodeTransaksi, $jenisPembayaran);
                      	if($cek) {
                          	if($cek->payment_id == $dataPay->id) {
                              	if($dataPay->layanan_payment == "moroarto") {
                                  	$dataResponse['layananPayment'] = "moroarto";
                                    $dataResponse['detail']['kodeTransaksi'] = $kodeTransaksi;
                                    $dataResponse['detail']['jenis_pembayaran'] = $cek->jenis_pembayaran;
                                    $dataResponse['detail']['grossAmount'] = $cek->total_gross_amount;
                                    $dataResponse['detail']['createdAt'] = $cek->created_at;
                                    $dataResponse['detail']['payment_id'] = $cek->payment_id;
                                    $dataResponse['detail']['bank'] = $dataPay->bank;
                                    $dataResponse['detail']['logoPayment'] = $dataPay->logo_payment;
                                    $dataResponse['detail']['titlePayment'] = $dataPay->title_payment;
                                    $dataResponse['detail']['namaPemilik'] = $dataPay->nama_pemilik;
                                  	$dataResponse['detail']['noRekening'] = $dataPay->no_rekening;
                                  	$dataResponse['detail']['costAmount'] = $cek->cost_amount;
                                  	
                                  	return $this->respond($dataResponse);
                                } else {
                                   //untuk midtrans
                                }
                            } else {
                              	$unixAmount = random_string('numeric', 3);
                              	//$unixAmount = "0";
                              	$dataPembayaran = [
                                    'payment_id' => $dataPay->id,
                                    'user_id' => $userId,
                                    'jenis_pembayaran' => "topup",
                                    'gross_amount' => $dataTopup->nominal,
                                  	'total_gross_amount' => (int)$dataTopup->nominal + (int)$unixAmount,
                                  	'unix_amount' => (int)$unixAmount,
                                  	'cost_amount' => $dataPay->cost_payment,
                                    'bank' => $dataPay->bank,
                                    'status_payment' => 0,
                                    'created_at' => date('Y-m-d H:i:s'),
                                ];
                              	
                              	$builderUpdate = $this->_db->table('_history_tagihan_pembayaran_user_tb_b');
                              	$update = $builderUpdate->where('kode_transaksi', $kodeTransaksi)->update($dataPembayaran);
                              
                              	if($dataPay->layanan_payment == "moroarto") {
                                    $dataResponse['layananPayment'] = $dataPay->layanan_payment;
                                    $dataResponse['detail']['kodeTransaksi'] = $kodeTransaksi;
                                    $dataResponse['detail']['jenis_pembayaran'] = $dataPembayaran['jenis_pembayaran'];
                                    $dataResponse['detail']['grossAmount'] = (string)$dataPembayaran['total_gross_amount'];
                                    $dataResponse['detail']['createdAt'] = $dataPembayaran['created_at'];
                                    $dataResponse['detail']['payment_id'] = $dataPembayaran['payment_id'];
                                    $dataResponse['detail']['bank'] = $dataPay->bank;
                                    $dataResponse['detail']['logoPayment'] = $dataPay->logo_payment;
                                    $dataResponse['detail']['titlePayment'] = $dataPay->title_payment;
                                    $dataResponse['detail']['namaPemilik'] = $dataPay->nama_pemilik;
                                    $dataResponse['detail']['noRekening'] = $dataPay->no_rekening;
                                    $dataResponse['detail']['costAmount'] = $dataPembayaran['cost_amount'];

                                    return $this->respond($dataResponse);
                                } else {
                                  	//untuk midtrans
                                }
                            }
                        } else {
                          	$unixAmount = random_string('numeric', 3);
                          	$dataPembayaran = [
                                'kode_transaksi' => $kodeTransaksi,
                                'payment_id' => $dataPay->id,
                                'user_id' => $userId,
                                'jenis_pembayaran' => "topup",
                                'gross_amount' => $dataTopup->nominal,
                              	'total_gross_amount' => (int)$dataTopup->nominal + (int)$unixAmount,
                              	'unix_amount' => (int)$unixAmount,
                                'cost_amount' => $dataPay->cost_payment,
                                'bank' => $dataPay->bank,
                                'status_payment' => 0,
                                'created_at' => date('Y-m-d H:i:s'),
                              ];

                            $builderInsert = $this->_db->table('_history_tagihan_pembayaran_user_tb_b');
                            $insert = $builderInsert->insert($dataPembayaran);
                            //var_dump($insert);
                          
                          	if($dataPay->layanan_payment == "moroarto") {
                                $dataResponse['layananPayment'] = $dataPay->layanan_payment;
                                $dataResponse['detail']['kodeTransaksi'] = $kodeTransaksi;
                                $dataResponse['detail']['jenis_pembayaran'] = $dataPembayaran['jenis_pembayaran'];
                                $dataResponse['detail']['grossAmount'] = (string)$dataPembayaran['total_gross_amount'];
                                $dataResponse['detail']['createdAt'] = $dataPembayaran['created_at'];
                                $dataResponse['detail']['payment_id'] = $dataPembayaran['payment_id'];
                                $dataResponse['detail']['bank'] = $dataPay->bank;
                                $dataResponse['detail']['logoPayment'] = $dataPay->logo_payment;
                                $dataResponse['detail']['titlePayment'] = $dataPay->title_payment;
                                $dataResponse['detail']['namaPemilik'] = $dataPay->nama_pemilik;
                                $dataResponse['detail']['noRekening'] = $dataPay->no_rekening;
                                $dataResponse['detail']['costAmount'] = $dataPembayaran['cost_amount'];

                                return $this->respond($dataResponse);
                            }else{
                               //untuk midtrans
                              return $this->responNoContent("Jenis Pembayaran masih offline");
                            }
                        }
                      	
                    }else{
                      	return $this->responNoContent("Jenis Pembayaran tidak ditemukan");
                    }
                  	
                  	
                }else{
                  	return $this->fail("Tagihan pembayaran tidak ditemukan");
                }

            } else if($jenisPembayaran == "orderPpob"){
              	$builder = $this->_db->table('_orders_tb_b');

                $where = [
                    'kode_transaksi' => $kodeTransaksi,
                    'user_id' => $userId,
                ];

                $dataPpob = $builder->where($where)->get()->getRowObject();
              
              	if($dataPpob) {
                  	$builderPayment = $this->_db->table('_payment_gateway_tb_b');
                  	$dataPay = $builderPayment->where('id', $idPaymentGateway)->get()->getRowObject();
                  
                  	if($dataPay) {
                      	$cek = $this->_checkPayment($kodeTransaksi, $jenisPembayaran);
                      	if($cek) {
                          	if($cek->payment_id == $dataPay->id) {
                              	if($dataPay->layanan_payment == "moroarto") {
                                  	$dataResponse['layananPayment'] = "moroarto";
                                    $dataResponse['detail']['kodeTransaksi'] = $kodeTransaksi;
                                    $dataResponse['detail']['jenis_pembayaran'] = $cek->jenis_pembayaran;
                                    $dataResponse['detail']['grossAmount'] = $cek->total_gross_amount;
                                    $dataResponse['detail']['createdAt'] = $cek->created_at;
                                    $dataResponse['detail']['payment_id'] = $cek->payment_id;
                                    $dataResponse['detail']['bank'] = $dataPay->bank;
                                    $dataResponse['detail']['logoPayment'] = $dataPay->logo_payment;
                                    $dataResponse['detail']['titlePayment'] = $dataPay->title_payment;
                                    $dataResponse['detail']['namaPemilik'] = $dataPay->nama_pemilik;
                                  	$dataResponse['detail']['noRekening'] = $dataPay->no_rekening;
                                  	$dataResponse['detail']['costAmount'] = $cek->cost_amount;
                                  	
                                  	return $this->respond($dataResponse);
                                } else {
                                   //untuk midtrans
                                }
                            } else {
                              	$unixAmount = random_string('numeric', 3);
                              	$dataPembayaran = [
                                    'payment_id' => $dataPay->id,
                                    'user_id' => $userId,
                                    'jenis_pembayaran' => "orderPpob",
                                    'gross_amount' => $dataPpob->total_harga,
                                  	'total_gross_amount' => (int)$dataPpob->total_harga + (int)$unixAmount,
                              		'unix_amount' => (int)$unixAmount,
                                  	'cost_amount' => $dataPay->cost_payment,
                                    'bank' => $dataPay->bank,
                                    'status_payment' => 0,
                                    'created_at' => date('Y-m-d H:i:s'),
                                ];
                              	
                              	$builderUpdate = $this->_db->table('_history_tagihan_pembayaran_user_tb_b');
                              	$update = $builderUpdate->where('kode_transaksi', $kodeTransaksi)->update($dataPembayaran);
                              
                              	if($dataPay->layanan_payment == "moroarto") {
                                    $dataResponse['layananPayment'] = $dataPay->layanan_payment;
                                    $dataResponse['detail']['kodeTransaksi'] = $kodeTransaksi;
                                    $dataResponse['detail']['jenis_pembayaran'] = $dataPembayaran['jenis_pembayaran'];
                                    $dataResponse['detail']['grossAmount'] = (string)$dataPembayaran['total_gross_amount'];
                                    $dataResponse['detail']['createdAt'] = $dataPembayaran['created_at'];
                                    $dataResponse['detail']['payment_id'] = $dataPembayaran['payment_id'];
                                    $dataResponse['detail']['bank'] = $dataPay->bank;
                                    $dataResponse['detail']['logoPayment'] = $dataPay->logo_payment;
                                    $dataResponse['detail']['titlePayment'] = $dataPay->title_payment;
                                    $dataResponse['detail']['namaPemilik'] = $dataPay->nama_pemilik;
                                    $dataResponse['detail']['noRekening'] = $dataPay->no_rekening;
                                    $dataResponse['detail']['costAmount'] = $dataPembayaran['cost_amount'];

                                    return $this->respond($dataResponse);
                                } else {
                                  	//untuk midtrans
                                }
                            }
                        } else {
                          	$unixAmount = random_string('numeric', 3);
                          	$dataPembayaran = [
                                'kode_transaksi' => $kodeTransaksi,
                                'payment_id' => $dataPay->id,
                                'user_id' => $userId,
                                'jenis_pembayaran' => "orderPpob",
                                'gross_amount' => $dataPpob->total_harga,
                              	'total_gross_amount' => (int)$dataPpob->total_harga + (int)$unixAmount,
                              	'unix_amount' => (int)$unixAmount,
                                'cost_amount' => $dataPay->cost_payment,
                                'bank' => $dataPay->bank,
                                'status_payment' => 0,
                                'created_at' => date('Y-m-d H:i:s'),
                              ];

                            $builderInsert = $this->_db->table('_history_tagihan_pembayaran_user_tb_b');
                            $insert = $builderInsert->insert($dataPembayaran);
                            //var_dump($insert);
                          
                          	if($dataPay->layanan_payment == "moroarto") {
                                $dataResponse['layananPayment'] = $dataPay->layanan_payment;
                                $dataResponse['detail']['kodeTransaksi'] = $kodeTransaksi;
                                $dataResponse['detail']['jenis_pembayaran'] = $dataPembayaran['jenis_pembayaran'];
                                $dataResponse['detail']['grossAmount'] = (string)$dataPembayaran['total_gross_amount'];
                                $dataResponse['detail']['createdAt'] = $dataPembayaran['created_at'];
                                $dataResponse['detail']['payment_id'] = $dataPembayaran['payment_id'];
                                $dataResponse['detail']['bank'] = $dataPay->bank;
                                $dataResponse['detail']['logoPayment'] = $dataPay->logo_payment;
                                $dataResponse['detail']['titlePayment'] = $dataPay->title_payment;
                                $dataResponse['detail']['namaPemilik'] = $dataPay->nama_pemilik;
                                $dataResponse['detail']['noRekening'] = $dataPay->no_rekening;
                                $dataResponse['detail']['costAmount'] = $dataPembayaran['cost_amount'];

                                return $this->respond($dataResponse);
                            }else{
                               //untuk midtrans
                              return $this->responNoContent("Jenis Pembayaran masih offline");
                            }
                        }
                      	
                    }else{
                      	return $this->responNoContent("Jenis Pembayaran tidak ditemukan");
                    }
                  	
                  	
                }else{
                  	return $this->fail("Tagihan pembayaran tidak ditemukan");
                }
            } else if($jenisPembayaran == "orderTagihan"){
              	$builder = $this->_db->table('_orders_tb_b');

                $where = [
                    'kode_transaksi' => $kodeTransaksi,
                    'user_id' => $userId,
                ];

                $dataTagihan = $builder->where($where)->get()->getRowObject();
              
              	if($dataTagihan) {
                  	$builderPayment = $this->_db->table('_payment_gateway_tb_b');
                  	$dataPay = $builderPayment->where('id', $idPaymentGateway)->get()->getRowObject();
                  
                  	if($dataPay) {
                      	$cek = $this->_checkPayment($kodeTransaksi, $jenisPembayaran);
                      	if($cek) {
                          	if($cek->payment_id == $dataPay->id) {
                              	if($dataPay->layanan_payment == "moroarto") {
                                  	$dataResponse['layananPayment'] = "moroarto";
                                    $dataResponse['detail']['kodeTransaksi'] = $kodeTransaksi;
                                    $dataResponse['detail']['jenis_pembayaran'] = $cek->jenis_pembayaran;
                                    $dataResponse['detail']['grossAmount'] = $cek->total_gross_amount;
                                    $dataResponse['detail']['createdAt'] = $cek->created_at;
                                    $dataResponse['detail']['payment_id'] = $cek->payment_id;
                                    $dataResponse['detail']['bank'] = $dataPay->bank;
                                    $dataResponse['detail']['logoPayment'] = $dataPay->logo_payment;
                                    $dataResponse['detail']['titlePayment'] = $dataPay->title_payment;
                                    $dataResponse['detail']['namaPemilik'] = $dataPay->nama_pemilik;
                                  	$dataResponse['detail']['noRekening'] = $dataPay->no_rekening;
                                  	$dataResponse['detail']['costAmount'] = $cek->cost_amount;
                                  	
                                  	return $this->respond($dataResponse);
                                } else {
                                   //untuk midtrans
                                }
                            } else {
                              	$unixAmount = random_string('numeric', 3);
                              	$dataPembayaran = [
                                    'payment_id' => $dataPay->id,
                                    'user_id' => $userId,
                                    'jenis_pembayaran' => "orderTagihan",
                                    'gross_amount' => $dataTagihan->total_harga,
                                  	'total_gross_amount' => (int)$dataTagihan->total_harga + (int)$unixAmount,
                              		'unix_amount' => (int)$unixAmount,
                                  	'cost_amount' => $dataPay->cost_payment,
                                    'bank' => $dataPay->bank,
                                    'status_payment' => 0,
                                    'created_at' => date('Y-m-d H:i:s'),
                                ];
                              	
                              	$builderUpdate = $this->_db->table('_history_tagihan_pembayaran_user_tb_b');
                              	$update = $builderUpdate->where('kode_transaksi', $kodeTransaksi)->update($dataPembayaran);
                              
                              	if($dataPay->layanan_payment == "moroarto") {
                                    $dataResponse['layananPayment'] = $dataPay->layanan_payment;
                                    $dataResponse['detail']['kodeTransaksi'] = $kodeTransaksi;
                                    $dataResponse['detail']['jenis_pembayaran'] = $dataPembayaran['jenis_pembayaran'];
                                    $dataResponse['detail']['grossAmount'] = (string)$dataPembayaran['total_gross_amount'];
                                    $dataResponse['detail']['createdAt'] = $dataPembayaran['created_at'];
                                    $dataResponse['detail']['payment_id'] = $dataPembayaran['payment_id'];
                                    $dataResponse['detail']['bank'] = $dataPay->bank;
                                    $dataResponse['detail']['logoPayment'] = $dataPay->logo_payment;
                                    $dataResponse['detail']['titlePayment'] = $dataPay->title_payment;
                                    $dataResponse['detail']['namaPemilik'] = $dataPay->nama_pemilik;
                                    $dataResponse['detail']['noRekening'] = $dataPay->no_rekening;
                                    $dataResponse['detail']['costAmount'] = $dataPembayaran['cost_amount'];

                                    return $this->respond($dataResponse);
                                } else {
                                  	//untuk midtrans
                                }
                            }
                        } else {
                          	$unixAmount = random_string('numeric', 3);
                          	$dataPembayaran = [
                                'kode_transaksi' => $kodeTransaksi,
                                'payment_id' => $dataPay->id,
                                'user_id' => $userId,
                                'jenis_pembayaran' => "orderTagihan",
                                'gross_amount' => $dataTagihan->total_harga,
                              	'total_gross_amount' => (int)$dataTagihan->total_harga + (int)$unixAmount,
                              	'unix_amount' => (int)$unixAmount,
                                'cost_amount' => $dataPay->cost_payment,
                                'bank' => $dataPay->bank,
                                'status_payment' => 0,
                                'created_at' => date('Y-m-d H:i:s'),
                              ];

                            $builderInsert = $this->_db->table('_history_tagihan_pembayaran_user_tb_b');
                            $insert = $builderInsert->insert($dataPembayaran);
                            //var_dump($insert);
                          
                          	if($dataPay->layanan_payment == "moroarto") {
                                $dataResponse['layananPayment'] = $dataPay->layanan_payment;
                                $dataResponse['detail']['kodeTransaksi'] = $kodeTransaksi;
                                $dataResponse['detail']['jenis_pembayaran'] = $dataPembayaran['jenis_pembayaran'];
                                $dataResponse['detail']['grossAmount'] = (string)$dataPembayaran['total_gross_amount'];
                                $dataResponse['detail']['createdAt'] = $dataPembayaran['created_at'];
                                $dataResponse['detail']['payment_id'] = $dataPembayaran['payment_id'];
                                $dataResponse['detail']['bank'] = $dataPay->bank;
                                $dataResponse['detail']['logoPayment'] = $dataPay->logo_payment;
                                $dataResponse['detail']['titlePayment'] = $dataPay->title_payment;
                                $dataResponse['detail']['namaPemilik'] = $dataPay->nama_pemilik;
                                $dataResponse['detail']['noRekening'] = $dataPay->no_rekening;
                                $dataResponse['detail']['costAmount'] = $dataPembayaran['cost_amount'];

                                return $this->respond($dataResponse);
                            }else{
                               //untuk midtrans
                              return $this->responNoContent("Jenis Pembayaran masih offline");
                            }
                        }
                      	
                    }else{
                      	return $this->responNoContent("Jenis Pembayaran tidak ditemukan");
                    }
                  	
                  	
                }else{
                  	return $this->fail("Tagihan pembayaran tidak ditemukan");
                }
              
            } else if($jenisPembayaran == "orderPesanan"){
              	$builder = $this->_db->table('_orders_tb_b');

                $where = [
                    'kode_transaksi' => $kodeTransaksi,
                    'user_id' => $userId,
                ];

                $dataOrder = $builder->where($where)->get()->getRowObject();
              
              	if($dataOrder) {
                  	$builderPayment = $this->_db->table('_payment_gateway_tb_b');
                  	$dataPay = $builderPayment->where('id', $idPaymentGateway)->get()->getRowObject();
                  
                  	if($dataPay) {
                      	$cek = $this->_checkPayment($kodeTransaksi, $jenisPembayaran);
                      	if($cek) {
                          	if($cek->payment_id == $dataPay->id) {
                              	if($dataPay->layanan_payment == "moroarto") {
                                  	$dataResponse['layananPayment'] = "moroarto";
                                    $dataResponse['detail']['kodeTransaksi'] = $kodeTransaksi;
                                    $dataResponse['detail']['jenis_pembayaran'] = $cek->jenis_pembayaran;
                                    $dataResponse['detail']['grossAmount'] = $cek->total_gross_amount;
                                    $dataResponse['detail']['createdAt'] = $cek->created_at;
                                    $dataResponse['detail']['payment_id'] = $cek->payment_id;
                                    $dataResponse['detail']['bank'] = $dataPay->bank;
                                    $dataResponse['detail']['logoPayment'] = $dataPay->logo_payment;
                                    $dataResponse['detail']['titlePayment'] = $dataPay->title_payment;
                                    $dataResponse['detail']['namaPemilik'] = $dataPay->nama_pemilik;
                                  	$dataResponse['detail']['noRekening'] = $dataPay->no_rekening;
                                  	$dataResponse['detail']['costAmount'] = $cek->cost_amount;
                                  	
                                  	return $this->respond($dataResponse);
                                } else {
                                   //untuk midtrans
                                }
                            } else {
                              	$unixAmount = random_string('numeric', 3);
                              	$dataPembayaran = [
                                    'payment_id' => $dataPay->id,
                                    'user_id' => $userId,
                                    'jenis_pembayaran' => "orderPesanan",
                                    'gross_amount' => $dataOrder->total_harga,
                                  	'total_gross_amount' => (int)$dataOrder->total_harga + (int)$unixAmount,
                              		'unix_amount' => (int)$unixAmount,
                                  	'cost_amount' => $dataPay->cost_payment,
                                    'bank' => $dataPay->bank,
                                    'status_payment' => 0,
                                    'created_at' => date('Y-m-d H:i:s'),
                                ];
                              	
                              	$builderUpdate = $this->_db->table('_history_tagihan_pembayaran_user_tb_b');
                              	$update = $builderUpdate->where('kode_transaksi', $kodeTransaksi)->update($dataPembayaran);
                              
                              	if($dataPay->layanan_payment == "moroarto") {
                                    $dataResponse['layananPayment'] = $dataPay->layanan_payment;
                                    $dataResponse['detail']['kodeTransaksi'] = $kodeTransaksi;
                                    $dataResponse['detail']['jenis_pembayaran'] = $dataPembayaran['jenis_pembayaran'];
                                    $dataResponse['detail']['grossAmount'] = (string)$dataPembayaran['total_gross_amount'];
                                    $dataResponse['detail']['createdAt'] = $dataPembayaran['created_at'];
                                    $dataResponse['detail']['payment_id'] = $dataPembayaran['payment_id'];
                                    $dataResponse['detail']['bank'] = $dataPay->bank;
                                    $dataResponse['detail']['logoPayment'] = $dataPay->logo_payment;
                                    $dataResponse['detail']['titlePayment'] = $dataPay->title_payment;
                                    $dataResponse['detail']['namaPemilik'] = $dataPay->nama_pemilik;
                                    $dataResponse['detail']['noRekening'] = $dataPay->no_rekening;
                                    $dataResponse['detail']['costAmount'] = $dataPembayaran['cost_amount'];

                                    return $this->respond($dataResponse);
                                } else {
                                  	//untuk midtrans
                                }
                            }
                        } else {
                          	$unixAmount = random_string('numeric', 3);
                          	$dataPembayaran = [
                                'kode_transaksi' => $kodeTransaksi,
                                'payment_id' => $dataPay->id,
                                'user_id' => $userId,
                                'jenis_pembayaran' => "orderPesanan",
                                'gross_amount' => $dataOrder->total_harga,
                              	'gross_amount' => $dataOrder->total_harga,
                              	'total_gross_amount' => (int)$dataOrder->total_harga + (int)$unixAmount,
                                'cost_amount' => $dataPay->cost_payment,
                                'bank' => $dataPay->bank,
                                'status_payment' => 0,
                                'created_at' => date('Y-m-d H:i:s'),
                              ];

                            $builderInsert = $this->_db->table('_history_tagihan_pembayaran_user_tb_b');
                            $insert = $builderInsert->insert($dataPembayaran);
                            //var_dump($insert);
                          
                          	if($dataPay->layanan_payment == "moroarto") {
                                $dataResponse['layananPayment'] = $dataPay->layanan_payment;
                                $dataResponse['detail']['kodeTransaksi'] = $kodeTransaksi;
                                $dataResponse['detail']['jenis_pembayaran'] = $dataPembayaran['jenis_pembayaran'];
                                $dataResponse['detail']['grossAmount'] = (string)$dataPembayaran['total_gross_amount'];
                                $dataResponse['detail']['createdAt'] = $dataPembayaran['created_at'];
                                $dataResponse['detail']['payment_id'] = $dataPembayaran['payment_id'];
                                $dataResponse['detail']['bank'] = $dataPay->bank;
                                $dataResponse['detail']['logoPayment'] = $dataPay->logo_payment;
                                $dataResponse['detail']['titlePayment'] = $dataPay->title_payment;
                                $dataResponse['detail']['namaPemilik'] = $dataPay->nama_pemilik;
                                $dataResponse['detail']['noRekening'] = $dataPay->no_rekening;
                                $dataResponse['detail']['costAmount'] = $dataPembayaran['cost_amount'];

                                return $this->respond($dataResponse);
                            }else{
                               //untuk midtrans
                              return $this->responNoContent("Jenis Pembayaran masih offline");
                            }
                        }
                      	
                    }else{
                      	return $this->responNoContent("Jenis Pembayaran tidak ditemukan");
                    }
                  	
                  	
                }else{
                  	return $this->fail("Tagihan pembayaran tidak ditemukan");
                }
            } else {
              	return $this->fail("Gagal membuat pembayaran");
            }
        }
    }
  
  	private function _checkPayment($kodeTransaksi = "", $jenisPembayaran = ""){
      	$builder = $this->_db->table('_history_tagihan_pembayaran_user_tb_b');
      	$where=[
          	'kode_transaksi' => $kodeTransaksi,
          	'jenis_pembayaran' => $jenisPembayaran,
        ];
      	return $builder->where($where)->get()->getRowObject();
    }
  
  	private function textC(){
      $builder = $this->_db->table('_orders_tb_b');

            $where = [
                //'kode_transaksi' => $kodeTransaksi,
                //'user_id' => $userId,
            ];

            $dataOrder = $builder->where($where)->get()->getRowObject();
      if ($dataOrder) {
                $item_details = [];
                $customerDetails = [];
                if ($dataOrder->jenis_order == "ppob") {
                    $detailBuilder = $db->table('_details_order_ppob_tb_b');
                    $whereDetailOrder = [
                        'order_id' => $dataOrder->id
                    ];
                    $selectDetailOrder = "";
                    $detailBuilder->select('_details_order_ppob_tb_b.product_id as productId, _details_order_ppob_tb_b.harga_product as hargaProduct, _daftar_produk_ppob_tb_b.nama_product as namaProduct, _profil_users_tb.email as email, _profil_users_tb.firsname as firsname, _profil_users_tb.lastname as lastname, _profil_users_tb.no_hp as noHp');
                    $detailBuilder->join('_daftar_produk_ppob_tb_b', '_details_order_ppob_tb_b.product_id = _daftar_produk_ppob_tb_b.id');
                    $detailBuilder->join('_profil_users_tb', '_details_order_ppob_tb_b.user_id_pembeli = _profil_users_tb.id');
                    // $query = $detailBuilder->get();
                    $detailOrder = $detailBuilder->where($whereDetailOrder)->get()->getResult();

                    if (count($detailOrder) > 0) {
                        foreach ($detailOrder as $key) {
                            $item_details_temp = [];
                            $item_details_temp['id'] = $key->productId;
                            $item_details_temp['price'] = $key->hargaProduct;
                            $item_details_temp['quantity'] = 1;
                            $item_details_temp['name'] = $key->namaProduct;
                            $item_details[] = $item_details_temp;
                        }
                        $customerDetails['email'] = $detailOrder[0]->email;
                        $customerDetails['firs_name'] = $detailOrder[0]->firsname;
                        $customerDetails['last_name'] = $detailOrder[0]->lastname;
                        $customerDetails['phone'] = ($detailOrder[0]->noHp == null || $detailOrder[0]->noHp == "") ? "" : $detailOrder[0]->noHp;
                    } else {
                        return $this->fail('Create Metode Pembayaran Gagal.');
                    }
                }

                $paymentBuilder = $db->table('_payment_gateway_tb_b');
                $wherePayment = [
                    'id' => htmlspecialchars($this->request->getVar('paymentId'), true)
                ];
                $dataPayment = $paymentBuilder->where($wherePayment)->get()->getRowObject();
              	$feedDataPaymentBack['id'] = $dataPayment->id;
              	$feedDataPaymentBack['groupPayment'] = $dataPayment->group_payment;
              	$feedDataPaymentBack['logoPayment'] = $dataPayment->logo_payment;
              	$feedDataPaymentBack['titlePayment'] = $dataPayment->title_payment;
              	$feedDataPaymentBack['costPayment'] = $dataPayment->cost_payment;
              	$feedDataPaymentBack['favoritePayment'] = $dataPayment->favorite_payment;
              
                if ($dataPayment) {
                    $data = [];
                    $data['payment_type'] = $dataPayment->payment_type;
                    if ($dataPayment->payment_type == "cstore") {
                        $data['cstore']['store'] = $dataPayment->bank;
                        if ($dataPayment->bank == "Indomaret") {
                            $data['cstore']['message'] = "Tagihan Pembayaran Moroarto kode " . $dataOrder->kode_transaksi;
                        } else {
                            $data['cstore']['alfamart_free_text_1'] = "Tagihan Pembayaran Moroarto kode " . $dataOrder->kode_transaksi;
                        }
                    } else if ($dataPayment->payment_type == "bank_transfer") {
                        $data['bank_transfer']['bank'] = $dataPayment->bank;
                        // $data['bank_transfer']['va_number'] = "";
                        $inquiry = [];
                        $inquiry1 = [];
                        $inquiry1['id'] = "Tagihan Pembayaran Moroarto";
                        $inquiry1['en'] = "Moroarto Payment Billing";

                        $inquiry[] = $inquiry1;

                        $inquiryPayment = [];
                        $inquiryPayment1 = [];
                        $inquiryPayment1['id'] = "Tagihan Pembayaran Moroarto";
                        $inquiryPayment1['en'] = "Moroarto Payment Billing";
                        $inquiryPayment[] = $inquiryPayment1;
                        $data['bank_transfer']['free_text']['inquiry'] = $inquiry;
                        $data['bank_transfer']['free_text']['payment'] = $inquiryPayment;
                    } else {
                        $data['bank_transfer']['bank'] = $dataPayment->bank;
                        // $data['bank_transfer']['va_number'] = "";
                        $inquiry = [];
                        $inquiry1 = [];
                        $inquiry1['id'] = "Tagihan Pembayaran Moroarto";
                        $inquiry1['en'] = "Moroarto Payment Billing";

                        $inquiry[] = $inquiry1;

                        $inquiryPayment = [];
                        $inquiryPayment1 = [];
                        $inquiryPayment1['id'] = "Tagihan Pembayaran Moroarto";
                        $inquiryPayment1['en'] = "Moroarto Payment Billing";
                        $inquiryPayment[] = $inquiryPayment1;
                        $data['bank_transfer']['free_text']['inquiry'] = $inquiry;
                        $data['bank_transfer']['free_text']['payment'] = $inquiryPayment;
                    }
                    $data['transaction_details']['gross_amount'] = $dataOrder->total_harga;
                    $data['transaction_details']['order_id'] = $dataOrder->kode_transaksi;

                    $data['customer_details'] = $customerDetails;
                    $data['item_details'] = $item_details;

                    // return $this->respond($data);

                    // var_dump($data);
                    // die;

                    $options = [
                        // 'baseURI' => 'https://api.sandbox.midtrans.com/v2/charge',
                        'timeout'  => 3
                    ];
                    //$client = \Config\Services::curlrequest($options);

                    $response = $this->_createPaymentMidtrans($data);
                      /*$client->setBody(json_encode($data))
                        ->request('POST', 'https://api.sandbox.midtrans.com/v2/charge', [
                            'headers' => [
                                'Authorization' => 'Basic U0ItTWlkLXNlcnZlci1aNV9xVkxiTFdMaXBwUU5TNnRFVlc2a1U6',
                                'Accept' => 'application/json',
                                'Content-Type' => 'application/json',
                            ],
                            'connect_timeout' => 5,
                            // 'body' => json_encode($data)
                        ]);*/

                    // var_dump($response);
                    // die;
                    $statusCode = $response->getStatusCode();
                    if ($statusCode == 200 || $statusCode == 201) {
                      	$pengembalianResponse = json_decode($response->getBody());
                      	if($pengembalianResponse->status_code == 406) {
                          	//$clientDup = \Config\Services::curlrequest($options);
                          	$order_id_preReq = $data['transaction_details']['order_id'];
                          	//var_dump($order_id_preReq);die;
                      		$responseDup = $this->_statusPaymentMidtrans($order_id_preReq);
                              /*$clientDup->request('GET', 'https://api.sandbox.midtrans.com/v2/'.$order_id_preReq.'/status', [
                            	'headers' => [
                                	'Authorization' => 'Basic U0ItTWlkLXNlcnZlci1aNV9xVkxiTFdMaXBwUU5TNnRFVlc2a1U6',
                                	'Accept' => 'application/json',
                                	'Content-Type' => 'application/json',
                            	],
                            	'connect_timeout' => 5,
                            	// 'body' => json_encode($data)
                        	]);*/
                          
                        	$statusCodeReType = $responseDup->getStatusCode();
                          	if($statusCodeReType == 200 || $statusCodeReType == 201) {
                              	$pengembalianResponseDup = json_decode($responseDup->getBody());
                              	//var_dump($pengembalianResponseDup);die;
                              	//return $this->respond($pengembalianResponseDup);
                              	$resPaymentType = $pengembalianResponseDup->payment_type;
                          		if($resPaymentType == "bank_transfer") {
                              		$resVaNumber = $pengembalianResponseDup->va_numbers ?? null;
                              		if($resVaNumber){
                                      	if($pengembalianResponseDup->va_numbers[0]->bank == $dataPayment->bank){
                                          $feedBack = [
                                              'transaction_time' => $pengembalianResponseDup->transaction_time,
                                              'bank' => $pengembalianResponseDup->va_numbers[0]->bank,
                                              'va_number' => $pengembalianResponseDup->va_numbers[0]->va_number,
                                              'biller_code' => null,
                                              'total_tagihan' => (int)$pengembalianResponseDup->gross_amount,
                                              'detailPayment' => $feedDataPaymentBack
                                          ];
                                        }else{
                                          $responCancel = $this->_cancelPaymentMidtrans($order_id_preReq);
                                          if($responCancel->getStatusCode() == 200 || $responCancel->getStatusCode() == 201){
                                            $pengembalianResponseCancel = json_decode($response->getBody());
                                            if($pengembalianResponseCancel->status_code == 200) {
                                              	$responseChangePayment = $this->_createPaymentMidtrans($data);
                                              	$statusCodeChangePayment = $responseChangePayment->getStatusCode();
                    							if ($statusCodeChangePayment == 200 || $statusCodeChangePayment == 201) {
                                                  $pengembalianResponseChangePayment = json_decode($responseChangePayment->getBody());
                                                  $resPaymentTypeChangePayment = $pengembalianResponseChangePayment->payment_type;
                                                  if($resPaymentTypeChangePayment == "bank_transfer") {
                                                    $resVaNumberChangePayment = $pengembalianResponseChangePayment->va_numbers ?? null;
                                                    if($resVaNumberChangePayment){
                                                      $feedBack = [
                                                          'transaction_time' => $pengembalianResponseChangePayment->transaction_time,
                                                          'bank' => $pengembalianResponseChangePayment->va_numbers[0]->bank,
                                                          'va_number' => $pengembalianResponseChangePayment->va_numbers[0]->va_number,
                                                          'biller_code' => null,
                                                          'total_tagihan' => (int)$pengembalianResponseChangePayment->gross_amount,
                                                          'detailPayment' => $feedDataPaymentBack
                                                      ];
                                                    }else{
                                                      $feedBack = [
                                                          'transaction_time' => $pengembalianResponseChangePayment->transaction_time,
                                                          'bank' => 'permata',
                                                          'va_number' => $pengembalianResponseChangePayment->permata_va_number,
                                                          'biller_code' => null,
                                                          'total_tagihan' => (int)$pengembalianResponseChangePayment->gross_amount,
                                                          'detailPayment' => $feedDataPaymentBack
                                                      ];
                                                    }
                                                  }else if($resPaymentTypeChangePayment == "echannel") {

                                                      $feedBack = [
                                                          'transaction_time' => $pengembalianResponseChangePayment->transaction_time,
                                                          'bank' => 'mandiri',
                                                          'va_number' => $pengembalianResponseChangePayment->bill_key,
                                                          'biller_code' => $pengembalianResponseChangePayment->biller_code,
                                                          'total_tagihan' => (int)$pengembalianResponseChangePayment->gross_amount,
                                                          'detailPayment' => $feedDataPaymentBack
                                                      ];

                                                  }else {
                                                    $feedBack = [
                                                          'transaction_time' => $pengembalianResponseChangePayment->transaction_time,
                                                          'bank' => 'mandiri',
                                                          'va_number' => $pengembalianResponseChangePayment->bill_key,
                                                          'biller_code' => $pengembalianResponseChangePayment->biller_code,
                                                          'total_tagihan' => (int)$pengembalianResponseChangePayment->gross_amount,
                                                          'detailPayment' => $feedDataPaymentBack
                                                      ];
                                                  }

                                                  return $this->respond($feedBack);
                                                }else{
                                                  return $this->fail($statusCode);
                                                }
                                            }else{
                                              return $this->fail($statusCode);
                                            }
                                          }else{
                                            return $this->fail($statusCode);
                                          }
                                        }
                              		}else{
                                		$feedBack = [
                              				'transaction_time' => $pengembalianResponseDup->transaction_time,
                              				'bank' => 'permata',
                                  			'va_number' => $pengembalianResponseDup->permata_va_number,
                                  			'biller_code' => null,
                                  			'total_tagihan' => (int)$pengembalianResponseDup->gross_amount,
                                          	'detailPayment' => $feedDataPaymentBack
                            			];
                              		}
                            	}else if($resPaymentType == "echannel") {
                              
                                	$feedBack = [
                              			'transaction_time' => $pengembalianResponseDup->transaction_time,
                              			'bank' => 'mandiri',
                                  		'va_number' => $pengembalianResponseDup->bill_key,
                                  		'biller_code' => $pengembalianResponseDup->biller_code,
                                  		'total_tagihan' => (int)$pengembalianResponseDup->gross_amount,
                                      	'detailPayment' => $feedDataPaymentBack
                            		];
                              
                            	}else {
                              	$feedBack = [
                              			'transaction_time' => $pengembalianResponseDup->transaction_time,
                              			'bank' => 'mandiri',
                                  		'va_number' => $pengembalianResponseDup->bill_key,
                                  		'biller_code' => $pengembalianResponseDup->biller_code,
                                  		'total_tagihan' => (int)$pengembalianResponseDup->gross_amount,
                                  		'detailPayment' => $feedDataPaymentBack
                            		];
                            	}
                          	
                          		return $this->respond($feedBack);
                            	//return $this->respond(json_decode($responseDup->getBody()));
                          	}else{
                            	return $this->fail($statusCode);
                          	}
                        
                        }else{
                          	$resPaymentType = $pengembalianResponse->payment_type;
                          	if($resPaymentType == "bank_transfer") {
                              $resVaNumber = $pengembalianResponse->va_numbers ?? null;
                              if($resVaNumber){
                                $feedBack = [
                              		'transaction_time' => $pengembalianResponse->transaction_time,
                              		'bank' => $pengembalianResponse->va_numbers[0]->bank,
                                  	'va_number' => $pengembalianResponse->va_numbers[0]->va_number,
                                  	'biller_code' => null,
                                  	'total_tagihan' => (int)$pengembalianResponse->gross_amount,
                                  	'detailPayment' => $feedDataPaymentBack
                            	];
                              }else{
                                $feedBack = [
                              		'transaction_time' => $pengembalianResponse->transaction_time,
                              		'bank' => 'permata',
                                  	'va_number' => $pengembalianResponse->permata_va_number,
                                  	'biller_code' => null,
                                  	'total_tagihan' => (int)$pengembalianResponse->gross_amount,
                                  	'detailPayment' => $feedDataPaymentBack
                            	];
                              }
                            }else if($resPaymentType == "echannel") {
                              
                                $feedBack = [
                              		'transaction_time' => $pengembalianResponse->transaction_time,
                              		'bank' => 'mandiri',
                                  	'va_number' => $pengembalianResponse->bill_key,
                                  	'biller_code' => $pengembalianResponse->biller_code,
                                  	'total_tagihan' => (int)$pengembalianResponse->gross_amount,
                                  	'detailPayment' => $feedDataPaymentBack
                            	];
                              
                            }else {
                              $feedBack = [
                              		'transaction_time' => $pengembalianResponse->transaction_time,
                              		'bank' => 'mandiri',
                                  	'va_number' => $pengembalianResponse->bill_key,
                                  	'biller_code' => $pengembalianResponse->biller_code,
                                  	'total_tagihan' => (int)$pengembalianResponse->gross_amount,
                                	'detailPayment' => $feedDataPaymentBack
                            	];
                            }
                          	
                          	return $this->respond($feedBack);
                        }
                        
                    } else if($statusCode == 406){
                      	$clientDup = \Config\Services::curlrequest($options);
                      	$responseDup = $clientDup->request('GET', 'https://api.sandbox.midtrans.com/v2/'.$data['transaction_details']['order_id'].'/status', [
                            'headers' => [
                                'Authorization' => 'Basic U0ItTWlkLXNlcnZlci1aNV9xVkxiTFdMaXBwUU5TNnRFVlc2a1U6',
                                'Accept' => 'application/json',
                                'Content-Type' => 'application/json',
                            ],
                            'connect_timeout' => 5,
                            // 'body' => json_encode($data)
                        ]);
                        return $this->respond(json_encode($responseDup));
                    } else {
                      	return $this->fail($statusCode);
                    }
                } else {
                    return $this->fail('Create Metode Pembayaran Gagal.');
                }
            } else {
                return $this->fail('Create Metode Pembayaran Gagal.');
            }

            //die;


            // if (htmlspecialchars($this->request->getVar('jenisOrder'), true) == "ecommerce") {
            //     $uuid = new Uuid();
            //     $userId = htmlspecialchars($this->request->getVar('userId'), true);

            //     $kodeTransaksi = "MRTEC" . TIME() . random_string('numeric', 4);
            //     $id = $uuid->v4();

            //     $data = [
            //         'id' => $id,
            //         'kode_transaksi' => $kodeTransaksi,
            //         'user_id' => $userId,
            //         'jenis_order' => htmlspecialchars($this->request->getVar('jenisOrder'), true),
            //         'total_qty' => htmlspecialchars($this->request->getVar('qty'), true),
            //         'total_harga' => htmlspecialchars($this->request->getVar('totalHarga'), true),
            //         'status_order' => 0,
            //         'created_at' => date('Y-m-d H:i:s'),
            //     ];

            //     try {
            //         $user_id = $this->model->insert($data);
            //         if ($user_id) {
            //             $itemsProduct = explode(",", htmlspecialchars($this->request->getVar('itemsProduct'), true));
            //             $hargasProduct = explode(",", htmlspecialchars($this->request->getVar('hargasProduct'), true));
            //             $qtysProduct = explode(",", htmlspecialchars($this->request->getVar('qtysProduct'), true));
            //             $pengirimansProduct = explode(",", htmlspecialchars($this->request->getVar('pengirimansProduct'), true));
            //             $jenisPengirimansProduct = explode(",", htmlspecialchars($this->request->getVar('jenisPengirimansProduct'), true));
            //             $hargaPengirimansProduct = explode(",", htmlspecialchars($this->request->getVar('hargaPengirimansProduct'), true));

            //             $db      = \Config\Database::connect();

            //             foreach ($itemsProduct as $key => $value) {
            //                 $builder = $db->table('_details_order_commerce_tb_b');
            //                 $uuidNew = new Uuid();
            //                 $dataOrder = [
            //                     'id' => $uuidNew->v4(),
            //                     'order_id' => $kodeTransaksi,
            //                     'product_id' => $value,
            //                     'alamat_shippping_id' => htmlspecialchars($this->request->getVar('alamatPengiriman'), true),
            //                     'harga_product' => $hargasProduct[$key],
            //                     'qty_product' => $qtysProduct[$key],
            //                     'jasa_pengiriman' => $pengirimansProduct[$key],
            //                     'jenis_pengiriman' => $jenisPengirimansProduct[$key],
            //                     'harga_ongkir' => $hargaPengirimansProduct[$key],
            //                     'order_telah_sampai' => 0,
            //                     'kode_pengiriman' => "",
            //                     'user_id_pembeli' => $userId,
            //                     'created_at' => date('Y-m-d H:i:s'),
            //                 ];
            //                 $detailOrder = $builder->insert($dataOrder);
            //                 if ($detailOrder) {
            //                     $data['items_product'][] = $detailOrder;
            //                 } else {
            //                     $this->model->delete($id);
            //                     return $this->fail('Failed Created Orders');
            //                 }
            //             }
            //         }
            //     } catch (\Throwable $th) {
            //         return $this->fail($th);
            //     }
            //     return $this->respondCreated($data);
            // } else if (htmlspecialchars($this->request->getVar('jenisOrder'), true) == "ppob") {
            //     $uuid = new Uuid();
            //     $userId = htmlspecialchars($this->request->getVar('userId'), true);

            //     $kodeTransaksi = "MRTPOB" . TIME() . random_string('numeric', 4);
            //     $id = $uuid->v4();

            //     $data = [
            //         'id' => $id,
            //         'kode_transaksi' => $kodeTransaksi,
            //         'user_id' => $userId,
            //         'jenis_order' => htmlspecialchars($this->request->getVar('jenisOrder'), true),
            //         'total_qty' => htmlspecialchars($this->request->getVar('totalQty'), true),
            //         'total_harga' => htmlspecialchars($this->request->getVar('totalHarga'), true),
            //         'status_order' => 0,
            //         'created_at' => date('Y-m-d H:i:s'),
            //     ];

            //     try {
            //         $user_id = $this->model->insertData($data, false);
            //         // var_dump($user_id);
            //         if ($user_id > 0) {
            //             // $itemsProduct = explode(",", htmlspecialchars($this->request->getVar('kodeProduct'), true));
            //             // $hargasProduct = explode(",", htmlspecialchars($this->request->getVar('hargasProduct'), true));
            //             // $qtysProduct = explode(",", htmlspecialchars($this->request->getVar('qtysProduct'), true));
            //             // $pengirimansProduct = explode(",", htmlspecialchars($this->request->getVar('pengirimansProduct'), true));
            //             // $jenisPengirimansProduct = explode(",", htmlspecialchars($this->request->getVar('jenisPengirimansProduct'), true));
            //             // $hargaPengirimansProduct = explode(",", htmlspecialchars($this->request->getVar('hargaPengirimansProduct'), true));

            //             $db      = \Config\Database::connect();

            //             // foreach ($itemsProduct as $key => $value) {
            //             $builder = $db->table('_details_order_ppob_tb_b');
            //             $uuidNew = new Uuid();
            //             $dataOrder = [
            //                 'id' => $uuidNew->v4(),
            //                 'order_id' => $id,
            //                 'product_id' => htmlspecialchars($this->request->getVar('idProduct'), true),
            //                 'harga_product' => htmlspecialchars($this->request->getVar('hargaProduct'), true),
            //                 'no_pelanggan' => htmlspecialchars($this->request->getVar('noPelanggan'), true),
            //                 'jenis_ppob' => htmlspecialchars($this->request->getVar('jenis'), true),
            //                 'order_telah_selesai' => 0,
            //                 'user_id_pembeli' => $userId,
            //                 'created_at' => date('Y-m-d H:i:s'),
            //             ];
            //             $builder->insert($dataOrder);
            //             $detailOrder = $db->affectedRows();

            //             if ($detailOrder > 0) {
            //                 $data['items_product'] = $dataOrder;
            //             } else {
            //                 $this->model->delete($id);
            //                 return $this->fail('Failed Created Orders');
            //             }
            //             // }
            //         }
            //     } catch (\Throwable $th) {
            //         return $this->fail($th);
            //     }
            //     return $this->respondCreated($data);
            // } else {
            //     return $this->fail('Failed Created Orders');
            // }
    }
                                            
   	private function _statusPaymentMidtrans($orderId){
      	$options = [
              // 'baseURI' => 'https://api.sandbox.midtrans.com/v2/charge',
              'timeout'  => 3
        ];
        $client = \Config\Services::curlrequest($options);
      	$response = $client->request('GET', 'https://api.sandbox.midtrans.com/v2/'.$orderId.'/status', [
      		'headers' => [
                  'Authorization' => 'Basic U0ItTWlkLXNlcnZlci1aNV9xVkxiTFdMaXBwUU5TNnRFVlc2a1U6',
                  'Accept' => 'application/json',
                  'Content-Type' => 'application/json',
            ],
            'connect_timeout' => 5,
                            	// 'body' => json_encode($data)
        ]);
      	
      	return $response;
    }
  
  	private function _cancelPaymentMidtrans($orderId){
      	$options = [
              // 'baseURI' => 'https://api.sandbox.midtrans.com/v2/charge',
              'timeout'  => 3
        ];
        $client = \Config\Services::curlrequest($options);
      	$response = $client->request('POST', 'https://api.sandbox.midtrans.com/v2/'.$orderId.'/cancel', [
      		'headers' => [
                  'Authorization' => 'Basic U0ItTWlkLXNlcnZlci1aNV9xVkxiTFdMaXBwUU5TNnRFVlc2a1U6',
                  'Accept' => 'application/json',
                  'Content-Type' => 'application/json',
            ],
            'connect_timeout' => 5,
                            	// 'body' => json_encode($data)
        ]);
      	
      	return $response;
    }
  
  	private function _createPaymentMidtrans($data) {
      $options = [
              // 'baseURI' => 'https://api.sandbox.midtrans.com/v2/charge',
              'timeout'  => 3
        ];
      $client = \Config\Services::curlrequest($options);
      $response = $client->setBody(json_encode($data))
                        ->request('POST', 'https://api.sandbox.midtrans.com/v2/charge', [
                            'headers' => [
                                'Authorization' => 'Basic U0ItTWlkLXNlcnZlci1aNV9xVkxiTFdMaXBwUU5TNnRFVlc2a1U6',
                                'Accept' => 'application/json',
                                'Content-Type' => 'application/json',
                            ],
                            'connect_timeout' => 5,
                            // 'body' => json_encode($data)
                        ]);
      return $response;
    }

    // public function create()
    // {
    //     $rules = [
    //         // 'userId' => 'required|min_length[3]|max_length[50]',
    //         'userId' => 'required',
    //         'idProduct' => 'required',
    //         'qty' => 'required',
    //     ];

    //     if (!$this->validate($rules)) {
    //         return $this->fail($this->validator->getErrors());
    //     } else {
    //         $uuid = new Uuid();

    //         $data = [
    //             'id' => $uuid->v4(),
    //             'user_id' => htmlspecialchars($this->request->getVar('userId'), true),
    //             'product_id' => htmlspecialchars($this->request->getVar('idProduct'), true),
    //             'qty' => htmlspecialchars($this->request->getVar('qty'), true),
    //             'created_at' => date('Y-m-d H:i:s'),
    //         ];

    //         try {
    //             $user_id = $this->model->insert($data);
    //         } catch (\Throwable $th) {
    //             return $this->fail($th);
    //         }
    //         return $this->respondCreated($data);
    //     }
    // }

    // public function show($id = null)
    // {
    //     $data = $this->model->find($id);
    //     if ($data) {
    //         return $this->respond($data);
    //     } else {
    //         return $this->failNotFound('Item not found');
    //     }
    // }

    // public function update($id = null)
    // {
    //     $oldData = $this->model->find($id);
    //     $rules = [
    //         // 'id' => 'required|min_length[3]|max_length[50]',
    //         // 'lastname' => 'required|min_length[3]|max_length[50]',
    //         // 'email' => 'required|valid_email|is_unique[_users_tb.email]',
    //         'id' => 'required',
    //         'qty' => 'required',
    //         // 'password' => 'required|min_length[6]',
    //         // 'password_confirm' => 'matches[password]',
    //     ];

    //     if (!$this->validate($rules)) {
    //         return $this->failValidationError($this->validator->getError());
    //     } else {
    //         $data = [
    //             'id' => htmlspecialchars($id, true),
    //             'qty' => htmlspecialchars($this->request->getVar('qty'), true),
    //             'updated_at' => date('Y-m-d H:i:s'),
    //         ];

    //         try {
    //             $this->model->save($data);
    //             // unset($data['password']);
    //         } catch (\Throwable $th) {
    //             return $this->fail($th);
    //             // return $this->failNotFound('gagal simpan database');
    //         }
    //         return $this->respond($data);
    //     }
    // }

    // public function delete($id = null)
    // {
    //     $data = $this->model->find($id);
    //     if ($data) {
    //         try {
    //             $this->model->delete($id);
    //             $dat['status'] = "deleted";
    //             $dat['message'] = "Item data berhasil di hapus.";
    //             $dat['description'] = "Product berhasil di hapus dari keranjang";
    //             $dat['data'] = $data;
    //             return $this->respondDeleted($dat);
    //         } catch (\Throwable $th) {
    //             return $this->fail($th);
    //         }
    //     } else {
    //         return $this->failNotFound('Item not found');
    //     }
    // }
}
