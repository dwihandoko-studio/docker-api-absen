<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;

class Profiluser extends ResourceController
{
	protected $modelName = 'App\Models\UserProfilModel';
	protected $format = 'json';

	var $folderImage = 'profile';

	function __construct()
	{
		helper(['form', 'array', 'fotourl', 'filesystem']);
	}

	public function index()
	{
		$data['result'] = $this->model->findAll();
		$data['total_result'] = $this->model->countAllResults();
		if ($data['total_result'] > 0) {
			return $this->respond($data);
		} else {
			return $this->respondNoContent('Tidak ada content.');
		}
		// $per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
		// $pag = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

		// if ($pag == 1) {
		// 	$start = 0;
		// } else {
		// 	$start = (($pag - 1) * $per_page);
		// }
		// $data['result'] = $this->model->findAll($per_page, $start);
		// $data['total_result'] = $this->model->countAllResults();
		// if ($data['total_result'] > 0) {
		// 	$data['page'] = $pag;
		// 	$data['total_page'] = ceil($data['total_result'] / $per_page);
		// 	return $this->respond($data);
		// } else {
		// 	return $this->respondNoContent('Tidak ada content.');
		// }
	}

	public function create()
	{
		$rules = [
			'firsName' => 'required|min_length[3]|max_length[50]',
			//'lastName' => 'required|min_length[3]|max_length[50]',
			'userId' => 'required',
			'gender' => 'required',
		];

		if (!$this->validate($rules)) {
			return $this->fail($this->validator->getErrors());
		} else {
			$data = [
				'id' => htmlspecialchars($this->request->getVar('userId'), true),
				'firsname' => htmlspecialchars($this->request->getVar('firsName'), true),
				'lastname' => htmlspecialchars($this->request->getVar('firsName'), true),
				'email' => htmlspecialchars($this->request->getVar('email'), true),
				'kode_address' => htmlspecialchars($this->request->getVar('keyAddress'), true),
				'jenis_kelamin' => htmlspecialchars($this->request->getVar('gender'), true),
				'address' => htmlspecialchars($this->request->getVar('alamat'), true),
				'no_hp' => htmlspecialchars($this->request->getVar('nohp'), true),
				'profile_picture' => htmlspecialchars($this->request->getVar('profilePicture'), true),
				'is_penjual' => htmlspecialchars($this->request->getVar('isPenjual'), true),
				'created_at' => date('Y-m-d H:i:s'),
			];

			try {
				$user_id = $this->model->insert($data);
			} catch (\Throwable $th) {
				return $this->fail($th);
			}
			return $this->respondCreated($data);
		}
	}

	public function show($id = null)
	{
		$data = $this->model->find($id);
		if ($data) {
			return $this->respond($data);
		} else {
			return $this->failNotFound('Item not found');
		}
	}

	public function update($id = null)
	{
		$oldData = $this->model->find($id);
		$rules = [
			'firsname' => 'required|min_length[3]|max_length[50]',
			//'lastname' => 'required|min_length[3]|max_length[50]',
			'email' => 'required|valid_email|is_unique[_users_tb.email]',
			'instansi' => 'required',
			'level' => 'required',
			// 'password' => 'required|min_length[6]',
			// 'password_confirm' => 'matches[password]',
		];

		if (!$this->validate($rules)) {
			return $this->failValidationError($this->validator->getError());
		} else {
			$data = [
				'id' => htmlspecialchars($id, true),
				'firsname' => htmlspecialchars($this->request->getVar('firsname'), true),
				'lastname' => htmlspecialchars($this->request->getVar('firsname'), true),
				'email' => htmlspecialchars($this->request->getVar('email'), true),
				// 'password' => htmlspecialchars($this->request->getVar('password'), true),
				'intansi_id' => htmlspecialchars($this->request->getVar('instansi'), true),
				'level' => htmlspecialchars($this->request->getVar('level'), true),
				'is_active' => htmlspecialchars($this->request->getVar('is_active'), true),
				'updated_at' => date('Y-m-d H:i:s'),
			];

			try {
				$this->model->save($data);
				// unset($data['password']);
			} catch (\Throwable $th) {
				return $this->fail($th);
				// return $this->failNotFound('gagal simpan database');
			}
			return $this->respond($data);
		}
	}

	public function changepassword($id = null)
	{
		if ($this->request->getMethod() != 'post')
			return $this->fail('Only post request is allowed');

		$oldData = $this->model->find($id);
		$rules = [
			// 'firsname' => 'required|min_length[3]|max_length[50]',
			// 'lastname' => 'required|min_length[3]|max_length[50]',
			// 'email' => 'required|valid_email|is_unique[_users_tb.email]',
			// 'instansi' => 'required',
			// 'level' => 'required',
			'current_password' => 'required|min_length[6]',
			'password' => 'required|min_length[6]',
			'password_confirm' => 'matches[password]',
		];

		if (!$this->validate($rules)) {
			return $this->failValidationError($this->validator->getError());
		} else {
			$current_password = htmlspecialchars($this->request->getVar('current_password'), true);

			$data = [
				'id' => htmlspecialchars($id, true),
				'password' => htmlspecialchars($this->request->getVar('password'), true),
				'updated_at' => date('Y-m-d H:i:s'),
			];

			$cekPass = password_verify($current_password, $oldData['password']);
			if ($cekPass) {
				try {
					$this->model->save($data);
					unset($data['password']);
					$data['message'] = "Password berhasil di update";
				} catch (\Throwable $th) {
					return $this->fail($th);
					// return $this->failNotFound('gagal simpan database');
				}
				return $this->respond($data);
			} else {
				return $this->fail("Gagal Ganti Password");
			}
		}
	}

	public function delete($id = null)
	{
		$data = $this->model->find($id);
		if ($data) {
			try {
				$this->model->delete($id);
				$dat['status'] = "deleted";
				$dat['message'] = "Item data berhasil di hapus.";
				$dat['description'] = "User " . $data['email'] . " berhasil di hapus";
				$dat['data'] = $data;
				return $this->respondDeleted($dat);
			} catch (\Throwable $th) {
				return $this->fail($th);
			}
		} else {
			return $this->failNotFound('Item not found');
		}
	}

	public function user()
	{
		if ($this->request->getMethod() != 'post')
			return $this->fail('Only post request is allowed');

		$rules = [
			'username' => 'required|trim',
		];

		if (!$this->validate($rules)) {
			return $this->failValidationError($this->validator->getError());
		} else {
			// $username = htmlspecialchars($this->request->getGet('username'), true);

			// if ($username == null || $username == "") {
			// 	return $this->failValidationError("tidak ada username");
			// } else {
			$username = htmlspecialchars($this->request->getVar('username'), true);
			try {
				$data =
					$this->model->orWhere(['email' => $username, 'no_hp' => $username])->find();
				return $this->respond($data);
				// unset($data['password']);
				// $data['message'] = "Password berhasil di update";
			} catch (\Throwable $th) {
				return $this->fail($username);
				// return $this->failNotFound('gagal simpan database');
			}
		}
	}
}
