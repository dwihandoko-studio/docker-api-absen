<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;

class Productpublicrecomendation extends ResourceController
{
    protected $modelName = 'App\Models\ProductpublicModel';
    protected $format = 'json';

    var $folderImage = 'product';

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
    }

    public function index()
    {
        $per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
        $pag = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

        if ($pag == 1) {
            $start = 0;
        } else {
            $start = (($pag - 1) * $per_page);
        }


        if (!$this->request->getGet('category') and !$this->request->getGet('oldkey')) {
            $where = [
                'productStatus' => 1
            ];
            $data['result'] = $this->model->where($where)->orderBy('createdAt', 'desc')->findAll($per_page, $start);
            // $data['result'] = $this->model->findAll($per_page, $start);
            $data['total_result'] = $this->model->where($where)->countAllResults();
        } else {
            $keyword = htmlspecialchars($this->request->getGet('category'), true);
            $id = htmlspecialchars($this->request->getGet('oldkey'), true);

            $where = "subCategoryId = '$keyword' AND productId != '$id' AND productStatus = 1";
            $data['result'] = $this->model->where($where)->orderBy('createdAt', 'desc')->findAll($per_page, $start);
            $data['total_result'] = $this->model->where($where)->countAllResults();
        }


        // $data['result'] = $this->model->findAll($per_page, $start);
        // $data['total_result'] = $this->model->countAllResults();
        if ($data['total_result'] > 0) {
            $data['page'] = $pag;
            $data['total_page'] = ceil($data['total_result'] / $per_page);
            return $this->respond($data);
        } else {
            return $this->respondNoContent('Tidak ada content.');
        }
    }

    // public function show($url = null)
    // {
    //     $where = [
    //         'productStatus' => 1
    //     ];
    //     $data = $this->model->where($where)->findProductPublic(htmlspecialchars($url, true));
    //     if ($data) {
    //         $ip = htmlspecialchars($this->request->getGet('ip'), true);
    //         return $this->respond($data);
    //     } else {
    //         return $this->failNotFound('Item not found');
    //     }
    // }
}
