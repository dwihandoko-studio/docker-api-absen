<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Notificationlib;

class Cetak extends ResourceController
{
    //protected $modelName = 'App\Models\TransaksiModel';
    protected $format = 'json';

    var $folderImage = 'profile';
  	private $_db;

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
      	$this->_db = \Config\Database::connect();
    }
  
  	function struk(){
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            'kodeTransaksi' => 'required'
        ];
      	
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          	$kodeTransaksi = htmlspecialchars($this->request->getVar('kodeTransaksi'), true);
          	$builderCetak = $this->_db->table('_riwayat_struk_pembeli_pembayaran');
          	$cetak = $builderCetak->where('orderId', $kodeTransaksi)->get()->getRowObject();
          
          	if($cetak) {
              	$data = $cetak;
              	$data->sisaSaldo = (int) $cetak->sisaSaldo;
              	return $this->respond($data);
            } else {
              	return $this->respondNoContent();
            }
        }
    }
}