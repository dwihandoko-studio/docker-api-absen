<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Ppoblib;

class Ordermerchanppob extends ResourceController
{
    protected $modelName = 'App\Models\OrdermerchanppobModel';
    protected $format = 'json';

    var $folderImage = 'profile';

    function __construct()
    {
        helper(['form', 'text', 'array', 'fotourl', 'filesystem']);
    }

    public function addpulsa()
    {
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            // 'userId' => 'required|min_length[3]|max_length[50]',
            'userId' => 'required',
            'jenisOrder' => 'required',
            'totalHarga' => 'required',
            'totalQty' => 'required',
            'noPelanggan' => 'required',
          	'idProduct' => 'required',
          	'hargaProduct' => 'required',
          	'kodeProduct' => 'required',
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          $productId = htmlspecialchars($this->request->getVar('idProduct'), true);
          $db      = \Config\Database::connect();
          $builderGetProduct = $db->table('_daftar_produk_ppob_tb_b');
          $where = [
            'id' => $productId
          ];
          $dataRequestGetProduct = $builderGetProduct->where($where)->get()->getRowObject();
          if ($dataRequestGetProduct) {
            $newPpob = new Ppoblib();
            $cekAvailableProduct = $newPpob->infoProduct($dataRequestGetProduct->kode_product);
            if($cekAvailableProduct->STATUS_PRODUK != "AKTIF") {
              $responFailedNotAvailable['message'] = "Gagal, Produk sedang gangguan / tidak tersedia";
              return $this->respond($responFailedNotAvailable);
            }
          }

          $uuid = new Uuid();
          $userId = htmlspecialchars($this->request->getVar('userId'), true);

          $kodeTransaksi = "MA-POBMERC-" . TIME() . random_string('numeric', 4);
          $id = $uuid->v4();

          $data = [
            'id' => $id,
            'kode_transaksi' => $kodeTransaksi,
            'user_id' => $userId,
            'product_id' => htmlspecialchars($this->request->getVar('idProduct'), true),
            'harga_product' => htmlspecialchars($this->request->getVar('hargaProduct'), true),
            'no_pelanggan' => htmlspecialchars($this->request->getVar('noPelanggan'), true),
            'jenis_order' => htmlspecialchars($this->request->getVar('jenisOrder'), true),
            'total_qty' => htmlspecialchars($this->request->getVar('totalQty'), true),
            'total_harga' => htmlspecialchars($this->request->getVar('totalHarga'), true),
            'status_order' => 0,
            'order_telah_selesai' => 0,
            'created_at' => date('Y-m-d H:i:s'),
          ];

          //var_dump($data);
          //die;
          try {
            $user_id = $this->model->insertData($data, false);
            // var_dump($user_id);
            if ($user_id > 0) {
              $data['created'] = true;
            }
          } catch (\Throwable $th) {
            return $this->fail($th);
          }
          //var_dump($user_id);
          return $this->respondCreated($data);
        }
    }
  
  	public function addplnprabayar()
    {
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            // 'userId' => 'required|min_length[3]|max_length[50]',
            'userId' => 'required',
            'jenisOrder' => 'required',
            'totalHarga' => 'required',
            'totalQty' => 'required',
            'noPelanggan' => 'required',
          	'idProduct' => 'required',
          	'hargaProduct' => 'required',
          	'kodeProduct' => 'required',
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          $productId = htmlspecialchars($this->request->getVar('idProduct'), true);
          $db      = \Config\Database::connect();
          $builderGetProduct = $db->table('_daftar_produk_ppob_tb_b');
          $where = [
            'id' => $productId
          ];
          $dataRequestGetProduct = $builderGetProduct->where($where)->get()->getRowObject();
          if ($dataRequestGetProduct) {
            $newPpob = new Ppoblib();
            
            $string = substr($dataRequestGetProduct->kode_product, 0,7);
    		$cekAvailableProduct = $newPpob->infoProduct($string);
            
            //$cekAvailableProduct = $newPpob->infoProduct($dataRequestGetProduct->kode_product);
            
            if($cekAvailableProduct->STATUS_PRODUK != "AKTIF") {
              $responFailedNotAvailable['message'] = $cekAvailableProduct->STATUS_PRODUK;
              //$responFailedNotAvailable['message'] = "Gagal, Produk sedang gangguan / tidak tersedia";
              return $this->respond($responFailedNotAvailable);
            }
          }

          $uuid = new Uuid();
          $userId = htmlspecialchars($this->request->getVar('userId'), true);

          $kodeTransaksi = "MA-POBMERC-" . TIME() . random_string('numeric', 4);
          $id = $uuid->v4();

          $data = [
            'id' => $id,
            'kode_transaksi' => $kodeTransaksi,
            'user_id' => $userId,
            'product_id' => htmlspecialchars($this->request->getVar('idProduct'), true),
            'harga_product' => htmlspecialchars($this->request->getVar('hargaProduct'), true),
            'no_pelanggan' => htmlspecialchars($this->request->getVar('noPelanggan'), true),
            'jenis_order' => htmlspecialchars($this->request->getVar('jenisOrder'), true),
            'total_qty' => htmlspecialchars($this->request->getVar('totalQty'), true),
            'total_harga' => htmlspecialchars($this->request->getVar('totalHarga'), true),
            'status_order' => 0,
            'order_telah_selesai' => 0,
            'created_at' => date('Y-m-d H:i:s'),
          ];

          //var_dump($data);
          //die;
          try {
            $user_id = $this->model->insertData($data, false);
            // var_dump($user_id);
            if ($user_id > 0) {
              $data['created'] = true;
            }
          } catch (\Throwable $th) {
            return $this->fail($th);
          }
          //var_dump($user_id);
          return $this->respondCreated($data);
        }
    }
  	
  	public function confirmpin() {
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            // 'userId' => 'required|min_length[3]|max_length[50]',
            'userId' => 'required',
            'kodeTransaksi' => 'required',
            'pin' => 'required',
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          $userId = htmlspecialchars($this->request->getVar('userId'), true);
          $kodeTransaksi = htmlspecialchars($this->request->getVar('kodeTransaksi'), true);
          
          $db      = \Config\Database::connect();
          $builder = $db->table('_toko_tb_b');
          $hasil = $builder->where('user_id', $userId)->get()->getRowObject();
          
          if($hasil) {
            if($hasil->pin_ppob == htmlspecialchars($this->request->getVar('pin'), true)) {
              	$builderGet = $db->table('_orders_ppob_merchan_tb_b');
              	$builderGet->select('_orders_ppob_merchan_tb_b.kode_transaksi as kodeTransaksi, _orders_ppob_merchan_tb_b.jenis_order as jenisOrder, _orders_ppob_merchan_tb_b.product_id as productId, _orders_ppob_merchan_tb_b.no_pelanggan as noPelanggan, _orders_ppob_merchan_tb_b.order_telah_selesai as orderTelahSelesai, _orders_ppob_merchan_tb_b.total_harga as totalHarga, _orders_ppob_merchan_tb_b.status_order as statusOrder, _orders_ppob_merchan_tb_b.user_id as userId, _daftar_produk_ppob_tb_b.kode_product as kodeProduct, _daftar_produk_ppob_tb_b.nama_product as namaProduct, _daftar_produk_ppob_tb_b.nominal as nominal, _daftar_produk_ppob_tb_b.harga as harga, _toko_tb_b.toko_saldo as saldoToko, _toko_tb_b.margin_ppob_merchan as marginPpob');
              	$builderGet->join('_daftar_produk_ppob_tb_b', '_daftar_produk_ppob_tb_b.id = _orders_ppob_merchan_tb_b.product_id');
              	$builderGet->join('_toko_tb_b', '_toko_tb_b.user_id = _orders_ppob_merchan_tb_b.user_id');
          		$hasilGet = $builderGet->where('kode_transaksi', $kodeTransaksi)->get()->getRowObject();
              	if($hasilGet) {
                  if(($hasilGet->saldoToko + $hasilGet->marginPpob) > $hasilGet->totalHarga) {
                    if($hasilGet->jenisOrder == "pulsa") {
                      $newPpob = new Ppoblib();

                      $responTransaksiPpob = $newPpob->pulsa($hasilGet->kodeProduct, $hasilGet->noPelanggan, $kodeTransaksi);

                      //var_dump($responTransaksiPpob);


                      if ($responTransaksiPpob->STATUS == "00" || $responTransaksiPpob->STATUS == "" || $responTransaksiPpob->STATUS == "35" || $responTransaksiPpob->STATUS == "68") {

                        $dataInputHistoryPpob = [
                          'user_id' => $hasilGet->userId,
                          'order_id' => $kodeTransaksi,
                          'id_transaksi' => $responTransaksiPpob->REF2,
                          'kode_product' => $responTransaksiPpob->KODE_PRODUK,
                          'status_transaksi' => $responTransaksiPpob->STATUS_TRX,
                          'keterangan' => $responTransaksiPpob->KET,
                          'sn' => $responTransaksiPpob->SN,
                          'created_at' => date('Y-m-d H:i:s')
                        ];

                        $builderResponseTransaksiPpob = $db->table('_history_transaksi_ppob_tb_b');
                        $builderResponseTransaksiPpob->insert($dataInputHistoryPpob);
                        
                        $builderSaldoAfterTransaksi = $db->table('_toko_tb_b');
                        $oldSaldo = $hasilGet->saldoToko;
                        $newSaldo = $oldSaldo - ($hasilGet->marginPpob + (int)$responTransaksiPpob->SALDO_TERPOTONG);
                        $dataSaldoAferTransaksi = [
                          	'toko_saldo' => $newSaldo,
                          	'updated_at' => date('Y-m-d H:i:s')
                        ];
                        $builderSaldoAfterTransaksi->where('user_id', $hasilGet->userId)->update($dataSaldoAferTransaksi);

                        //return $this->respond($data);
                      }else{
                        $dataInputHistoryPpob = [
                          'user_id' => $hasilGet->userId,
                          'order_id' => $kodeTransaksi,
                          'id_transaksi' => $responTransaksiPpob->REF2,
                          'kode_product' => $responTransaksiPpob->KODE_PRODUK,
                          'status_transaksi' => $responTransaksiPpob->STATUS_TRX,
                          'keterangan' => $responTransaksiPpob->KET,
                          'sn' => $responTransaksiPpob->SN,
                          'created_at' => date('Y-m-d H:i:s')
                        ];

                        $builderResponseTransaksiPpob = $db->table('_history_transaksi_ppob_tb_b');
                        $builderResponseTransaksiPpob->insert($dataInputHistoryPpob);
                      }
                      return $this->respond($responTransaksiPpob);
                    }else if($hasilGet->jenisOrder == "plnprabayar") {
                      $newPpob = new Ppoblib();

                      $responTransaksiPpob = $newPpob->plnprabayar($hasilGet->nominal, $hasilGet->noPelanggan, $kodeTransaksi);

                      //var_dump($responTransaksiPpob);


                      if ($responTransaksiPpob->STATUS == "00"  || $responTransaksiPpob->STATUS == "" || $responTransaksiPpob->STATUS == "35" || $responTransaksiPpob->STATUS == "68") {
                        $ket = $responTransaksiPpob->NAMA_PELANGGAN . ";" . $responTransaksiPpob->IDPEL1 . ";" . $responTransaksiPpob->URL_STRUK;

                        $dataInputHistoryPpob = [
                          'user_id' => $hasilGet->userId,
                          'order_id' => $kodeTransaksi,
                          'id_transaksi' => $responTransaksiPpob->REF2,
                          'kode_product' => $hasilGet->kodeProduct,
                          'status_transaksi' => $responTransaksiPpob->KET,
                          'keterangan' => $ket,
                          'sn' => $responTransaksiPpob->DETAIL['SN'],
                          'created_at' => date('Y-m-d H:i:s')
                        ];

                        $builderResponseTransaksiPpob = $db->table('_history_transaksi_ppob_tb_b');
                        $builderResponseTransaksiPpob->insert($dataInputHistoryPpob);
                        
                        $builderSaldoAfterTransaksi = $db->table('_toko_tb_b');
                        $oldSaldo = $hasilGet->saldoToko;
                        $newSaldo = $oldSaldo - ($hasilGet->marginPpob + (int)$responTransaksiPpob->SALDO_TERPOTONG);
                        $dataSaldoAferTransaksi = [
                          	'toko_saldo' => $newSaldo,
                          	'updated_at' => date('Y-m-d H:i:s')
                        ];
                        $builderSaldoAfterTransaksi->where('user_id', $hasilGet->userId)->update($dataSaldoAferTransaksi);

                        //return $this->respond($data);
                      }else{
                        $ket = $responTransaksiPpob->NAMA_PELANGGAN . ";" . $responTransaksiPpob->IDPEL1 . ";" . $responTransaksiPpob->URL_STRUK;
                        $dataInputHistoryPpob = [
                          'user_id' => $hasilGet->userId,
                          'order_id' => $kodeTransaksi,
                          'id_transaksi' => $responTransaksiPpob->REF2,
                          'kode_product' => $hasilGet->kodeProduct,
                          'status_transaksi' => $responTransaksiPpob->KET,
                          'keterangan' => $ket,
                          'sn' => $responTransaksiPpob->DETAIL['SN'],
                          'created_at' => date('Y-m-d H:i:s')
                        ];

                        $builderResponseTransaksiPpob = $db->table('_history_transaksi_ppob_tb_b');
                        $builderResponseTransaksiPpob->insert($dataInputHistoryPpob);
                      }
                      return $this->respond($responTransaksiPpob);
                    }else {
                      return $this->fail("Confirmation Failed");
                    }
                  }else{
                    $res['message'] = "Saldo Anda Tidak Mencukupi, Silahkan Deposit Terlebih Dahulu";
                    return $this->respondCreated($res);
                  }
                }else{
                  return $this->fail("Confirmation Failed");
                }
            }else{
              $res['message'] = "Pin Transaksi Anda Salah";
              return $this->respondCreated($res);
              //return $this->fail("Pin Transaksi Anda Salah.");
            }
          }else{
            return $this->fail("Confirmation Failed.");
          }
          
        }
    }
  
  public function testcontroller() {
    if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
    
    $rules = [
          	'kodeProduct' => 'required',
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
    
    //$newPpob = new Ppoblib();
          //$textString = htmlspecialchars($this->request->getVar('kodeProduct'), true);
    //$textString = "PLNPRAH20";
    //$string = substr($textString, 0,7);
    //$cekAvailableProduct = $newPpob->datatransaksi("20200830000000", "20200830235900","","","50191187512");
          //$cekAvailableProduct = $newPpob->cetakulang("MRTPOB-MERC-15987676811753");
    var_dump($cekAvailableProduct);
          return $this->respond($cekAvailableProduct);
        }
  }
}
