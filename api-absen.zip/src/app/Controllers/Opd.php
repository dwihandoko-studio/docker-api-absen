<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;

class Opd extends ResourceController
{
	protected $modelName = 'App\Models\OpdModel';
	protected $format = 'json';

	var $folderImage = 'berita';

	function __construct()
	{
		helper(['form', 'array', 'fotourl', 'filesystem']);
	}

	public function index()
	{
		$data['result'] = $this->model->findAll();
		$data['total_result'] = $this->model->countAllResults();
		if ($data['total_result'] > 0) {
			return $this->respond($data);
		} else {
			return $this->respondNoContent('Tidak ada content.');
		}
		// $per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
		// $pag = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

		// if ($pag == 1) {
		// 	$start = 0;
		// } else {
		// 	$start = (($pag - 1) * $per_page);
		// }
		// $data['result'] = $this->model->findAll($per_page, $start);
		// $data['total_result'] = $this->model->countAllResults();
		// if ($data['total_result'] > 0) {
		// 	$data['page'] = $pag;
		// 	$data['total_page'] = ceil($data['total_result'] / $per_page);
		// 	return $this->respond($data);
		// } else {
		// 	return $this->respondNoContent('Tidak ada content.');
		// }
	}

	public function create()
	{
		$rules = [
			'nama' => 'required|is_unique[_opd_b_tb.opd_title]',
			'description' => 'required',
		];

		if (!$this->validate($rules)) {
			return $this->fail($this->validator->getError());
		} else {
			$nama = htmlspecialchars($this->request->getVar('nama'), true);

			$data = [
				'opd_title' => $nama,
				'opd_description' => htmlspecialchars($this->request->getVar('description'), true),
				'opd_is_active' => htmlspecialchars($this->request->getVar('is_active'), true),
				'opd_created_at' => date('Y-m-d H:i:s'),
			];
			try {
				$post_id = $this->model->insert($data);
				$data['id'] = $post_id;
			} catch (\Throwable $th) {
				return $this->fail($th);
			}
			return $this->respondCreated($data);
		}
	}

	public function show($id = null)
	{
		$data = $this->model->find($id);
		if ($data) {
			return $this->respond($data);
		} else {
			return $this->failNotFound('Item not found');
		}
	}

	public function update($id = null)
	{
		$oldData = $this->model->find($id);
		$rules = [
			'nama' => 'required|is_unique[_opd_b_tb.opd_title]',
			'description' => 'required',
		];

		if (!$this->validate($rules)) {
			return $this->failValidationError($this->validator->getError());
		} else {
			$nama = htmlspecialchars($this->request->getVar('nama'), true);

			$data = [
				'id' => htmlspecialchars($id, true),
				'opd_title' => $nama,
				'opd_description' => htmlspecialchars($this->request->getVar('description'), true),
				'opd_is_active' => htmlspecialchars($this->request->getVar('is_active'), true),
				'opd_updated_at' => date('Y-m-d H:i:s'),
			];

			try {
				$this->model->save($data);
			} catch (\Throwable $th) {
				return $this->fail($th);
				// return $this->failNotFound('gagal simpan database');
			}
			return $this->respond($data);
		}
	}

	public function delete($id = null)
	{
		$data = $this->model->find($id);
		if ($data) {
			try {
				$this->model->delete($id);
				$dat['status'] = "deleted";
				$dat['message'] = "Item data berhasil di hapus.";
				$dat['description'] = "Item data " . $data['opd_title'] . " berhasil di hapus";
				$dat['data'] = $data;
				return $this->respondDeleted($dat);
			} catch (\Throwable $th) {
				return $this->fail($th);
			}
		} else {
			return $this->failNotFound('Item not found');
		}
	}
}
