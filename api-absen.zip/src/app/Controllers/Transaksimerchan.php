<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Notificationlib;

class Transaksimerchan extends ResourceController
{
    protected $modelName = 'App\Models\TransaksiModel';
    protected $format = 'json';

    var $folderImage = 'profile';

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
    }

    public function index()
    {
      	if (!$this->request->getGet('userId')) {
            return $this->respondNoContent('Tidak ada content.');
        }else{
      		$per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
        	$start = (int) htmlspecialchars($this->request->getGet('start'), true) ? (int) htmlspecialchars($this->request->getGet('start'), true) : 0;
          	$userId = htmlspecialchars($this->request->getGet('userId'), true);
          
          	//var_dump($userId);die;

        	$where = [
            	'user_id' => $userId
        	];
        	$dataOrdered = $this->model->where($where)->orderBy('created_at', 'desc')->findAll($per_page, $start);
        	$data['total_result'] = $this->model->where($where)->countAllResults();
          	
        	if ($data['total_result'] > 0) {
              	$db      = \Config\Database::connect();
              	$itemOrder = [];
              	foreach($dataOrdered as $val) {
                  $orders = [];
                  if($val['jenis_order'] == "ppob"){
                    $builder = $db->table('_details_order_ppob_tb_b');
                    $builder->select('_details_order_ppob_tb_b.product_id as productId, _daftar_produk_ppob_tb_b.nama_product as namaProduct, _details_order_ppob_tb_b.no_pelanggan as noPelanggan, _details_order_ppob_tb_b.jenis_ppob as jenisPpob');
                    $builder->join('_daftar_produk_ppob_tb_b', '_details_order_ppob_tb_b.product_id = _daftar_produk_ppob_tb_b.id');
            		$orders['itemOrderPpob'] = $builder->where('order_id', $val['id'])->get()->getResult();
                    $orders['jenisOrder'] = $val['jenis_order'];
                    $orders['kodeTransaksi'] = $val['kode_transaksi'];
                    $orders['totalHarga'] = $val['total_harga'];
                    $orders['totalQty'] = $val['total_qty'];
                    $orders['statusOrder'] = $val['status_order'];
                    $orders['createdAt'] = $val['created_at'];
                  }else{
                    $builder = $db->table('_details_order_commerce_tb_b');
                    $builder->select('_details_order_commerce_tb_b.product_id as productId, _product_tb_b.product_title as namaProduct, _details_order_commerce_tb_b.qty_product as qtyProduct, _details_order_commerce_tb_b.harga_ongkir as hargaOngkir');
                    $builder->join('_product_tb_b', '_details_order_ppob_tb_b.product_id = _product_tb_b.id');
            		$orders['itemOrderEcom'] = $builder->where('order_id', $val->id)->get()->getResult();
                    $orders['jenisOrder'] = $val->jenis_order;
                    $orders['kodeTransaksi'] = $val->kode_transaksi;
                    $orders['totalHarga'] = $val->total_harga;
                    $orders['totalQty'] = $val->total_qty;
                    $orders['statusOrder'] = $val->status_order;
                    $orders['createdAt'] = $val['created_at'];
                  }
                  $itemOrder[] = $orders;
                }
              	$data['result']= $itemOrder;
            	
              
            	// $data['page'] = $pag;
            	$data['total_page'] = ceil($data['total_result'] / $per_page);
            	return $this->respond($data);
        	} else {
            	return $this->respondNoContent('Tidak ada content.');
        	}
        }

        // return $this->respondNoContent('Tidak ada content.');
        if (!$this->request->getGet('userId')) {
            return $this->respondNoContent('Tidak ada content.');
        } else {
            $userId = htmlspecialchars($this->request->getGet('userId'), true);

            $db      = \Config\Database::connect();
            $builder = $db->table('_orders_tb_b');
            $hasil = $builder->where('user_id', $userId)->orderBy('created_at', 'desc')->get();

            $data['result'] = $hasil->getResult();
            $data['total_result'] = count($data['result']);

            // $where = [
            //     'userId' => $userId
            // ];
            // $data['result'] = $this->model->where($where)->orderBy('createdAt', 'desc')->findAll();
            // // $data['result'] = $this->model->findAll($per_page, $start);
            // $data['total_result'] = $this->model->where($where)->countAllResults();
        }

        if ($data['total_result'] > 0) {
            return $this->respond($data);
        } else {
            return $this->respondNoContent('Tidak ada content.');
        }
    }
  
  	public function ppob() {
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            'userId' => 'required'
        ];
      	
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          $userId = htmlspecialchars($this->request->getVar('userId'), true);
          $db      = \Config\Database::connect();
          $builderGetTransaksi = $db->table('_orders_ppob_merchan_tb_b');
          $where = "_orders_ppob_merchan_tb_b.user_id ='$userId' AND _orders_ppob_merchan_tb_b.status_order != 0";
          //$where = [
          //  'user_id' => $userId
          //];
          //$select = "id, kode_transaksi as kodeTransaksi, jenis_order as jenisOrder, product_id as productId, harga_product as hargaProduct, no_pelanggan as noPelanggan, order_telah_selesai as orderSelesai, total_qty as totalQty, status_order as statusOrder, user_id as userId, created_at as createdAt, updated_at as updatedAt";
          //$builderGetTransaksi->select($select);
          $select = "_orders_ppob_merchan_tb_b.id, _orders_ppob_merchan_tb_b.kode_transaksi as kodeTransaksi, _orders_ppob_merchan_tb_b.jenis_order as jenisOrder, _orders_ppob_merchan_tb_b.product_id as productId, _orders_ppob_merchan_tb_b.harga_product as hargaProduct, _orders_ppob_merchan_tb_b.no_pelanggan as noPelanggan, order_telah_selesai as orderSelesai, _orders_ppob_merchan_tb_b.total_qty as totalQty, _orders_ppob_merchan_tb_b.status_order as statusOrder, _orders_ppob_merchan_tb_b.user_id as userId, _orders_ppob_merchan_tb_b.created_at as createdAt, _orders_ppob_merchan_tb_b.updated_at as updatedAt, _history_transaksi_ppob_tb_b.status_transaksi as statusTransaksi, _history_transaksi_ppob_tb_b.keterangan as keterangan, _history_transaksi_ppob_tb_b.sn as sn, _daftar_produk_ppob_tb_b.nama_product as namaProduct, _daftar_produk_ppob_tb_b.category_product as categoryProduct, _daftar_produk_ppob_tb_b.group_product as groupProduct, _daftar_produk_ppob_tb_b.nominal as nominal";
          $builderGetTransaksi->select($select);
          $builderGetTransaksi->join('_history_transaksi_ppob_tb_b','_history_transaksi_ppob_tb_b.order_id = _orders_ppob_merchan_tb_b.kode_transaksi');
          $builderGetTransaksi->join('_daftar_produk_ppob_tb_b','_daftar_produk_ppob_tb_b.id = _orders_ppob_merchan_tb_b.product_id');
          $dataTransaksi = $builderGetTransaksi->where($where)->get()->getResult();
          if ($dataTransaksi) {
            $data['result'] = $dataTransaksi;
            	return $this->respond($data);
          }else{
            	return $this->respondNoContent('Tidak ada content.');
          }
        }
    }
  
  	public function detailppob() {
      if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            'kodeTransaksi' => 'required'
        ];
      	
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          $kodeTransaksi = htmlspecialchars($this->request->getVar('kodeTransaksi'), true);
          $db      = \Config\Database::connect();
          $builderGetTransaksi = $db->table('_orders_ppob_merchan_tb_b');
          $where = "kode_transaksi ='$kodeTransaksi'";
          //$where = [
          //  'user_id' => $userId
          //];
          $select = "_orders_ppob_merchan_tb_b.id, _orders_ppob_merchan_tb_b.kode_transaksi as kodeTransaksi, _orders_ppob_merchan_tb_b.jenis_order as jenisOrder, _orders_ppob_merchan_tb_b.product_id as productId, _orders_ppob_merchan_tb_b.harga_product as hargaProduct, _orders_ppob_merchan_tb_b.no_pelanggan as noPelanggan, order_telah_selesai as orderSelesai, _orders_ppob_merchan_tb_b.total_qty as totalQty, _orders_ppob_merchan_tb_b.status_order as statusOrder, _orders_ppob_merchan_tb_b.user_id as userId, _orders_ppob_merchan_tb_b.created_at as createdAt, _orders_ppob_merchan_tb_b.updated_at as updatedAt, _history_transaksi_ppob_tb_b.status_transaksi as statusTransaksi, _history_transaksi_ppob_tb_b.keterangan as keterangan, _history_transaksi_ppob_tb_b.sn as sn, _daftar_produk_ppob_tb_b.nama_product as namaProduct, _daftar_produk_ppob_tb_b.category_product as categoryProduct, _daftar_produk_ppob_tb_b.group_product as groupProduct, _daftar_produk_ppob_tb_b.nominal as nominal";
          $builderGetTransaksi->select($select);
          $builderGetTransaksi->join('_history_transaksi_ppob_tb_b','_history_transaksi_ppob_tb_b.order_id = _orders_ppob_merchan_tb_b.kode_transaksi');
          $builderGetTransaksi->join('_daftar_produk_ppob_tb_b','_daftar_produk_ppob_tb_b.id = _orders_ppob_merchan_tb_b.product_id');
          $dataTransaksi = $builderGetTransaksi->where($where)->get()->getRowObject();
          if ($dataTransaksi) {
            	$notification = new Notificationlib();
            	$notification->read($dataTransaksi->userId, $dataTransaksi->kodeTransaksi);
            	return $this->respond($dataTransaksi);
          }else{
            	return $this->respondNoContent('Tidak ada content.');
          }
        }
    }

}
