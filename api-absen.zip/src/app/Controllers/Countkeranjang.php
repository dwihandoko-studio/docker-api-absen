<?php
namespace App\Controllers;

header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Libraries\Uuid;

class Countkeranjang extends ResourceController
{
    protected $modelName = 'App\Models\KeranjangModel';
    protected $format = 'json';

    var $folderImage = 'profile';
  	private $_db;

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
      	$this->_db = \Config\Database::connect();
    }
  
  	public function index(){
      	if (!$this->request->getGet('user')) {
            return $this->respondNoContent('Tidak ada content.');
        } else {
            $userId = htmlspecialchars($this->request->getGet('user'), true);

            $dataCountKeranjang = $this->model->where('user_id', $userId)->countAllResults();
          //var_dump($dataCountKeranjang);die;
            if ($dataCountKeranjang > 0) {
                $data['total_result'] = (string)$dataCountKeranjang;
                return $this->respond($data);
            } else {
                return $this->respondNoContent('Item not found');
            }
        }
    }

}