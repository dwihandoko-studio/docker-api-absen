<?php

namespace App\Controllers;

//use App\Libraries\Veritrans;
use App\Libraries\Notificationlib;
use App\Libraries\Uuid;
use App\Libraries\Onesignallib;
use App\Libraries\Orderslib;
use App\Libraries\Poinlib;


class Handleppob extends BaseController
{
  protected $modelName = 'App\Models\HandlenotificationModel';
  
  private $_db;

    function __construct()
    {
        helper(['form', 'text', 'array', 'fotourl', 'filesystem']);
      	$this->_db = \Config\Database::connect();
    }
  /*public function __construct()
    {
        parent::__construct();
        $params = array('server_key' => 'your_server_key', 'production' => false);
		//$this->load->library('veritrans');
		//$this->veritrans->config($params);
		//$this->load->helper('url');
		
    }*/


  public function rajabiller()
  {
    echo 'test notification handler ppob';
    $json_result = file_get_contents('php://input');
	try{
        $result = json_decode($json_result);
        $uuid = new Uuid();
        $id = $uuid->v4();
        $data = [
          'id' => $id,
          'id_transaksi' => $result->id_transaksi,
          'time_request' => $result->time_request,
          'id_produk' => $result->id_produk,
          'nama_produk' => $result->nama_produk,
          'id_pelanggan' => $result->id_pelanggan,
          'nominal' => $result->nominal,
          'total_bayar' => $result->total_bayar,
          'sn' => $result->sn,
          'response_code' => $result->response_code,
          'keterangan' => $result->keterangan,
          'created_at' => date('Y-m-d H:i:s')
        ];

        //$db      = \Config\Database::connect();
        $builder = $this->_db->table('riwayat_notif_ppob_rajabiller');
        $builder->insert($data);
      
      	$builderTransaksi = $this->_db->table('_history_transaksi_ppob_tb_b');
      	$whereTransaksi = [
          	'id_transaksi' => $result->id_transaksi,
          	'layanan_ppob' => 'rajabiller'
        ];
      	$dataTransaksi = $builderTransaksi->where($whereTransaksi)->get()->getRowObject();
      	if($dataTransaksi) {
          	if($result->response_code == "00") {
              	$dataUpdate = [
                    'status_transaksi' => "SUKSES",
                    'sn' => $result->sn,
                    'updated_at' => date('Y-m-d H:i:s')
                ];
                $builderTransaksi->where('id_transaksi', $result->id_transaksi)->update($dataUpdate);
              
              	$orderlib = new Orderslib();
              
              	$dataOrders = $orderlib->getDataDetailTransaksi($dataTransaksi->order_id);

                $codePayment = explode('-', $dataTransaksi->order_id);
                if ($codePayment[1] == "POBPUB") {
                  	$orderlib->updateOrderToSukses($dataTransaksi->order_id);
                  
                  	if (count($dataOrders) > 0) {
                    	$dataOrder = $dataOrders[0];
                    
                    	$oldPointReward = (int) $dataOrder->userPoinReward;
                        $newPointReward = $oldPointReward + (int) $dataOrder->poinProduct;
                      
                      	$poinLib = new Poinlib();
                      	$cekRiwayatPointAlready = $poinLib->cekAlreadyRiwayatPoint($dataTransaksi->order_id, $dataOrder->userIdPembeli, "debit");
                      
                      	if(!(count($cekRiwayatPointAlready) > 0)) {
                    
                            if($dataOrder->categoryProduct == "plnprabayar") {

                              $dataRiwayatPoin=[
                                'user_id' => $dataOrder->userIdPembeli,
                                'kode_transaksi' => $dataTransaksi->order_id,
                                'jenis_poin' => 'debit',
                                'jenis_guna' => 'Pembayaran',
                                'poin_old' => $oldPointReward,
                                'poin_new' => $newPointReward,
                                'poin_perubahan' => (int) $dataOrder->poinProduct,
                                'keterangan' => "pembelian " . $dataOrder->namaProduct . " " . $dataOrder->noPelanggan . " " . " (" . $dataTransaksi->order_id . ")",
                                'created_at' => date('Y-m-d H:i:s')
                              ];
                            } else {
                              $dataRiwayatPoin=[
                                'user_id' => $dataOrder->userIdPembeli,
                                'kode_transaksi' => $dataTransaksi->order_id,
                                'jenis_poin' => 'debit',
                                'jenis_guna' => 'Pembayaran',
                                'poin_old' => $oldPointReward,
                                'poin_new' => $newPointReward,
                                'poin_perubahan' => (int) $dataOrder->poinProduct,
                                'keterangan' => "pembelian " . $dataOrder->categoryProduct . " " . $dataOrder->groupProduct . " " . $dataOrder->titleProduct . " (" . $dataTransaksi->order_id . ")",
                                'created_at' => date('Y-m-d H:i:s')
                              ];
                            }

                            if((int) $dataOrder->poinProduct > 0){
                              $poinUpdate = new Poinlib();
                              $poinUpdate->updatePoin($newPointReward, $dataOrder->userIdPembeli);

                              $poinUpdate->insertRiwayatPoin($dataRiwayatPoin);
                            }
                        }
                  }
                  
                  	$updatePpobCetakStruk = $this->_db->table('_riwayat_struk_pembeli_pembayaran');
                    $dataStrukUpdate = [
                      'sn' => $result->sn,
                      'keterangan' => "SUKSES",
                      'noResi' => $result->id_transaksi,
                      'statusTransaksi' => "SUKSES"
                    ];
                  	$whereStruk = [
                      	'orderId' => $dataTransaksi->order_id
                    ];
                    $statusUpdateStruk = $updatePpobCetakStruk->where($whereStruk)->update($dataStrukUpdate);

                        $dataNotifSystem = [
                          'kode_transaksi' => $dataTransaksi->order_id,
                          'title' => $result->nama_produk,
                          'description' => $result->keterangan,
                          'send_from' => "system",
                          'send_to' => $dataTransaksi->user_id,
                          'action_page' => "detail_order",
                          'action_api' => "ppobpub"
                        ];
                        $saveNotifSystem = new Notificationlib();
                        $saveNotifSystem->send($dataNotifSystem);

                        $dataNotif = [
                          'send_to' => $dataTransaksi->user_id,
                          'title' => $result->nama_produk,
                          'content' => $result->keterangan,
                          'app_url' => "ppobpub;".$dataTransaksi->order_id.";detail_order"
                        ];

                        $onesignal = new Onesignallib();
                        $send = $onesignal->pushNotifToUser($dataNotif);

                        return $this->respond($send);
                  
                }else if ($codePayment[1] == "POBTAG"){
					$orderlib->updateOrderToSukses($dataTransaksi->order_id);
                  
                  	if (count($dataOrders) > 0) {
                    	$dataOrder = $dataOrders[0];
                    
                    	$oldPointReward = (int) $dataOrder->userPoinReward;
                        $newPointReward = $oldPointReward + (int) $dataOrder->poinTransaksi;
                      
                      	$poinLib = new Poinlib();
                      	$cekRiwayatPointAlready = $poinLib->cekAlreadyRiwayatPoint($dataTransaksi->order_id, $dataOrder->userIdPembeli, "debit");
                      
                      	if(!(count($cekRiwayatPointAlready) > 0)) {

                            $dataRiwayatPoin=[
                              'user_id' => $dataOrder->userIdPembeli,
                              'kode_transaksi' => $dataTransaksi->order_id,
                              'jenis_poin' => 'debit',
                              'jenis_guna' => 'Pembayaran',
                              'poin_old' => $oldPointReward,
                              'poin_new' => $newPointReward,
                              'poin_perubahan' => (int) $dataOrder->poinTransaksi,
                              'keterangan' => "pembayaran " . $dataOrder->jenisTagihan . " " . $dataOrder->noPelanggan . " " . $dataOrder->namaPelanggan . " (" . $dataTransaksi->order_id . ")",
                              'created_at' => date('Y-m-d H:i:s')
                            ];

                            if((int) $dataOrder->poinTransaksi > 0){
                              $poinUpdate = new Poinlib();
                              $poinUpdate->updatePoin($newPointReward, $dataOrder->userIdPembeli);

                              $poinUpdate->insertRiwayatPoin($dataRiwayatPoin);
                            }
                        }
                  	}
                  
                  	$updatePpobCetakStruk = $this->_db->table('_riwayat_struk_pembeli_pembayaran');
                    $dataStrukUpdate = [
                      'sn' => $result->sn,
                      'keterangan' => "SUKSES",
                      'noResi' => $result->id_transaksi,
                      'statusTransaksi' => "SUKSES"
                    ];
                  	$whereStruk = [
                      	'orderId' => $dataTransaksi->order_id
                    ];
                    $statusUpdateStruk = $updatePpobCetakStruk->where($whereStruk)->update($dataStrukUpdate);

                    $dataNotifSystem = [
                      'kode_transaksi' => $dataTransaksi->order_id,
                      'title' => $result->nama_produk,
                      'description' => $result->keterangan,
                      'send_from' => "system",
                      'send_to' => $dataTransaksi->user_id,
                      'action_page' => "detail_order",
                      'action_api' => "ppobpub"
                    ];
                    $saveNotifSystem = new Notificationlib();
                    $saveNotifSystem->send($dataNotifSystem);

                    $dataNotif = [
                      'send_to' => $dataTransaksi->user_id,
                      'title' => $result->nama_produk,
                      'content' => $result->keterangan,
                      'app_url' => "ppobpub;".$dataTransaksi->order_id.";detail_order"
                    ];

                    $onesignal = new Onesignallib();
                    $send = $onesignal->pushNotifToUser($dataNotif);
                  
                  	$dataRes=[
                      	"woke"
                    ];

                    return $this->respond($dataRes);
                }
            } else {
              	$orderlib = new Orderslib();
              
              	$dataOrders = $orderlib->getDataDetailTransaksi($dataTransaksi->order_id);
              	$dataOrder = $dataOrders[1];
              	
              	$codePayment = explode('-', $dataTransaksi->order_id);
                if ($codePayment[1] == "POBPUB") {
					if ((int)$dataOrder->statusOrder == 1) {
                      	$statusLib = new Orderslib();
                        $statusLib->updateOrderToGagal($dataOrder->kodeTransaksi);
						
                      	$oldSaldo = (int)$dataOrder->userSaldo;
                      	$newSaldo = $oldSaldo - (int)$dataOrder->totalHarga;

                        $updateSaldo->refundSaldo($oldSaldo, $dataOrder->userIdPembeli);
						
                      	if($dataOrder->categoryProduct == "plnprabayar") {
                            $dataRiwayatRefundSaldo = [
                              'user_id' => $dataOrder->userIdPembeli,
                              'kode_transaksi' => $dataOrder->kodeTransaksi,
                              'jenis_saldo' => 'debit',
                              'jenis_guna' => 'Refund Saldo',
                              'saldo_old' => $newSaldo,
                              'saldo_new' => $oldSaldo,
                              'saldo_perubahan' => (int)$dataOrder->totalHarga,
                              'keterangan' => "Pengembalian dari gagal transaksi " . $dataOrder->namaProduct . " " . $dataOrder->noPelanggan . " " . " (" . $dataOrder->kodeTransaksi . ")",
                              'created_at' => date('Y-m-d H:i:s')
                            ];
                        }else{
                          	$dataRiwayatRefundSaldo = [
                              'user_id' => $dataOrder->userIdPembeli,
                              'kode_transaksi' => $dataOrder->kodeTransaksi,
                              'jenis_saldo' => 'debit',
                              'jenis_guna' => 'Refund Saldo',
                              'saldo_old' => $newSaldo,
                              'saldo_new' => $oldSaldo,
                              'saldo_perubahan' => (int)$dataOrder->totalHarga,
                              'keterangan' => "Pengembalian dari gagal transaksi " . $dataOrder->categoryProduct . " " . $dataOrder->groupProduct . " " . $dataOrder->titleProduct . " (" . $dataOrder->kodeTransaksi . ")",
                              'created_at' => date('Y-m-d H:i:s')
                            ];
                        }
                        $updateSaldo->insertRiwayatSaldo($dataRiwayatRefundSaldo);
                    }
                } else {
                  	if ((int)$dataOrder->statusOrder == 1) {
                      	$statusLib = new Orderslib();
                        $statusLib->updateOrderToGagal($dataOrder->kodeTransaksi);
						
                      	$oldSaldo = (int)$dataOrder->userSaldo;
                      	$newSaldo = $oldSaldo - (int)$dataOrder->totalHarga;

                        $updateSaldo->refundSaldo($oldSaldo, $dataOrder->userIdPembeli);

                        $dataRiwayatRefundSaldo = [
                          'user_id' => $dataOrder->userIdPembeli,
                          'kode_transaksi' => $dataOrder->kodeTransaksi,
                          'jenis_saldo' => 'debit',
                          'jenis_guna' => 'Refund Saldo',
                          'saldo_old' => $newSaldo,
                          'saldo_new' => $oldSaldo,
                          'saldo_perubahan' => (int)$dataOrder->totalHarga,
                          'keterangan' => "Pengembalian dari gagal transaksi " . $dataOrder->jenisTagihan . " " . $dataOrder->noPelanggan . " " . $dataOrder->namaPelanggan . " (" . $dataOrder->kodeTransaksi . ")",
                          'created_at' => date('Y-m-d H:i:s')
                        ];
                        $updateSaldo->insertRiwayatSaldo($dataRiwayatRefundSaldo);
                    }
                }
            }
                
        }
      	
      	
      
      	
      
      	

        echo ' => Push Notification Berhasil.';
    } catch (\Throwable $th) {
      	echo $th;
      	//echo ' => no content';
    }
  }
}