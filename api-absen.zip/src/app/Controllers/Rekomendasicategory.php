<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;


class Rekomendasicategory extends ResourceController
{
    // protected $modelName = 'App\Models\TokoModel';
    protected $format = 'json';

    var $folderImage = 'toko';

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
    }

    public function index()
    {
        $opd = htmlspecialchars($this->request->getGet('opd'), true);
        $per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
        $pag = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

        if ($pag == 1) {
            $start = 0;
        } else {
            $start = (($pag - 1) * $per_page);
        }


        if ($opd) {
            // $dataFirs = $this->model->where(['post_opd' => $opd])->findAll();
            // return $this->respond($dataFirs);
            // $filename = dot_array_search('image.name', $_FILES);

            if (!$this->request->getGet('keyword')) {
                $data['result'] = $this->model->where(['post_opd' => $opd])->findAll();
                // $data['result'] = $this->model->where(['post_opd' => $opd])->findAll($per_page, $start);
                $data['total_result'] = $this->model->where(['post_opd' => $opd])->countAllResults();
            } else {
                $keyword = htmlspecialchars($this->request->getGet('keyword'), true);
                // $keyword = '/' . htmlspecialchars($this->request->getGet('keyword'), true) . '/';
                // $searchOrWhere = [
                // 	'post_title' => $keyword,
                // 	'post_description' => $keyword,
                // 	'post_tag' => $keyword
                // ];
                // $dataFirs = $this->model->where(['post_opd' => $opd])->orLike($searchOrWhere)->findAll();
                // $fun = array_search($opd, array_column($dataFirs, 'post_opd'));
                // $fun = searchFromArray($dataFirs, 'post_opd', $opd);
                // $fun = _array_search_dot(['post_title' => $keyword, 'post_description' => $keyword], $dataFirs);
                // return $this->respond($fun);
                $where = "post_opd = $opd AND (post_title LIKE '%$keyword%' OR post_description LIKE '%$keyword%' OR post_tag LIKE '%$keyword%')";

                $data['result'] = $this->model->where($where)->findAll($per_page, $start);
                $data['total_result'] = $this->model->where($where)->countAllResults();
            }
        } else {
            if (!$this->request->getGet('keyword')) {
                $data['result'] = $this->model->findAll();
                // $data['result'] = $this->model->findAll($per_page, $start);
                $data['total_result'] = $this->model->countAllResults();
            } else {
                $keyword = htmlspecialchars($this->request->getGet('keyword'), true);
                $searchOrWhere = [
                    'post_title' => $keyword,
                    'post_description' => $keyword,
                    'post_tag' => $keyword
                ];
                // $where = "post_title LIKE '$keyword' OR post_description LIKE '$keyword' OR post_tags LIKE '$keyword'";
                // $where = "post_title LIKE '$keyword' OR post_description LIKE '$keyword' OR post_tags LIKE '$keyword'";
                // $where = "post_title LIKE '%.$keyword.%' ESCAPE '!'OR post_description LIKE '%testing%' ESCAPE '!'OR `post_tag` LIKE '%testing%' ESCAPE '!'";

                $data['result'] = $this->model->orLike($searchOrWhere)->findAll($per_page, $start);
                $data['total_result'] = $this->model->orLike($searchOrWhere)->countAllResults();
            }


            // $data['result'] = $this->model->findAll($per_page, $start);
            // $data['total_result'] = $this->model->countAllResults();
        }
        if ($data['total_result'] > 0) {
            $data['page'] = $pag;
            $data['total_page'] = ceil($data['total_result'] / $per_page);
            return $this->respond($data);
        } else {
            return $this->respondNoContent('Tidak ada content.');
        }
    }

    public function create()
    {
        $rules = [
            'userId' => 'required',
            'title' => 'required',
            'description' => 'required',
            'url' => 'required',
            'slogan' => 'required',
        ];
        $filename = dot_array_search('image.name', $_FILES);

        if ($filename != '') {
            $img = ['image' => 'uploaded[image]|max_size[image, 1024]|is_image[image]'];
            $rules = array_merge($rules, $img);
        }

        if (!$this->validate($rules)) {
            return $this->fail("Field Required");
            // return $this->fail($this->validator->getError());
        } else {
            $title = htmlspecialchars($this->request->getVar('title'), true);
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            $description = htmlspecialchars($this->request->getVar('description'), true);
            $slogan = htmlspecialchars($this->request->getVar('slogan'), true);
            $urlToko = htmlspecialchars($this->request->getVar('url'), true);

            $uuid = new Uuid();

            // $urlToko = _create_url_toko($title);

            // $db = \Config\Database::connect();
            // $builder = $db->table('_toko_tb_b');
            // $cekToko = $builder->select('toko_url')->where('toko_url', $urlToko)->countAllResults();

            // if ($cekToko > 0) {
            // 	return $this->fail("Nama toko sudah ada");
            // } else {
            $data = [
                'id' => $uuid->v4(),
                'toko_title' => $title,
                'toko_description' => $description,
                'toko_slogan' => $slogan,
                'user_id' => $userId,
                'toko_url' => $urlToko,
                'toko_featured_image' => "",
                'toko_status' => 1,
                'created_at' => date('Y-m-d H:i:s'),
            ];

            if ($filename != '') {


                $file = $this->request->getFile('image');
                $filesName = $file->getName();
                $newName = _create_name_foto($filesName);

                if (!file_exists('./assets/uploads/' . $this->folderImage)) {
                    mkdir('./assets/uploads/' . $this->folderImage, 0777);
                    $dir = './assets/uploads/' . $this->folderImage;
                } else {
                    $dir = './assets/uploads/' . $this->folderImage;
                }

                if ($file->isValid() && !$file->hasMoved()) {
                    try {
                        $file->move($dir, $newName);
                        $data['toko_featured_image'] = $newName;
                    } catch (\Throwable $th) {
                        return $this->failNotFound('gagal upload');
                    }
                } else {
                    return $this->failNotFound('gagal valid file');
                }
            }

            try {
                $post_id = $this->model->insert($data);

                $db = \Config\Database::connect();
                $builder = $db->table('_profil_users_tb');
                // $cekToko = $builder->set(['is_penjual' => 1])->where('id', $data['toko_user_id']);
                $cekToko = $builder->update(['is_penjual' => 1], ['id' => $data['toko_user_id']]);
            } catch (\Throwable $th) {
                return $this->fail("saved Gagal");
                // return $this->fail($th);
            }

            $datas = [
                'idToko' => $data['id'],
                'titleToko' => $data['toko_title'],
                'descriptionToko' => $data['toko_description'],
                'sloganToko' => $data['toko_slogan'],
                'userToko' => $data['user_id'],
                'imageToko' => "",
                'urlToko' => $data['toko_url'],
                'statusToko' => $data['toko_status'],
                'created_at' => $data['created_at'],
            ];

            return $this->respondCreated($datas);
            // }
        }
    }

    public function cektoko()
    {
        $data = [];
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

        $rules = [
            'urlToko' => 'required|trim',
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getError());
        } else {
            $url = "https://www.yestore.id/" . htmlspecialchars($this->request->getVar('urlToko'), true);

            $db = \Config\Database::connect();
            $builder = $db->table('_toko_tb_b');
            $cekToko = $builder->select('toko_url')->where('toko_url', $url)->countAllResults();

            $data = [
                'urlToko' => $url,
            ];

            if ($cekToko > 0) {
                $data['message'] = "Url toko sudah ada, ganti dengan url lain.";
                return $this->respond($data);
            } else {
                $data['message'] = "Url warung can use";
                return $this->respondCreated($data);
            }
        }
    }

    public function show($id = null)
    {
        $select = "id as idToko, toko_title as titleToko, toko_description as descriptionToko, toko_slogan as sloganToko, toko_url as urlToko, toko_featured_image as imageToko, toko_status as statusToko, toko_status_description as statusTokoDescription, user_id as userToko";
        $data = $this->model->select($select)->finduserid($id);
        if ($data) {
            return $this->respond($data);
        } else {
            return $this->failNotFound('Item not found');
        }
    }

    public function update($id = null)
    {
        $oldData = $this->model->find($id);
        $rules = [
            'opd' => 'required',
            // 'category' => 'required',
            'user_id' => 'required',
            'title' => 'required',
            'description' => 'required'
        ];

        $filename = dot_array_search('image.name', $_FILES);

        if ($filename != '') {
            $img = ['image' => 'uploaded[image]|max_size[image, 1024]|is_image[image]'];
            // $img = ['featured_image' => 'uploaded[featured_image]|mime_in[featured_image,image/jpg,image/png,image/gif,image/jpeg]|max_size[featured_image, 1024]'];
            $rules = array_merge($rules, $img);
        }

        if (!$this->validate($rules)) {
            return $this->failValidationError($this->validator->getError());
        } else {
            // $input = $this->request->getRawInput();
            $title = htmlspecialchars($this->request->getVar('title'), true);
            $opd = htmlspecialchars($this->request->getVar('opd'), true);
            $category = htmlspecialchars($this->request->getVar('category'), true);

            $tags = htmlspecialchars($this->request->getVar('tag'), true);

            $urlToko = _create_url_toko($title);

            $rulToko = [
                'email' => 'required|trim|valid_email|is_unique[_users_tb.email]',
            ];

            $data = [
                'id' => htmlspecialchars($id, true),
                'post_opd' => $opd,
                'post_category' => $category,
                'post_title' => $title,
                'post_description' => $this->request->getVar('description'),
                'post_url' => _create_url($opd, $title),
                'post_trending' => htmlspecialchars($this->request->getVar('trending'), true),
                'post_tag' => $tags,
                'post_is_active' => htmlspecialchars($this->request->getVar('is_active'), true),
                'post_updated_at' => date('Y-m-d H:i:s'),
            ];

            if ($filename != '') {


                $file = $this->request->getFile('image');
                $filesName = $file->getName();
                $newName = _create_name_foto($filesName);
                // if (!$file->isValid())
                // 	return $this->fail($file->getErrorString());

                // $file->move('./assets/uploads');

                // if (!file_exists('./assets/uploads/' . $this->folderImage . '/' . $opd)) {
                // 	mkdir('./assets/uploads/' . $this->folderImage . '/' . $opd, 0777);
                // 	$dir = './assets/uploads/' . $this->folderImage . '/' . $opd;
                // } else {
                $dir = './assets/uploads/' . $this->folderImage . '/' . $opd;
                // }



                // $file = $this->request->getFile('image');
                // $filesName = $file->getName();
                // $newName = _create_name_foto($filesName);
                // if (!$file->isValid())
                // 	return $this->fail($file->getErrorString());
                if ($file->isValid() && !$file->hasMoved()) {
                    try {
                        $file->move($dir, $newName);
                        $oldFileName = $oldData['post_featured_image'];
                        unlink(FCPATH . $dir . '/' . $oldFileName);
                        $data['post_featured_image'] = $newName;
                    } catch (\Throwable $th) {
                        // return $this->fail($th);
                        return $this->failNotFound('gagal upload');
                    }
                } else {
                    // return $this->fail($file->getErrorString());
                    return $this->failNotFound('gagal valid file');
                }
            }
            try {
                $this->model->save($data);

                $tag_array = explode(',', $tags);
                $db      = \Config\Database::connect();

                $buildersDelete = $db->table('_tag_berita_target');
                $buildersDelete->delete(['berita_id', $id]);


                foreach ($tag_array as $tag_name) {
                    $builder = $db->table('_tags_tb');
                    $tag = strtolower(trim($tag_name));
                    $data_tag = [
                        'tag_name' => $tag,
                        'tag_ori_name' => $tag_name
                    ];
                    $builder->ignore(true)->insert($data_tag);
                    $tag_ids = $builder->select('id')->where('tag_name', $tag)->get()->getRowObject();

                    $tag_id = $tag_ids->id;

                    $builders = $db->table('_tag_berita_target');
                    $data_tag_berita = [
                        'tag_id' => $tag_id,
                        'berita_id' => $id,
                        'berita_url' => $data['post_url']
                    ];
                    $builders->insert($data_tag_berita);
                }
            } catch (\Throwable $th) {
                // return $this->fail($th);
                return $this->failNotFound('gagal simpan database');
            }

            return $this->respond($data);
        }
    }

    public function delete($id = null)
    {
        $data = $this->model->find($id);
        if ($data) {
            try {
                $fileName = $data['post_featured_image'];
                $opd = $data['post_opd'];
                // delete_files('./assets/uploads/' . $fileName);
                unlink(FCPATH . './assets/uploads/' . $this->folderImage . '/' . $opd . '/' . $fileName);

                $db      = \Config\Database::connect();

                $buildersDelete = $db->table('_tag_berita_target');
                $buildersDelete->delete(['berita_id', $id]);

                $this->model->delete($id);
                $dat['status'] = "deleted";
                $dat['message'] = "Item data berhasil di hapus.";
                $dat['description'] = "Item data " . $data['post_title'] . "berhasil di hapus";
                $dat['data'] = $data;
                return $this->respondDeleted($dat);
            } catch (\Throwable $th) {
                return $this->fail($th);
            }
        } else {
            return $this->failNotFound('Item not found');
        }
    }

    public function findcategory()
    {
        $data = [];
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

        $rules = [
            'keyword' => 'required|trim',
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getError());
        } else {
            $keyword = htmlspecialchars($this->request->getVar('keyword'), true);

            $db = \Config\Database::connect();
            $builder = $db->table('_category_tb_b');
            $select1 = "id as idCat, id as kodeCategory, category_name as categoryName, prioritas_search as orderBy";
            $where1 = "key_search LIKE '%$keyword%' AND is_active = 1";
            $array1 = $builder->select($select1)->where($where1)->get()->getResultArray();

            $builder2 = $db->table('_sub_category_tb_b');
            $select2 = "_sub_category_tb_b.id as idCat, CONCAT(_category_tb_b.id,'/',_sub_category_tb_b.id) as kodeCategory, CONCAT(_category_tb_b.category_name,'/',_sub_category_tb_b.sub_category_name) as categoryName, _sub_category_tb_b.prioritas_search as orderBy";
            $builder2->select($select2);
            $builder2->join('_category_tb_b', '_sub_category_tb_b.category_id=_category_tb_b.id');
            $where2 = "_sub_category_tb_b.key_search LIKE '%$keyword%' AND _sub_category_tb_b.is_active = 1";
            $array2 = $builder2->where($where2)->get()->getResultArray();

            $builder3 = $db->table('_litle_sub_category_tb_b');
            $select3 = "_litle_sub_category_tb_b.id as idCat, CONCAT(_category_tb_b.id,'/',_sub_category_tb_b.id,'/',_litle_sub_category_tb_b.id) as kodeCategory, CONCAT(_category_tb_b.category_name,'/',_sub_category_tb_b.sub_category_name,'/',_litle_sub_category_tb_b.litle_sub_category_name) as categoryName, _litle_sub_category_tb_b.prioritas_search as orderBy";
            $builder3->select($select3);
            $builder3->join('_category_tb_b', '_litle_sub_category_tb_b.category_id=_category_tb_b.id');
            $builder3->join('_sub_category_tb_b', '_litle_sub_category_tb_b.sub_category_id=_sub_category_tb_b.id');
            $where3 = "_litle_sub_category_tb_b.key_search LIKE '%$keyword%' AND _litle_sub_category_tb_b.is_active = 1";
            $array3 = $builder3->where($where3)->get()->getResultArray();

            $datas = array_merge($array1, $array2, $array3);

            $keys = array_column($datas, 'orderBy');

            array_multisort($keys, SORT_DESC, $datas);

            $dataFix = array_slice($datas, 0, 5);


            if (count($dataFix) > 0) {
                $data['findRecomendedCategory'] = $dataFix;
                return $this->respond($data);
            } else {
                return $this->respondNoContent("Data Tidak Ditemukan");
            }
        }
    }
}
