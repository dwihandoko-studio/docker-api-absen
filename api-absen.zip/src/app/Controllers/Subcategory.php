<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;

class Subcategory extends ResourceController
{
    //protected $modelName = 'App\Models\ProductpublicModel';
    protected $format = 'json';

    var $folderImage = 'product';

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
      	$this->_db      = \Config\Database::connect();
    }
  
  	public function index()
    { 
      	if (!$this->request->getGet('category')) {
          $where = [
            'is_active' => 1
          ];
        }else{
          $catId = htmlspecialchars($this->request->getGet('category'), true);
          $where = [
            'category_id' => $catId,
            'is_active' => 1
          ];
        }
        $select = "id as subCategoryId, category_id as categoryId, sub_category_name as subCategoryName, key_search as keySearch";
      
        $cat = $this->_db->table('_sub_category_tb_b')->select($select)->where($where)->orderBy('sub_category_name', 'asc')->get()->getResult();

        if(count($cat) > 0) {
          $data['result'] = $cat;
          $data['total_result'] = count($cat);
          return $this->respond($data);
        }else{
          return $this->respondNoContent('Tidak ada content.');
        }
    }
}