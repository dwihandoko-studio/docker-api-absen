<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;

class Promotionproductpublic extends ResourceController
{
    protected $modelName = 'App\Models\PromotionproductpublicModel';
    protected $format = 'json';

    var $folderImage = 'product';

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
    }

    public function index()
    {
        $per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
        $pag = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

        if ($pag == 1) {
            $start = 0;
        } else {
            $start = (($pag - 1) * $per_page);
        }

        $db = \Config\Database::connect();
        $buildersPromotion = $db->table('_promotion_tb_b');
        $buildersPromotionItem = $db->table('_promotion_item_tb_b');
        $buildersPromotionItemProduct = $db->table('product_public');

        if (!$this->request->getGet('key')) {
            $where = [
                'productStatus' => 1
            ];
            $data['result'] = $this->model->where($where)->orderBy('createdAt', 'desc')->findAll($per_page, $start);
            // $data['result'] = $this->model->findAll($per_page, $start);
            $data['total_result'] = $this->model->where($where)->countAllResults();
        } else {
            $id = htmlspecialchars($this->request->getGet('key'), true);


            $select1 = "id as id, promotion_title as promotionTitle, promotion_banner as promotionBanner, promotion_sponsored as promotionSponsored, promotion_item_list as item_list, promotion_is_active as promotionIsActive";
            $where1 = "id = '$id' AND promotion_is_active = 1";
            $array1 = $buildersPromotion->select($select1)->where($where1)->get()->getRowArray();

            $idListPromo = explode(',', $array1['item_list']);

            $array1['itemListPromotion'] = array();
            foreach ($idListPromo as $value) {
                $select2 = "id as promotionId, promotion_item_name as promotionName, promotion_item_start_nominal as promotionStartNominal, promotion_item_product as item_product, promotion_item_start_date as startPromotion, promotion_item_end_date as endPromotion";
                $where2 = "id = '$value' AND promotion_item_is_active = 1";
                $array2 = $buildersPromotionItem->select($select2)->where($where2)->get()->getRowArray();

                $idProduct = explode(',', $array2['item_product']);

                $array2['itemProductPromotion'] = array();

                foreach ($idProduct as $k) {
                    $where3 = "productId = '$k' AND productStatus = 1";
                    $array2['itemProductPromotion'][] = $buildersPromotionItemProduct->where($where3)->get()->getRowArray();
                }
                $array1['itemListPromotion'][] = $array2;
            }

            // $array1['itemListPromotion'] = $dataItemPromo;
            $result = array();
            $result[] = $array1;
            $data['result'] = $result;
            $data['total_result'] = count($data['result']);
        }


        // $data['result'] = $this->model->findAll($per_page, $start);
        // $data['total_result'] = $this->model->countAllResults();
        if ($data['total_result'] > 0) {
            $data['page'] = $pag;
            $data['total_page'] = ceil($data['total_result'] / $per_page);
            return $this->respond($data);
        } else {
            return $this->respondNoContent('Tidak ada content.');
        }
    }

    // public function show($url = null)
    // {
    //     $where = [
    //         'productStatus' => 1
    //     ];
    //     $data = $this->model->where($where)->findProductPublic(htmlspecialchars($url, true));
    //     if ($data) {
    //         $ip = htmlspecialchars($this->request->getGet('ip'), true);
    //         return $this->respond($data);
    //     } else {
    //         return $this->failNotFound('Item not found');
    //     }
    // }
}
