<?php

namespace App\Controllers;
use App\Libraries\Uuid;
use App\Libraries\Absen\Userlib;

class Disclaimer extends BaseController
{
    function __construct()
	{
		helper(['form','text', 'date', 'array', 'fotourl', 'filesystem']);
      	$this->_db = \Config\Database::connect();
    }
    
    public function index()
    {
        // $data['testing'] = _create_name_foto('WhatsApp Image 2020-05-05 at 22.05.57.jpeg');
        // return view('disclaimer');

        $userId = htmlspecialchars($this->request->getGet('user'), true);

        $start_dateR = $this->request->getGet('startdate');
        $end_dateR = $this->request->getGet('enddate');

        //REF JAM KERJA
        $whereJamKerja = "instansi_induk = (SELECT instansi_induk FROM _profil_users_tb WHERE id = '$userId')";
        $refJamKerja = $this->_db->table('_jam_kerja_tb')->where($whereJamKerja)->where('flag_status', 1)->get()->getRowArray();
        $jamMasukAwal = str_replace(':', '', $refJamKerja['jam_masuk_awal']);
        $jamMasukAkhir = str_replace(':', '', $refJamKerja['jam_masuk_akhir']);
        $jamMasuk = str_replace(':', '', $refJamKerja['jam_masuk']);
        $jamSiangAwal = str_replace(':', '', $refJamKerja['jam_siang_awal']);
        $jamSiangAkhir = str_replace(':', '', $refJamKerja['jam_siang_akhir']);
        $jamPulangAwal = str_replace(':', '', $refJamKerja['jam_pulang_awal']);
        $jamPulangAkhir = str_replace(':', '', $refJamKerja['jam_pulang_akhir']);
        $jamPulang = str_replace(':', '', $refJamKerja['jam_pulang']);
        $jamPulangRamadhanAwal = str_replace(':', '', $refJamKerja['jam_pulang_ramadhan_awal']);
        $jamPulangRamadhanAkhir = str_replace(':', '', $refJamKerja['jam_pulang_ramadhan_akhir']);
        $jamPulangRamadhan = str_replace(':', '', $refJamKerja['jam_pulang_ramadhan']);
        $jamMasukJumatAwal = str_replace(':', '', $refJamKerja['jam_masuk_jumat_awal']);
        $jamMasukJumatAkhir = str_replace(':', '', $refJamKerja['jam_masuk_jumat_akhir']);
        $jamMasukJumat = str_replace(':', '', $refJamKerja['jam_masuk_jumat']);
        $jamPulangJumatAwal = str_replace(':', '', $refJamKerja['jam_pulang_jumat_awal']);
        $jamPulangJumatAkhir = str_replace(':', '', $refJamKerja['jam_pulang_jumat_akhir']);
        $jamPulangJumat = str_replace(':', '', $refJamKerja['jam_pulang_jumat']);
        $jamPulangJumatRamadhanAwal = str_replace(':', '', $refJamKerja['jam_pulang_jumat_ramadhan_awal']);
        $jamPulangJumatRamadhanAkhir = str_replace(':', '', $refJamKerja['jam_pulang_jumat_ramadhan_akhir']);
        $jamPulangJumatRamadhan = str_replace(':', '', $refJamKerja['jam_pulang_jumat_ramadhan']);
        $jamApelAwal = str_replace(':', '', $refJamKerja['jam_apel_awal']);
        $jamApelAkhir = str_replace(':', '', $refJamKerja['jam_apel_akhir']);
        $jamApel = str_replace(':', '', $refJamKerja['jam_apel']);

        $setMasuk = $refJamKerja['jam_masuk'];
        $setPulang = $refJamKerja['jam_pulang'];
        
        $selectPegawais = "a.id, a.fullname, a.nik as nipNik, a.email, a.no_hp as nohp, a.jabatan_id as jabatanId, b.jabatan, a.instansi_id as instansiId, c.instansi, a.profile_picture as imageProfil, a.player_id_onesignal as idOnesignal, a.role_user as roleUser, a.is_active as status, a.created_at as createdAt, a.updated_at as updatedAt";
        $pegawais = $this->_db->table('_profil_users_tb a')
                            ->select($selectPegawais)
                            ->join('_jabatan_tb b', 'b.id = a.jabatan_id', 'LEFT')
                            ->join('_instansi_tb c', 'c.id = a.instansi_id', 'LEFT')
                            ->where("a.instansi_induk = (SELECT instansi_induk FROM _profil_users_tb WHERE id = '$userId')")
                            
                            ->orderBy('a.fullname', 'asc')
                            ->get()->getResultObject();

        //TANGGAL MAPPING
        $start_date = explode('-', $start_dateR);
        $bulan = $start_date[1] . '/' . $start_date[0];
        $start_date = $start_dateR;
        
        $selectLibur = "libur, keterangan";
        $whereLibur = "libur >= '$start_date' AND libur <= '$end_dateR'";
        $hariLibur = $this->_db->table('jadwal_harilibur')
                            ->select($selectLibur)
                            ->where($whereLibur)
                            ->get()->getResultObject();
        
        // Mengambil data Absen Pegawai per Periode
        $date_from = strtotime($start_date); // Convert date to a UNIX timestamp
        $date_to = strtotime($end_dateR); // Convert date to a UNIX timestamp

        for ($i = $date_from; $i <= $date_to; $i += 86400) {
            $tanggalBulan[] = date('Y-m-d', $i);
        }

        if(count($pegawais) > 0) {
            foreach ($pegawais as $value) {

                $selectAbsen = "id, user_id as userId, latitude, longitude, jenis_absen as jenisAbsenId, IF(jenis_absen = 1, 'Masuk', IF(jenis_absen = 2, 'Siang', 'Pulang')) as jenisAbsen, lampiran, keterangan, CONCAT( IF(HOUR(created_at) < 10, CONCAT('0',HOUR(created_at)),HOUR(created_at)), ':', IF(MINUTE(created_at) < 10, CONCAT('0',MINUTE(created_at)), MINUTE(created_at))) as waktuAbsen, DATE(created_at) as tglAbsen, created_at as createdAt";

                $absenPegawai = $this->_db->table('_absen_tb')
                                    ->select($selectAbsen)
                                    ->where("user_id", $value->id)
                                    ->where("DATE(created_at) >=", $start_date)
                                    ->where("DATE(created_at) <=", $end_dateR)
                                    ->groupBy(["DATE(created_at)", "jenis_absen"])
                                    ->orderBy("DATE(created_at)", "ASC")
                                    ->orderBy("created_at", "DESC")
                                    ->get()->getResult();

                $value->dataAbsen = $absenPegawai;
            }
        }
        
        // --- RAMADHAN 2017 ---
        $periodramadhan = new \DatePeriod(
            new \DateTime("2020-05-27"),
            new \DateInterval('P1D'),
            new \DateTime("2020-06-26 23:59:59")
        );
        $daterangeramadhan = array();
        foreach ($periodramadhan as $date) {
            $daterangeramadhan[] = $date->format('Y-m-d');
        }
        $ramadhan = array();
        foreach ($daterangeramadhan as $key) {
            if (date('N', strtotime($key)) < 6) {
                $ramadhan[] = $key;
            }
        }
        
        $data['tgl_awal_pilih'] = $start_date;
        $data['tgl_akhir_pilih'] = $end_dateR;

        $data['start_dateR'] = $start_dateR;
        $data['end_dateR'] = $end_dateR;
        $data['absensi'] = $pegawais;
        $data['hariLibur'] = $hariLibur;
        $data['bulan'] = $bulan;
        $data['tanggalBulan'] = $tanggalBulan;
        
        $data['ramadhanformatslash'] = $ramadhan;

        $data['awal_telatdtg'] = (string)($jamMasuk + 100);
        $data['akhir_telatdtg'] = (string)($jamMasukAkhir + 100);
        $data['awal_plgcepat'] = $jamPulangAwal;
        $data['jamSiangAwal'] = $jamSiangAwal;
        $data['jamSiangAkhir'] = $jamSiangAkhir;
        $data['akhir_plgcepat'] = $jamPulang;
        $data['jam_jamdtg'] = $jamMasukAwal;
        $data['akhir_jamplg'] = $jamPulangAkhir;
        $data['jamPulangRamadhan'] = $jamPulangRamadhan;
        $data['jamPulangRamadhanAwal'] = $jamPulangRamadhanAwal;
        $data['jamPulangRamadhanAkhir'] = $jamPulangRamadhanAkhir;
        $data['jamMasukJumatAwal'] = $jamMasukJumatAwal;
        $data['jamMasukJumatAkhir'] = (string)($jamMasukJumatAkhir + 100);
        $data['jamMasukJumat'] = (string)($jamMasukJumat + 100);
        $data['jamPulangJumatAwal'] = $jamPulangJumatAwal;
        $data['jamPulangJumatAkhir'] = $jamPulangJumatAkhir;
        $data['jamPulangJumat'] = $jamPulangJumat;
        $data['jamPulangJumatRamadhanAwal'] = $jamPulangJumatRamadhanAwal;
        $data['jamPulangJumatRamadhanAkhir'] = $jamPulangJumatRamadhanAkhir;
        $data['jamPulangJumatRamadhan'] = $jamPulangJumatRamadhan;
        $data['jam_jamapel'] = $jamApel;
        $data['awal_jamapel'] = $jamApelAwal;
        $data['akhir_jamapel'] = $jamApelAkhir;

        $data['setMasuk'] = $setMasuk;
        $data['setPulang'] = $setPulang;

        echo json_encode($data);die;
    }

    //--------------------------------------------------------------------

}
