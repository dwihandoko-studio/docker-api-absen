<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Bcalib;
use App\Libraries\Midtranslib;
use App\Libraries\Onesignallib;

class Topup extends ResourceController
{
    protected $modelName = 'App\Models\TopupModel';
    protected $format = 'json';

    var $folderImage = 'profile';
	private $_db;

    function __construct()
    {
        helper(['text', 'form', 'array', 'fotourl', 'filesystem']);
      	$this->_db = \Config\Database::connect();
    }
  
  	public function index() {
      	if (!$this->request->getGet('user')) {
            return $this->respondNoContent('Tidak ada content.');
        }else{
          	$userId = htmlspecialchars($this->request->getGet('user'), true);
          	if(!$this->request->getGet('kodetransaksi')) {
              	$builder = $this->_db->table('_topup_tb_b');
              	
              	$select = "id, kode_transaksi as kodeTransaksi, jenis_topup as jenisTopup, nominal, gross_amount as grossAmount, status_topup as statusTopup, user_id as userId, created_at createdAt, updated_at as updatedAt";
              	$where = [
                  	'user_id' => $userId,
                ];
              	$topups = $builder->select($select)->where($where)->orderBy('created_at', 'desc')->get()->getResult();
              	if(count($topups) > 0) {
                  	$data['result'] = $topups;
                  	$data['total_result'] = count($topups);
                  	return $this->respond($data);
                }else{
                  	return $this->respondNoContent("Data tidak ditemukan");
                }
            }else{
              	$kodeTransaksi = htmlspecialchars($this->request->getGet('kodetransaksi'), true);
              
              	$builder = $this->_db->table('_topup_tb_b');
              	
              	$select = "id, kode_transaksi as kodeTransaksi, jenis_topup as jenisTopup, nominal, gross_amount as grossAmount, status_topup as statusTopup, user_id as userId, created_at createdAt, updated_at as updatedAt";
              	$where = [
                  	'kode_transaksi' => $kodeTransaksi,
                  	'user_id' => $userId,
                ];
              	$topup = $builder->select($select)->where($where)->orderBy('created_at', 'desc')->get()->getRowObject();
              	if($topup) {
                  	$builderPayment = $this->_db->table('_payment_gateway_tb_b');
                  	
                  	$selectPayment = "id, layanan_payment as layananPayment, payment_type as paymentType, bank, group_payment as groupPayment, logo_payment as logoPayment, title_payment as titlePayment, nama_pemilik as namaPemilik, no_rekening as noRekening, cost_payment as costPayment, no_urut as noUrut, group_urut as groupUrut, status_payment as statusPayment, favorite_payment as favoritePayment, created_at as createdAt, updated_at as updatedAt";
                  	
                  	$wherePayment = "publish = 1 AND payment_type != 'saldo'";
                  
                  	$payments = $builderPayment->select($selectPayment)->where($wherePayment)->orderBy('no_urut', 'asc')->get()->getResult();
                  	
                  	$data['itemTopup'] = $topup;
                  	$data['listPayment'] = $payments;
                  	return $this->respond($data);
                }else{
                  	return $this->respondNoContent("Data tidak ditemukan");
                }
            }
        }
    }
  
  	public function addsaldo()
	{
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            // 'userId' => 'required|min_length[3]|max_length[50]',
            'userId' => 'required',
            'jenisTopup' => 'required',
            'nominal' => 'required'
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          $uuid = new Uuid();
          $userId = htmlspecialchars($this->request->getVar('userId'), true);

          $kodeTransaksi = "MA-TOPUP-" . TIME() . random_string('numeric', 4);
          $id = $uuid->v4();
          $nominal = (int)htmlspecialchars($this->request->getVar('nominal'), true);
          $unixNominalAdd = (int)random_string('numeric', 3);
          $grossAmount = $nominal + $unixNominalAdd;
          
          //var_dump($grossAmount);die;

          $data = [
            'id' => $id,
            'kode_transaksi' => $kodeTransaksi,
            'user_id' => $userId,
            'jenis_topup' => htmlspecialchars($this->request->getVar('jenisTopup'), true),
            'nominal' => $nominal,
            'gross_amount' => $nominal,
            'status_topup' => 0,
            'created_at' => date('Y-m-d H:i:s'),
          ];

          //try {
            	$user_id = $this->model->insertData($data, false);
            	
            	if($user_id > 0) {
                  	$dataRespon = [
                      	'id' => $data['id'],
                      	'kodeTransaksi' => $data['kode_transaksi'],
                      	'userId' => $data['user_id'],
                      	'jenisTopup' => $data['jenis_topup'],
                      	'nominal' => (string)$data['nominal'],
                      	'grossAmount' => (string)$data['gross_amount'],
                      	'statusTopup' => (string)$data['status_topup'],
                      	'createdAt' => $data['created_at']
                    ];
                  	return $this->respondCreated($dataRespon);
                }else{
                  	return $this->fail("gagal membuat topup");
                }
          //} catch (\Throwable $th) {
          //  	return $this->fail("Terjadi kesalahan internal");
          //}
            
            
        }
	}
  
  
  public function textC(){
    $user_id = 0;
    if ($user_id > 0) {
              	$db      = \Config\Database::connect();
              	$builderGetUser = $db->table('_profil_users_tb');
              	$dataCostomer = $builderGetUser->where('id',$userId)->get()->getRowObject();
              	if($dataCostomer) {
                        $customerDetails = [];
                        $customerDetails['email'] = $dataCostomer->email;
                        $customerDetails['firs_name'] = $dataCostomer->firsname;
                        $customerDetails['last_name'] = $dataCostomer->lastname;
                        $customerDetails['phone'] = ($dataCostomer->no_hp == null || $dataCostomer->no_hp == "") ? "" : $dataCostomer->no_hp;
              
                    $dataReqPayment = [];
                    $dataReqPayment['payment_type'] = "bank_transfer";
                    $dataReqPayment['bank_transfer']['bank'] = "bca";
                        $inquiry = [];
                        $inquiry1 = [];
                        $inquiry1['id'] = "Tagihan Pembayaran Moroarto";
                        $inquiry1['en'] = "Moroarto Payment Billing";

                        $inquiry[] = $inquiry1;

                        $inquiryPayment = [];
                        $inquiryPayment1 = [];
                        $inquiryPayment1['id'] = "Tagihan Pembayaran Moroarto";
                        $inquiryPayment1['en'] = "Moroarto Payment Billing";
                        $inquiryPayment[] = $inquiryPayment1;
                    $dataReqPayment['bank_transfer']['free_text']['inquiry'] = $inquiry;
                    $dataReqPayment['bank_transfer']['free_text']['payment'] = $inquiryPayment;
                    $dataReqPayment['transaction_details']['gross_amount'] = $grossAmount;
                    $dataReqPayment['transaction_details']['order_id'] = $kodeTransaksi;

                        $item_details_temp = [];
                        $item_details_temp['id'] = "TOPUP".time();
                        $item_details_temp['price'] = $nominal;
                        $item_details_temp['quantity'] = 1;
                        $item_details_temp['name'] = "TOPUP SALDO MERCHAN ".$nominal;

                        $item_details_temp1 = [];
                        $item_details_temp1['id'] = "UNIX".time();
                        $item_details_temp1['price'] = $unixNominalAdd;
                        $item_details_temp1['quantity'] = 1;
                        $item_details_temp1['name'] = "Kode Unik Pembayaran ".$nominal;

                        $item_details[] = $item_details_temp;
                        $item_details[] = $item_details_temp1;

                    $dataReqPayment['customer_details'] = $customerDetails;
                    $dataReqPayment['item_details'] = $item_details;
                  
                  	$midtrans = new Midtranslib();
                  	$requestMidtrans = $midtrans->bankTransferBca($dataReqPayment);
                  
                  	$feedDataPaymentBack['id'] = "ce4c6378-dddf-11ea-b2e8-54ee75f229ba";
                    $feedDataPaymentBack['groupPayment'] = "Transfer Virtual Account";
                    $feedDataPaymentBack['logoPayment'] = "bca.png";
                    $feedDataPaymentBack['titlePayment'] = "BCA Virtual Account";
                    $feedDataPaymentBack['costPayment'] = "4000";
                    $feedDataPaymentBack['favoritePayment'] = "1";
                  
                  	$feedBack = [
                      'transaction_time' => $requestMidtrans->transaction_time,
                      'bank' => $requestMidtrans->va_numbers[0]->bank,
                      'va_number' => $requestMidtrans->va_numbers[0]->va_number,
                      'biller_code' => null,
                      'total_tagihan' => (int)$requestMidtrans->gross_amount,
                      'detailPayment' => $feedDataPaymentBack
                    ];
                  
                  	$dataVaUpdate = [
                      	'bank' => $requestMidtrans->va_numbers[0]->bank,
                      	'va_number' => $requestMidtrans->va_numbers[0]->va_number,
                    ];
                  
                  	$builderUpdateVa = $db->table('_topup_merchan_tb_b');
              		$dataCostomer = $builderUpdateVa->where('kode_transaksi',$kodeTransaksi)->update($dataVaUpdate);

                    return $this->respond($feedBack);
                }else{
                    $this->fail("Failed Create Payment");
                }
            }else{
                $this->fail("Failed Create Payment");
            }
  }
  
  
  
  
  
  
  
  public function testcontroller() {
    if ($this->request->getMethod() != 'post')
            return $this->fail('Only get request is allowed');
    
    $userId = htmlspecialchars($this->request->getVar('userId'), true);
    $title = htmlspecialchars($this->request->getVar('title'), true);
    $content = htmlspecialchars($this->request->getVar('content'), true);
    
    $onesignal = new Onesignallib();
    
    $data = [
      'send_to' => $userId,
      'title' => $title,
      'content' => $content,
      'app_url' => "ppobmerchan;MA-POBMERC-15990646758076;detail_oder"
    ];
    
    $send = $onesignal->pushNotifToUser($data);
    
    return $this->respond($send);
    
    //$rules = [
         // 	'kodeProduct' => 'required',
        //];

       // if (!$this->validate($rules)) {
        //    return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
       // } else {
    
    //$newPpob = new Ppoblib();
          //$textString = htmlspecialchars($this->request->getVar('kodeProduct'), true);
    //$textString = "PLNPRAH20";
    //$string = substr($textString, 0,7);
    //$cekAvailableProduct = $newPpob->datatransaksi("20200830000000", "20200830235900","","","50191187512");
          //$cekAvailableProduct = $newPpob->cetakulang("MRTPOB-MERC-15987676811753");
    
          //$newTopup = new Bcalib();
          //$res = $newTopup->getBalance();
    	  //$res = $newTopup->getAccountStatement("0201245680","2016-08-29","2016-09-01");
    	//$res = $newTopup->fundTransfer("0201245680", "00000003", "123/MRT/2020", "100000.00", "0201245681", "Transfer Test", "Online Transfer");
    //if($res) {
    //  return $this->respond($res);
    //}else{
    //  return $this->fail("Gagal");
    //}
  }
}
