<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;

class Beritapublic extends ResourceController
{
	protected $modelName = 'App\Models\BeritapublicModel';
	protected $format = 'json';

	var $folderImage = 'berita';

	function __construct()
	{
		helper(['form', 'array', 'fotourl', 'filesystem']);
	}

	public function index()
	{
		$opd = htmlspecialchars($this->request->getGet('opd'), true);
		$per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
		$pag = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

		if ($pag == 1) {
			$start = 0;
		} else {
			$start = (($pag - 1) * $per_page);
		}

		if ($opd) {
			if (!$this->request->getGet('keyword')) {
				$where = [
					'opd_id' => $opd,
					'active' => 1
				];
				$data['result'] = $this->model->where($where)->orderBy('created_at', 'desc')->findAll($per_page, $start);
				// $data['result'] = $this->model->where(['post_opd' => $opd])->findAll($per_page, $start);
				$data['total_result'] = $this->model->where($where)->countAllResults();
			} else {
				$keyword = htmlspecialchars($this->request->getGet('keyword'), true);
				$where = "opd_id = $opd AND active = 1 AND (title LIKE '%$keyword%' OR description LIKE '%$keyword%' OR tags LIKE '%$keyword%')";
				$data['result'] = $this->model->where($where)->orderBy('created_at', 'desc')->findAll($per_page, $start);
				$data['total_result'] = $this->model->where($where)->countAllResults();
			}
		} else {
			if (!$this->request->getGet('keyword')) {
				$where = [
					'active' => 1
				];
				$data['result'] = $this->model->where($where)->orderBy('created_at', 'desc')->findAll($per_page, $start);
				// $data['result'] = $this->model->findAll($per_page, $start);
				$data['total_result'] = $this->model->where($where)->countAllResults();
			} else {
				$keyword = htmlspecialchars($this->request->getGet('keyword'), true);

				$where = "active = 1 AND (title LIKE '%$keyword%' OR description LIKE '%$keyword%' OR tags LIKE '%$keyword%')";
				$data['result'] = $this->model->where($where)->orderBy('created_at', 'desc')->findAll($per_page, $start);
				$data['total_result'] = $this->model->where($where)->countAllResults();
			}


			// $data['result'] = $this->model->findAll($per_page, $start);
			// $data['total_result'] = $this->model->countAllResults();
		}
		if ($data['total_result'] > 0) {
			$data['page'] = $pag;
			$data['total_page'] = ceil($data['total_result'] / $per_page);
			return $this->respond($data);
		} else {
			return $this->respondNoContent('Tidak ada content.');
		}
	}

	public function show($url = null)
	{
		$where = [
			'active' => 1
		];
		$data = $this->model->where($where)->findurl(htmlspecialchars($url, true));
		if ($data) {
			$ip = htmlspecialchars($this->request->getGet('ip'), true);
			return $this->respond($data);
		} else {
			return $this->failNotFound('Item not found');
		}
	}
}
