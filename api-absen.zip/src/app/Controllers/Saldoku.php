<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Notificationlib;

class Saldoku extends ResourceController
{
    protected $modelName = 'App\Models\TransaksiModel';
    protected $format = 'json';

    var $folderImage = 'profile';
  	private $_db;

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
      	$this->_db = \Config\Database::connect();
    }

    public function index()
    {
      	if (!$this->request->getGet('user')) {
            return $this->respondNoContent('Tidak ada content.');
        }else{
      		$per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
        	$start = (int) htmlspecialchars($this->request->getGet('start'), true) ? (int) htmlspecialchars($this->request->getGet('start'), true) : 0;
          	$userId = htmlspecialchars($this->request->getGet('user'), true);
          
          	$where=[
              'id' => $userId,
            ];
          
          	$select = "id, saldo";
          
          	$builder = $this->_db->table('_profil_users_tb');
          
          	$user = $builder->select($select)->where($where)->get()->getRowObject();
          
          	//var_dump($user);
          
          	if($user) {
              
              	$builderSaldo = $this->_db->table('_riwayat_saldo');
              	$selectSaldo = "id, user_id as userId, jenis_saldo as jenisSaldo, jenis_guna as jenisGuna, saldo_old as saldoOld, saldo_new as saldoNew, saldo_perubahan as saldoPerubahan, keterangan, created_at as createdAt";
              	$riwayatSaldo = $builderSaldo->select($selectSaldo)->where('user_id', $user->id)->orderBy('created_at', 'desc')->get()->getResult();
              	
              	$data['saldo'] = $user->saldo;
              	$data['riwayatSaldo'] = $riwayatSaldo;
              
              	return $this->respond($data);
            }else{
              	return $this->responNoContent('Tidak ada content.');
            }
        }
    }
}