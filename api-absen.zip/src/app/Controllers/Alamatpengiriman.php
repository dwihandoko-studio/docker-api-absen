<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;

class Alamatpengiriman extends ResourceController
{
	protected $modelName = 'App\Models\AlamatpengirimanModel';
	protected $format = 'json';

	var $folderImage = 'profile';
  	private $_db;

	function __construct()
	{
		helper(['form','text', 'array', 'fotourl', 'filesystem']);
      	$this->_db = \Config\Database::connect();
	}

	public function index()
	{
		if (!$this->request->getGet('userId')) {
            return $this->respondNoContent('Tidak ada content.');
        } else {
            $userId = htmlspecialchars($this->request->getGet('userId'), true);
          	
          	if (!$this->request->getGet('default')) {
                $where = [
                    'user_id' => $userId
                ];
              	
              	$builder = $this->_db->table('_alamat_kiriman_users_tb');
              	$select = "_alamat_kiriman_users_tb.*, ref_kecamatan.province as provinsiName, ref_kecamatan.city as kabupatenKotaName, ref_kecamatan.type as kabupatenKota, ref_kecamatan.subdistrict_name as kecamatanName";
              
              	$dataAlamats = $builder->select($select)->join('ref_kecamatan', 'ref_kecamatan.subdistrict_id = _alamat_kiriman_users_tb.kecamatan_id')->where($where)->orderBy('is_utama', 'desc')->orderBy('label_alamat', 'asc')->orderBy('created_at', 'asc')->get()->getResult();
              
                //$data['result'] = $this->model->where($where)->orderBy('is_utama', 'desc')->orderBy('label_alamat', 'asc')->orderBy('created_at', 'asc')->findAll();
                // // $data['result'] = $this->model->findAll($per_page, $start);
              	$data['result'] = $dataAlamats;
                $data['total_result'] = count($dataAlamats);
            }else{
              	
              	$builder = $this->_db->table('_alamat_kiriman_users_tb');
              	$where = [
                    'user_id' => $userId,
                  	'is_utama' => 1
                ];
              	$select = "_alamat_kiriman_users_tb.*, ref_kecamatan.province as provinsiName, ref_kecamatan.city as kabupatenKotaName, ref_kecamatan.type as kabupatenKota, ref_kecamatan.subdistrict_name as kecamatanName";
              	
              	$hasil = $builder->select($select)->join('ref_kecamatan', 'ref_kecamatan.subdistrict_id = _alamat_kiriman_users_tb.kecamatan_id')->where($where)->orderBy('created_at', 'desc')->get();

              	$data = $hasil->getRow();
              	if($data) {
                	return $this->respond($data);
                }else{
                	return $this->respondNoContent('Tidak ada content.');
                }
              	//$data['total_result'] = count($data['result']);
            }

            //$db      = \Config\Database::connect();
            //$builder = $db->table('keranjang_view');
            //$hasil = $builder->where('userId', $userId)->orderBy('createdAt', 'desc')->get();

            //$data['result'] = $hasil->getResult();
            //$data['total_result'] = count($data['result']);

            //$where = [
            //    'user_id' => $userId
            //];
            //$data['result'] = $this->model->where($where)->orderBy('createdAt', 'desc')->findAll();
            // // $data['result'] = $this->model->findAll($per_page, $start);
            //$data['total_result'] = $this->model->where($where)->countAllResults();
        }

        if ($data['total_result'] > 0) {
            return $this->respond($data);
        } else {
            return $this->respondNoContent('Tidak ada content.');
        }
	}

	public function create()
	{
		$rules = [
			// 'userId' => 'required|min_length[3]|max_length[50]',
			'userId' => 'required',
			'provId' => 'required',
			'kabId' => 'required',
			'kecId' => 'required',
			'detailAlamat' => 'required',
			'kodePos' => 'required',
			'labelAlamat' => 'required',
			'namaPenerima' => 'required',
			'nohpPenerima' => 'required',
		];

		if (!$this->validate($rules)) {
			return $this->fail($this->validator->getErrors());
		} else {
			$uuid = new Uuid();
          
          	$userId = htmlspecialchars($this->request->getVar('userId'), true);
          	$isUtama = htmlspecialchars($this->request->getVar('is_utama'), true) ?? 0;

			$data = [
				'id' => $uuid->v4(),
				'user_id' => $userId,
				'provinsi_id' => htmlspecialchars($this->request->getVar('provId'), true),
				'kabupaten_id' => htmlspecialchars($this->request->getVar('kabId'), true),
				'kecamatan_id' => htmlspecialchars($this->request->getVar('kecId'), true),
				'detail_alamat' => htmlspecialchars($this->request->getVar('detailAlamat'), true),
				'kode_pos' => htmlspecialchars($this->request->getVar('kodePos'), true),
				'label_alamat' => htmlspecialchars($this->request->getVar('labelAlamat'), true),
				'nama_penerima' => htmlspecialchars($this->request->getVar('namaPenerima'), true),
				'nohp_penerima' => htmlspecialchars($this->request->getVar('nohpPenerima'), true),
				'is_utama' => $isUtama,
				'is_penjual' => htmlspecialchars($this->request->getVar('isPenjual'), true),
				'created_at' => date('Y-m-d H:i:s'),
			];
          
          	$builderCek = $this->_db->table('_alamat_kiriman_users_tb');
          	$dataCek = $builderCek->where('user_id', $userId)->get()->getResult();
          
          	if(count($dataCek) <= 0){
              $data['is_utama'] = 1;
            }

			try {
				$user_id = $this->model->insert($data);
              	if($isUtama == 1) {
                    $builder = $db->table('_alamat_kiriman_users_tb');
                  	$idAlamat = $data['id'];
                    $where = "user_id = '$userId' AND id != '$idAlamat'";
                    $hasil = $builder->set('is_utama', 0)->where($where)->update();
                }
			} catch (\Throwable $th) {
				return $this->fail($th);
			}
			return $this->respondCreated($data);
		}
	}

	public function show($id = null)
	{
		$data = $this->model->find($id);
		if ($data) {
			return $this->respond($data);
		} else {
			return $this->failNotFound('Item not found');
		}
	}

	public function update($id = null)
	{
		$oldData = $this->model->find($id);
		$rules = [
			'firsname' => 'required|min_length[3]|max_length[50]',
			'lastname' => 'required|min_length[3]|max_length[50]',
			'email' => 'required|valid_email|is_unique[_users_tb.email]',
			'instansi' => 'required',
			'level' => 'required',
			// 'password' => 'required|min_length[6]',
			// 'password_confirm' => 'matches[password]',
		];

		if (!$this->validate($rules)) {
			return $this->failValidationError($this->validator->getError());
		} else {
			$data = [
				'id' => htmlspecialchars($id, true),
				'firsname' => htmlspecialchars($this->request->getVar('firsname'), true),
				'lastname' => htmlspecialchars($this->request->getVar('lastname'), true),
				'email' => htmlspecialchars($this->request->getVar('email'), true),
				// 'password' => htmlspecialchars($this->request->getVar('password'), true),
				'intansi_id' => htmlspecialchars($this->request->getVar('instansi'), true),
				'level' => htmlspecialchars($this->request->getVar('level'), true),
				'is_active' => htmlspecialchars($this->request->getVar('is_active'), true),
				'updated_at' => date('Y-m-d H:i:s'),
			];

			try {
				$this->model->save($data);
				// unset($data['password']);
			} catch (\Throwable $th) {
				return $this->fail($th);
				// return $this->failNotFound('gagal simpan database');
			}
			return $this->respond($data);
		}
	}

	public function delete($id = null)
	{
		$data = $this->model->find($id);
		if ($data) {
			try {
				$this->model->delete($id);
				$dat['status'] = "deleted";
				$dat['message'] = "Item data berhasil di hapus.";
				$dat['description'] = "User " . $data['email'] . " berhasil di hapus";
				$dat['data'] = $data;
				return $this->respondDeleted($dat);
			} catch (\Throwable $th) {
				return $this->fail($th);
			}
		} else {
			return $this->failNotFound('Item not found');
		}
	}
}
