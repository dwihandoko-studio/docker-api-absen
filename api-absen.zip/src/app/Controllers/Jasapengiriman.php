<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Orderslib;
use App\Libraries\Ongkirlib;
use App\Libraries\Pesananlib;

class Jasapengiriman extends ResourceController
{
    protected $modelName = 'App\Models\OrdermerchanppobModel';
    protected $format = 'json';

    var $folderImage = 'profile';
  	private $_db;

    function __construct()
    {
        helper(['form', 'text', 'array', 'fotourl', 'filesystem']);
      	$this->_db = \Config\Database::connect();
    }
  
  	public function getkurir() {
        if ($this->request->getMethod() != 'post')
              return $this->fail('Only post request is allowed');
        $rules = [
          // 'userId' => 'required|min_length[3]|max_length[50]',
          'from' => 'required',
          'to' => 'required',
          'weight' => 'required',
          'kurir' => 'required',
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
            //return $this->fail("Required");
        } else {
            $from = htmlspecialchars($this->request->getVar('from'), true);
            $to = htmlspecialchars($this->request->getVar('to'), true);
          	$weight = htmlspecialchars($this->request->getVar('weight'), true);
          	$kurir = htmlspecialchars($this->request->getVar('kurir'), true);
          
          	//echo $from . "<br>" . $to . "<br>" . $weight . "<br>" . $kurir;

            $ongkirLib = new Ongkirlib();
          	$getOngkir = $ongkirLib->getKurir($from, $to, $weight, $kurir);
          
          	//if($getOngkir != null) {
            //  	$data = [];
            //  	foreach($getOngkir as $val) {
            //        if(count($val->costs) > 0){
//foreach($val->costs as $cost) {
            //              	$data[$val->code] = [
            //                'code' => $val->code,
            //              	'name' => $val->name,
            //              	'cost' => 
             //           ];
            //            }
            //            
            //        }
            //    }
            //}
          	if($getOngkir != null) {
              	$cost = new \stdClass;
              	$cost->value = 0;
              	$cost->etd = "Jangkauan 1km";
              	$cost->note = "Jangkauan max 5km";
              
              	$costs = new \stdClass;
              	$costs->service = "COD";
              	$costs->description = "Cash On Delivery";
              	$costs->cost[] = $cost;
              
              	$cod = new \stdClass;
                $cod->code = "cod";
                $cod->name = "Cash On Delivery";
                $cod->costs[] = $costs;
              
              	$cost1 = new \stdClass;
              	$cost1->value = 0;
              	$cost1->etd = "Tergantung pengambilan";
              	$cost1->note = "Tergantung pengambilan";
              
              	$costs1 = new \stdClass;
              	$costs1->service = "Ambil Di Tempat";
              	$costs1->description = "Pengambilan di tempat";
              	$costs1->cost[] = $cost1;
              
              	$cod1 = new \stdClass;
                $cod1->code = "ambilditempat";
                $cod1->name = "Ambil Di Tempat";
                $cod1->costs[] = $costs1;
              
              	//$cod = [
                //  	'code' => "cod",
                //  	'name' => "Cash On Delivery",
                //  	'consts' => [
                      				
                //    			],
                //];
              
       			$getOngkir->results[] = $cod;
              	$getOngkir->results[] = $cod1;
          	return $this->respond($getOngkir);
            }else {
              return $this->respondNoContent("Tidak ada data");
            }
        }
    }
  
  	public function lacak() {
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
      
        $rules = [
            'codePengiriman' => 'required',
          	'noResi' => 'required'
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          	$codePengiriman = htmlspecialchars($this->request->getVar('codePengiriman'), true);
          	$noResi = htmlspecialchars($this->request->getVar('noResi'), true);
          	
            //$pesananLib = new Pesananlib();
            //$dataPesanan = $pesananLib->getDataDetailEcomPesananDetail($idPesanan);

            //if(!$dataPesanan) {
            //    return $this->respondNoContent("Tidak ada Content");
            //}
          
          	$ongkirLib = new Ongkirlib();
          	$getLacak = $ongkirLib->lacakPengiriman($codePengiriman, $noResi);
          
          	//var_dump($getLacak);die;
          
          	
          	if($getLacak != null){
              	if($codePengiriman == "jnt") {
                  	$deliveryStatus = new \stdClass;
                  	$deliveryStatus->status = $getLacak->result->delivery_status->status;
                  	$deliveryStatus->podReceiver = $getLacak->result->delivery_status->pod_receiver;
                  	$deliveryStatus->podDate = $getLacak->result->delivery_status->pod_date;
                  	$deliveryStatus->podTime = $getLacak->result->delivery_status->pod_time;
                  
                  	$detail = new \stdClass;
                  	$detail->noResi = $getLacak->result->details->waybill_number;
                  	$detail->tanggalPengiriman = $getLacak->result->details->waybill_date;
                  	$detail->waktuPengiriman = $getLacak->result->details->waybill_time;
                  	$detail->beratBarang = $getLacak->result->details->weight;
                  	$detail->pengirimanDari = $getLacak->result->details->origin;
                  	$detail->pengirimanKe = $getLacak->result->details->destination;
                  	$detail->namaPengiriman = $getLacak->result->details->shippper_name;
                  	$detail->alamatPengiriman1 = $getLacak->result->details->shipper_address1;
                  	$detail->alamatPengiriman2 = $getLacak->result->details->shipper_address2;
                  	$detail->alamatPengiriman3 = $getLacak->result->details->shipper_address3;
                  	$detail->kotaPengirim = $getLacak->result->details->shipper_city;
                  	$detail->namaPenerima = $getLacak->result->details->receiver_name;
                  	$detail->alamatPenerima1 = $getLacak->result->details->receiver_address1;
                  	$detail->alamatPenerima2 = $getLacak->result->details->receiver_address2;
                  	$detail->alamatPenerima3 = $getLacak->result->details->receiver_address3;
                  	$detail->kotaPenerima = $getLacak->result->details->receiver_city;
                  
                  	$dataLacak = new \stdClass;
                    $dataLacak->courierCode = $getLacak->result->summary->courier_code;
                    $dataLacak->courierName = $getLacak->result->summary->courier_name;
                  	$dataLacak->serviceCode = $getLacak->result->summary->courier_name;
                    $dataLacak->noResi = $getLacak->result->summary->waybill_number;
                    $dataLacak->statusDelivered = $getLacak->result->delivered;
                  	$dataLacak->deliveryStatus = $deliveryStatus;
                  	$dataLacak->detail = $detail;

                    $dataManifest = [];

                    foreach($getLacak->result->manifest as $val){
                      	$manifest = new \stdClass;
                      	$manifest->manifestCode = $val->manifest_code;
                      	$manifest->manifestDescription = $val->manifest_description;
                      	$manifest->manifestDate = $val->manifest_date;
                      	$manifest->manifestTime = $val->manifest_time;
                      	$manifest->manifestDateTime = $val->manifest_date . " " . $val->manifest_time . ":00";
                      	$manifest->cityName = $val->city_name;
                      
                      	$dataManifest[] = $manifest;
                    }
                  
                    $dataLacak->manifest = $dataManifest;
                  
                  	return $this->respond($dataLacak);
                  
                } else if($codePengiriman == "pos") {
                  	$deliveryStatus = new \stdClass;
                  	$deliveryStatus->status = $getLacak->result->delivery_status->status;
                  	$deliveryStatus->podReceiver = $getLacak->result->delivery_status->pod_receiver;
                  	$deliveryStatus->podDate = $getLacak->result->delivery_status->pod_date;
                  	$deliveryStatus->podTime = $getLacak->result->delivery_status->pod_time;
                  
                  	$detail = new \stdClass;
                  	$detail->noResi = $getLacak->result->details->waybill_number;
                  	$detail->tanggalPengiriman = $getLacak->result->details->waybill_date;
                  	$detail->waktuPengiriman = $getLacak->result->details->waybill_time;
                  	$detail->beratBarang = $getLacak->result->details->weight;
                  	$detail->pengirimanDari = $getLacak->result->details->origin;
                  	$detail->pengirimanKe = $getLacak->result->details->destination;
                  	$detail->namaPengiriman = $getLacak->result->details->shippper_name;
                  	$detail->alamatPengiriman1 = $getLacak->result->details->shipper_address1;
                  	$detail->alamatPengiriman2 = $getLacak->result->details->shipper_address2;
                  	$detail->alamatPengiriman3 = $getLacak->result->details->shipper_address3;
                  	$detail->kotaPengirim = $getLacak->result->details->shipper_city;
                  	$detail->namaPenerima = $getLacak->result->details->receiver_name;
                  	$detail->alamatPenerima1 = $getLacak->result->details->receiver_address1;
                  	$detail->alamatPenerima2 = $getLacak->result->details->receiver_address2;
                  	$detail->alamatPenerima3 = $getLacak->result->details->receiver_address3;
                  	$detail->kotaPenerima = $getLacak->result->details->receiver_city;
                  
                  	$dataLacak = new \stdClass;
                    $dataLacak->courierCode = $getLacak->result->summary->courier_code;
                    $dataLacak->courierName = $getLacak->result->summary->courier_name;
                  	$dataLacak->serviceCode = $getLacak->result->summary->service_code;
                    $dataLacak->noResi = $getLacak->result->summary->waybill_number;
                    $dataLacak->statusDelivered = $getLacak->result->delivered;
                  	$dataLacak->deliveryStatus = $deliveryStatus;
                  	$dataLacak->detail = $detail;

                    $dataManifest = [];

                    foreach($getLacak->result->manifest as $val){
                      	if($val->manifest_code == "SELESAI ANTAR") {
                          	$kode = "5";
                        } else if ($val->manifest_code == "DALAM PROSES" && strpos($val->manifest_description, 'Proses antar') !== false) {
                          	$kode = "2";
                        } else if ($val->manifest_code == "DALAM PROSES" && strpos($val->manifest_description, 'Diteruskan ke Kantor') !== false) {
                          	$kode = "3";
                        } else if($val->manifest_code == "PENERIMAAN DI LOKET") {
                          	$kode = "1";
                        } else {
                          	$kode = "4";
                        }
                      	$manifest = new \stdClass;
                      	$manifest->manifestCode = $kode;
                      	$manifest->manifestDescription = $val->manifest_description;
                      	$manifest->manifestDate = $val->manifest_date;
                      	$manifest->manifestTime = $val->manifest_time;
                      	$manifest->manifestDateTime = $val->manifest_date . " " . $val->manifest_time;
                      	$manifest->cityName = $val->city_name;
                      
                      	$dataManifest[] = $manifest;
                    }
                  
                    $dataLacak->manifest = $dataManifest;
                  
                  	return $this->respond($dataLacak);
                  
                } else if($codePengiriman == "sicepat") {
                  
                  	$deliveryStatus = new \stdClass;
                  	$deliveryStatus->status = $getLacak->result->delivery_status->status;
                  	$deliveryStatus->podReceiver = $getLacak->result->delivery_status->pod_receiver;
                  	$deliveryStatus->podDate = $getLacak->result->delivery_status->pod_date;
                  	$deliveryStatus->podTime = $getLacak->result->delivery_status->pod_time;
                  
                  	$detail = new \stdClass;
                  	$detail->noResi = $getLacak->result->details->waybill_number;
                  	$detail->tanggalPengiriman = $getLacak->result->details->waybill_date;
                  	$detail->waktuPengiriman = $getLacak->result->details->waybill_time;
                  	$detail->beratBarang = $getLacak->result->details->weight;
                  	$detail->pengirimanDari = $getLacak->result->details->origin;
                  	$detail->pengirimanKe = $getLacak->result->details->destination;
                  	$detail->namaPengiriman = $getLacak->result->details->shippper_name;
                  	$detail->alamatPengiriman1 = $getLacak->result->details->shipper_address1;
                  	$detail->alamatPengiriman2 = $getLacak->result->details->shipper_address2;
                  	$detail->alamatPengiriman3 = $getLacak->result->details->shipper_address3;
                  	$detail->kotaPengirim = $getLacak->result->details->shipper_city;
                  	$detail->namaPenerima = $getLacak->result->details->receiver_name;
                  	$detail->alamatPenerima1 = $getLacak->result->details->receiver_address1;
                  	$detail->alamatPenerima2 = $getLacak->result->details->receiver_address2;
                  	$detail->alamatPenerima3 = $getLacak->result->details->receiver_address3;
                  	$detail->kotaPenerima = $getLacak->result->details->receiver_city;
                  
                  	$dataLacak = new \stdClass;
                    $dataLacak->courierCode = $getLacak->result->summary->courier_code;
                    $dataLacak->courierName = $getLacak->result->summary->courier_name;
                  	$dataLacak->serviceCode = $getLacak->result->summary->service_code;
                    $dataLacak->noResi = $getLacak->result->summary->waybill_number;
                    $dataLacak->statusDelivered = $getLacak->result->delivered;
                  	$dataLacak->deliveryStatus = $deliveryStatus;
                  	$dataLacak->detail = $detail;

                    $dataManifest = [];

                    foreach($getLacak->result->manifest as $val){
                      	if (strpos($val->manifest_description, 'Terima permintaan pick up') !== false) {
                          	$kode = "0";
                        } else if (strpos($val->manifest_description, 'Paket telah di pick up') !== false) {
                          	$kode = "0";
                        } else if (strpos($val->manifest_description, 'Paket telah di input') !== false) {
                          	$kode = "1";
                        } else if (strpos($val->manifest_description, 'Paket keluar dari') !== false) {
                          	$kode = "3";
                        } else if (strpos($val->manifest_description, 'Paket telah di terima') !== false) {
                          	$kode = "2";
                        } else if (strpos($val->manifest_description, 'Paket dibawa') !== false) {
                          	$kode = "4";
                        } else if(strpos($val->manifest_description, 'Paket diterima oleh') !== false) {
                          	$kode = "5";
                        } else {
                          	$kode = "1";
                        }
                      	$manifest = new \stdClass;
                      	$manifest->manifestCode = $kode;
                      	$manifest->manifestDescription = $val->manifest_description;
                      	$manifest->manifestDate = $val->manifest_date;
                      	$manifest->manifestTime = $val->manifest_time;
                      	$manifest->manifestDateTime = $val->manifest_date . " " . $val->manifest_time . ":00";
                      	$manifest->cityName = $val->city_name;
                      
                      	$dataManifest[] = $manifest;
                    }
                  
                    $dataLacak->manifest = $dataManifest;
                  
                  	return $this->respond($dataLacak);
                  
                } else {
                  	return $this->respond($getLacak);
                  	return $this->respondNoContent("Tidak ada Content");
                }
              	
            }else{
              	return $this->respondNoContent("Tidak ada Content");
            }
          
            
        }
    }
  	
}