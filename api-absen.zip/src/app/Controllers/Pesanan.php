<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Notificationlib;
use App\Libraries\Pesananlib;

class Pesanan extends ResourceController
{
    protected $modelName = 'App\Models\TransaksiModel';
    protected $format = 'json';

    var $folderImage = 'profile';
  	private $_db;

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
      	$this->_db = \Config\Database::connect();
    }
  
  	public function baru(){
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
      
        $rules = [
            'userId' => 'required'
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          	$userId = htmlspecialchars($this->request->getVar('userId'), true);
          	$builderToko = $this->_db->table('_toko_tb_b');
          	$whereToko = [
              	'user_id' => $userId,
            ];
          
          	$dataToko = $builderToko->where($whereToko)->get()->getRowObject();
          
          	if(!$dataToko)
              	return $this->respondNoContent("Tidak ada Content");
          
          	
            $pesanans = [];
            $pesananLib = new Pesananlib();
            $dataPesanans = $pesananLib->getDataDetailEcomPesananBaru($dataToko->id);

            if(!(count($dataPesanans) > 0)) {
                return $this->respondNoContent("Tidak ada Content");
            }
          
          	//$pesanans['dataPesanan'] = $dataPesanans;
          
            $data['dataPesanan']= $dataPesanans;
            return $this->respond($data);
        }
    }
  
  	public function diproses(){
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
      
        $rules = [
            'userId' => 'required'
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          	$userId = htmlspecialchars($this->request->getVar('userId'), true);
          	$builderToko = $this->_db->table('_toko_tb_b');
          	$whereToko = [
              	'user_id' => $userId,
            ];
          
          	$dataToko = $builderToko->where($whereToko)->get()->getRowObject();
          
          	if(!$dataToko)
              	return $this->respondNoContent("Tidak ada Content");
          
          	
            $pesanans = [];
            $pesananLib = new Pesananlib();
            $dataPesanans = $pesananLib->getDataDetailEcomPesananDiproses($dataToko->id);

            if(!(count($dataPesanans) > 0)) {
                return $this->respondNoContent("Tidak ada Content");
            }
          
          	//$pesanans['dataPesanan'] = $dataPesanans;
          
            $data['dataPesanan']= $dataPesanans;
            return $this->respond($data);
        }
    }
  
  	public function dikirim(){
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
      
        $rules = [
            'userId' => 'required'
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          	$userId = htmlspecialchars($this->request->getVar('userId'), true);
          	$builderToko = $this->_db->table('_toko_tb_b');
          	$whereToko = [
              	'user_id' => $userId,
            ];
          
          	$dataToko = $builderToko->where($whereToko)->get()->getRowObject();
          
          	if(!$dataToko)
              	return $this->respondNoContent("Tidak ada Content");
          
          	
            $pesanans = [];
            $pesananLib = new Pesananlib();
            $dataPesanans = $pesananLib->getDataDetailEcomPesananDikirim($dataToko->id);

            if(!(count($dataPesanans) > 0)) {
                return $this->respondNoContent("Tidak ada Content");
            }
          
          	//$pesanans['dataPesanan'] = $dataPesanans;
          
            $data['dataPesanan']= $dataPesanans;
            return $this->respond($data);
        }
    }
  
  	public function detail(){
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
      
        $rules = [
            //'userId' => 'required',
          	'idPesanan' => 'required'
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          	//$userId = htmlspecialchars($this->request->getVar('userId'), true);
          	$idPesanan = htmlspecialchars($this->request->getVar('idPesanan'), true);
          	
            $pesananLib = new Pesananlib();
            $dataPesanan = $pesananLib->getDataDetailEcomPesananDetail($idPesanan);

            if(!$dataPesanan) {
                return $this->respondNoContent("Tidak ada Content");
            }
          
            return $this->respond($dataPesanan);
        }
    }
  
  	public function keproses(){
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
      
        $rules = [
            //'userId' => 'required',
          	'idPesanan' => 'required'
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          	//$userId = htmlspecialchars($this->request->getVar('userId'), true);
          	$idPesanan = htmlspecialchars($this->request->getVar('idPesanan'), true);
          	
            $pesananLib = new Pesananlib();
            $dataPesanan = $pesananLib->changeEcomPesananToProses($idPesanan);

            if(!$dataPesanan) {
                return $this->respondNoContent("Tidak ada Content");
            }
          
            return $this->respond($dataPesanan);
        }
    }
  
  	public function ketolak(){
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
      
        $rules = [
            //'userId' => 'required',
          	'idPesanan' => 'required'
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          	//$userId = htmlspecialchars($this->request->getVar('userId'), true);
          	$idPesanan = htmlspecialchars($this->request->getVar('idPesanan'), true);
          	
            $pesananLib = new Pesananlib();
            $dataPesanan = $pesananLib->changeEcomPesananToTolak($idPesanan);

            if(!$dataPesanan) {
                return $this->respondNoContent("Tidak ada Content");
            }
          
            return $this->respond($dataPesanan);
        }
    }
  
  	public function kekirim(){
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
      
        $rules = [
            //'userId' => 'required',
          	'idPesanan' => 'required',
          	'noResi' => 'required',
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          	$noResi = htmlspecialchars($this->request->getVar('noResi'), true);
          	$idPesanan = htmlspecialchars($this->request->getVar('idPesanan'), true);
          	
            $pesananLib = new Pesananlib();
            $dataPesanan = $pesananLib->changeEcomPesananToDikirim($idPesanan, $noResi);

            if(!$dataPesanan) {
                return $this->respondNoContent("Tidak ada Content");
            }
          
            return $this->respond($dataPesanan);
        }
    }
}