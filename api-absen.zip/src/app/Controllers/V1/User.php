<?php

namespace App\Controllers\V1;

use App\Controllers\BaseController;

use \App\Libraries\Oauth;
use \OAuth2\Request;
use CodeIgniter\API\ResponseTrait;
use App\Models\UserModel;
use App\Models\UserEmailModel;
use App\Models\UserNohpModel;
use App\Libraries\Uuid;

class User extends BaseController
{
    use ResponseTrait;
    // protected $modelName = 'App\Models\UserModel';

    function __construct()
    {
        helper(['form', 'text']);
    }

    public function login()
    {
        $oauth = new Oauth();
        $request = new Request();
        $respond = $oauth->server->handleTokenRequest($request->createFromGlobals());
        $code = $respond->getStatusCode();
        $body = $respond->getResponseBody();

        if ($code == 200) {
            //   $playerId = htmlspecialchars($this->request->getVar('player_id'), true);
            $data = json_decode($body);

            //   $db      = \Config\Database::connect();
            //   $builderGetUserId = $db->table('oauth_refresh_tokens');
            //   $dataUser = $builderGetUserId->where('refresh_token', $data->refresh_token)->get()->getRowObject();
            //   if($dataUser){
            //     $builderUpdatePlayer = $db->table('_profil_users_tb');
            //     $dataUpdatePlayer = [
            //     //   'player_id_onesignal' => $playerId,
            //       'updated_at' => date('Y-m-d H:i:s')
            //     ];
            //     $update = $builderUpdatePlayer->where('id', $dataUser->user_id)->update($dataUpdatePlayer);
            //   }

        }
        return $this->respond(json_decode($body), $code);
    }

    public function regis()
    {
        $data = [];

        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

        $rules = [
            'email' => 'trim',
            'noTelepon' => 'trim',
            'nik' => 'required',
            'password' => 'required|min_length[6]',
        ];

        if (!$this->validate($rules)) {
            // return $this->failNotFound("rules eror");
            return $this->fail($this->validator->getErrors());
        } else {
            if ($this->request->getVar('email') || $this->request->getVar('noTelepon')) {
                $model = new UserModel();
                $uuid = new Uuid();

                $data = [
                    'id' => $uuid->v4(),
                    'email' => htmlspecialchars($this->request->getVar('email'), true),
                    'nik' => htmlspecialchars($this->request->getVar('nik'), true),
                    'no_hp' => htmlspecialchars($this->request->getVar('noTelepon'), true),
                    'password' => htmlspecialchars($this->request->getVar('password'), true),
                    'created_at' => date('Y-m-d H:i:s'),
                ];

                try {
                    // $db      =
                    //     \Config\Database::connect();
                    // $builder = $db->table('_users_tb');
                    // $builder->set('id', 'UUID()', FALSE);
                    $user_id = $model->insert($data);
                    // $data['id'] = $user_id;
                    unset($data['password']);
                } catch (\Throwable $th) {
                    return $this->fail($th);
                    // return $this->failNotFound("eror insert");
                }
                return $this->respondCreated($data);
            } else {
                return $this->fail("Username is required");
            }
        }
    }

    public function cekuser()
    {
        $data = [];

        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

        $email = htmlspecialchars($this->request->getVar('email'), true);
        $nohp = htmlspecialchars($this->request->getVar('noTelepon'), true);
        $nik = htmlspecialchars($this->request->getVar('nik'), true);

        $token = random_string('numeric', 5);

        $startTime = date('Y-m-d H:i:s');
        // $expired = date('Y-m-d H:i:s');
        $expired = date('Y-m-d H:i:s', strtotime('+1 hour', strtotime($startTime)));

        if ($email != null) {
            $rules = [
                'email' => 'required|trim|valid_email|is_unique[_users_tb.email]',
                'nik' => 'required|trim|is_unique[_users_tb.nik]',
            ];

            if (!$this->validate($rules)) {
                return $this->fail($this->validator->getErrors());
            } else {
                $model = new UserEmailModel();
                $data = [
                    'email' => $email,
                    'token' => $token,
                    'expired' => $expired,
                ];

                try {
                    $user_id = $model->insert($data);
                    $data['id'] = $user_id;
                    if ($user_id) {
                        $email = \Config\Services::email();

                        //$email->setFrom('admin-silat@lampungtengahkab.go.id', 'Yestore Commerce');
                        $email->setFrom('admin@moroarto.com', 'PT. MORO ARTO GLOBALINDO');
                        $email->setTo($data['email']);

                        $email->setSubject('Aktivasi Akun MoroArto');
                        $email->setMessage('<b> Yestore</b>\r\n \r\n \r\n Halo <b>Guys!<b> \r\n \r\n Masukkan kode berikut untuk melakukan aktivasi akun Moroarto kamu. \r\n <center><b>' . $data['token'] . '</b></center> \r\n \r\n \r\n <b>Catatan:</b> \r\n Kode di atas hanya berlaku 60 menit. Harap untuk tidak meneyebarkan kode ini. \r\n \r\n email ini dibuat secara otomatis, mohon tidak membalas. Jika butuh bantuan, silahkan <a href="https://help.moroarto.com/">Hubungi Kami</a>.');

                        if ($email->send()) {
                            $data['message'] = "Kode OTP telah di kirim. Silahkan cek inbox atau spam.";
                        } else {
                            return $this->fail($email->printDebugger());
                        }
                    } else {
                        return $this->fail('Create OTP');
                    }
                } catch (\Throwable $th) {
                    return $this->fail($th);
                }
                return $this->respondCreated($data);
            }
        } else if ($nohp != null) {
            $rules = [
                'noTelepon' => 'required|trim|is_unique[_users_tb.no_hp]',
                'nik' => 'required|trim|is_unique[_users_tb.nik]',
            ];

            if (!$this->validate($rules)) {
                return $this->fail($this->validator->getErrors());
            } else {
                // $model = new UserEmailModel();
                $data = [
                    'email' => $nohp,
                    'token' => $token,
                    'expired' => $expired,
                ];

                // try {
                //     $user_id = $model->insert($data);
                //     $data['id'] = $user_id;
                //     if ($user_id) {
                //         $email = \Config\Services::email();

                //         $email->setFrom('admin-silat@lampungtengahkab.go.id', 'Yestore Commerce');
                //         $email->setTo($data['email']);

                //         $email->setSubject('Aktivasi Akun Yestore Commerce');
                //         $email->setMessage('<b> Yestore</b>\r\n \r\n \r\n Halo <b>Guys!<b> \r\n \r\n Masukkan kode berikut untuk melakukan aktivasi akun Yestore kamu. \r\n <center><b>' . $data['token'] . '</b></center> \r\n \r\n \r\n <b>Catatan:</b> \r\n Kode di atas hanya berlaku 60 menit. Harap untuk tidak meneyebarkan kode ini. \r\n \r\n email ini dibuat secara otomatis, mohon tidak membalas. Jika butuh bantuan, silahkan <a href="https://help.yestore.id/">Hubungi Kami</a>.');

                //         if ($email->send()) {
                $data['message'] = "Kode OTP telah di kirim. Silahkan cek WhatsApp anda.";
                //         } else {
                //             return $this->fail($email->printDebugger());
                //         }
                //     } else {
                //         return $this->fail('Create OTP');
                //     }
                // } catch (\Throwable $th) {
                //     return $this->fail($th);
                // }
                return $this->respondCreated($data);
            }
        } else {
            return $this->fail("Not Alowed.");
        }
    }

    public function verifitoken()
    {
        $data = [];

        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

        $rules = [
            'email' => 'required|valid_email|is_unique[_users_tb.email]',
            'password' => 'required|min_length[6]',
        ];

        if (!$this->validate($rules)) {
            // return $this->failNotFound("rules eror");
            return $this->fail($this->validator->getErrors());
        } else {
        }
    }
    
    public function resetpassword()
    {

        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

        $rules = [
            'username' => 'required|valid_email',
        ];

        if (!$this->validate($rules)) {
            // return $this->failNotFound("rules eror");
            return $this->fail($this->validator->getErrors());
        } else {
            $db      = \Config\Database::connect();
            $username = htmlspecialchars($this->request->getVar('username'), true);
            
            $builder = $db->table('_users_tb');
            $user = $builder->where('email', $username)->get()->getRowObject();
            if($user){
                return $this->_sendEmailReset($user->email);
            }else{
                return $this->fail('Username tidak ditemukan');
            }
        }
    }
    
    private function _sendEmailReset($email)
    {
        $data=[
            'email'=> $email,
            'message' => "Silahkan cek e-mail anda."
        ];
        return $this->respond($data);
    }
}
