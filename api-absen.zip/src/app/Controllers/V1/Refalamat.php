<?php

namespace App\Controllers\V1;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Capil\Refensialamatlib;

class Refalamat extends ResourceController
{
	//protected $modelName = 'App\Models\SliderhomeModel';
	protected $format = 'json';

	var $folderImage = 'slider';
	private $_db;

	function __construct()
	{
		helper(['text', 'form', 'array', 'fotourl', 'filesystem']);
		$this->_db      = \Config\Database::connect();
	}

	function provinsi() {
	    $id = ($this->request->getVar('id'))?htmlspecialchars($this->request->getVar('id'), true):"";
	    $provinsiLib = new Refensialamatlib();
	    $provinsi = $provinsiLib->provinsi($id);
	    if(count($provinsi) > 0) {
	        return $this->respond($provinsi);
	    } else {
	        return $this->respondNoContent("Tidak ada Content");
	    }
	}
	
	function kabupaten() {
	    $id = ($this->request->getVar('id'))?htmlspecialchars($this->request->getVar('id'), true):"";
	    $provinsiLib = new Refensialamatlib();
	    $kabupaten = $provinsiLib->kabupaten($id);
	    if(count($kabupaten) > 0) {
	        return $this->respond($kabupaten);
	    } else {
	        return $this->respondNoContent("Tidak ada Content");
	    }
	}
	
	function kecamatan() {
	    $id = ($this->request->getVar('id'))?htmlspecialchars($this->request->getVar('id'), true):"";
	    $provinsiLib = new Refensialamatlib();
	    $kecamatan = $provinsiLib->kecamatan($id);
	    if(count($kecamatan) > 0) {
	        return $this->respond($kecamatan);
	    } else {
	        return $this->respondNoContent("Tidak ada Content");
	    }
	}
	
	function kelurahan() {
	    $id = ($this->request->getVar('id'))?htmlspecialchars($this->request->getVar('id'), true):"";
	    $provinsiLib = new Refensialamatlib();
	    $kelurahan = $provinsiLib->kelurahan($id);
	    if(count($kelurahan) > 0) {
	        return $this->respond($kelurahan);
	    } else {
	        return $this->respondNoContent("Tidak ada Content");
	    }
	}
}
