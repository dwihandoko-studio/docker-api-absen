<?php

namespace App\Controllers\V1;

use CodeIgniter\RESTful\ResourceController;
// use App\Libraries\Uuid;
use App\Libraries\Notificationlib;
use App\Libraries\Capil\Userlib;

class Contact extends ResourceController
{
    //protected $modelName = 'App\Models\OrdermerchanppobModel';
    protected $format = 'json';
  	private $_db;

    var $folderImage = 'profile';

    function __construct()
    {
        helper(['form', 'text', 'array', 'fotourl', 'filesystem']);
      	$this->_db      = \Config\Database::connect();
    }

  	public function index() {
  	 //   return $this->fail('User cant Null');
      	$per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 20;
        $start = (int) htmlspecialchars($this->request->getGet('start'), true) ? (int) htmlspecialchars($this->request->getGet('start'), true) : 0;
      	
      
      	if(!$this->request->getGet('userId'))
          	return $this->fail('User cant Null'); 

      	$userId = htmlspecialchars($this->request->getGet('userId'), true);
      	
      	$userLib = new Userlib();
      	$user = $userLib->getUser($userId);
      	
      	if($user){
      	    if((int)$user->role_user != 0) {
      	        //echo json_encode($user);die;
      	        $builder = $this->_db->table('_contact_tb a');
      	
              	$where = "a.deleted_at IS NULL AND a.user_id != '$userId' AND (a.user_owner = 'system' OR (a.user_owner = '$userId' AND a.is_active = 1))";
              	
              	$builder->select('a.id as id, a.user_id as userIdFriend, a.is_online as isOnline, a.updated_at as lastActive, b.fullname, b.nik, b.no_hp as noHp, b.profile_picture as profilePicture');
              	$builder->join('_profil_users_tb b', 'b.id = a.user_id');
                $data['result'] = $builder->where($where)->orderBy('a.updated_at', 'desc')->orderBy('b.fullname', 'asc')->get($per_page, $start)->getResult();
                $data['total_result'] = $builder->where($where)->countAllResults();
              
                if ($data['total_result'] > 0) {
                    $data['total_page'] = ceil($data['total_result'] / $per_page);
                    return $this->respond($data);
                } else {
                    return $this->respondNoContent('Tidak ada content.');
                }
      	    }
      	}
      	$builder = $this->_db->table('_contact_tb a');
      	
      	$where = "a.deleted_at IS NULL AND a.user_id != '$userId' AND (a.user_owner = 'system' OR (a.user_owner = '$userId' AND a.is_active = 1))";
      	
      	$builder->select('a.id as id, a.user_id as userIdFriend, a.is_online as isOnline, a.updated_at as lastActive, b.fullname, b.nik, b.no_hp as noHp, b.profile_picture as profilePicture');
      	$builder->join('_profil_users_tb b', 'b.id = a.user_id');
        $data['result'] = $builder->where($where)->groupBy('a.user_id')->orderBy('a.updated_at', 'desc')->orderBy('b.fullname', 'asc')->get($per_page, $start)->getResult();
        $data['total_result'] = $builder->where($where)->countAllResults();
      
        if ($data['total_result'] > 0) {
            $data['total_page'] = ceil($data['total_result'] / $per_page);
            return $this->respond($data);
        } else {
            return $this->respondNoContent('Tidak ada content.');
        }
      
    }
  
  	public function updateonline() {
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            // 'userId' => 'required|min_length[3]|max_length[50]',
            'userId' => 'required'
        ];

        if (!$this->validate($rules)) {
            return $this->respondNoContent();
          //return $this->fail("Required");
        } else {
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            $builder = $this->_db->table('_contact_tb');
            $data = [
                'is_online' => 1,
                'updated_at' => date('Y-m-d H:i:s'),
            ];
            
            $builder->where('user_id', $userId)->update($data);
            return $this->respond($data);
        }
    }
    
    public function listusernotregister() {
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
            
            $per_page = (int) htmlspecialchars($this->request->getVar('limit'), true) ? (int) htmlspecialchars($this->request->getVar('limit'), true) : 20;
            $start = (int) htmlspecialchars($this->request->getVar('start'), true) ? (int) htmlspecialchars($this->request->getVar('start'), true) : 0;
        
            $builder = $this->_db->table('_contact_user_no_register_tb a');
            
            $where = "deleted_at IS NULL AND is_active = 1";
      	
          	$builder->select('a.nik as userIdFriend, a.is_online as isOnline, a.updated_at as lastActive, a.nama as fullname');
            $data['result'] = $builder->where($where)->groupBy('a.nik')->orderBy('a.updated_at', 'desc')->orderBy('a.nama', 'asc')->get($per_page, $start)->getResult();
            $data['total_result'] = $builder->where($where)->countAllResults();
          
            if ($data['total_result'] > 0) {
                $data['total_page'] = ceil($data['total_result'] / $per_page);
                return $this->respond($data);
            } else {
                return $this->respondNoContent('Tidak ada content.');
            }
        
    }
  
  	public function addfromnotregister() {
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            'nik' => 'required',
            'nama' => 'required'
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
            $nik = htmlspecialchars($this->request->getVar('nik'), true);
            $nama = htmlspecialchars($this->request->getVar('nama'), true);
            
            // $uuid = new Uuid();
            $data = [
                // 'id' => $uuid->v4(),
                'nik' => $nik,
                'nama' => $nama,
                'is_active' => 1,
                'is_online' => 1,
                'user_not_register' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ];
            
            $builder = $this->_db->table('_contact_user_no_register_tb');
            $builder->ignore(true)->insert($data);
            
            return $this->respond($data);
        }
    }
  
    public function listusermessageall() {
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
            
            $per_page = (int) htmlspecialchars($this->request->getVar('limit'), true) ? (int) htmlspecialchars($this->request->getVar('limit'), true) : 20;
            $start = (int) htmlspecialchars($this->request->getVar('start'), true) ? (int) htmlspecialchars($this->request->getVar('start'), true) : 0;
        
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            // var_dump($userId);die;
          	$builder = $this->_db->table('_message_tb a');
          	
          	$where = "a.send_to = '$userId' OR a.send_from = '$userId'";
          	
        //   	$builder->select(
          	$select = 'a.id as id, a.description as isiPesan, a.send_from as senderId, a.send_to as receivedId, a.status_read as hasRead, a.status_send as hasSend, a.updated_at as readedAt, a.created_at as createdAt, if(b.fullname IS NULL, d.nama, b.fullname) as fullnameSender, b.profile_picture as profilePictureSender, c.fullname as fullnameReceived, c.profile_picture as profilePictureReceived';
        //   	$builder->join('_profil_users_tb b', 'b.id = a.send_from');
        //   	$builder->join('_profil_users_tb c', 'c.id = a.send_to');
            $data['result'] = $builder->select($select)->join('_profil_users_tb b', 'a.send_from = b.id', 'left')->join('_profil_users_tb c', 'a.send_to = c.id', 'left')->join('_contact_user_no_register_tb d', 'a.send_from = d.nik', 'left')->where($where)->groupBy('a.send_from')->groupBy('a.send_to')->orderBy('a.created_at', 'desc')->get($per_page, $start)->getResult();
            $data['total_result'] = $builder->where($where)->countAllResults();
            
            // $query = $this->_db->query("SELECT a.id as id, a.description as isiPesan, a.send_from as senderId, a.send_to as receivedId, a.status_read as hasRead, a.status_send as hasSend, a.updated_at as readedAt, a.created_at as createdAt, b.fullname as fullnameSender, b.profile_picture as profilePictureSender, c.fullname as fullnameReceived, c.profile_picture as profilePictureReceived FROM _message_tb a INNER JOIN _profil_users_tb b ON b.id = a.send_from INNER JOIN _profil_users_tb c ON c.id = a.send_to WHERE a.send_to = '$userId' OR a.send_from = '$userId'");
            // $data['result'] = $query->getResultArray();
            // $data['total_result'] = count($data['result']);
            // var_dump($data);die;
            if ($data['total_result'] > 0) {
                $data['total_page'] = ceil($data['total_result'] / $per_page);
                return $this->respond($data);
            } else {
                return $this->respondNoContent('Tidak ada content.');
            }
        
    }
}
