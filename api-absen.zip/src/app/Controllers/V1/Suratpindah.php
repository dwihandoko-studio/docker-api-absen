<?php

namespace App\Controllers\V1;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Capil\Permohonanlib;
use App\Libraries\Capil\Userlib;
use App\Libraries\Onesignallib;
use App\Libraries\Notificationlib;

class Suratpindah extends ResourceController
{
    protected $modelName = 'App\Models\TokoModel';
    protected $format = 'json';

    var $folderImage = 'permohonan/suratpindah';

    private $_db;

    function __construct()
    {
        helper(['text','file', 'form', 'array', 'fotourl', 'filesystem']);
        $this->_db      = \Config\Database::connect();
    }

    public function index()
    {
        
        $per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
        $pag = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

        if ($pag == 1) {
            $start = 0;
        } else {
            $start = (($pag - 1) * $per_page);
        }

		if (!$this->request->getGet('toko')) {
          $where = [
            '_product_tb_b.product_status' => 1
          ];
        }else{
          $tokoId = htmlspecialchars($this->request->getGet('toko'), true);
          $where = [
            '_product_tb_b.toko_id' => $tokoId,
          ];
        }
        $select = "_product_tb_b.id as productId, _product_tb_b.product_barcode as productBarcode, _product_tb_b.product_title as productTitle, _product_tb_b.product_description as productDescription, _product_tb_b.product_price_buy as productPriceBuy, _product_tb_b.product_price_sell as productPriceSell, _product_tb_b.product_weight as productWeight, _product_tb_b.product_qty as productQty, _product_tb_b.product_status as productStatus, _product_tb_b.product_unlimited as productUnlimited, _product_tb_b.product_thumb as productThumb, _product_tb_b.product_image as productImage, _product_tb_b.created_at as createdAt, _product_tb_b.updated_at as updatedAt, _category_tb_b.category_name as categoryName, _sub_category_tb_b.sub_category_name as subCategoryName";
      	
        $products = $this->_db->table('_product_tb_b')->select($select)->join('_category_tb_b', '_product_tb_b.category_id = _category_tb_b.id')->join('_sub_category_tb_b', '_product_tb_b.sub_category_id = _sub_category_tb_b.id')->where($where)->orderBy('_product_tb_b.created_at', 'desc')->get()->getResult();

        if(count($products) > 0) {
          $data['result'] = $products;
          $data['total_result'] = count($products);
          return $this->respond($data);
        }else{
          return $this->respondNoContent('Tidak ada content.');
        }
    }
    
    public function buat() {
        $rules = [
			'userId' => 'required|trim',
			'nik' => 'required|trim',
			'kk' => 'required|trim',
			'nama' => 'required|trim',
			'alamatSaatIni' => 'required|trim',
			'alamatTujuan' => 'required|trim',
			'provinsiTujuan' => 'required|trim',
			'kabupatenTujuan' => 'required|trim',
			'kecamatanTujuan' => 'required|trim',
			'kelurahanTujuan' => 'required|trim',
			'jumlahAnggota' => 'required|trim',
			'alasanPindah' => 'required|trim',
			'keterangan' => 'required|trim',
// 			'kecamatan' => 'required|trim',
			'lampiranKTP' => 'uploaded[lampiranKTP]|max_size[lampiranKTP, 1024]|is_image[lampiranKTP]',
			'lampiranKK' => 'uploaded[lampiranKK]|max_size[lampiranKK, 1024]|is_image[lampiranKK]',
		];
		
		$filenamelampiranFormulirPindah = dot_array_search('lampiranFormulirPindah.name', $_FILES);
		if($filenamelampiranFormulirPindah != '') {
		    $lampiranFormulirPindahVal = ['lampiranFormulirPindah' => 'uploaded[lampiranFormulirPindah]|max_size[lampiranFormulirPindah, 1024]|is_image[lampiranFormulirPindah]'];
		    $rules = array_merge($rules, $lampiranFormulirPindahVal);
		}
		
		$filenamelampiranDokumentPendukungLain = dot_array_search('lampiranDokumentPendukungLain.name', $_FILES);
		if($filenamelampiranDokumentPendukungLain != '') {
		    $lampiranDokumentPendukungLainVal = ['lampiranDokumentPendukungLain' => 'uploaded[lampiranDokumentPendukungLain]|max_size[lampiranDokumentPendukungLain, 1024]|is_image[lampiranDokumentPendukungLain]'];
		    $rules = array_merge($rules, $lampiranDokumentPendukungLainVal);
		}
		
		if (!$this->validate($rules)) {
			return $this->fail($this->validator->getErrors());
// 			return $this->failValidationError($this->validator->getError());
		} else {
		    $userId = htmlspecialchars($this->request->getVar('userId'), true);
		    $nik = htmlspecialchars($this->request->getVar('nik'), true);
		    $kk = htmlspecialchars($this->request->getVar('kk'), true);
		    $nama = htmlspecialchars($this->request->getVar('nama'), true);
		    $alamatSaatIni = htmlspecialchars($this->request->getVar('alamatSaatIni'), true);
		    $alamatTujuan = htmlspecialchars($this->request->getVar('alamatTujuan'), true);
		    $provinsiTujuan = htmlspecialchars($this->request->getVar('provinsiTujuan'), true);
		    $kabupatenTujuan = htmlspecialchars($this->request->getVar('kabupatenTujuan'), true);
		    $kecamatanTujuan = htmlspecialchars($this->request->getVar('kecamatanTujuan'), true);
		    $kelurahanTujuan = htmlspecialchars($this->request->getVar('kelurahanTujuan'), true);
		    $alasanPindah = htmlspecialchars($this->request->getVar('alasanPindah'), true);
		    $jumlahAnggota = htmlspecialchars($this->request->getVar('jumlahAnggota'), true);
		    $keterangan = htmlspecialchars($this->request->getVar('keterangan'), true);
		  //  $kecamatan = htmlspecialchars($this->request->getVar('kecamatan'), true);
		    
		    if (!file_exists('./assets/uploads/' . $this->folderImage)) {
                mkdir('./assets/uploads/' . $this->folderImage, 0755);
                $dir = './assets/uploads/' . $this->folderImage;
            } else {
                $dir = './assets/uploads/' . $this->folderImage;
            }
            
            $userLib = new Userlib();
            $user = $userLib->getUser($userId);
            
            if(!$user){
                return $this->fail("User tidak ditemukan");
            }
            
            $uuid = new Uuid();

            $dataPermohonan = [
                'id' => $uuid->v4(),
                'user_id' => $userId,
                'nik_pemohon' => $nik,
                'kk_pemohon' => $kk,
                'nama_pemohon' => $nama,
                'alamat_saat_ini' => $alamatSaatIni,
                'alamat_tujuan' => $alamatTujuan,
                'provinsi_tujuan' => $provinsiTujuan,
                'kabupaten_tujuan' => $kabupatenTujuan,
                'kecamatan_tujuan' => $kecamatanTujuan,
                'kelurahan_tujuan' => $kelurahanTujuan,
                'alasan_pindah' => $alasanPindah,
                'jumlah_anggota' => $jumlahAnggota,
                'keterangan' => $keterangan,
                'kecamatan' => $user->kecamatan,
                'created_at' => date('Y-m-d H:i:s'),
            ];
		    
		    $lampiranKTP = $this->request->getFile('lampiranKTP');
			$filesNamelampiranKTP = $lampiranKTP->getName();
			$newNamelampiranKTP = _create_name_foto($filesNamelampiranKTP);
			
			if ($lampiranKTP->isValid() && !$lampiranKTP->hasMoved()) {
                $lampiranKTP->move($dir, $newNamelampiranKTP);
                $dataPermohonan['lampiran_ktp'] = $newNamelampiranKTP;
            } else {
                return $this->fail("Upload KTP");
                // return $this->fail($lampiranKTP->getErrorString());
            }
            
            $lampiranKK = $this->request->getFile('lampiranKK');
			$filesNamelampiranKK = $lampiranKK->getName();
			$newNamelampiranKK = _create_name_foto($filesNamelampiranKK);
			
			if ($lampiranKK->isValid() && !$lampiranKK->hasMoved()) {
                $lampiranKK->move($dir, $newNamelampiranKK);
                $dataPermohonan['lampiran_kk'] = $newNamelampiranKK;
            } else {
                unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                return $this->fail($lampiranKK->getErrorString());
            }
            
            if($filenamelampiranFormulirPindah != '') {
                $lampiranFormulirPindah = $this->request->getFile('lampiranFormulirPindah');
    			$filesNamelampiranFormulirPindah = $lampiranFormulirPindah->getName();
    			$newNamelampiranFormulirPindah = _create_name_foto($filesNamelampiranFormulirPindah);
    			
    			if ($lampiranFormulirPindah->isValid() && !$lampiranFormulirPindah->hasMoved()) {
                    $lampiranFormulirPindah->move($dir, $newNamelampiranFormulirPindah);
                    $dataPermohonan['lampiran_formulir_pindah'] = $newNamelampiranFormulirPindah;
                } else {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    return $this->fail($lampiranFormulirPindah->getErrorString());
                }
            }
            
            if($filenamelampiranDokumentPendukungLain != '') {
                $lampiranDokumentPendukungLain = $this->request->getFile('lampiranDokumentPendukungLain');
    			$filesNamelampiranDokumentPendukungLain = $lampiranDokumentPendukungLain->getName();
    			$newNamelampiranDokumentPendukungLain = _create_name_foto($filesNamelampiranDokumentPendukungLain);
    			
    			if ($lampiranDokumentPendukungLain->isValid() && !$lampiranDokumentPendukungLain->hasMoved()) {
                    $lampiranDokumentPendukungLain->move($dir, $newNamelampiranDokumentPendukungLain);
                    $dataPermohonan['lampiran_dokument_pendukung_lain'] = $newNamelampiranDokumentPendukungLain;
                } else {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    if($filenamelampiranFormulirPindah != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_formulir_pindah']);
                    }
                    return $this->fail($lampiranDokumentPendukungLain->getErrorString());
                }
            }
            
            $permohonanLib = new Permohonanlib();
            $inputPermohonanBaru = $permohonanLib->createPermohonan("SRTPINDAH", $userId);
            
            if($inputPermohonanBaru) {
                try{
                    $dataPermohonan['kode_permohonan'] = $inputPermohonanBaru;
                    $builder = $this->_db->table('_permohonan_surat_pindah_tb');
                    $insertData = $builder->insert($dataPermohonan);
                } catch (\Throwable $th) {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranBukuNikah);
                    if($filenamelampiranFormulirKK != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_formulir_kk']);
                    }
                    if($filenamelampiranDokumentPendukungLain != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_dokument_pendukung_lain']);
                    }
                    return $this->fail("menyimpan data");
                    // return $this->fail($th);
                }
                
                
                $dataNotifSystem = [
                  'kode_permohonan' => $dataPermohonan['kode_permohonan'],
                  'title' => "Permohonan Surat Pindah",
                  'description' => "Permohonan Surat Pindah",
                  'send_from' => $dataPermohonan['user_id'],
                  'send_to' => "KEPENDUDUKAN",
                  'action_page' => "detail_surat_pindah",
                  'action_api' => "suratpindah"
                ];
                $saveNotifSystem = new Notificationlib();
                $saveNotifSystem->send($dataNotifSystem);

                $dataNotif = [
                  'send_to' => "KEPENDUDUKAN",
                  'title' => "Permohonan Surat Pindah",
                  'content' => "Permohonan Surat Pindah",
                  'app_url' => "suratpindah;".$dataPermohonan['kode_permohonan'].";detail_surat_pindah"
                ];

                $onesignal = new Onesignallib();
                $send = $onesignal->pushNotifToAdmin($dataNotif);
                
                
                return $this->respond($dataPermohonan);
            } else {
                unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                unlink(FCPATH . $dir . '/' . $newNamelampiranBukuNikah);
                if($filenamelampiranFormulirKK != ''){
                    unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_formulir_kk']);
                }
                if($filenamelampiranDokumentPendukungLain != ''){
                    unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_dokument_pendukung_lain']);
                }
                return $this->fail("menyimpan data");
            }
            
            
		}
    }
}
