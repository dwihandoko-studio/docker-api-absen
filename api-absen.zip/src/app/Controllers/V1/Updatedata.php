<?php

namespace App\Controllers\V1;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Capil\Permohonanlib;
use App\Libraries\Capil\Userlib;
use App\Libraries\Onesignallib;
use App\Libraries\Notificationlib;

class Updatedata extends ResourceController
{
    protected $modelName = 'App\Models\TokoModel';
    protected $format = 'json';

    var $folderImage = 'permohonan/updatedata';

    private $_db;

    function __construct()
    {
        helper(['text','file', 'form', 'array', 'fotourl', 'filesystem']);
        $this->_db      = \Config\Database::connect();
    }

    public function index()
    {
        
        $per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
        $pag = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

        if ($pag == 1) {
            $start = 0;
        } else {
            $start = (($pag - 1) * $per_page);
        }

		if (!$this->request->getGet('toko')) {
          $where = [
            '_product_tb_b.product_status' => 1
          ];
        }else{
          $tokoId = htmlspecialchars($this->request->getGet('toko'), true);
          $where = [
            '_product_tb_b.toko_id' => $tokoId,
          ];
        }
        $select = "_product_tb_b.id as productId, _product_tb_b.product_barcode as productBarcode, _product_tb_b.product_title as productTitle, _product_tb_b.product_description as productDescription, _product_tb_b.product_price_buy as productPriceBuy, _product_tb_b.product_price_sell as productPriceSell, _product_tb_b.product_weight as productWeight, _product_tb_b.product_qty as productQty, _product_tb_b.product_status as productStatus, _product_tb_b.product_unlimited as productUnlimited, _product_tb_b.product_thumb as productThumb, _product_tb_b.product_image as productImage, _product_tb_b.created_at as createdAt, _product_tb_b.updated_at as updatedAt, _category_tb_b.category_name as categoryName, _sub_category_tb_b.sub_category_name as subCategoryName";
      	
        $products = $this->_db->table('_product_tb_b')->select($select)->join('_category_tb_b', '_product_tb_b.category_id = _category_tb_b.id')->join('_sub_category_tb_b', '_product_tb_b.sub_category_id = _sub_category_tb_b.id')->where($where)->orderBy('_product_tb_b.created_at', 'desc')->get()->getResult();

        if(count($products) > 0) {
          $data['result'] = $products;
          $data['total_result'] = count($products);
          return $this->respond($data);
        }else{
          return $this->respondNoContent('Tidak ada content.');
        }
    }
    
    public function buat() {
        $rules = [
			'userId' => 'required|trim',
			'kk' => 'required|trim',
			'nikSuami' => 'required|trim',
			'namaSuami' => 'required|trim',
			'nikIstri' => 'required|trim',
			'namaIstri' => 'required|trim',
// 			'kecamatan' => 'required|trim',
			'jumlahAnak' => 'required|trim',
			'keterangan' => 'required|trim',
			'lampiranKK' => 'uploaded[lampiranKK]|max_size[lampiranKK, 1024]|is_image[lampiranKK]',
		];
		
		$filenamelampiranKTP = dot_array_search('lampiranKTP.name', $_FILES);
		if($filenamelampiranKTP != '') {
		    $lampiranKTPVal = ['lampiranKTP' => 'uploaded[lampiranKTP]|max_size[lampiranKTP, 1024]|is_image[lampiranKTP]'];
		    $rules = array_merge($rules, $lampiranKTPVal);
		}
		
		$filenamelampiranDokumentPendukungLain = dot_array_search('lampiranDokumentPendukungLain.name', $_FILES);
		if($filenamelampiranDokumentPendukungLain != '') {
		    $lampiranDokumentPendukungLainVal = ['lampiranDokumentPendukungLain' => 'uploaded[lampiranDokumentPendukungLain]|max_size[lampiranDokumentPendukungLain, 1024]|is_image[lampiranDokumentPendukungLain]'];
		    $rules = array_merge($rules, $lampiranDokumentPendukungLainVal);
		}
		
		if (!$this->validate($rules)) {
			return $this->fail($this->validator->getErrors());
// 			return $this->failValidationError($this->validator->getError());
		} else {
		    $userId = htmlspecialchars($this->request->getVar('userId'), true);
		    $kk = htmlspecialchars($this->request->getVar('kk'), true);
		    $nikSuami = htmlspecialchars($this->request->getVar('nikSuami'), true);
		    $namaSuami = htmlspecialchars($this->request->getVar('namaSuami'), true);
		    $nikIstri = htmlspecialchars($this->request->getVar('nikIstri'), true);
		    $namaIstri = htmlspecialchars($this->request->getVar('namaIstri'), true);
		  //  $kecamatan = htmlspecialchars($this->request->getVar('kecamatan'), true);
		    $jumlahAnak = htmlspecialchars($this->request->getVar('jumlahAnak'), true);
		    $keterangan = htmlspecialchars($this->request->getVar('keterangan'), true);
		    $nikAnak1 = ($this->request->getVar('nikAnak1')) ? htmlspecialchars($this->request->getVar('nikAnak1'), true):"";
		    $namaAnak1 = ($this->request->getVar('namaAnak1')) ? htmlspecialchars($this->request->getVar('namaAnak1'), true):"";
		    $nikAnak2 = ($this->request->getVar('nikAnak2')) ? htmlspecialchars($this->request->getVar('nikAnak2'), true):"";
		    $namaAnak2 = ($this->request->getVar('namaAnak2')) ? htmlspecialchars($this->request->getVar('namaAnak2'), true):"";
		    $nikAnak3 = ($this->request->getVar('nikAnak3')) ? htmlspecialchars($this->request->getVar('nikAnak3'), true):"";
		    $namaAnak3 = ($this->request->getVar('namaAnak3')) ? htmlspecialchars($this->request->getVar('namaAnak3'), true):"";
		    $nikAnak4 = ($this->request->getVar('nikAnak4')) ? htmlspecialchars($this->request->getVar('nikAnak4'), true):"";
		    $namaAnak4 = ($this->request->getVar('namaAnak4')) ? htmlspecialchars($this->request->getVar('namaAnak4'), true):"";
		    $nikAnak5 = ($this->request->getVar('nikAnak5')) ? htmlspecialchars($this->request->getVar('nikAnak5'), true):"";
		    $namaAnak5 = ($this->request->getVar('namaAnak5')) ? htmlspecialchars($this->request->getVar('namaAnak5'), true):"";
		    
		    if (!file_exists('./assets/uploads/' . $this->folderImage)) {
                mkdir('./assets/uploads/' . $this->folderImage, 0755);
                $dir = './assets/uploads/' . $this->folderImage;
            } else {
                $dir = './assets/uploads/' . $this->folderImage;
            }
            
            $userLib = new Userlib();
            $user = $userLib->getUser($userId);
            
            if(!$user){
                return $this->fail("User tidak ditemukan");
            }
            
            $uuid = new Uuid();

            $dataPermohonan = [
                'id' => $uuid->v4(),
                'user_id' => $userId,
                'kk_pemohon' => $kk,
                'nik_suami' => $nikSuami,
                'nama_suami' => $namaSuami,
                'nik_istri' => $nikIstri,
                'nama_istri' => $namaIstri,
                'kecamatan' => $user->kecamatan,
                'nik_anak1' => ($nikAnak1 !== "") ? $nikAnak1:null,
                'nama_anak1' => ($namaAnak1 !== "") ? $namaAnak1:null,
                'nik_anak2' => ($nikAnak2 !== "") ? $nikAnak2:null,
                'nama_anak2' => ($namaAnak2 !== "") ? $namaAnak2:null,
                'nik_anak3' => ($nikAnak3 !== "") ? $nikAnak3:null,
                'nama_anak3' => ($namaAnak3 !== "") ? $namaAnak3:null,
                'nik_anak4' => ($nikAnak4 !== "") ? $nikAnak4:null,
                'nama_anak4' => ($namaAnak4 !== "") ? $namaAnak4:null,
                'nik_anak5' => ($nikAnak5 !== "") ? $nikAnak5:null,
                'nama_anak5' => ($namaAnak5 !== "") ? $namaAnak5:null,
                'jumlah_anak' => $jumlahAnak,
                'keterangan' => $keterangan,
                'created_at' => date('Y-m-d H:i:s'),
            ];
		    
            $lampiranKK = $this->request->getFile('lampiranKK');
			$filesNamelampiranKK = $lampiranKK->getName();
			$newNamelampiranKK = _create_name_foto($filesNamelampiranKK);
			
			if ($lampiranKK->isValid() && !$lampiranKK->hasMoved()) {
                $lampiranKK->move($dir, $newNamelampiranKK);
                $dataPermohonan['lampiran_kk'] = $newNamelampiranKK;
            } else {
                unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                return $this->fail($lampiranKK->getErrorString());
            }
            
            if($filenamelampiranKTP != '') {
    		    $lampiranKTP = $this->request->getFile('lampiranKTP');
    			$filesNamelampiranKTP = $lampiranKTP->getName();
    			$newNamelampiranKTP = _create_name_foto($filesNamelampiranKTP);
    			
    			if ($lampiranKTP->isValid() && !$lampiranKTP->hasMoved()) {
                    $lampiranKTP->move($dir, $newNamelampiranKTP);
                    $dataPermohonan['lampiran_ktp'] = $newNamelampiranKTP;
                } else {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    return $this->fail($lampiranKTP->getErrorString());
                }
            }
            
            if($filenamelampiranDokumentPendukungLain != '') {
                $lampiranDokumentPendukungLain = $this->request->getFile('lampiranDokumentPendukungLain');
    			$filesNamelampiranDokumentPendukungLain = $lampiranDokumentPendukungLain->getName();
    			$newNamelampiranDokumentPendukungLain = _create_name_foto($filesNamelampiranDokumentPendukungLain);
    			
    			if ($lampiranDokumentPendukungLain->isValid() && !$lampiranDokumentPendukungLain->hasMoved()) {
                    $lampiranDokumentPendukungLain->move($dir, $newNamelampiranDokumentPendukungLain);
                    $dataPermohonan['lampiran_dokument_pendukung_lain'] = $newNamelampiranDokumentPendukungLain;
                } else {
                    
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    if($filenamelampiranKTP != '') {
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_ktp']);
                    }
                    
                    return $this->fail($lampiranDokumentPendukungLain->getErrorString());
                }
            }
            
            $permohonanLib = new Permohonanlib();
            $inputPermohonanBaru = $permohonanLib->createPermohonan("UPDATEDATA", $userId);
            
            if($inputPermohonanBaru) {
                try{
                    $dataPermohonan['kode_permohonan'] = $inputPermohonanBaru;
                    $builder = $this->_db->table('_permohonan_update_data_tb');
                    $insertData = $builder->insert($dataPermohonan);
                } catch (\Throwable $th) {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    if($filenamelampiranKTP != '') {
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_ktp']);
                    }
                    
                    if($filenamelampiranDokumentPendukungLain != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_dokument_pendukung_lain']);
                    }
                    return $this->fail("menyimpan data");
                    // return $this->fail($th);
                }
                
                
                $dataNotifSystem = [
                  'kode_permohonan' => $dataPermohonan['kode_permohonan'],
                  'title' => "Permohonan Update Data",
                  'description' => "Permohonan Update Data",
                  'send_from' => $dataPermohonan['user_id'],
                  'send_to' => "DATA",
                  'action_page' => "detail_update_data",
                  'action_api' => "updatedata"
                ];
                $saveNotifSystem = new Notificationlib();
                $saveNotifSystem->send($dataNotifSystem);

                $dataNotif = [
                  'send_to' => "DATA",
                  'title' => "Permohonan Update Data",
                  'content' => "Permohonan Update Data",
                  'app_url' => "updatedata;".$dataPermohonan['kode_permohonan'].";detail_update_data"
                ];

                $onesignal = new Onesignallib();
                $send = $onesignal->pushNotifToAdmin($dataNotif);
                
                
                return $this->respond($dataPermohonan);
            } else {
                unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                if($filenamelampiranKTP != '') {
                    unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_ktp']);
                }
                
                if($filenamelampiranDokumentPendukungLain != ''){
                    unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_dokument_pendukung_lain']);
                }
                return $this->fail("menyimpan data permohonan");
            }
            
            
		}
    }
}
