<?php

namespace App\Controllers\V1;

use CodeIgniter\RESTful\ResourceController;

class Settinginformation extends ResourceController
{
    // protected $modelName = 'App\Models\VersionAppModel';
    protected $format = 'json';

    var $folderImage = 'slider';

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
    }

    public function index()
    {
        $keyword = htmlspecialchars($this->request->getGet('keyword'), true);
        
        if($keyword != ""){
            $key = $keyword;
        }else{
            $key = "syaratketentuan";
        }
        
        $db = \Config\Database::connect();
        $builder = $db->table('setting_information');
        $select = "id, keyword_key as keyword, value_key as value";
        $where = [
            'keyword_key' => $key,
            'is_active' => 1
        ];
        $data = $builder->select($select)->where($where)->orderBy('created_at', 'DESC')->get()->getRowObject();

        if ($data) {
            return $this->respond($data);
        } else {
            return $this->respondNoContent('Tidak ada content.');
        }
    }
}
