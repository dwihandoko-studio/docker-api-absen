<?php

namespace App\Controllers\v1;

use App\Controllers\BaseController;
use App\Libraries\Capil\Refensialamatlib;

class Home extends BaseController
{
	public function index()
	{
	    echo "Not Alowed";die;
	    $id = $this->request->getGet('id');
	    if($id != null){
	        $where = "id > $id";
	    }else{
	        $where = "id > 5302013";
	        echo "selesai";
	        die;
	    }
	    $db = \Config\Database::connect();
	    $builder = $db->table('ref_tbl_kecamatan');
        $dataKecamatan = $builder->where($where)->limit(100)->get()->getResult();
	    
		echo "<pre>";
      	$kataShowAwal = [
          	"Mulai Mensyncront..."
        ];
      	
      	print_r($kataShowAwal);
      	//die;
      
      	foreach($dataKecamatan as $val){
          	echo "<pre>";
              $kataShowMulai = [
                  $val->id_kabupaten => "Mengambil Data " . $val->kecamatan . ". . ."
              ];
      	
      		print_r($kataShowMulai);
          	$refensialamatlib = new Refensialamatlib();
          	$a = $refensialamatlib->getInsertKelurahan($val->id);
          
          	if(count($a) > 0){
            echo "<pre>";
      		echo "Kelurahan pada kecamatan ". $val->kecamatan . " sudah terinput.";
          	}else{
          	    echo "<pre>";
      		echo "Kelurahan pada kecamatan ". $val->kecamatan . " belum terinput.";
          	}
            
        }
        $old = $dataKecamatan[99]->id;
        
        return redirect()->to('/v1/?id='.$old);

	}
	
	private function getAction($id){
	    $url = "https://dev.farizdotid.com/api/daerahindonesia/kelurahan?id_kecamatan=".$id;
	    $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 0);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 500);
        // curl_setopt($ch, CURLOPT_POSTFIELDS,$encoderData);  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        
        $server_output = curl_exec ($ch);

        curl_close ($ch);

        $db = \Config\Database::connect();


        $data = json_decode($server_output);
      	var_dump($data);
        //$i = 0;
        $s = $data->kelurahan;
        print_r("<pre>");
        print_r("jumlah semua data kecamatan => " . count($s) . "<br>");
        //echo "jumlah semua data => " . count($a);
        //var_dump($a);die;
        //if($i == 100){
          
    
          foreach ($s as $val) {
            $dataInsert = [
              'id'=> (string)$val->id,
              'id_kecamatan'=> $val->id_kecamatan,
              'kelurahan'=> $val->nama,
            ];
    
            $builders = $db->table('ref_tbl_kelurahan');
            $inserted = $builders->ignore(true)->insert($dataInsert);
            print_r("<pre>");
            print_r($val->nama);
          }
         print_r("<pre>");
	}

	//--------------------------------------------------------------------

}
