<?php

namespace App\Controllers\V1;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Capil\Permohonanlib;
use App\Libraries\Capil\Userlib;
use App\Libraries\Onesignallib;
use App\Libraries\Notificationlib;

class Akteperkawinan extends ResourceController
{
    protected $modelName = 'App\Models\TokoModel';
    protected $format = 'json';

    var $folderImage = 'permohonan/aktaperkawinan';

    private $_db;

    function __construct()
    {
        helper(['text','file', 'form', 'array', 'fotourl', 'filesystem']);
        $this->_db      = \Config\Database::connect();
    }

    public function index()
    {
        
        $per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
        $pag = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

        if ($pag == 1) {
            $start = 0;
        } else {
            $start = (($pag - 1) * $per_page);
        }

		if (!$this->request->getGet('toko')) {
          $where = [
            '_product_tb_b.product_status' => 1
          ];
        }else{
          $tokoId = htmlspecialchars($this->request->getGet('toko'), true);
          $where = [
            '_product_tb_b.toko_id' => $tokoId,
          ];
        }
        $select = "_product_tb_b.id as productId, _product_tb_b.product_barcode as productBarcode, _product_tb_b.product_title as productTitle, _product_tb_b.product_description as productDescription, _product_tb_b.product_price_buy as productPriceBuy, _product_tb_b.product_price_sell as productPriceSell, _product_tb_b.product_weight as productWeight, _product_tb_b.product_qty as productQty, _product_tb_b.product_status as productStatus, _product_tb_b.product_unlimited as productUnlimited, _product_tb_b.product_thumb as productThumb, _product_tb_b.product_image as productImage, _product_tb_b.created_at as createdAt, _product_tb_b.updated_at as updatedAt, _category_tb_b.category_name as categoryName, _sub_category_tb_b.sub_category_name as subCategoryName";
      	
        $products = $this->_db->table('_product_tb_b')->select($select)->join('_category_tb_b', '_product_tb_b.category_id = _category_tb_b.id')->join('_sub_category_tb_b', '_product_tb_b.sub_category_id = _sub_category_tb_b.id')->where($where)->orderBy('_product_tb_b.created_at', 'desc')->get()->getResult();

        if(count($products) > 0) {
          $data['result'] = $products;
          $data['total_result'] = count($products);
          return $this->respond($data);
        }else{
          return $this->respondNoContent('Tidak ada content.');
        }
    }
    
    public function buat() {
        $rules = [
			'userId' => 'required|trim',
			'nikSuami' => 'required|trim',
			'kkSuami' => 'required|trim',
			'namaSuami' => 'required|trim',
			'agamaSuami' => 'required|trim',
			'alamatSuami' => 'required|trim',
			'nikIstri' => 'required|trim',
			'kkIstri' => 'required|trim',
			'namaIstri' => 'required|trim',
			'agamaIstri' => 'required|trim',
			'alamatIstri' => 'required|trim',
// 			'kecamatan' => 'required|trim',
			'namaPemukaAgama' => 'required|trim',
			'tempatPerkawinan' => 'required|trim',
			'tglPerkawinan' => 'required|trim',
			'agamaKepercayaan' => 'required|trim',
			'keterangan' => 'required|trim',
			'lampiranKTP' => 'uploaded[lampiranKTP]|max_size[lampiranKTP, 1024]|is_image[lampiranKTP]',
			'lampiranKK' => 'uploaded[lampiranKK]|max_size[lampiranKK, 1024]|is_image[lampiranKK]'
		];
		
		$filenamelampiranFotoGandeng = dot_array_search('lampiranFotoGandeng.name', $_FILES);
		if($filenamelampiranFotoGandeng != '') {
		    $lampiranFotoGandengVal = ['lampiranFotoGandeng' => 'uploaded[lampiranFotoGandeng]|max_size[lampiranFotoGandeng, 1024]|is_image[lampiranFotoGandeng]'];
		    $rules = array_merge($rules, $lampiranFotoGandengVal);
		}
		
		$filenamelampiranSuratKeteranganPerkawinan = dot_array_search('lampiranSuratKeteranganPerkawinan.name', $_FILES);
		if($filenamelampiranSuratKeteranganPerkawinan != '') {
		    $lampiranSuratKeteranganPerkawinanVal = ['lampiranSuratKeteranganPerkawinan' => 'uploaded[lampiranSuratKeteranganPerkawinan]|max_size[lampiranSuratKeteranganPerkawinan, 1024]|is_image[lampiranSuratKeteranganPerkawinan]'];
		    $rules = array_merge($rules, $lampiranSuratKeteranganPerkawinanVal);
		}
		
		$filenamelampiranAkteKelahiranSuami = dot_array_search('lampiranAkteKelahiranSuami.name', $_FILES);
		if($filenamelampiranAkteKelahiranSuami != '') {
		    $lampiranAkteKelahiranSuamiVal = ['lampiranAkteKelahiranSuami' => 'uploaded[lampiranAkteKelahiranSuami]|max_size[lampiranAkteKelahiranSuami, 1024]|is_image[lampiranAkteKelahiranSuami]'];
		    $rules = array_merge($rules, $lampiranAkteKelahiranSuamiVal);
		}
		
		$filenamelampiranAkteKelahiranIstri = dot_array_search('lampiranAkteKelahiranIstri.name', $_FILES);
		if($filenamelampiranAkteKelahiranIstri != '') {
		    $lampiranAkteKelahiranIstriVal = ['lampiranAkteKelahiranIstri' => 'uploaded[lampiranAkteKelahiranIstri]|max_size[lampiranAkteKelahiranIstri, 1024]|is_image[lampiranAkteKelahiranIstri]'];
		    $rules = array_merge($rules, $lampiranAkteKelahiranIstriVal);
		}
		
		$filenamelampiranDokumentPendukungLain = dot_array_search('lampiranDokumentPendukungLain.name', $_FILES);
		if($filenamelampiranDokumentPendukungLain != '') {
		    $lampiranDokumentPendukungLainVal = ['lampiranDokumentPendukungLain' => 'uploaded[lampiranDokumentPendukungLain]|max_size[lampiranDokumentPendukungLain, 1024]|is_image[lampiranDokumentPendukungLain]'];
		    $rules = array_merge($rules, $lampiranDokumentPendukungLainVal);
		}
		
		if (!$this->validate($rules)) {
			return $this->fail($this->validator->getErrors());
// 			return $this->failValidationError($this->validator->getError());
		} else {
		    $userId = htmlspecialchars($this->request->getVar('userId'), true);
		    $nikSuami = htmlspecialchars($this->request->getVar('nikSuami'), true);
		    $kkSuami = htmlspecialchars($this->request->getVar('kkSuami'), true);
		    $namaSuami = htmlspecialchars($this->request->getVar('namaSuami'), true);
		    $agamaSuami = htmlspecialchars($this->request->getVar('agamaSuami'), true);
		    $alamatSuami = htmlspecialchars($this->request->getVar('alamatSuami'), true);
		    $nikIstri = htmlspecialchars($this->request->getVar('nikIstri'), true);
		    $kkIstri = htmlspecialchars($this->request->getVar('kkIstri'), true);
		    $namaIstri = htmlspecialchars($this->request->getVar('namaIstri'), true);
		    $agamaIstri = htmlspecialchars($this->request->getVar('agamaIstri'), true);
		    $alamatIstri = htmlspecialchars($this->request->getVar('alamatIstri'), true);
		  //  $kecamatan = htmlspecialchars($this->request->getVar('kecamatan'), true);
		    $namaPemukaAgama = htmlspecialchars($this->request->getVar('namaPemukaAgama'), true);
		    $tempatPerkawinan = htmlspecialchars($this->request->getVar('tempatPerkawinan'), true);
		    $tglPerkawinan = htmlspecialchars($this->request->getVar('tglPerkawinan'), true);
		    $agamaKepercayaan = htmlspecialchars($this->request->getVar('agamaKepercayaan'), true);
		    $saksi1 = ($this->request->getVar('saksi1')) ? htmlspecialchars($this->request->getVar('saksi1'), true):null;
		    $saksi2 = ($this->request->getVar('saksi2')) ? htmlspecialchars($this->request->getVar('saksi2'), true):null;
		    $keterangan = htmlspecialchars($this->request->getVar('keterangan'), true);
		    
		    if (!file_exists('./assets/uploads/' . $this->folderImage)) {
                mkdir('./assets/uploads/' . $this->folderImage, 0755);
                $dir = './assets/uploads/' . $this->folderImage;
            } else {
                $dir = './assets/uploads/' . $this->folderImage;
            }
            
            $userLib = new Userlib();
            $user = $userLib->getUser($userId);
            
            if(!$user){
                return $this->fail("User tidak ditemukan");
            }
            
            $uuid = new Uuid();

            $dataPermohonan = [
                'id' => $uuid->v4(),
                'user_id' => $userId,
                'nik_suami' => $nikSuami,
                'kk_suami' => $kkSuami,
                'nama_suami' => $namaSuami,
                'agama_suami' => $agamaSuami,
                'alamat_suami' => $alamatSuami,
                'nik_istri' => $nikIstri,
                'kk_istri' => $kkIstri,
                'nama_istri' => $namaIstri,
                'agama_istri' => $agamaIstri,
                'alamat_istri' => $alamatIstri,
                'kecamatan' => $user->kecamatan,
                'nama_pemuka_agama' => $namaPemukaAgama,
                'tempat_perkawinan' => $tempatPerkawinan,
                'tgl_perkawinan' => $tglPerkawinan,
                'agama_kepercayaan' => $agamaKepercayaan,
                'saksi_1' => $saksi1,
                'saksi_2' => $saksi2,
                'keterangan' => $keterangan,
                'created_at' => date('Y-m-d H:i:s'),
            ];
		    
		    $lampiranKTP = $this->request->getFile('lampiranKTP');
			$filesNamelampiranKTP = $lampiranKTP->getName();
			$newNamelampiranKTP = _create_name_foto($filesNamelampiranKTP);
			
			if ($lampiranKTP->isValid() && !$lampiranKTP->hasMoved()) {
                $lampiranKTP->move($dir, $newNamelampiranKTP);
                $dataPermohonan['lampiran_ktp'] = $newNamelampiranKTP;
            } else {
                return $this->fail("Upload KTP");
                // return $this->fail($lampiranKTP->getErrorString());
            }
            
            $lampiranKK = $this->request->getFile('lampiranKK');
			$filesNamelampiranKK = $lampiranKK->getName();
			$newNamelampiranKK = _create_name_foto($filesNamelampiranKK);
			
			if ($lampiranKK->isValid() && !$lampiranKK->hasMoved()) {
                $lampiranKK->move($dir, $newNamelampiranKK);
                $dataPermohonan['lampiran_kk'] = $newNamelampiranKK;
            } else {
                unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                return $this->fail($lampiranKK->getErrorString());
            }
            
            if($filenamelampiranFotoGandeng != '') {
                $lampiranFotoGandeng = $this->request->getFile('lampiranFotoGandeng');
    			$filesNamelampiranFotoGandeng = $lampiranFotoGandeng->getName();
    			$newNamelampiranFotoGandeng = _create_name_foto($filesNamelampiranFotoGandeng);
    			
    			if ($lampiranFotoGandeng->isValid() && !$lampiranFotoGandeng->hasMoved()) {
                    $lampiranFotoGandeng->move($dir, $newNamelampiranFotoGandeng);
                    $dataPermohonan['lampiran_foto_gandeng'] = $newNamelampiranFotoGandeng;
                } else {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    return $this->fail($lampiranFotoGandeng->getErrorString());
                }
            }
            
            if($filenamelampiranSuratKeteranganPerkawinan != '') {
                $lampiranSuratKeteranganPerkawinan = $this->request->getFile('lampiranSuratKeteranganPerkawinan');
    			$filesNamelampiranSuratKeteranganPerkawinan = $lampiranSuratKeteranganPerkawinan->getName();
    			$newNamelampiranSuratKeteranganPerkawinan = _create_name_foto($filesNamelampiranSuratKeteranganPerkawinan);
    			
    			if ($lampiranSuratKeteranganPerkawinan->isValid() && !$lampiranSuratKeteranganPerkawinan->hasMoved()) {
                    $lampiranSuratKeteranganPerkawinan->move($dir, $newNamelampiranSuratKeteranganPerkawinan);
                    $dataPermohonan['lampiran_surat_keterangan_perkawinan'] = $newNamelampiranSuratKeteranganPerkawinan;
                } else {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    if($filenamelampiranFotoGandeng != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_foto_gandeng']);
                    }
                    return $this->fail($lampiranSuratKeteranganPerkawinan->getErrorString());
                }
            }
            
            if($filenamelampiranAkteKelahiranSuami != '') {
                $lampiranAkteKelahiranSuami = $this->request->getFile('lampiranAkteKelahiranSuami');
    			$filesNamelampiranAkteKelahiranSuami = $lampiranAkteKelahiranSuami->getName();
    			$newNamelampiranAkteKelahiranSuami = _create_name_foto($filesNamelampiranAkteKelahiranSuami);
    			
    			if ($lampiranAkteKelahiranSuami->isValid() && !$lampiranAkteKelahiranSuami->hasMoved()) {
                    $lampiranAkteKelahiranSuami->move($dir, $newNamelampiranAkteKelahiranSuami);
                    $dataPermohonan['lampiran_akte_kelahiran_suami'] = $newNamelampiranAkteKelahiranSuami;
                } else {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    if($filenamelampiranFotoGandeng != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_foto_gandeng']);
                    }
                    if($filenamelampiranSuratKeteranganPerkawinan != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_surat_keterangan_perkawinan']);
                    }
                    return $this->fail($lampiranAkteKelahiranSuami->getErrorString());
                }
            }
            
            if($filenamelampiranAkteKelahiranIstri != '') {
                $lampiranAkteKelahiranIstri = $this->request->getFile('lampiranAkteKelahiranIstri');
    			$filesNamelampiranAkteKelahiranIstri = $lampiranAkteKelahiranIstri->getName();
    			$newNamelampiranAkteKelahiranIstri = _create_name_foto($filesNamelampiranAkteKelahiranIstri);
    			
    			if ($lampiranAkteKelahiranIstri->isValid() && !$lampiranAkteKelahiranIstri->hasMoved()) {
                    $lampiranAkteKelahiranIstri->move($dir, $newNamelampiranAkteKelahiranIstri);
                    $dataPermohonan['lampiran_akte_kelahiran_istri'] = $newNamelampiranAkteKelahiranIstri;
                } else {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    if($filenamelampiranFotoGandeng != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_foto_gandeng']);
                    }
                    if($filenamelampiranSuratKeteranganPerkawinan != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_surat_keterangan_perkawinan']);
                    }
                    if($filenamelampiranAkteKelahiranSuami != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_akte_kelahiran_suami']);
                    }
                    return $this->fail($lampiranAkteKelahiranIstri->getErrorString());
                }
            }
            
            if($filenamelampiranDokumentPendukungLain != '') {
                $lampiranDokumentPendukungLain = $this->request->getFile('lampiranDokumentPendukungLain');
    			$filesNamelampiranDokumentPendukungLain = $lampiranDokumentPendukungLain->getName();
    			$newNamelampiranDokumentPendukungLain = _create_name_foto($filesNamelampiranDokumentPendukungLain);
    			
    			if ($lampiranDokumentPendukungLain->isValid() && !$lampiranDokumentPendukungLain->hasMoved()) {
                    $lampiranDokumentPendukungLain->move($dir, $newNamelampiranDokumentPendukungLain);
                    $dataPermohonan['lampiran_dokument_pendukung_lain'] = $newNamelampiranDokumentPendukungLain;
                } else {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    if($filenamelampiranFotoGandeng != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_foto_gandeng']);
                    }
                    if($filenamelampiranSuratKeteranganPerkawinan != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_surat_keterangan_perkawinan']);
                    }
                    if($filenamelampiranAkteKelahiranSuami != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_akte_kelahiran_suami']);
                    }
                    if($filenamelampiranAkteKelahiranIstri != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_akte_kelahiran_istri']);
                    }
                    return $this->fail($lampiranDokumentPendukungLain->getErrorString());
                }
            }
            //var_dump($dataPermohonan);
            // return $this->fail($dataPermohonan);
            // die;
            $permohonanLib = new Permohonanlib();
            $inputPermohonanBaru = $permohonanLib->createPermohonan("AKTAKAWIN", $userId);
            
            //return $this->fail($inputPermohonanBaru);
            if($inputPermohonanBaru) {
                try{
                    $dataPermohonan['kode_permohonan'] = $inputPermohonanBaru;
                    $builder = $this->_db->table('_permohonan_akte_perkawinan_tb');
                    $insertData = $builder->insert($dataPermohonan);
                } catch (\Throwable $th) {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    if($filenamelampiranFotoGandeng != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_foto_gandeng']);
                    }
                    if($filenamelampiranSuratKeteranganPerkawinan != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_surat_keterangan_perkawinan']);
                    }
                    if($filenamelampiranAkteKelahiranSuami != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_akte_kelahiran_suami']);
                    }
                    if($filenamelampiranAkteKelahiranIstri != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_akte_kelahiran_istri']);
                    }
                    if($filenamelampiranDokumentPendukungLain != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_dokument_pendukung_lain']);
                    }
                    return $this->fail("menyimpan data");
                    // return $this->fail($th);
                }
                
                
                $dataNotifSystem = [
                  'kode_permohonan' => $dataPermohonan['kode_permohonan'],
                  'title' => "Permohonan Akta Perkawinan",
                  'description' => "Permohonan Akta Perkawinan",
                  'send_from' => $dataPermohonan['user_id'],
                  'send_to' => "PENCATATAN_SIPIL",
                  'action_page' => "detail_akte_perkawinan",
                  'action_api' => "akteperkawinan"
                ];
                $saveNotifSystem = new Notificationlib();
                $saveNotifSystem->send($dataNotifSystem);

                $dataNotif = [
                  'send_to' => "PENCATATAN_SIPIL",
                  'title' => "Permohonan Akta Perkawinan",
                  'content' => "Permohonan Akta Perkawinan",
                  'app_url' => "akteperkawinan;".$dataPermohonan['kode_permohonan'].";detail_akte_perkawinan"
                ];

                $onesignal = new Onesignallib();
                $send = $onesignal->pushNotifToAdmin($dataNotif);
                
                
                return $this->respond($dataPermohonan);
            } else {
                unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                if($filenamelampiranFotoGandeng != ''){
                    unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_foto_gandeng']);
                }
                if($filenamelampiranSuratKeteranganPerkawinan != ''){
                    unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_surat_keterangan_perkawinan']);
                }
                if($filenamelampiranAkteKelahiranSuami != ''){
                    unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_akte_kelahiran_suami']);
                }
                if($filenamelampiranAkteKelahiranIstri != ''){
                    unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_akte_kelahiran_istri']);
                }
                if($filenamelampiranDokumentPendukungLain != ''){
                    unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_dokument_pendukung_lain']);
                }
                return $this->fail("menyimpan data permohonan");
            }
            
            
		}
    }
}
