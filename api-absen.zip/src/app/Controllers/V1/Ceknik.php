<?php

namespace App\Controllers\V1;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Capil\Permohonanlib;
use App\Libraries\Capil\Userlib;
use App\Libraries\Onesignallib;
use App\Libraries\Notificationlib;

class Ceknik extends ResourceController
{
    protected $modelName = 'App\Models\TokoModel';
    protected $format = 'json';

    var $folderImage = 'permohonan/ceknik';

    private $_db;

    function __construct()
    {
        helper(['text','file', 'form', 'array', 'fotourl', 'filesystem']);
        $this->_db      = \Config\Database::connect();
    }

    public function index()
    {
        
        $per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
        $pag = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

        if ($pag == 1) {
            $start = 0;
        } else {
            $start = (($pag - 1) * $per_page);
        }

		if (!$this->request->getGet('toko')) {
          $where = [
            '_product_tb_b.product_status' => 1
          ];
        }else{
          $tokoId = htmlspecialchars($this->request->getGet('toko'), true);
          $where = [
            '_product_tb_b.toko_id' => $tokoId,
          ];
        }
        $select = "_product_tb_b.id as productId, _product_tb_b.product_barcode as productBarcode, _product_tb_b.product_title as productTitle, _product_tb_b.product_description as productDescription, _product_tb_b.product_price_buy as productPriceBuy, _product_tb_b.product_price_sell as productPriceSell, _product_tb_b.product_weight as productWeight, _product_tb_b.product_qty as productQty, _product_tb_b.product_status as productStatus, _product_tb_b.product_unlimited as productUnlimited, _product_tb_b.product_thumb as productThumb, _product_tb_b.product_image as productImage, _product_tb_b.created_at as createdAt, _product_tb_b.updated_at as updatedAt, _category_tb_b.category_name as categoryName, _sub_category_tb_b.sub_category_name as subCategoryName";
      	
        $products = $this->_db->table('_product_tb_b')->select($select)->join('_category_tb_b', '_product_tb_b.category_id = _category_tb_b.id')->join('_sub_category_tb_b', '_product_tb_b.sub_category_id = _sub_category_tb_b.id')->where($where)->orderBy('_product_tb_b.created_at', 'desc')->get()->getResult();

        if(count($products) > 0) {
          $data['result'] = $products;
          $data['total_result'] = count($products);
          return $this->respond($data);
        }else{
          return $this->respondNoContent('Tidak ada content.');
        }
    }
    
    public function buat() {
        $rules = [
			'userId' => 'required|trim',
			'nik' => 'required|trim',
			'kk' => 'required|trim',
			'nama' => 'required|trim',
// 			'kecamatan' => 'required|trim',
			'jenisCek' => 'required|trim',
			'keterangan' => 'required|trim',
			'lampiranKK' => 'uploaded[lampiranKK]|max_size[lampiranKK, 1024]|is_image[lampiranKK]',
		];
		
		$filenamelampiranKTP = dot_array_search('lampiranKTP.name', $_FILES);
		if($filenamelampiranKTP != '') {
		    $lampiranKTPVal = ['lampiranKTP' => 'uploaded[lampiranKTP]|max_size[lampiranKTP, 1024]|is_image[lampiranKTP]'];
		    $rules = array_merge($rules, $lampiranKTPVal);
		}
		
		$filenamelampiranDokumentPendukungLain = dot_array_search('lampiranDokumentPendukungLain.name', $_FILES);
		if($filenamelampiranDokumentPendukungLain != '') {
		    $lampiranDokumentPendukungLainVal = ['lampiranDokumentPendukungLain' => 'uploaded[lampiranDokumentPendukungLain]|max_size[lampiranDokumentPendukungLain, 1024]|is_image[lampiranDokumentPendukungLain]'];
		    $rules = array_merge($rules, $lampiranDokumentPendukungLainVal);
		}
		
		if (!$this->validate($rules)) {
			return $this->fail($this->validator->getErrors());
// 			return $this->failValidationError($this->validator->getError());
		} else {
		    $userId = htmlspecialchars($this->request->getVar('userId'), true);
		    $nik = htmlspecialchars($this->request->getVar('nik'), true);
		    $kk = htmlspecialchars($this->request->getVar('kk'), true);
		    $nama = htmlspecialchars($this->request->getVar('nama'), true);
		  //  $kecamatan = htmlspecialchars($this->request->getVar('kecamatan'), true);
		    $jenisCek = htmlspecialchars($this->request->getVar('jenisCek'), true);
		    $keterangan = htmlspecialchars($this->request->getVar('keterangan'), true);
		    $tglRekaman = ($this->request->getVar('tglRekaman')) ? htmlspecialchars($this->request->getVar('tglRekaman'), true):"";
		    
		    if (!file_exists('./assets/uploads/' . $this->folderImage)) {
                mkdir('./assets/uploads/' . $this->folderImage, 0755);
                $dir = './assets/uploads/' . $this->folderImage;
            } else {
                $dir = './assets/uploads/' . $this->folderImage;
            }
            
            $userLib = new Userlib();
            $user = $userLib->getUser($userId);
            
            if(!$user){
                return $this->fail("User tidak ditemukan");
            }
            
            $uuid = new Uuid();

            $dataPermohonan = [
                'id' => $uuid->v4(),
                'user_id' => $userId,
                'nik_pemohon' => $nik,
                'kk_pemohon' => $kk,
                'nama_pemohon' => $nama,
                'kecamatan' => $user->kecamatan,
                'tgl_rekaman' => ($tglRekaman !== "") ? $tglRekaman:null,
                'jenis_cek' => $jenisCek,
                'keterangan' => $keterangan,
                'created_at' => date('Y-m-d H:i:s'),
            ];
		    
            $lampiranKK = $this->request->getFile('lampiranKK');
			$filesNamelampiranKK = $lampiranKK->getName();
			$newNamelampiranKK = _create_name_foto($filesNamelampiranKK);
			
			if ($lampiranKK->isValid() && !$lampiranKK->hasMoved()) {
                $lampiranKK->move($dir, $newNamelampiranKK);
                $dataPermohonan['lampiran_kk'] = $newNamelampiranKK;
            } else {
                unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                return $this->fail($lampiranKK->getErrorString());
            }
            
            if($filenamelampiranKTP != '') {
    		    $lampiranKTP = $this->request->getFile('lampiranKTP');
    			$filesNamelampiranKTP = $lampiranKTP->getName();
    			$newNamelampiranKTP = _create_name_foto($filesNamelampiranKTP);
    			
    			if ($lampiranKTP->isValid() && !$lampiranKTP->hasMoved()) {
                    $lampiranKTP->move($dir, $newNamelampiranKTP);
                    $dataPermohonan['lampiran_ktp'] = $newNamelampiranKTP;
                } else {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    return $this->fail($lampiranKTP->getErrorString());
                }
            }
            
            if($filenamelampiranDokumentPendukungLain != '') {
                $lampiranDokumentPendukungLain = $this->request->getFile('lampiranDokumentPendukungLain');
    			$filesNamelampiranDokumentPendukungLain = $lampiranDokumentPendukungLain->getName();
    			$newNamelampiranDokumentPendukungLain = _create_name_foto($filesNamelampiranDokumentPendukungLain);
    			
    			if ($lampiranDokumentPendukungLain->isValid() && !$lampiranDokumentPendukungLain->hasMoved()) {
                    $lampiranDokumentPendukungLain->move($dir, $newNamelampiranDokumentPendukungLain);
                    $dataPermohonan['lampiran_dokument_pendukung_lain'] = $newNamelampiranDokumentPendukungLain;
                } else {
                    
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    if($filenamelampiranKTP != '') {
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_ktp']);
                    }
                    
                    return $this->fail($lampiranDokumentPendukungLain->getErrorString());
                }
            }
            
            $permohonanLib = new Permohonanlib();
            $inputPermohonanBaru = $permohonanLib->createPermohonan("CEKNIK", $userId);
            
            if($inputPermohonanBaru) {
                try{
                    $dataPermohonan['kode_permohonan'] = $inputPermohonanBaru;
                    $builder = $this->_db->table('_permohonan_cek_nik_tb');
                    $insertData = $builder->insert($dataPermohonan);
                } catch (\Throwable $th) {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    if($filenamelampiranKTP != '') {
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_ktp']);
                    }
                    
                    if($filenamelampiranDokumentPendukungLain != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_dokument_pendukung_lain']);
                    }
                    return $this->fail("menyimpan data");
                    // return $this->fail($th);
                }
                
                
                $dataNotifSystem = [
                  'kode_permohonan' => $dataPermohonan['kode_permohonan'],
                  'title' => "Permohonan Cek NIK",
                  'description' => "Permohonan Cek NIK",
                  'send_from' => $dataPermohonan['user_id'],
                  'send_to' => "DATA",
                  'action_page' => "detail_cek_nik",
                  'action_api' => "ceknik"
                ];
                $saveNotifSystem = new Notificationlib();
                $saveNotifSystem->send($dataNotifSystem);

                $dataNotif = [
                  'send_to' => "DATA",
                  'title' => "Permohonan Cek NIK",
                  'content' => "Permohonan Cek NIK",
                  'app_url' => "ceknik;".$dataPermohonan['kode_permohonan'].";detail_cek_nik"
                ];

                $onesignal = new Onesignallib();
                $send = $onesignal->pushNotifToAdmin($dataNotif);
                
                
                return $this->respond($dataPermohonan);
            } else {
                unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                if($filenamelampiranKTP != '') {
                    unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_ktp']);
                }
                
                if($filenamelampiranDokumentPendukungLain != ''){
                    unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_dokument_pendukung_lain']);
                }
                return $this->fail("menyimpan data permohonan");
            }
            
            
		}
    }
}
