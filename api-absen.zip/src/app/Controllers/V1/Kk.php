<?php

namespace App\Controllers\V1;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Capil\Permohonanlib;
use App\Libraries\Capil\Userlib;
use App\Libraries\Onesignallib;
use App\Libraries\Notificationlib;

class Kk extends ResourceController
{
    protected $modelName = 'App\Models\TokoModel';
    protected $format = 'json';

    var $folderImage = 'permohonan/kk';

    private $_db;

    function __construct()
    {
        helper(['text','file', 'form', 'array', 'fotourl', 'filesystem']);
        $this->_db      = \Config\Database::connect();
    }

    public function index()
    {
        
        $per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
        $pag = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

        if ($pag == 1) {
            $start = 0;
        } else {
            $start = (($pag - 1) * $per_page);
        }

		if (!$this->request->getGet('toko')) {
          $where = [
            '_product_tb_b.product_status' => 1
          ];
        }else{
          $tokoId = htmlspecialchars($this->request->getGet('toko'), true);
          $where = [
            '_product_tb_b.toko_id' => $tokoId,
          ];
        }
        $select = "_product_tb_b.id as productId, _product_tb_b.product_barcode as productBarcode, _product_tb_b.product_title as productTitle, _product_tb_b.product_description as productDescription, _product_tb_b.product_price_buy as productPriceBuy, _product_tb_b.product_price_sell as productPriceSell, _product_tb_b.product_weight as productWeight, _product_tb_b.product_qty as productQty, _product_tb_b.product_status as productStatus, _product_tb_b.product_unlimited as productUnlimited, _product_tb_b.product_thumb as productThumb, _product_tb_b.product_image as productImage, _product_tb_b.created_at as createdAt, _product_tb_b.updated_at as updatedAt, _category_tb_b.category_name as categoryName, _sub_category_tb_b.sub_category_name as subCategoryName";
      	
        $products = $this->_db->table('_product_tb_b')->select($select)->join('_category_tb_b', '_product_tb_b.category_id = _category_tb_b.id')->join('_sub_category_tb_b', '_product_tb_b.sub_category_id = _sub_category_tb_b.id')->where($where)->orderBy('_product_tb_b.created_at', 'desc')->get()->getResult();

        if(count($products) > 0) {
          $data['result'] = $products;
          $data['total_result'] = count($products);
          return $this->respond($data);
        }else{
          return $this->respondNoContent('Tidak ada content.');
        }
    }
    
    public function buat() {
        $rules = [
			'userId' => 'required|trim',
			'nik' => 'required|trim',
			'kk' => 'required|trim',
			'nama' => 'required|trim',
			'keterangan' => 'required|trim',
// 			'kecamatan' => 'required|trim',
			'jenisPermohonan' => 'required|trim',
// 			'lampiranKTP' => 'uploaded[lampiranKTP]|max_size[lampiranKTP, 1024]|is_image[lampiranKTP]',
			'lampiranKTP' => 'uploaded[lampiranKTP]|max_size[lampiranKTP, 1024]|is_image[lampiranKTP]',
			'lampiranKK' => 'uploaded[lampiranKK]|max_size[lampiranKK, 1024]|is_image[lampiranKK]',
			'lampiranBukuNikah' => 'uploaded[lampiranBukuNikah]|max_size[lampiranBukuNikah, 1024]|is_image[lampiranBukuNikah]'
		];
		
		$filenamelampiranFormulirKK = dot_array_search('lampiranFormulirKK.name', $_FILES);
		if($filenamelampiranFormulirKK != '') {
		    $lampiranFormulirKKVal = ['lampiranFormulirKK' => 'uploaded[lampiranFormulirKK]|max_size[lampiranFormulirKK, 1024]|is_image[lampiranFormulirKK]'];
		    $rules = array_merge($rules, $lampiranFormulirKKVal);
		}
		
		$filenamelampiranSuratKeteranganHapus = dot_array_search('lampiranSuratKeteranganHapus.name', $_FILES);
		if($filenamelampiranSuratKeteranganHapus != '') {
		    $lampiranSuratKeteranganHapusVal = ['lampiranSuratKeteranganHapus' => 'uploaded[lampiranSuratKeteranganHapus]|max_size[lampiranSuratKeteranganHapus, 1024]|is_image[lampiranSuratKeteranganHapus]'];
		    $rules = array_merge($rules, $lampiranSuratKeteranganHapusVal);
		}
		
		$filenamelampiranSuratKeteranganTambah = dot_array_search('lampiranSuratKeteranganTambah.name', $_FILES);
		if($filenamelampiranSuratKeteranganTambah != '') {
		    $lampiranSuratKeteranganTambahVal = ['lampiranSuratKeteranganTambah' => 'uploaded[lampiranSuratKeteranganTambah]|max_size[lampiranSuratKeteranganTambah, 1024]|is_image[lampiranSuratKeteranganTambah]'];
		    $rules = array_merge($rules, $lampiranSuratKeteranganTambahVal);
		}
		
		$filenamelampiranDokumentPendukungLain = dot_array_search('lampiranDokumentPendukungLain.name', $_FILES);
		if($filenamelampiranDokumentPendukungLain != '') {
		    $lampiranDokumentPendukungLainVal = ['lampiranDokumentPendukungLain' => 'uploaded[lampiranDokumentPendukungLain]|max_size[lampiranDokumentPendukungLain, 1024]|is_image[lampiranDokumentPendukungLain]'];
		    $rules = array_merge($rules, $lampiranDokumentPendukungLainVal);
		}
		
		if (!$this->validate($rules)) {
			return $this->fail($this->validator->getErrors());
// 			return $this->failValidationError($this->validator->getError());
		} else {
		    $userId = htmlspecialchars($this->request->getVar('userId'), true);
		    $nik = htmlspecialchars($this->request->getVar('nik'), true);
		    $kk = htmlspecialchars($this->request->getVar('kk'), true);
		    $nama = htmlspecialchars($this->request->getVar('nama'), true);
		    $keterangan = htmlspecialchars($this->request->getVar('keterangan'), true);
		  //  $kecamatan = htmlspecialchars($this->request->getVar('kecamatan'), true);
		    $jenisPermohonan = htmlspecialchars($this->request->getVar('jenisPermohonan'), true);
		    
		    if (!file_exists('./assets/uploads/' . $this->folderImage)) {
                mkdir('./assets/uploads/' . $this->folderImage, 0755);
                $dir = './assets/uploads/' . $this->folderImage;
            } else {
                $dir = './assets/uploads/' . $this->folderImage;
            }
            
            $userLib = new Userlib();
            $user = $userLib->getUser($userId);
            
            if(!$user){
                return $this->fail("User tidak ditemukan");
            }
            
            $uuid = new Uuid();

            $dataPermohonan = [
                'id' => $uuid->v4(),
                'user_id' => $userId,
                'nik_pemohon' => $nik,
                'kk_pemohon' => $kk,
                'nama_pemohon' => $nama,
                'keterangan' => $keterangan,
                'kecamatan' => $user->kecamatan,
                'jenis_permohonan_kk' => $jenisPermohonan,
                'created_at' => date('Y-m-d H:i:s'),
            ];
		    
		    $lampiranKTP = $this->request->getFile('lampiranKTP');
			$filesNamelampiranKTP = $lampiranKTP->getName();
			$newNamelampiranKTP = _create_name_foto($filesNamelampiranKTP);
			
			if ($lampiranKTP->isValid() && !$lampiranKTP->hasMoved()) {
                $lampiranKTP->move($dir, $newNamelampiranKTP);
                $dataPermohonan['lampiran_ktp'] = $newNamelampiranKTP;
            } else {
                return $this->fail("Upload KTP");
                // return $this->fail($lampiranKTP->getErrorString());
            }
            
            $lampiranKK = $this->request->getFile('lampiranKK');
			$filesNamelampiranKK = $lampiranKK->getName();
			$newNamelampiranKK = _create_name_foto($filesNamelampiranKK);
			
			if ($lampiranKK->isValid() && !$lampiranKK->hasMoved()) {
                $lampiranKK->move($dir, $newNamelampiranKK);
                $dataPermohonan['lampiran_kk'] = $newNamelampiranKK;
            } else {
                unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                return $this->fail($lampiranKK->getErrorString());
            }
            
            $lampiranBukuNikah = $this->request->getFile('lampiranBukuNikah');
			$filesNamelampiranBukuNikah = $lampiranBukuNikah->getName();
			$newNamelampiranBukuNikah = _create_name_foto($filesNamelampiranBukuNikah);
			
			if ($lampiranBukuNikah->isValid() && !$lampiranBukuNikah->hasMoved()) {
                $lampiranBukuNikah->move($dir, $newNamelampiranBukuNikah);
                $dataPermohonan['lampiran_buku_nikah'] = $newNamelampiranBukuNikah;
            } else {
                unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                return $this->fail($lampiranBukuNikah->getErrorString());
            }
            
            if($filenamelampiranFormulirKK != '') {
                $lampiranFormulirKK = $this->request->getFile('lampiranFormulirKK');
    			$filesNamelampiranFormulirKK = $lampiranFormulirKK->getName();
    			$newNamelampiranFormulirKK = _create_name_foto($filesNamelampiranFormulirKK);
    			
    			if ($lampiranFormulirKK->isValid() && !$lampiranFormulirKK->hasMoved()) {
                    $lampiranFormulirKK->move($dir, $newNamelampiranFormulirKK);
                    $dataPermohonan['lampiran_formulir_kk'] = $newNamelampiranFormulirKK;
                } else {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranBukuNikah);
                    return $this->fail($lampiranFormulirKK->getErrorString());
                }
            }
            
            if($filenamelampiranSuratKeteranganHapus != '') {
                $lampiranSuratKeteranganHapus = $this->request->getFile('lampiranSuratKeteranganHapus');
    			$filesNamelampiranSuratKeteranganHapus = $lampiranSuratKeteranganHapus->getName();
    			$newNamelampiranSuratKeteranganHapus = _create_name_foto($filesNamelampiranSuratKeteranganHapus);
    			
    			if ($lampiranSuratKeteranganHapus->isValid() && !$lampiranSuratKeteranganHapus->hasMoved()) {
                    $lampiranSuratKeteranganHapus->move($dir, $newNamelampiranSuratKeteranganHapus);
                    $dataPermohonan['lampiran_surat_keterangan_hapus'] = $newNamelampiranSuratKeteranganHapus;
                } else {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranBukuNikah);
                    if($filenamelampiranFormulirKK != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_formulir_kk']);
                    }
                    return $this->fail($lampiranSuratKeteranganHapus->getErrorString());
                }
            }
            
            if($filenamelampiranSuratKeteranganTambah != '') {
                $lampiranSuratKeteranganTambah = $this->request->getFile('lampiranSuratKeteranganTambah');
    			$filesNamelampiranSuratKeteranganTambah = $lampiranSuratKeteranganTambah->getName();
    			$newNamelampiranSuratKeteranganTambah = _create_name_foto($filesNamelampiranSuratKeteranganTambah);
    			
    			if ($lampiranSuratKeteranganTambah->isValid() && !$lampiranSuratKeteranganTambah->hasMoved()) {
                    $lampiranSuratKeteranganTambah->move($dir, $newNamelampiranSuratKeteranganTambah);
                    $dataPermohonan['lampiran_surat_keterangan_tambah'] = $newNamelampiranSuratKeteranganTambah;
                } else {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranBukuNikah);
                    if($filenamelampiranFormulirKK != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_formulir_kk']);
                    }
                    if($filenamelampiranSuratKeteranganHapus != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_surat_keterangan_hapus']);
                    }
                    return $this->fail($lampiranSuratKeteranganTambah->getErrorString());
                }
            }
            
            if($filenamelampiranDokumentPendukungLain != '') {
                $lampiranDokumentPendukungLain = $this->request->getFile('lampiranDokumentPendukungLain');
    			$filesNamelampiranDokumentPendukungLain = $lampiranDokumentPendukungLain->getName();
    			$newNamelampiranDokumentPendukungLain = _create_name_foto($filesNamelampiranDokumentPendukungLain);
    			
    			if ($lampiranDokumentPendukungLain->isValid() && !$lampiranDokumentPendukungLain->hasMoved()) {
                    $lampiranDokumentPendukungLain->move($dir, $newNamelampiranDokumentPendukungLain);
                    $dataPermohonan['lampiran_dokument_pendukung_lain'] = $newNamelampiranDokumentPendukungLain;
                } else {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranBukuNikah);
                    if($filenamelampiranFormulirKK != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_formulir_kk']);
                    }
                    if($filenamelampiranSuratKeteranganHapus != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_surat_keterangan_hapus']);
                    }
                    if($filenamelampiranSuratKeteranganTambah != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_surat_keterangan_tambah']);
                    }
                    return $this->fail($lampiranDokumentPendukungLain->getErrorString());
                }
            }
            
            $permohonanLib = new Permohonanlib();
            $inputPermohonanBaru = $permohonanLib->createPermohonan("KK", $userId);
            
            if($inputPermohonanBaru) {
                try{
                    $dataPermohonan['kode_permohonan'] = $inputPermohonanBaru;
                    $builder = $this->_db->table('_permohonan_kk_tb');
                    $insertData = $builder->insert($dataPermohonan);
                } catch (\Throwable $th) {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranBukuNikah);
                    if($filenamelampiranFormulirKK != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_formulir_kk']);
                    }
                    if($filenamelampiranSuratKeteranganHapus != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_surat_keterangan_hapus']);
                    }
                    if($filenamelampiranSuratKeteranganTambah != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_surat_keterangan_tambah']);
                    }
                    if($filenamelampiranDokumentPendukungLain != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_dokument_pendukung_lain']);
                    }
                    return $this->fail("menyimpan data");
                    // return $this->fail($th);
                }
                
                
                $dataNotifSystem = [
                  'kode_permohonan' => $dataPermohonan['kode_permohonan'],
                  'title' => "Permohonan KK",
                  'description' => "Permohonan Kartu Keluarga Jenis" . ($dataPermohonan['jenis_permohonan_kk'] == "1") ? "Buat Kartu Keluarga" : ($dataPermohonan['jenis_permohonan_kk'] == "2") ? "Perbaikan Kartu Keluarga" : ($dataPermohonan['jenis_permohonan_kk'] == "3") ? "Tambah Anggota Keluarga" : ($dataPermohonan['jenis_permohonan_kk'] == "4") ? "Hapus Anggota Keluarga" : "Lainnya" ,
                  'send_from' => $dataPermohonan['user_id'],
                  'send_to' => "KEPENDUDUKAN",
                  'action_page' => "detail_kk",
                  'action_api' => "kk"
                ];
                $saveNotifSystem = new Notificationlib();
                $saveNotifSystem->send($dataNotifSystem);

                $dataNotif = [
                  'send_to' => "KEPENDUDUKAN",
                  'title' => "Permohonan KK",
                  'content' => "Permohonan Kartu Keluarga Jenis" . ($dataPermohonan['jenis_permohonan_kk'] == "1") ? "Buat Kartu Keluarga" : ($dataPermohonan['jenis_permohonan_kk'] == "2") ? "Perbaikan Kartu Keluarga" : ($dataPermohonan['jenis_permohonan_kk'] == "3") ? "Tambah Anggota Keluarga" : ($dataPermohonan['jenis_permohonan_kk'] == "4") ? "Hapus Anggota Keluarga" : "Lainnya" ,
                  'app_url' => "kk;".$dataPermohonan['kode_permohonan'].";detail_kk"
                ];

                $onesignal = new Onesignallib();
                $send = $onesignal->pushNotifToAdmin($dataNotif);
                
                
                return $this->respond($dataPermohonan);
            } else {
                unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                unlink(FCPATH . $dir . '/' . $newNamelampiranBukuNikah);
                if($filenamelampiranFormulirKK != ''){
                    unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_formulir_kk']);
                }
                if($filenamelampiranSuratKeteranganHapus != ''){
                    unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_surat_keterangan_hapus']);
                }
                if($filenamelampiranSuratKeteranganTambah != ''){
                    unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_surat_keterangan_tambah']);
                }
                if($filenamelampiranDokumentPendukungLain != ''){
                    unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_dokument_pendukung_lain']);
                }
                return $this->fail("menyimpan data");
            }
            
            
		}
    }

    public function create()
    {
        $rules = [
            'userId' => 'required',
            'tokoId' => 'required',
            'barcode' => 'required',
            'namaProduk' => 'required',
            'deskripsiProduk' => 'required',
            'categoryProduk' => 'required',
            'subCategoryProduk' => 'required',
            'satuanProduk' => 'required',
            'qtyProduk' => 'required',
            'hargaBeliProduk' => 'required',
            'hargaJualProduk' => 'required',
            'diskonProduk' => 'required',
            'poinProduk' => 'required',
            'beratProduk' => 'required',
            'feeAdmin' => 'required',
          	'sendFrom' => 'required',
            //'files' => 'uploaded[files]|max_size[files, 1024]|is_image[files]'
        ];
        // $img = ['featured_image' => 'uploaded[featured_image]|mime_in[featured_image,image/jpg,image/png,image/gif,image/jpeg]|max_size[featured_image, 1024]'];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getError());
        } else {
            //get the file
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            $tokoId = htmlspecialchars($this->request->getVar('tokoId'), true);
            $barcode = htmlspecialchars($this->request->getVar('barcode'), true);
            $namaProduk = htmlspecialchars($this->request->getVar('namaProduk'), true);
            $deskripsiProduk = htmlspecialchars($this->request->getVar('deskripsiProduk'), true);
            $categoryProduk = htmlspecialchars($this->request->getVar('categoryProduk'), true);
            $subCategoryProduk = htmlspecialchars($this->request->getVar('subCategoryProduk'), true);
            $satuanProduk = htmlspecialchars($this->request->getVar('satuanProduk'), true);
            $qtyProduk = htmlspecialchars($this->request->getVar('qtyProduk'), true);
            $hargaBeliProduk = htmlspecialchars($this->request->getVar('hargaBeliProduk'), true);
            $hargaJualProduk = htmlspecialchars($this->request->getVar('hargaJualProduk'), true);
            $diskonProduk = htmlspecialchars($this->request->getVar('diskonProduk'), true);
            $poinProduk = htmlspecialchars($this->request->getVar('poinProduk'), true);
            $beratProduk = htmlspecialchars($this->request->getVar('beratProduk'), true);
            $feeAdmin = htmlspecialchars($this->request->getVar('feeAdmin'), true);
            $files = $this->request->getFiles();

            
            $imageThumb = "";

            if (!file_exists('./assets/uploads/' . $this->folderImage)) {
                mkdir('./assets/uploads/' . $this->folderImage, 0777);
                $dir = './assets/uploads/' . $this->folderImage;
            } else {
                $dir = './assets/uploads/' . $this->folderImage;
            }
          	$namesForStored = array();
			//var_dump($files);die;
          	if((int)htmlspecialchars($this->request->getVar('sendFrom'), true) == 1) {
              foreach ($files['images'] as $file) {
                $a = $file[0]->getClientMimeType();
                
                if ($a=="image/jpeg" || $a=="image/png" || $a=="image/jpg") {
                
                    $filesName = $file[0]->getName();
                    $newName = _create_name_foto($filesName);
                    if ($file[0]->isValid() && !$file[0]->hasMoved()) {

                        $file[0]->move($dir, $newName);

                        $namesForStored[] = $newName;
                    } else {
                      return $this->fail($file[0]->getErrorString());
                    }




                 } else {
                    return $this->fail("type file tidak diizinkan");
                 }

              }
            }else{
              foreach ($files['images'] as $file) {
                $a = $file->getClientMimeType();
                if ($a=="image/jpeg" || $a=="image/png" || $a=="image/jpg") {
                    $filesName = $file->getName();
                    $newName = _create_name_foto($filesName);
                    if ($file->isValid() && !$file->hasMoved()) {

                        $file->move($dir, $newName);

                        $namesForStored[] = $newName;
                    } else {
                      return $this->fail($file->getErrorString());
                    }




                 } else {
                    return $this->fail("type file tidak diizinkan");
                 }

              }
            }

            $uuid = new Uuid();

            $data = [
                'id' => $uuid->v4(),
                'product_barcode' => $barcode,
                'category_id' => $categoryProduk,
                'sub_category_id' => $subCategoryProduk,
                'product_title' => $namaProduk,
              	'product_satuan' => $satuanProduk,
                'product_description' => $deskripsiProduk,
                'product_price_buy' => $hargaBeliProduk,
                'product_price_sell' => $hargaJualProduk,
                'product_weight' => $beratProduk,
                'product_qty' => $qtyProduk,
                'product_status' => 1,
                'product_unlimited' => 0,
                'product_thumb' => $namesForStored[0],
                'product_image' => implode(",", $namesForStored),
                'fee_admin' => $feeAdmin,
                'toko_id' => $tokoId,
                'created_at' => date('Y-m-d H:i:s'),
            ];

            try {
                $post_id = $this->model->insert($data);
                $builder = $this->_db->table('_product_tb_b');
                $builder->insert($data);
            } catch (\Throwable $th) {
                foreach ($filesName as $name) {
                    unlink(FCPATH . './assets/uploads/' . $this->folderImage . '/' . $name);
                }
                return $this->fail($th);
            }

            return $this->respondCreated($data);
        }
    }
}
