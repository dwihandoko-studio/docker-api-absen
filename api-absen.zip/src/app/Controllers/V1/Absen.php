<?php

namespace App\Controllers\V1;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Absen\Permohonanlib;
use App\Libraries\Absen\Userlib;
use App\Libraries\Onesignallib;
use App\Libraries\Notificationlib;

class Absen extends ResourceController
{
    protected $modelName = 'App\Models\TokoModel';
    protected $format = 'json';

    var $folderImage = 'absen';

    private $_db;

    function __construct()
    {
        helper(['text','file', 'form', 'array', 'fotourl', 'filesystem']);
        $this->_db      = \Config\Database::connect();
    }

    public function index()
    {
        // $limit = 5;
        $limit = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 20;
        $page = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

        if ($page == 1) {
            $start = 0;
        } else {
            $start = (($page - 1) * $limit);
        }

		if (!$this->request->getGet('user')) {
          return $this->fail("user_id required");
        }

        if(!$this->request->getGet('idpegawai')) {
            $userId = htmlspecialchars($this->request->getGet('user'), true);
        } else {
            $userId = htmlspecialchars($this->request->getGet('idpegawai'), true);
        }

        
        $select = "id, user_id as userId, latitude, longitude, jenis_absen as jenisAbsenId, IF(jenis_absen = 1, 'Masuk', IF(jenis_absen = 2, 'Siang', 'Pulang')) as jenisAbsen, lampiran, keterangan, CONCAT( IF(HOUR(created_at) < 10, CONCAT('0',HOUR(created_at)),HOUR(created_at)), ':', IF(MINUTE(created_at) < 10, CONCAT('0',MINUTE(created_at)), MINUTE(created_at))) as waktuAbsen, DATE(created_at) as tglAbsen, created_at as createdAt";
      	
        $absens = $this->_db->table('_absen_tb')->select($select)->where('user_id', $userId)->orderBy('created_at', 'desc')->limit($limit, $start)->get()->getResult();

        $jumlahData = $this->_db->table('_absen_tb')->where('user_id', $userId)->countAllResults();
        if(count($absens) > 0) {
          $data['page'] = $page;
          $data['total_page'] = ceil($jumlahData / $limit);
          $data['total_result'] = $jumlahData;
          $data['result'] = $absens;
          return $this->respond($data);
        }else{
          return $this->respondNoContent('Tidak ada content.');
        }
    }
    
    public function add() {
        $rules = [
			'userId' => 'required|trim',
			'latitude' => 'required|trim',
			'longitude' => 'required|trim',
			'jenisAbsen' => 'required|trim',
			'lampiran' => 'uploaded[lampiran]|max_size[lampiran, 1024]|is_image[lampiran]'
		];
		
		if (!$this->validate($rules)) {
			return $this->fail($this->validator->getErrors());
// 			return $this->failValidationError($this->validator->getError());
		} else {
		    $userId = htmlspecialchars($this->request->getVar('userId'), true);
            $latitude = htmlspecialchars($this->request->getVar('latitude'), true);
            $longitude = htmlspecialchars($this->request->getVar('longitude'), true);
            $jenisAbsen = htmlspecialchars($this->request->getVar('jenisAbsen'), true);
            $keterangan = htmlspecialchars($this->request->getVar('keterangan'), true);
            
            // return $this->fail($jenisAbsen);
		    
		    if (!file_exists('./assets/uploads/' . $this->folderImage)) {
                mkdir('./assets/uploads/' . $this->folderImage, 0755);
                $dir = './assets/uploads/' . $this->folderImage;
            } else {
                $dir = './assets/uploads/' . $this->folderImage;
            }
            
            $userLib = new Userlib();
            $user = $userLib->getUser($userId);
            
            if(!$user){
                return $this->fail("User tidak ditemukan");
            }
            
            $uuid = new Uuid();

            $dataAbsen = [
                'id' => $uuid->v4(),
                'user_id' => $userId,
                'latitude' => $latitude,
                'longitude' => $longitude,
                'jenis_absen' => (int)$jenisAbsen,
                'keterangan' => $keterangan,
                'created_at' => date('Y-m-d H:i:s'),
            ];
		    
		    $lampiran = $this->request->getFile('lampiran');
			$filesNamelampiran = $lampiran->getName();
			$newNamelampiran = _create_name_foto($filesNamelampiran);
			
			if ($lampiran->isValid() && !$lampiran->hasMoved()) {
                $lampiran->move($dir, $newNamelampiran);
                $dataAbsen['lampiran'] = $newNamelampiran;
            } else {
                return $this->fail("Upload ");
                // return $this->fail($lampiran->getErrorString());
            }
            
            try{
                $builder = $this->_db->table('_absen_tb');
                $insertData = $builder->insert($dataAbsen);
            } catch (\Throwable $th) {
                unlink(FCPATH . $dir . '/' . $newNamelampiran);
                return $this->fail("menyimpan data");
                // return $this->fail($th);
            }

            if($dataAbsen['jenis_absen'] == "1") {
                $nameAbsen = "Masuk";
            } else if ($dataAbsen['jenis_absen'] == "2") {
                $nameAbsen = "Siang";
            } else {
                $nameAbsen = "Pulang";
            }
            
            
            $dataNotifSystem = [
                'id_absen' => $dataAbsen['id'],
                'title' => "Absen " . $nameAbsen,
                'description' => $user->fullname . " melakukan absen.",
                'send_from' => "system",
                'send_to' => "ATASAN",
                'action_page' => "detail_absen",
                'action_api' => "absen"
            ];
            $saveNotifSystem = new Notificationlib();
            $saveNotifSystem->send($dataNotifSystem);

            $dataNotif = [
                'send_to' => "ATASAN",
                'title' => "Absen " . $nameAbsen,
                'content' => $user->fullname . " melakukan absen.",
                'app_url' => "absen;".$dataAbsen['id'].";detail_absen"
            ];

            $onesignal = new Onesignallib();
            $send = $onesignal->pushNotifToAdmin($dataNotif);
            
            
            return $this->respond($dataAbsen);
		}
    }
}
