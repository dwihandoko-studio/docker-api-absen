<?php

namespace App\Controllers\V1;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Notificationlib;

class Message extends ResourceController
{
    //protected $modelName = 'App\Models\OrdermerchanppobModel';
    protected $format = 'json';
  	private $_db;

    var $folderImage = 'profile';

    function __construct()
    {
        helper(['form', 'text', 'array', 'fotourl', 'filesystem']);
      	$this->_db      = \Config\Database::connect();
    }

  	public function index() {
  	 //   return $this->fail('User cant Null');
      	$per_page = (int) htmlspecialchars($this->request->getVar('limit'), true) ? (int) htmlspecialchars($this->request->getVar('limit'), true) : 20;
        $start = (int) htmlspecialchars($this->request->getVar('start'), true) ? (int) htmlspecialchars($this->request->getVar('start'), true) : 0;
      	
      
      	if(!$this->request->getGet('senderId') && !$this->request->getGet('receivedId'))
          	return $this->fail('User cant Null'); 

      	$senderId = htmlspecialchars($this->request->getGet('senderId'), true);
      	$receivedId = htmlspecialchars($this->request->getGet('receivedId'), true);
      	$builder = $this->_db->table('_message_tb a');
      	
      	$where = "(send_to = '$senderId' AND send_from = '$receivedId') OR (send_to = '$receivedId' AND send_from = '$senderId')";
      	
      	$builder->select('a.id as id, a.description as isiPesan, a.send_from as senderId, a.send_to as receivedId, a.status_read as hasRead, a.status_send as hasSend, a.updated_at as readedAt, a.created_at as createdAt');
    //   	, b.fullname as fullnameSender, b.profile_picture as profilePictureSender, c.fullname as fullnameReceived, c.profile_picture as profilePictureReceived');
    //   	$builder->join('_profil_users_tb b', 'b.id = a.send_from');
    //   	$builder->join('_profil_users_tb c', 'c.id = a.send_to');
        $data['result'] = $builder->where($where)->orderBy('a.created_at', 'desc')->get($per_page, $start)->getResult();
        $data['total_result'] = $builder->where($where)->countAllResults();
      
        if ($data['total_result'] > 0) {
            $data['total_page'] = ceil($data['total_result'] / $per_page);
            return $this->respond($data);
        } else {
            return $this->respondNoContent('Tidak ada content.');
        }
      
    }
  
  	public function add() {
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            // 'userId' => 'required|min_length[3]|max_length[50]',
            'senderId' => 'required',
            'receivedId' => 'required',
            'message' => 'required',
            'createdAt' => 'required'
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
            $senderId = htmlspecialchars($this->request->getVar('senderId'), true);
            $receivedId = htmlspecialchars($this->request->getVar('receivedId'), true);
            $message = htmlspecialchars($this->request->getVar('message'), true);
            $createdAt = htmlspecialchars($this->request->getVar('createdAt'), true);
          
            $builder = $this->_db->table('_message_tb');
            $uuid = new Uuid();
            $data = [
                'id' => $uuid->v4(),
                'description' => $message,
                'send_from' => $senderId,
                'send_to' => $receivedId,
                'created_at' => $createdAt,
                'status_send' => 1,
                'status_read' => 0,
            ];
            $builder->insert($data);
            return $this->respond($data);
        }
    }
  
  	public function readed() {
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            'kodePermohonan' => 'required',
            'userId' => 'required'
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          $userId = htmlspecialchars($this->request->getVar('userId'), true);
          $kodeTransaksi = htmlspecialchars($this->request->getVar('kodePermohonan'), true);
          $view = new Notificationlib();
          $view->read($userId,$kodeTransaksi);
          return $this->respond("OK");
        }
    }
  
}
