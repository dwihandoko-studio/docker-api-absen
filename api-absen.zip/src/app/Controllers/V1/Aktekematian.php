<?php

namespace App\Controllers\V1;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Capil\Permohonanlib;
use App\Libraries\Capil\Userlib;
use App\Libraries\Onesignallib;
use App\Libraries\Notificationlib;

class Aktekematian extends ResourceController
{
    protected $modelName = 'App\Models\TokoModel';
    protected $format = 'json';

    var $folderImage = 'permohonan/aktakematian';

    private $_db;

    function __construct()
    {
        helper(['text','file', 'form', 'array', 'fotourl', 'filesystem']);
        $this->_db      = \Config\Database::connect();
    }

    public function index()
    {
        
        $per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
        $pag = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

        if ($pag == 1) {
            $start = 0;
        } else {
            $start = (($pag - 1) * $per_page);
        }

		if (!$this->request->getGet('toko')) {
          $where = [
            '_product_tb_b.product_status' => 1
          ];
        }else{
          $tokoId = htmlspecialchars($this->request->getGet('toko'), true);
          $where = [
            '_product_tb_b.toko_id' => $tokoId,
          ];
        }
        $select = "_product_tb_b.id as productId, _product_tb_b.product_barcode as productBarcode, _product_tb_b.product_title as productTitle, _product_tb_b.product_description as productDescription, _product_tb_b.product_price_buy as productPriceBuy, _product_tb_b.product_price_sell as productPriceSell, _product_tb_b.product_weight as productWeight, _product_tb_b.product_qty as productQty, _product_tb_b.product_status as productStatus, _product_tb_b.product_unlimited as productUnlimited, _product_tb_b.product_thumb as productThumb, _product_tb_b.product_image as productImage, _product_tb_b.created_at as createdAt, _product_tb_b.updated_at as updatedAt, _category_tb_b.category_name as categoryName, _sub_category_tb_b.sub_category_name as subCategoryName";
      	
        $products = $this->_db->table('_product_tb_b')->select($select)->join('_category_tb_b', '_product_tb_b.category_id = _category_tb_b.id')->join('_sub_category_tb_b', '_product_tb_b.sub_category_id = _sub_category_tb_b.id')->where($where)->orderBy('_product_tb_b.created_at', 'desc')->get()->getResult();

        if(count($products) > 0) {
          $data['result'] = $products;
          $data['total_result'] = count($products);
          return $this->respond($data);
        }else{
          return $this->respondNoContent('Tidak ada content.');
        }
    }
    
    public function buat() {
        $rules = [
			'userId' => 'required|trim',
// 			'nikPelapor' => 'required|trim',
// 			'kkPelapor' => 'required|trim',
// 			'namaPelapor' => 'required|trim',
// 			'alamatPelapor' => 'required|trim',
// 			'kecamatan' => 'required|trim',
			'hubungan' => 'required|trim',
			'nikAlmarhum' => 'required|trim',
			'kkAlmarhum' => 'required|trim',
			'namaAlmarhum' => 'required|trim',
			'tempatKematian' => 'required|trim',
			'tglKematian' => 'required|trim',
			'waktuKematian' => 'required|trim',
			'sebabKematian' => 'required|trim',
			'jenisKelaminAlmarhum' => 'required|trim',
			'keterangan' => 'required|trim',
			'lampiranKTP' => 'uploaded[lampiranKTP]|max_size[lampiranKTP, 1024]|is_image[lampiranKTP]',
			'lampiranKK' => 'uploaded[lampiranKK]|max_size[lampiranKK, 1024]|is_image[lampiranKK]'
		];
		
		$filenamelampiranFormulirAkte = dot_array_search('lampiranFormulirAkte.name', $_FILES);
		if($filenamelampiranFormulirAkte != '') {
		    $lampiranFormulirAkteVal = ['lampiranFormulirAkte' => 'uploaded[lampiranFormulirAkte]|max_size[lampiranFormulirAkte, 1024]|is_image[lampiranFormulirAkte]'];
		    $rules = array_merge($rules, $lampiranFormulirAkteVal);
		}
		
		$filenamelampiranSuratKeteranganKematian = dot_array_search('lampiranSuratKeteranganKematian.name', $_FILES);
		if($filenamelampiranSuratKeteranganKematian != '') {
		    $lampiranSuratKeteranganKematianVal = ['lampiranSuratKeteranganKematian' => 'uploaded[lampiranSuratKeteranganKematian]|max_size[lampiranSuratKeteranganKematian, 1024]|is_image[lampiranSuratKeteranganKematian]'];
		    $rules = array_merge($rules, $lampiranSuratKeteranganKematianVal);
		}
		
		$filenamelampiranDokumentPendukungLain = dot_array_search('lampiranDokumentPendukungLain.name', $_FILES);
		if($filenamelampiranDokumentPendukungLain != '') {
		    $lampiranDokumentPendukungLainVal = ['lampiranDokumentPendukungLain' => 'uploaded[lampiranDokumentPendukungLain]|max_size[lampiranDokumentPendukungLain, 1024]|is_image[lampiranDokumentPendukungLain]'];
		    $rules = array_merge($rules, $lampiranDokumentPendukungLainVal);
		}
		
		if (!$this->validate($rules)) {
			return $this->fail($this->validator->getErrors());
// 			return $this->failValidationError($this->validator->getError());
		} else {
		    $userId = htmlspecialchars($this->request->getVar('userId'), true);
		  //  $nikPelapor = htmlspecialchars($this->request->getVar('nikPelapor'), true);
		  //  $kkPelapor = htmlspecialchars($this->request->getVar('kkPelapor'), true);
		  //  $namaPelapor = htmlspecialchars($this->request->getVar('namaPelapor'), true);
		  //  $alamatPelapor = htmlspecialchars($this->request->getVar('alamatPelapor'), true);
		  //  $kecamatan = htmlspecialchars($this->request->getVar('kecamatan'), true);
		    $hubungan = htmlspecialchars($this->request->getVar('hubungan'), true);
		    $nikAlmarhum = htmlspecialchars($this->request->getVar('nikAlmarhum'), true);
		    $kkAlmarhum = htmlspecialchars($this->request->getVar('kkAlmarhum'), true);
		    $namaAlmarhum = htmlspecialchars($this->request->getVar('namaAlmarhum'), true);
		    $tempatKematian = htmlspecialchars($this->request->getVar('tempatKematian'), true);
		    $tglKematian = htmlspecialchars($this->request->getVar('tglKematian'), true);
		    $waktuKematian = htmlspecialchars($this->request->getVar('waktuKematian'), true);
		    $sebabKematian = htmlspecialchars($this->request->getVar('sebabKematian'), true);
		    $jenisKelaminAlmarhum = htmlspecialchars($this->request->getVar('jenisKelaminAlmarhum'), true);
		    $saksi1 = ($this->request->getVar('saksi1')) ? htmlspecialchars($this->request->getVar('saksi1'), true):null;
		    $saksi2 = ($this->request->getVar('saksi2')) ? htmlspecialchars($this->request->getVar('saksi2'), true):null;
		    $keterangan = htmlspecialchars($this->request->getVar('keterangan'), true);
		    
		    if (!file_exists('./assets/uploads/' . $this->folderImage)) {
                mkdir('./assets/uploads/' . $this->folderImage, 0755);
                $dir = './assets/uploads/' . $this->folderImage;
            } else {
                $dir = './assets/uploads/' . $this->folderImage;
            }
            
            $userLib = new Userlib();
            $user = $userLib->getUser($userId);
            
            if(!$user){
                return $this->fail("User tidak ditemukan");
            }
            
            $uuid = new Uuid();

            $dataPermohonan = [
                'id' => $uuid->v4(),
                'user_id' => $userId,
                'nik_pelapor' => $user->nik,
                'kk_pelapor' => $user->kk,
                'nama_pelapor' => $user->fullname,
                'alamat_pelapor' => $user->alamat,
                'kecamatan' => $user->kecamatan,
                'hubungan' => $hubungan,
                'nik_almarhum' => $nikAlmarhum,
                'kk_almarhum' => $kkAlmarhum,
                'nama_almarhum' => $namaAlmarhum,
                'tempat_kematian' => $tempatKematian,
                'tgl_kematian' => $tglKematian,
                'waktu_kematian' => $waktuKematian,
                'jenis_kelamin_almarhum' => $jenisKelaminAlmarhum,
                'saksi_1' => $saksi1,
                'saksi_2' => $saksi2,
                'keterangan' => $keterangan,
                'created_at' => date('Y-m-d H:i:s'),
            ];
		    
		    $lampiranKTP = $this->request->getFile('lampiranKTP');
			$filesNamelampiranKTP = $lampiranKTP->getName();
			$newNamelampiranKTP = _create_name_foto($filesNamelampiranKTP);
			
			if ($lampiranKTP->isValid() && !$lampiranKTP->hasMoved()) {
                $lampiranKTP->move($dir, $newNamelampiranKTP);
                $dataPermohonan['lampiran_ktp'] = $newNamelampiranKTP;
            } else {
                return $this->fail("Upload KTP");
                // return $this->fail($lampiranKTP->getErrorString());
            }
            
            $lampiranKK = $this->request->getFile('lampiranKK');
			$filesNamelampiranKK = $lampiranKK->getName();
			$newNamelampiranKK = _create_name_foto($filesNamelampiranKK);
			
			if ($lampiranKK->isValid() && !$lampiranKK->hasMoved()) {
                $lampiranKK->move($dir, $newNamelampiranKK);
                $dataPermohonan['lampiran_kk'] = $newNamelampiranKK;
            } else {
                unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                return $this->fail($lampiranKK->getErrorString());
            }
            
            if($filenamelampiranFormulirAkte != '') {
                $lampiranFormulirAkte = $this->request->getFile('lampiranFormulirAkte');
    			$filesNamelampiranFormulirAkte = $lampiranFormulirAkte->getName();
    			$newNamelampiranFormulirAkte = _create_name_foto($filesNamelampiranFormulirAkte);
    			
    			if ($lampiranFormulirAkte->isValid() && !$lampiranFormulirAkte->hasMoved()) {
                    $lampiranFormulirAkte->move($dir, $newNamelampiranFormulirAkte);
                    $dataPermohonan['lampiran_formulir_akte'] = $newNamelampiranFormulirAkte;
                } else {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    return $this->fail($lampiranFormulirAkte->getErrorString());
                }
            }
            
            if($filenamelampiranSuratKeteranganKematian != '') {
                $lampiranSuratKeteranganKematian = $this->request->getFile('lampiranSuratKeteranganKematian');
    			$filesNamelampiranSuratKeteranganKematian = $lampiranSuratKeteranganKematian->getName();
    			$newNamelampiranSuratKeteranganKematian = _create_name_foto($filesNamelampiranSuratKeteranganKematian);
    			
    			if ($lampiranSuratKeteranganKematian->isValid() && !$lampiranSuratKeteranganKematian->hasMoved()) {
                    $lampiranSuratKeteranganKematian->move($dir, $newNamelampiranSuratKeteranganKematian);
                    $dataPermohonan['lampiran_surat_keterangan_kematian'] = $newNamelampiranSuratKeteranganKematian;
                } else {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    if($filenamelampiranFormulirAkte != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_formulir_akte']);
                    }
                    return $this->fail($lampiranSuratKeteranganKematian->getErrorString());
                }
            }
            
            if($filenamelampiranDokumentPendukungLain != '') {
                $lampiranDokumentPendukungLain = $this->request->getFile('lampiranDokumentPendukungLain');
    			$filesNamelampiranDokumentPendukungLain = $lampiranDokumentPendukungLain->getName();
    			$newNamelampiranDokumentPendukungLain = _create_name_foto($filesNamelampiranDokumentPendukungLain);
    			
    			if ($lampiranDokumentPendukungLain->isValid() && !$lampiranDokumentPendukungLain->hasMoved()) {
                    $lampiranDokumentPendukungLain->move($dir, $newNamelampiranDokumentPendukungLain);
                    $dataPermohonan['lampiran_dokument_pendukung_lain'] = $newNamelampiranDokumentPendukungLain;
                } else {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    if($filenamelampiranFormulirAkte != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_formulir_akte']);
                    }
                    if($filenamelampiranSuratKeteranganKematian != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_surat_keterangan_kematian']);
                    }
                    return $this->fail($lampiranDokumentPendukungLain->getErrorString());
                }
            }
            //var_dump($dataPermohonan);die;
            $permohonanLib = new Permohonanlib();
            $inputPermohonanBaru = $permohonanLib->createPermohonan("AKTAKEMATIAN", $userId);
            
            
            if($inputPermohonanBaru) {
                try{
                    $dataPermohonan['kode_permohonan'] = $inputPermohonanBaru;
                    $builder = $this->_db->table('_permohonan_akte_kematian_tb');
                    $insertData = $builder->insert($dataPermohonan);
                } catch (\Throwable $th) {
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                    unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                    if($filenamelampiranFormulirAkte != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_formulir_akte']);
                    }
                    if($filenamelampiranSuratKeteranganKematian != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_surat_keterangan_kematian']);
                    }
                    if($filenamelampiranDokumentPendukungLain != ''){
                        unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_dokument_pendukung_lain']);
                    }
                    return $this->fail("menyimpan data");
                    // return $this->fail($th);
                }
                
                $dataNotifSystem = [
                  'kode_permohonan' => $dataPermohonan['kode_permohonan'],
                  'title' => "Permohonan Akta Kematian",
                  'description' => "Permohonan Pelaporan Kematian",
                  'send_from' => $dataPermohonan['user_id'],
                  'send_to' => "PENCATATAN_SIPIL",
                  'action_page' => "detail_akte_kematian",
                  'action_api' => "aktekematian"
                ];
                $saveNotifSystem = new Notificationlib();
                $saveNotifSystem->send($dataNotifSystem);

                $dataNotif = [
                  'send_to' => "PENCATATAN_SIPIL",
                  'title' => "Permohonan Akta Kematian",
                  'content' => "Permohonan Pelaporan Kematian",
                  'app_url' => "aktekematian;".$dataPermohonan['kode_permohonan'].";detail_akte_kematian"
                ];

                $onesignal = new Onesignallib();
                $send = $onesignal->pushNotifToAdmin($dataNotif);
                
                return $this->respond($dataPermohonan);
            } else {
                unlink(FCPATH . $dir . '/' . $newNamelampiranKTP);
                unlink(FCPATH . $dir . '/' . $newNamelampiranKK);
                if($filenamelampiranFormulirAkte != ''){
                    unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_formulir_akte']);
                }
                if($filenamelampiranSuratKeteranganKematian != ''){
                    unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_surat_keterangan_kematian']);
                }
                if($filenamelampiranDokumentPendukungLain != ''){
                    unlink(FCPATH . $dir . '/' . $dataPermohonan['lampiran_dokument_pendukung_lain']);
                }
                return $this->fail("menyimpan data permohonan");
            }
            
            
		}
    }
}
