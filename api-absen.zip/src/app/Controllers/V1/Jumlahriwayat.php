<?php

namespace App\Controllers\V1;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Capil\Permohonanlib;
use App\Libraries\Onesignallib;
use App\Libraries\Notificationlib;

class Jumlahriwayat extends ResourceController
{
    protected $modelName = 'App\Models\TokoModel';
    protected $format = 'json';

    var $folderImage = 'permohonan/aktakelahiran';

    private $_db;

    function __construct()
    {
        helper(['text','file', 'form', 'array', 'fotourl', 'filesystem']);
        $this->_db      = \Config\Database::connect();
    }

    public function count() {
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
            
        $rules = [
			'userId' => 'required|trim',
		];
		
		if (!$this->validate($rules)) {
			return $this->fail($this->validator->getErrors());
// 			return $this->failValidationError($this->validator->getError());
		} else {
		    $userId = htmlspecialchars($this->request->getVar('userId'), true);
		    
		    $builder = $this->_db->table('_permohonan_tb_b');
		    $where = [
		        'user_id' => $userId
		        ];
		    $cek = $builder->where($where)->get()->getResult();
		    
		    if(count($cek) > 0) {
		    $builders = $this->_db->table('_permohonan_tb_b');
		    $select = "COUNT(*) as total, COUNT(IF(status_permohonan = 0, 1, NULL)) 'antrian', COUNT(IF(status_permohonan = 1, 1, NULL)) 'diproses', COUNT(IF(status_permohonan = 2, 1, NULL)) 'selesai', COUNT(IF(status_permohonan > 2, 1, NULL)) 'ditolak', user_id as userId";
		    $result = $builders->select($select)->where($where)->get()->getRowObject();
		    return $this->respond($result);
		    }else{
		        return $this->respondNoContent('Tidak ada content');
		    }
		}
    }
}
