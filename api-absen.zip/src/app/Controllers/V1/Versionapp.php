<?php

namespace App\Controllers\V1;

use CodeIgniter\RESTful\ResourceController;

class VersionApp extends ResourceController
{
    // protected $modelName = 'App\Models\VersionAppModel';
    protected $format = 'json';

    var $folderImage = 'slider';

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
    }

    public function index()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('_version_app_tb_b');
        $select = "id as idApp, app_name as appName, package_name as packageName, version_app as version, build_number_app as buildNumber, url_playstore as urlPlaystore, url_appstore as urlAppstore, is_active as is_active, created_at as created_at";
        $where = "is_active = 1";
        $data = $builder->select($select)->where($where)->orderBy('created_at', 'DESC')->get()->getRowObject();

        if ($data) {
            return $this->respond($data);
        } else {
            return $this->respondNoContent('Tidak ada content.');
        }
    }
}
