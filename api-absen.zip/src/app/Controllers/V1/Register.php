<?php

namespace App\Controllers\V1;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Capil\Niklib;
use App\Libraries\Capil\Userlib;

class Register extends ResourceController
{
    protected $modelName = 'App\Models\UserModel';
    protected $format = 'json';

    var $folderImage = 'user';
  	private $_db;

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
      	$this->_db = \Config\Database::connect();
    }

    public function index()
    {
      	return $this->fail("tidak ada data");
    }
    
    public function ceknik()
    {
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
      
        $rules = [
            'nik' => 'required|trim|is_unique[_users_tb.nik]',
        ];
      
      	if (!$this->validate($rules)) {
      	    $res['message'] = $this->validator->getErrors();
            return $this->respondCreated($res);
        } else {
            $nik = htmlspecialchars($this->request->getVar('nik'), true);
            
            $nikLib = new Niklib();
            $a = $nikLib->cekNik($nik);
            //var_dump($a);die;
            if($a) {
                $userLib = new Userlib();
                $user = $userLib->cekUser($nik);
                if($user) {
                    $res['message'] = "NIK telah terdaftar di aplikasi. Silahkan melakukan Login.";
                    return $this->respondCreated($res);
                }
                if((int)$a->AGAMA == 1) {
                    $agama = "ISLAM";
                }else if((int)$a->AGAMA == 2) {
                    $agama = "KRISTEN";
                }else if((int)$a->AGAMA == 3) {
                    $agama = "KATHOLIK";
                }else if((int)$a->AGAMA == 4) {
                    $agama = "HINDU";
                }else if((int)$a->AGAMA == 5) {
                    $agama = "BUDHA";
                }else if((int)$a->AGAMA == 6) {
                    $agama = "KONGHUCHU";
                }else{
                    $agama = "KEPERCAYAAN";
                }
                $data = [
                    'nik' => $a->NIK,
                    'kk' => $a->NO_KK,
                    'namaLengkap' => $a->NAMA_LGKP,
                    'jenisKelamin' => $a->JENIS_KLMIN_EKTP,
                    'tempatLahir' => $a->TMPT_LHR,
                    'tglLahir' => $a->TGL_LHR,
                    'agama' => $agama,
                    'pekerjaan' => $a->JENIS_PKRJN_EKTP,
                    'kodeAlamat' => $a->NO_PROP . "-" . $a->NO_KAB . "-" . $a->NO_KEC . "-" . $a->NO_KEL,
                    'provinsi' => $a->NAMA_PROP_EKTP,
                    'kabupaten' => $a->NAMA_KAB_EKTP,
                    'kecamatan' => $a->NAMA_KEC_EKTP,
                    'kelurahan' => $a->NAMA_KEL_EKTP,
                    'alamat' => $a->ALAMAT . ";" . $a->NO_RT . "/" . $a->NO_RW . ";" . $a->KODE_POS,
                    ];
                return $this->respond($data);
            }else{
                return $this->respondNoContent('Tidak ada content.');
            }
        }
    }
    
    public function cekuser() {
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            // 'userId' => 'required|min_length[3]|max_length[50]',
            'email' => 'required|trim|valid_email|is_unique[_users_tb.email]',
            'nohp' => 'required|trim|numeric|is_unique[_users_tb.no_hp]',
        ];

        if (!$this->validate($rules)) {
            if ($this->validator->hasError('email')) {
                if($this->validator->hasError('nohp')){
                    $errorEmail = ($this->validator->getError('email') === "The email field must contain a unique value.") ? "Email" : $this->validator->getError('email');
                    $errorNohp = ($this->validator->getError('nohp') === "The nohp field must contain a unique value.") ? "No Handphone sudah terdaftar." : $this->validator->getError('nohp');
                    $res['message'] =  $errorEmail . " dan " . $errorNohp;
                }else{
                    $res['message'] = ($this->validator->getError('email') == "The email field must contain a unique value.") ? "Email sudah terdaftar." : $this->validator->getError('email');
                }
            //return $this->respondCreated($res);
            }else{
                $res['message'] = ($this->validator->getError('nohp') == "The nohp field must contain a unique value.") ? "No Handphone sudah terdaftar." : $this->validator->getError('nohp');
            }
          	//$res['message'] = $this->validator->getErrors();
            return $this->respondCreated($res);
        } else {
            
            $email = htmlspecialchars($this->request->getVar('email'), true);
          	$nohp = htmlspecialchars($this->request->getVar('nohp'), true);
          
          	$data = [
          	    'email' => $email,
          	    'nohp' => $nohp,
          	];
          	
          	return $this->respond($data);
          	
          	$token = random_string('numeric', 6);

            $startTime = date('Y-m-d H:i:s');
            // $expired = date('Y-m-d H:i:s');
            $expired = date('Y-m-d H:i:s', strtotime('+1 hour', strtotime($startTime)));
          
            $data = [
              'email' => $email,
              'token' => $token,
              'expired' => $expired,
            ];
          
        //   	$id = $model->insert($data);
			
          	$data['timeExpired'] = $startTime;
          
        //   	$smsOtp = new Smsotp();
        //   	$resOtp = $smsOtp->sendOtp($nohp, "<#> Moroarto: Your code is ". $token ." \n HBbDHCBNV/Y");
          	return $this->respond($data);
            
        }
    }
    
    public function storeuser() {
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            // 'userId' => 'required|min_length[3]|max_length[50]',
            'email' => 'required|trim|valid_email|is_unique[_users_tb.email]',
            'nohp' => 'required|trim|numeric|is_unique[_users_tb.no_hp]',
            'nik' => 'required|trim|numeric|is_unique[_users_tb.nik]',
            'password' => 'required|trim',
            'uuid' => 'required|trim',
            // 'kk' => 'required|trim',
            'fullname' => 'required|trim',
            // 'tempatLahir' => 'required|trim',
            // 'tanggalLahir' => 'required|trim',
            // 'agama' => 'required|trim',
            'alamat' => 'required|trim',
            // 'kodeAlamat' => 'required|trim',
            // 'provinsi' => 'required|trim',
            // 'kabupaten' => 'required|trim',
            // 'kecamatan' => 'required|trim',
            // 'kelurahan' => 'required|trim',
        ];

        if (!$this->validate($rules)) {
          	//$res['message'] = $this->validator->getErrors();
            return $this->fail($this->validator->getErrors());
            // return $this->fail("error validation");
        } else {
            
            $email = htmlspecialchars($this->request->getVar('email'), true);
          	$nohp = htmlspecialchars($this->request->getVar('nohp'), true);
          	$nik = htmlspecialchars($this->request->getVar('nik'), true);
          	$password = htmlspecialchars($this->request->getVar('password'), true);
          	$uuid = htmlspecialchars($this->request->getVar('uuid'), true);
          	$kk = htmlspecialchars($this->request->getVar('kk'), true)??null;
          	$fullname = htmlspecialchars($this->request->getVar('fullname'), true);
          	$tempatLahir = htmlspecialchars($this->request->getVar('tempatLahir'), true)??null;
          	$tanggalLahir = htmlspecialchars($this->request->getVar('tanggalLahir'), true)??null;
          	$agama = htmlspecialchars($this->request->getVar('agama'), true)??"";
          	$jenisKelamin = htmlspecialchars($this->request->getVar('jenisKelamin'), true) ?? "BELUM DISETEL";
          	$alamat = htmlspecialchars($this->request->getVar('alamat'), true);
          	$kodeAlamat = htmlspecialchars($this->request->getVar('kodeAlamat'), true)??null;
          	$provinsi = htmlspecialchars($this->request->getVar('provinsi'), true)??null;
          	$kabupaten = htmlspecialchars($this->request->getVar('kabupaten'), true)??null;
          	$kecamatan = htmlspecialchars($this->request->getVar('kecamatan'), true)??null;
          	$kelurahan = htmlspecialchars($this->request->getVar('kelurahan'), true)??null;
          	$date = date('Y-m-d H:i:s');
          
            $data = [
                'id' => $uuid,
                'nik' => $nik,
                'email' => $email,
                'no_hp' => $nohp,
                'password' => password_hash($password, PASSWORD_DEFAULT),
                'created_at' => $date,
            ];
            
            try {
          	
              	$builder = $this->_db->table('_users_tb');
              	$builder->insert($data);
              	
              	$dataProfil = [
                    'id' => $uuid,
                    'nik' => $nik,
                    'email' => $email,
                    'no_hp' => $nohp,
                    'fullname' => $fullname,
                    'kk' => $kk,
                    'tempat_lahir' => $tempatLahir,
                    'tgl_lahir' => $tanggalLahir,
                    'agama' => $agama,
                    'jenis_kelamin' => $jenisKelamin,
                    'alamat' => $alamat,
                    'kode_alamat' => $kodeAlamat,
                    'provinsi' => $provinsi,
                    'kabupaten' => $kabupaten,
                    'kecamatan' => $kecamatan,
                    'kelurahan' => $kelurahan,
                    'created_at' => $date,
                ];
              	
              	$builderProfil = $this->_db->table('_profil_users_tb');
              	$builderProfil->insert($dataProfil);
              	
              	return $this->respond($dataProfil);
            } catch (exception $th) {
                //print_r($th);
                return $this->fail("error insert");
            }
          	
        }
    }
}