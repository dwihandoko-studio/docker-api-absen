<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;

class Userlogin extends ResourceController
{
	protected $modelName = 'App\Models\UserloginModel';
	protected $format = 'json';

	var $folderImage = 'profile';

	function __construct()
	{
		helper(['form', 'array', 'fotourl', 'filesystem']);
	}

	public function index()
	{
		$per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
		$pag = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

		if ($pag == 1) {
			$start = 0;
		} else {
			$start = (($pag - 1) * $per_page);
		}


		if (!$this->request->getGet('username')) {
			$data['result'] = $this->model->findAll($per_page, $start);
			$data['total_result'] = $this->model->countAllResults();
		} else {
			$keyword = htmlspecialchars($this->request->getGet('username'), true);

			$data['result'] = $this->model->where('email', $keyword)->findAll($per_page, $start);
			$data['total_result'] = $this->model->where('email', $keyword)->countAllResults();
		}


		// $data['result'] = $this->model->findAll($per_page, $start);
		// $data['total_result'] = $this->model->countAllResults();
		if ($data['total_result'] > 0) {
			$data['page'] = $pag;
			$data['total_page'] = ceil($data['total_result'] / $per_page);
			return $this->respond($data);
		} else {
			return $this->respondNoContent('Tidak ada content.');
		}
	}

	public function create()
	{
		$rules = [
			'opd' => 'required',
			'category' => 'required',
			'user_id' => 'required',
			'title' => 'required|min_length[6]',
			'description' => 'required',
			'image' => 'uploaded[image]|max_size[image, 1024]|is_image[image]'
		];
		// $img = ['featured_image' => 'uploaded[featured_image]|mime_in[featured_image,image/jpg,image/png,image/gif,image/jpeg]|max_size[featured_image, 1024]'];

		if (!$this->validate($rules)) {
			return $this->fail($this->validator->getError());
		} else {
			//get the file
			$title = htmlspecialchars($this->request->getVar('title'), true);
			$opd = htmlspecialchars($this->request->getVar('opd'), true);
			$category = htmlspecialchars($this->request->getVar('category'), true);

			$file = $this->request->getFile('image');
			$filesName = $file->getName();
			$newName = _create_name_foto($filesName);
			// if (!$file->isValid())
			// 	return $this->fail($file->getErrorString());

			// $file->move('./assets/uploads');

			if (!file_exists('./assets/uploads/' . $this->folderImage . '/' . $opd)) {
				mkdir('./assets/uploads/' . $this->folderImage . '/' . $opd, 0777);
				$dir = './assets/uploads/' . $this->folderImage . '/' . $opd;
			} else {
				$dir = './assets/uploads/' . $this->folderImage . '/' . $opd;
			}

			if ($file->isValid() && !$file->hasMoved()) {
				try {
					$file->move($dir, $newName);
				} catch (\Throwable $th) {
					return $this->fail($th);
				}
			} else {
				return $this->fail($file->getErrorString());
			}

			$data = [
				'post_opd' => $opd,
				'post_category' => $category,
				'post_user_id' => htmlspecialchars($this->request->getVar('user_id'), true),
				'post_title' => $title,
				'post_description' => $this->request->getVar('description'),
				'post_url' => _create_url($opd, $category, $title),
				'post_trending' => htmlspecialchars($this->request->getVar('trending'), true),
				'post_tag' => htmlspecialchars($this->request->getVar('tag'), true),
				'post_featured_image' => $newName,
				'post_is_active' => htmlspecialchars($this->request->getVar('is_active'), true),
				'post_created_at' => date('Y-m-d H:i:s'),
			];
			try {
				$post_id = $this->model->insert($data);
				$data['id'] = $post_id;
			} catch (\Throwable $th) {
				return $this->fail($th);
			}
			return $this->respondCreated($data);
		}
	}

	public function show($id = null)
	{
		$data = $this->model->find($id);
		if ($data) {
			return $this->respond($data);
		} else {
			return $this->failNotFound('Item not found');
		}
	}

	public function update($id = null)
	{
		$oldData = $this->model->find($id);
		$rules = [
			'opd' => 'required',
			'category' => 'required',
			'user_id' => 'required',
			'title' => 'required|min_length[6]',
			'description' => 'required'
		];


		$filename = dot_array_search('image.name', $_FILES);

		if ($filename != '') {
			$img = ['image' => 'uploaded[image]|max_size[image, 1024]|is_image[image]'];
			// $img = ['featured_image' => 'uploaded[featured_image]|mime_in[featured_image,image/jpg,image/png,image/gif,image/jpeg]|max_size[featured_image, 1024]'];
			$rules = array_merge($rules, $img);
		}



		if (!$this->validate($rules)) {
			return $this->failValidationError($this->validator->getError());
		} else {
			// $input = $this->request->getRawInput();
			$title = htmlspecialchars($this->request->getVar('title'), true);
			$opd = htmlspecialchars($this->request->getVar('opd'), true);
			$category = htmlspecialchars($this->request->getVar('category'), true);


			$data = [
				'id' => htmlspecialchars($id, true),
				'post_opd' => $opd,
				'post_category' => $category,
				'post_title' => $title,
				'post_description' => htmlspecialchars($this->request->getVar('description'), true),
				'post_url' => _create_url($opd, $category, $title),
				'post_trending' => htmlspecialchars($this->request->getVar('trending'), true),
				'post_tag' => htmlspecialchars($this->request->getVar('tag'), true),
				'post_is_active' => htmlspecialchars($this->request->getVar('is_active'), true),
				'post_updated_at' => date('Y-m-d H:i:s'),
			];

			if ($filename != '') {


				$file = $this->request->getFile('image');
				$filesName = $file->getName();
				$newName = _create_name_foto($filesName);
				// if (!$file->isValid())
				// 	return $this->fail($file->getErrorString());

				// $file->move('./assets/uploads');

				// if (!file_exists('./assets/uploads/' . $this->folderImage . '/' . $opd)) {
				// 	mkdir('./assets/uploads/' . $this->folderImage . '/' . $opd, 0777);
				// 	$dir = './assets/uploads/' . $this->folderImage . '/' . $opd;
				// } else {
				$dir = './assets/uploads/' . $this->folderImage . '/' . $opd;
				// }



				// $file = $this->request->getFile('image');
				// $filesName = $file->getName();
				// $newName = _create_name_foto($filesName);
				// if (!$file->isValid())
				// 	return $this->fail($file->getErrorString());
				if ($file->isValid() && !$file->hasMoved()) {
					try {
						$file->move($dir, $newName);
						$oldFileName = $oldData['post_featured_image'];
						unlink(FCPATH . $dir . '/' . $oldFileName);
						$data['post_featured_image'] = $newName;
					} catch (\Throwable $th) {
						// return $this->fail($th);
						return $this->failNotFound('gagal upload');
					}
				} else {
					// return $this->fail($file->getErrorString());
					return $this->failNotFound('gagal valid file');
				}
			}
			try {
				$this->model->save($data);
			} catch (\Throwable $th) {
				// return $this->fail($th);
				return $this->failNotFound('gagal simpan database');
			}
			return $this->respond($data);
		}
	}

	public function delete($id = null)
	{
		$data = $this->model->find($id);
		if ($data) {
			try {
				$fileName = $data['post_featured_image'];
				$opd = $data['post_opd'];
				// delete_files('./assets/uploads/' . $fileName);
				unlink(FCPATH . './assets/uploads/' . $this->folderImage . '/' . $opd . '/' . $fileName);
				$this->model->delete($id);
				$dat['status'] = "deleted";
				$dat['message'] = "item data berhasil di hapus.";
				$dat['descripsi'] = "item data denga id " . $data['id'] . "berhasil di hapus";
				$dat['data'] = $data;
				return $this->respondDeleted($dat);
			} catch (\Throwable $th) {
				return $this->fail($th);
			}
		} else {
			return $this->failNotFound('Item not found');
		}
	}
}
