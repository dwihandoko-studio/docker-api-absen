<?php

namespace App\Controllers\V1;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Notificationlib;
use App\Libraries\Capil\Permohonanlib;

class Permohonan extends ResourceController
{
    protected $modelName = 'App\Models\TokoModel';
    protected $format = 'json';

    var $folderImage = 'permohonan/kk';

    private $_db;

    function __construct()
    {
        helper(['text','file', 'form', 'array', 'fotourl', 'filesystem']);
        $this->_db      = \Config\Database::connect();
    }

    public function index()
    {
        
        $limit = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
        $start = (int) htmlspecialchars($this->request->getGet('start'), true) ? (int) htmlspecialchars($this->request->getGet('start'), true) : 0;

		if (!$this->request->getGet('user')) {
		    return $this->fail("User required");
		}
		
        $userId = htmlspecialchars($this->request->getGet('user'), true);
        $permohonanLib = new Permohonanlib();
        $result = $permohonanLib->getPermohonanUser($userId,12, $limit, $start);

        if($result) {
        //   $data['result'] = $products;
        //   $data['total_result'] = count($products);
          return $this->respond($result);
        }else{
          return $this->respondNoContent('Tidak ada content.');
        }
    }
    
    public function detail()
    {
        
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

		$rules = [
            'userId' => 'required|trim',
            'kodePermohonan' => 'required|trim',
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
		
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            $kodePermohonan = htmlspecialchars($this->request->getVar('kodePermohonan'), true);
            
            $kode = explode("-", $kodePermohonan);
            
            if($kode[0] == "KK"){
                $permohonanLib = new Permohonanlib();
                $result = $permohonanLib->getDetailPermohonananKk($kodePermohonan);
                
                if($result) {
                    if($userId == $result->userId){
                        $notifLib = new Notificationlib();
                        $notifLib->read($userId, $result->kodePermohonan);
                    }
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }else if($kode[0] == "AKTAKEL") {
                $permohonanLib = new Permohonanlib();
                $result = $permohonanLib->getDetailPermohonananAkteKelahiran($kodePermohonan);
                
                if($result) {
                    if($userId == $result->userId){
                        $notifLib = new Notificationlib();
                        $notifLib->read($userId, $result->kodePermohonan);
                    }
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }else if($kode[0] == "KIA") {
                $permohonanLib = new Permohonanlib();
                $result = $permohonanLib->getDetailPermohonananKia($kodePermohonan);
                
                if($result) {
                    if($userId == $result->userId){
                        $notifLib = new Notificationlib();
                        $notifLib->read($userId, $result->kodePermohonan);
                    }
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }else if($kode[0] == "KTP") {
                $permohonanLib = new Permohonanlib();
                $result = $permohonanLib->getDetailPermohonananKtp($kodePermohonan);
                
                if($result) {
                    if($userId == $result->userId){
                        $notifLib = new Notificationlib();
                        $notifLib->read($userId, $result->kodePermohonan);
                    }
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }else if($kode[0] == "CEKNIK") {
                $permohonanLib = new Permohonanlib();
                $result = $permohonanLib->getDetailPermohonananCekNik($kodePermohonan);
                
                if($result) {
                    if($userId == $result->userId){
                        $notifLib = new Notificationlib();
                        $notifLib->read($userId, $result->kodePermohonan);
                    }
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }else if($kode[0] == "UPDATEDATA") {
                $permohonanLib = new Permohonanlib();
                $result = $permohonanLib->getDetailPermohonananUpdateData($kodePermohonan);
                
                if($result) {
                    if($userId == $result->userId){
                        $notifLib = new Notificationlib();
                        $notifLib->read($userId, $result->kodePermohonan);
                    }
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }else if($kode[0] == "AKTACER") {
                $permohonanLib = new Permohonanlib();
                $result = $permohonanLib->getDetailPermohonananAktePerceraian($kodePermohonan);
                
                if($result) {
                    if($userId == $result->userId){
                        $notifLib = new Notificationlib();
                        $notifLib->read($userId, $result->kodePermohonan);
                    }
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }else if($kode[0] == "AKTAKEMATIAN") {
                $permohonanLib = new Permohonanlib();
                $result = $permohonanLib->getDetailPermohonananAkteKematian($kodePermohonan);
                
                if($result) {
                    if($userId == $result->userId){
                        $notifLib = new Notificationlib();
                        $notifLib->read($userId, $result->kodePermohonan);
                    }
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }else if($kode[0] == "AKTAKAWIN") {
                $permohonanLib = new Permohonanlib();
                $result = $permohonanLib->getDetailPermohonananAktePerkawinan($kodePermohonan);
                
                if($result) {
                    if($userId == $result->userId){
                        $notifLib = new Notificationlib();
                        $notifLib->read($userId, $result->kodePermohonan);
                    }
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }else if($kode[0] == "SRTPINDAH") {
                $permohonanLib = new Permohonanlib();
                $result = $permohonanLib->getDetailPermohonananSuratPindah($kodePermohonan);
                
                if($result) {
                    if($userId == $result->userId){
                        $notifLib = new Notificationlib();
                        $notifLib->read($userId, $result->kodePermohonan);
                    }
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }
        }
    }
    
    public function antrian()
    {
        
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

		$rules = [
            'userId' => 'required|trim',
            'limit' => 'required|trim',
            'start' => 'required|trim',
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
		
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            $limit = htmlspecialchars($this->request->getVar('limit'), true);
            $start = htmlspecialchars($this->request->getVar('start'), true);
            
            $permohonanLib = new Permohonanlib();
            $result = $permohonanLib->getPermohonanUser($userId, 0, (int)$limit, (int)$start);
    
            if($result) {
            //   $data['result'] = $products;
            //   $data['total_result'] = count($products);
              return $this->respond($result);
            }else{
              return $this->respondNoContent('Tidak ada content.');
            }
        }
    }
    
    public function diproses()
    {
        
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

		$rules = [
            'userId' => 'required|trim',
            'limit' => 'required|trim',
            'start' => 'required|trim',
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
		
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            $limit = htmlspecialchars($this->request->getVar('limit'), true);
            $start = htmlspecialchars($this->request->getVar('start'), true);
            
            $permohonanLib = new Permohonanlib();
            $result = $permohonanLib->getPermohonanUser($userId, 1, (int)$limit, (int)$start);
    
            if($result) {
            //   $data['result'] = $products;
            //   $data['total_result'] = count($products);
              return $this->respond($result);
            }else{
              return $this->respondNoContent('Tidak ada content.');
            }
        }
    }
    
    public function batal()
    {
        
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

		$rules = [
            'userId' => 'required|trim',
            'limit' => 'required|trim',
            'start' => 'required|trim',
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
		
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            $limit = htmlspecialchars($this->request->getVar('limit'), true);
            $start = htmlspecialchars($this->request->getVar('start'), true);
            
            $permohonanLib = new Permohonanlib();
            $result = $permohonanLib->getPermohonanUser($userId, 3, (int)$limit, (int)$start);
    
            if($result) {
            //   $data['result'] = $products;
            //   $data['total_result'] = count($products);
              return $this->respond($result);
            }else{
              return $this->respondNoContent('Tidak ada content.');
            }
        }
    }
    
    public function selesai()
    {
        
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

		$rules = [
            'userId' => 'required|trim',
            'limit' => 'required|trim',
            'start' => 'required|trim',
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
		
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            $limit = htmlspecialchars($this->request->getVar('limit'), true);
            $start = htmlspecialchars($this->request->getVar('start'), true);
            
            $permohonanLib = new Permohonanlib();
            $result = $permohonanLib->getPermohonanUser($userId, 2, (int)$limit, (int)$start);
    
            if($result) {
            //   $data['result'] = $products;
            //   $data['total_result'] = count($products);
              return $this->respond($result);
            }else{
              return $this->respondNoContent('Tidak ada content.');
            }
        }
    }
    
    public function dokumentselesai()
    {
        
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

		$rules = [
            'userId' => 'required|trim',
            // 'limit' => 'required|trim',
            // 'start' => 'required|trim',
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
		
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            // $limit = htmlspecialchars($this->request->getVar('limit'), true);
            // $start = htmlspecialchars($this->request->getVar('start'), true);
            
            $permohonanLib = new Permohonanlib();
            $result = $permohonanLib->getDokumentSelesai($userId);
            
            // var_dump($result);die;
    
            if(count($result) > 0) {
              $data['result'] = $result;
              $data['totalResult'] = count($result);
              return $this->respond($data);
            }else{
              return $this->respondNoContent('Tidak ada content.');
            }
        }
    }
}