<?php

namespace App\Controllers\V1\Admin;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Capil\Admin\Permohonanadminlib;
use App\Libraries\Onesignallib;
use App\Libraries\Notificationlib;

class Permohonan extends ResourceController
{
    protected $modelName = 'App\Models\TokoModel';
    protected $format = 'json';

    var $folderImage = 'permohonan/lampiranselesai';

    private $_db;

    function __construct()
    {
        helper(['text','file', 'form', 'array', 'fotourl', 'filesystem']);
        $this->_db      = \Config\Database::connect();
    }

    public function index()
    {
        
        $limit = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
        $start = (int) htmlspecialchars($this->request->getGet('start'), true) ? (int) htmlspecialchars($this->request->getGet('start'), true) : 0;

		if (!$this->request->getGet('user')) {
		    return $this->fail("User required");
		}
		
        $userId = htmlspecialchars($this->request->getGet('user'), true);
        $permohonanLib = new Permohonanadminlib();
        $result = $permohonanLib->getPermohonanUser($userId,12, $limit, $start);

        if($result) {
        //   $data['result'] = $products;
        //   $data['total_result'] = count($products);
          return $this->respond($result);
        }else{
          return $this->respondNoContent('Tidak ada content.');
        }
    }
    
    public function detail()
    {
        
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

		$rules = [
            'userId' => 'required|trim',
            'kodePermohonan' => 'required|trim',
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
		
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            $kodePermohonan = htmlspecialchars($this->request->getVar('kodePermohonan'), true);
            
            $kode = explode("-", $kodePermohonan);
            
            if($kode[0] == "KK"){
                $permohonanLib = new Permohonanadminlib();
                $result = $permohonanLib->getDetailPermohonananKk($kodePermohonan);
                
                if($result) {
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }else if($kode[0] == "AKTAKEL") {
                $permohonanLib = new Permohonanadminlib();
                $result = $permohonanLib->getDetailPermohonananAkteKelahiran($kodePermohonan);
                
                if($result) {
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }else if($kode[0] == "KIA") {
                $permohonanLib = new Permohonanadminlib();
                $result = $permohonanLib->getDetailPermohonananKia($kodePermohonan);
                
                if($result) {
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }else if($kode[0] == "KTP") {
                $permohonanLib = new Permohonanadminlib();
                $result = $permohonanLib->getDetailPermohonananKtp($kodePermohonan);
                
                if($result) {
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }else if($kode[0] == "CEKNIK") {
                $permohonanLib = new Permohonanadminlib();
                $result = $permohonanLib->getDetailPermohonananCekNik($kodePermohonan);
                
                if($result) {
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }else if($kode[0] == "UPDATEDATA") {
                $permohonanLib = new Permohonanadminlib();
                $result = $permohonanLib->getDetailPermohonananUpdateData($kodePermohonan);
                
                if($result) {
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }else if($kode[0] == "AKTACER") {
                $permohonanLib = new Permohonanadminlib();
                $result = $permohonanLib->getDetailPermohonananAktePerceraian($kodePermohonan);
                
                if($result) {
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }else if($kode[0] == "AKTAKEMATIAN") {
                $permohonanLib = new Permohonanadminlib();
                $result = $permohonanLib->getDetailPermohonananAkteKematian($kodePermohonan);
                
                if($result) {
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }else if($kode[0] == "AKTAKAWIN") {
                $permohonanLib = new Permohonanadminlib();
                $result = $permohonanLib->getDetailPermohonananAktePerkawinan($kodePermohonan);
                
                if($result) {
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }else if($kode[0] == "SRTPINDAH") {
                $permohonanLib = new Permohonanadminlib();
                $result = $permohonanLib->getDetailPermohonananSuratPindah($kodePermohonan);
                
                if($result) {
                    return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
            }
        }
    }
    
    public function antrian()
    {
        
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

		$rules = [
            'userId' => 'required|trim',
            'limit' => 'required|trim',
            'start' => 'required|trim',
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
		
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            $limit = htmlspecialchars($this->request->getVar('limit'), true);
            $start = htmlspecialchars($this->request->getVar('start'), true);
            
            $builder = $this->_db->table('_profil_users_tb');
            $select = "_user_level_access_tb.hak_access";
            $where = [
                '_profil_users_tb.id' => $userId,
                '_user_level_access_tb.is_active' => 1,
            ];
            $dataRes = $builder->select($select)->join('_user_level_access_tb', '_user_level_access_tb.level = _profil_users_tb.role_user')->where($where)->get()->getResult();
            
            // //var_dump($dataRes);die;
            
            if(count($dataRes) > 0) {
                $whereGet = [];
                foreach ($dataRes as $val) {
                    $whereGet[] = $val->hak_access;
                }
                $permohonanLib = new Permohonanadminlib();
                $result = $permohonanLib->getPermohonanUser($whereGet, 0, (int)$limit, (int)$start);
        
                if($result) {
                //   $data['result'] = $products;
                //   $data['total_result'] = count($products);
                  return $this->respond($result);
                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }
                
            } else{
                return $this->respondNoContent('Akses tidak diizinkan.');
            }
            
        }
    }
    
    public function diproses()
    {
        
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

		$rules = [
            'userId' => 'required|trim',
            'limit' => 'required|trim',
            'start' => 'required|trim',
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
		
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            $limit = htmlspecialchars($this->request->getVar('limit'), true);
            $start = htmlspecialchars($this->request->getVar('start'), true);
            
            $permohonanLib = new Permohonanadminlib();
            $result = $permohonanLib->getPermohonanUser($userId, 1, (int)$limit, (int)$start);
    
            if($result) {
            //   $data['result'] = $products;
            //   $data['total_result'] = count($products);
              return $this->respond($result);
            }else{
              return $this->respondNoContent('Tidak ada content.');
            }
        }
    }
    
    public function batal()
    {
        
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

		$rules = [
            'userId' => 'required|trim',
            'limit' => 'required|trim',
            'start' => 'required|trim',
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
		
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            $limit = htmlspecialchars($this->request->getVar('limit'), true);
            $start = htmlspecialchars($this->request->getVar('start'), true);
            
            $permohonanLib = new Permohonanadminlib();
            $result = $permohonanLib->getPermohonanUser($userId, 3, (int)$limit, (int)$start);
    
            if($result) {
            //   $data['result'] = $products;
            //   $data['total_result'] = count($products);
              return $this->respond($result);
            }else{
              return $this->respondNoContent('Tidak ada content.');
            }
        }
    }
    
    public function selesai()
    {
        
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

		$rules = [
            'userId' => 'required|trim',
            'limit' => 'required|trim',
            'start' => 'required|trim',
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
		
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            $limit = htmlspecialchars($this->request->getVar('limit'), true);
            $start = htmlspecialchars($this->request->getVar('start'), true);
            
            $permohonanLib = new Permohonanadminlib();
            $result = $permohonanLib->getPermohonanUser($userId, 2, (int)$limit, (int)$start);
    
            if($result) {
            //   $data['result'] = $products;
            //   $data['total_result'] = count($products);
              return $this->respond($result);
            }else{
              return $this->respondNoContent('Tidak ada content.');
            }
        }
    }
    
    private function _getDataSendNotif($kodePermohonan, $from, $to, $status)
    {
        $kode = explode("-", $kodePermohonan);
                
        $dataNotifSystem = [
          'kode_permohonan' => $kodePermohonan,
          'send_from' => $from,
          'send_to' => $to,
        ];
        
        $dataNotif = [
          'send_to' => $to,
        ];
    
        if($kode[0] == "KK"){
            $dataNotif['title'] = "Permohonan KK" . $status;
            $dataNotif['content'] = "Permohonan KK" . $status;
            $dataNotif['app_url'] = "kk;".$kodePermohonan.";detail_kk";
            $dataNotifSystem['title'] = "Permohonan KK" . $status;
            $dataNotifSystem['description'] = "Permohonan KK" . $status;
            $dataNotifSystem['action_page'] = "detail_kk";
            $dataNotifSystem['action_api'] = "kk";
        }else if($kode[0] == "AKTAKEL") {
            $dataNotif['title'] = "Permohonan Akte Kelahiran" . $status;
            $dataNotif['content'] = "Permohonan Akte Kelahiran" . $status;
            $dataNotif['app_url'] = "aktekelahiran;".$kodePermohonan.";detail_akte_kelahiran";
            $dataNotifSystem['title'] = "Permohonan Akte Kelahiran" . $status;
            $dataNotifSystem['description'] = "Permohonan Akte Kelahiran" . $status;
            $dataNotifSystem['action_page'] = "detail_akte_kelahiran";
            $dataNotifSystem['action_api'] = "aktekelahiran";
        }else if($kode[0] == "KIA") {
            $dataNotif['title'] = "Permohonan KIA" . $status;
            $dataNotif['content'] = "Permohonan KIA" . $status;
            $dataNotif['app_url'] = "kia;".$kodePermohonan.";detail_kia";
            $dataNotifSystem['title'] = "Permohonan KIA" . $status;
            $dataNotifSystem['description'] = "Permohonan Kartu Identitas Anak" . $status;
            $dataNotifSystem['action_page'] = "detail_kia";
            $dataNotifSystem['action_api'] = "kia";
        }else if($kode[0] == "KTP") {
            $dataNotif['title'] = "Permohonan KTP" . $status;
            $dataNotif['content'] = "Permohonan KTP" . $status;
            $dataNotif['app_url'] = "ktp;".$kodePermohonan.";detail_ktp";
            $dataNotifSystem['title'] = "Permohonan KTP" . $status;
            $dataNotifSystem['description'] = "Permohonan Kartu Tanda Penduduk" . $status;
            $dataNotifSystem['action_page'] = "detail_ktp";
            $dataNotifSystem['action_api'] = "ktp";
        }else if($kode[0] == "CEKNIK") {
            $dataNotif['title'] = "Permohonan CEK NIK" . $status;
            $dataNotif['content'] = "Permohonan CEK NIK" . $status;
            $dataNotif['app_url'] = "ceknik;".$kodePermohonan.";detail_cek_nik";
            $dataNotifSystem['title'] = "Permohonan CEK NIK" . $status;
            $dataNotifSystem['description'] = "Permohonan CEK NIK" . $status;
            $dataNotifSystem['action_page'] = "detail_cek_nik";
            $dataNotifSystem['action_api'] = "ceknik";
        }else if($kode[0] == "UPDATEDATA") {
            $dataNotif['title'] = "Permohonan Update Data" . $status;
            $dataNotif['content'] = "Permohonan Update Data" . $status;
            $dataNotif['app_url'] = "updatedata;".$kodePermohonan.";detail_update_data";
            $dataNotifSystem['title'] = "Permohonan Update Data" . $status;
            $dataNotifSystem['description'] = "Permohonan Update Data" . $status;
            $dataNotifSystem['action_page'] = "detail_update_data";
            $dataNotifSystem['action_api'] = "updatedata";
        }else if($kode[0] == "AKTACER") {
            $dataNotif['title'] = "Permohonan Akta Cerai" . $status;
            $dataNotif['content'] = "Permohonan Akta Cerai" . $status;
            $dataNotif['app_url'] = "akteperceraian;".$kodePermohonan.";detail_akte_perceraian";
            $dataNotifSystem['title'] = "Permohonan Akta Cerai" . $status;
            $dataNotifSystem['description'] = "Permohonan Akta Perceraian" . $status;
            $dataNotifSystem['action_page'] = "detail_akte_perceraian";
            $dataNotifSystem['action_api'] = "akteperceraian";
        }else if($kode[0] == "AKTAKEMATIAN") {
            $dataNotif['title'] = "Permohonan Akta Kematian" . $status;
            $dataNotif['content'] = "Permohonan Akta Kematian" . $status;
            $dataNotif['app_url'] = "aktekematian;".$kodePermohonan.";detail_akte_kematian";
            $dataNotifSystem['title'] = "Permohonan Akta Kematian" . $status;
            $dataNotifSystem['description'] = "Permohonan Akta Kematian" . $status;
            $dataNotifSystem['action_page'] = "detail_akte_kematian";
            $dataNotifSystem['action_api'] = "aktekematian";
        }else if($kode[0] == "AKTAKAWIN") {
            $dataNotif['title'] = "Permohonan Akta Perkawinan" . $status;
            $dataNotif['content'] = "Permohonan Akta Perkawinan" . $status;
            $dataNotif['app_url'] = "akteperkawinan;".$kodePermohonan.";detail_akte_perkawinan";
            $dataNotifSystem['title'] = "Permohonan Akta Perkawinan" . $status;
            $dataNotifSystem['description'] = "Permohonan Akta Perkawinan" . $status;
            $dataNotifSystem['action_page'] = "detail_akte_perkawinan";
            $dataNotifSystem['action_api'] = "akteperkawinan";
        }else if($kode[0] == "SRTPINDAH") {
            $dataNotif['title'] = "Permohonan Surat Pindah" . $status;
            $dataNotif['content'] = "Permohonan Surat Pindah" . $status;
            $dataNotif['app_url'] = "suratpindah;".$kodePermohonan.";detail_surat_pindah";
            $dataNotifSystem['title'] = "Permohonan Surat Pindah" . $status;
            $dataNotifSystem['description'] = "Permohonan Surat Pindah" . $status;
            $dataNotifSystem['action_page'] = "detail_surat_pindah";
            $dataNotifSystem['action_api'] = "suratpindah";
        }else {
            $dataNotif['title'] = "Permohonan Surat Pindah" . $status;
            $dataNotif['content'] = "Permohonan Surat Pindah" . $status;
            $dataNotif['app_url'] = "suratpindah;".$kodePermohonan.";detail_surat_pindah";
            $dataNotifSystem['title'] = "Permohonan Surat Pindah" . $status;
            $dataNotifSystem['description'] = "Permohonan Surat Pindah" . $status;
            $dataNotifSystem['action_page'] = "detail_surat_pindah";
            $dataNotifSystem['action_api'] = "suratpindah";
        }
        
        $data['dataNotif'] = $dataNotif;
        $data['dataNotifSystem'] = $dataNotifSystem;
        
        return $data;
    }
    
    public function ketolak()
    {
        
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

		$rules = [
            'userId' => 'required|trim',
            'pemohon' => 'required|trim',
            'kodePermohonan' => 'required|trim',
            'keterangan' => 'required|trim',
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
		
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            $pemohon = htmlspecialchars($this->request->getVar('pemohon'), true);
            $kodePermohonan = htmlspecialchars($this->request->getVar('kodePermohonan'), true);
            $keterangan = htmlspecialchars($this->request->getVar('keterangan'), true);
            
            $permohonanLib = new Permohonanadminlib();
            $result = $permohonanLib->changeToTolak($userId, $pemohon, $kodePermohonan, $keterangan);
    
            if($result) {
                $notif = $this->_getDataSendNotif($kodePermohonan, $userId, $pemohon, " Ditolak");
                
                try {
                    $saveNotifSystem = new Notificationlib();
                    $saveNotifSystem->send($notif['dataNotifSystem']);
    
                    $onesignal = new Onesignallib();
                    $send = $onesignal->pushNotifToUser($notif['dataNotif']);
                    
                    //var_dump($send);
                } catch (exception $e) {
                    $builder = $this->_db->table('log_send_onesignal');
                    $dataLog = [
                      	'data' => json_encode($e),
                      	'created_at' => date('Y-m-d H:i:s'),
                    ];
              		$builderLog->insert($dataLog);
                }
                
                return $this->respond($result);
            }else{
                return $this->fail('gagal update.');
            }
        }
    }
    
    public function keproses()
    {
        
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

		$rules = [
            'userId' => 'required|trim',
            'pemohon' => 'required|trim',
            'kodePermohonan' => 'required|trim',
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
		
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            $pemohon = htmlspecialchars($this->request->getVar('pemohon'), true);
            $kodePermohonan = htmlspecialchars($this->request->getVar('kodePermohonan'), true);
            
            $permohonanLib = new Permohonanadminlib();
            $result = $permohonanLib->changeToProses($userId, $pemohon, $kodePermohonan);
    
            if($result) {
                $notif = $this->_getDataSendNotif($kodePermohonan, $userId, $pemohon, " Diproses");
                
                try {
                    $saveNotifSystem = new Notificationlib();
                    $saveNotifSystem->send($notif['dataNotifSystem']);
    
                    $onesignal = new Onesignallib();
                    $send = $onesignal->pushNotifToUser($notif['dataNotif']);
                    
                    //var_dump($send);
                } catch (exception $e) {
                    $builder = $this->_db->table('log_send_onesignal');
                    $dataLog = [
                      	'data' => json_encode($e),
                      	'created_at' => date('Y-m-d H:i:s'),
                    ];
              		$builderLog->insert($dataLog);
                }
                
                return $this->respond($result);
            }else{
                return $this->fail('gagal update.');
            }
        }
    }
    
    public function keselesai()
    {
        
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');

		$rules = [
            'userId' => 'required|trim',
            'pemohon' => 'required|trim',
            'kodePermohonan' => 'required|trim',
            'keterangan' => 'required|trim',
        ];
        
        
		$filenamelampiran = dot_array_search('lampiran.name', $_FILES);
		//var_dump($filenamelampiran);die;
		if($filenamelampiran != '') {
		    $lampiranVal = ['lampiran' => 'uploaded[lampiran]|max_size[lampiran, 2028]', 'lampiranName' => 'required|trim'];
		    $rules = array_merge($rules, $lampiranVal);
		}
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
		
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            $pemohon = htmlspecialchars($this->request->getVar('pemohon'), true);
            $kodePermohonan = htmlspecialchars($this->request->getVar('kodePermohonan'), true);
            $keterangan = htmlspecialchars($this->request->getVar('keterangan'), true);
            
            if (!file_exists('./assets/uploads/' . $this->folderImage)) {
                mkdir('./assets/uploads/' . $this->folderImage, 0755);
                $dir = './assets/uploads/' . $this->folderImage;
            } else {
                $dir = './assets/uploads/' . $this->folderImage;
            }
            
            $permohonanLib = new Permohonanadminlib();
            
            if($filenamelampiran != '') {
                $lampiran = $this->request->getFile('lampiran');
                $filesNamelampiran = htmlspecialchars($this->request->getVar('lampiranName'), true);
    // 			$filesNamelampiran = $lampiran->getName();
    // 			var_dump($filesNamelampiran);die;
    			$newNamelampiran = _create_name_foto($filesNamelampiran);
    			
    			if ($lampiran->isValid() && !$lampiran->hasMoved()) {
                    $lampiran->move($dir, $newNamelampiran);
                    
                    $file_parts = pathinfo($filesNamelampiran);
                    $exts = $file_parts['extension'];
                    if($exts == 'pdf'){
                        $typeFile = 1;
                    }else{
                        $typeFile = 0;
                    }
                    
                    $result = $permohonanLib->changeToSelesai($userId, $pemohon, $kodePermohonan, $keterangan, $newNamelampiran, $typeFile);
                } else {
                    // return $this->fail($lampiranFormulirAkte->getErrorString());
                    $result = false;
                }
            }else{
                $result = $permohonanLib->changeToSelesai($userId, $pemohon, $kodePermohonan, $keterangan);
            }
            
            
    
            if($result) {
                $notif = $this->_getDataSendNotif($kodePermohonan, $userId, $pemohon, " Selesai");
                
                try {
                    $saveNotifSystem = new Notificationlib();
                    $saveNotifSystem->send($notif['dataNotifSystem']);
    
                    $onesignal = new Onesignallib();
                    $send = $onesignal->pushNotifToUser($notif['dataNotif']);
                    
                    //var_dump($send);
                } catch (exception $e) {
                    $builder = $this->_db->table('log_send_onesignal');
                    $dataLog = [
                      	'data' => json_encode($e),
                      	'created_at' => date('Y-m-d H:i:s'),
                    ];
              		$builderLog->insert($dataLog);
                }
                
                return $this->respond($result);
            }else{
                return $this->fail('gagal update.');
            }
        }
    }
}