<?php

namespace App\Controllers\V1;

use CodeIgniter\RESTful\ResourceController;

class Sliderpublic extends ResourceController
{
    protected $modelName = 'App\Models\SliderhomeModel';
    protected $format = 'json';

    var $folderImage = 'slider';

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
    }

    public function index()
    {
        // $opd = htmlspecialchars($this->request->getGet('opd'), true);
        $per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
        $pag = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

        if ($pag == 1) {
            $start = 0;
        } else {
            $start = (($pag - 1) * $per_page);
        }

        if (!$this->request->getGet('keyword')) {
            $where = [
                'slider_is_active' => 1
            ];
            $select = "id as id, bg_color as bgColor, slider_title as title,  slider_featured_image as image, slider_url as url, slider_created_at as createdAt";
            $data['result'] = $this->model->select($select)->where($where)->orderBy('slider_created_at', 'desc')->findAll();
            // $data['result'] = $this->model->findAll($per_page, $start);
            $data['total_result'] = $this->model->where($where)->countAllResults();
        } else {
            $keyword = htmlspecialchars($this->request->getGet('keyword'), true);

            $where = "slider_is_active = 1 AND (slider_title LIKE '%$keyword%' OR slider_description LIKE '%$keyword%')";
            $select = "id as id, bg_color as bgColor, slider_title as title,  slider_featured_image as image, slider_url as url, slider_created_at as createdAt";
            $data['result'] = $this->model->select($select)->where($where)->orderBy('slider_created_at', 'desc')->findAll($per_page, $start);
            $data['total_result'] = $this->model->where($where)->countAllResults();
        }


        // $data['result'] = $this->model->findAll($per_page, $start);
        // $data['total_result'] = $this->model->countAllResults();
        if ($data['total_result'] > 0) {
            $data['page'] = $pag;
            $data['total_page'] = ceil($data['total_result'] / $per_page);
            return $this->respond($data);
        } else {
            return $this->respondNoContent('Tidak ada content.');
        }
    }

    public function show($url = null)
    {
        $where = [
            'slider_is_active' => 1
        ];
        $data = $this->model->where($where)->findurl(htmlspecialchars($url, true));
        if ($data) {
            $ip = htmlspecialchars($this->request->getGet('ip'), true);
            return $this->respond($data);
        } else {
            return $this->failNotFound('Item not found');
        }
    }
}
