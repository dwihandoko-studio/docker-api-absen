<?php

namespace App\Controllers\V1;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Absen\Userlib;

class Jabatan extends ResourceController
{
	// protected $modelName = 'App\Models\AlamatpengirimanModel';
	protected $format = 'json';

	var $folderImage = 'profile';
  	private $_db;

	function __construct()
	{
		helper(['form','text', 'array', 'fotourl', 'filesystem']);
      	$this->_db = \Config\Database::connect();
	}

	public function index()
	{
        $limit = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 20;
        $page = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

        if ($page == 1) {
            $start = 0;
        } else {
            $start = (($page - 1) * $limit);
        }

		if (!$this->request->getGet('user')) {
          return $this->fail("user_id required");
        }

        // if (!$this->request->getGet('admin')) {
        //     $where = [
        //         'user_id' => $userId,
        //     ];
        // } else {
        //     $where = [
        //         'user_id' => $userId
        //     ];
        // }
        if(!$this->request->getGet('instansi')){
            $userId = htmlspecialchars($this->request->getGet('user'), true);
            
            $select = "a.id, a.jabatan, a.instansi_id as instansiId, a.instansi_induk as indukInstansi, b.instansi";
            
            $absens = $this->_db->table('_jabatan_tb a')->select($select)->join('_instansi_tb b', 'b.id = a.instansi_id')->where('a.user_id', $userId)->limit($limit, $start)->get()->getResult();

            $jumlahData = $this->_db->table('_jabatan_tb a')->where('a.user_id', $userId)->countAllResults();
        }else{

            $userId = htmlspecialchars($this->request->getGet('user'), true);
            $instansi = htmlspecialchars($this->request->getGet('instansi'), true);
            $select = "a.id, a.jabatan, a.instansi_id as instansiId, a.instansi_induk as indukInstansi, b.instansi";
            
            $absens = $this->_db->table('_jabatan_tb a')->select($select)->join('_instansi_tb b', 'b.id = a.instansi_id')->where(['a.user_id' => $userId, 'a.instansi_id' => $instansi])->orderBy('a.created_at', 'desc')->orderBy('a.created_at', 'desc')->limit($limit, $start)->get()->getResult();

            $jumlahData = $this->_db->table('_jabatan_tb a')->where(['a.user_id' => $userId, 'a.instansi_id' => $instansi])->countAllResults();
        }
        if(count($absens) > 0) {
          $data['page'] = $page;
          $data['total_page'] = ceil($jumlahData / $limit);
          $data['total_result'] = $jumlahData;
          $data['result'] = $absens;
          return $this->respond($data);
        }else{
          return $this->respondNoContent('Tidak ada content.');
        }
	}

	public function add()
	{
        // return $this->fail("work");
		$rules = [
			'userId' => 'required',
            'instansi' => 'required',
            'jabatan' => 'required',
		];

		if (!$this->validate($rules)) {
			return $this->fail($this->validator->getErrors());
		} else {
			$uuid = new Uuid();
          
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            
            $userLib = new Userlib();
            $user = $userLib->getUser($userId);

            if($user) {

                $data = [
                    'id' => $uuid->v4(),
                    'user_id' => $userId,
                    'instansi_induk' => $user->instansi_induk,
                    'instansi_id' => htmlspecialchars($this->request->getVar('instansi'), true),
                    'jabatan' => htmlspecialchars($this->request->getVar('jabatan'), true),
                    'created_at' => date('Y-m-d H:i:s'),
                ];
            
                try {
                    $builder = $this->_db->table('_jabatan_tb');
                    $user_id = $builder->insert($data);
                    
                } catch (Exception $th) {
                    return $this->fail($th);
                }
                
                return $this->respondCreated($data);
            } else {
                return $this->fail("user tidak ditemukan");
            }
		}
	}

	public function show($id = null)
	{
		$data = $this->model->find($id);
		if ($data) {
			return $this->respond($data);
		} else {
			return $this->failNotFound('Item not found');
		}
	}

	public function update($id = null)
	{
		$oldData = $this->model->find($id);
		$rules = [
			'firsname' => 'required|min_length[3]|max_length[50]',
			'lastname' => 'required|min_length[3]|max_length[50]',
			'email' => 'required|valid_email|is_unique[_users_tb.email]',
			'instansi' => 'required',
			'level' => 'required',
			// 'password' => 'required|min_length[6]',
			// 'password_confirm' => 'matches[password]',
		];

		if (!$this->validate($rules)) {
			return $this->failValidationError($this->validator->getError());
		} else {
			$data = [
				'id' => htmlspecialchars($id, true),
				'firsname' => htmlspecialchars($this->request->getVar('firsname'), true),
				'lastname' => htmlspecialchars($this->request->getVar('lastname'), true),
				'email' => htmlspecialchars($this->request->getVar('email'), true),
				// 'password' => htmlspecialchars($this->request->getVar('password'), true),
				'intansi_id' => htmlspecialchars($this->request->getVar('instansi'), true),
				'level' => htmlspecialchars($this->request->getVar('level'), true),
				'is_active' => htmlspecialchars($this->request->getVar('is_active'), true),
				'updated_at' => date('Y-m-d H:i:s'),
			];

			try {
				$this->model->save($data);
				// unset($data['password']);
			} catch (\Throwable $th) {
				return $this->fail($th);
				// return $this->failNotFound('gagal simpan database');
			}
			return $this->respond($data);
		}
	}

	public function delete($id = null)
	{
		$data = $this->model->find($id);
		if ($data) {
			try {
				$this->model->delete($id);
				$dat['status'] = "deleted";
				$dat['message'] = "Item data berhasil di hapus.";
				$dat['description'] = "User " . $data['email'] . " berhasil di hapus";
				$dat['data'] = $data;
				return $this->respondDeleted($dat);
			} catch (\Throwable $th) {
				return $this->fail($th);
			}
		} else {
			return $this->failNotFound('Item not found');
		}
	}
}
