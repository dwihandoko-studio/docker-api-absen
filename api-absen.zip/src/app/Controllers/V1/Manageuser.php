<?php

namespace App\Controllers\V1;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Absen\Userlib;

class Manageuser extends ResourceController
{
	// protected $modelName = 'App\Models\AlamatpengirimanModel';
	protected $format = 'json';

	var $folderImage = 'profile';
  	private $_db;

	function __construct()
	{
		helper(['form','text', 'array', 'fotourl', 'filesystem']);
      	$this->_db = \Config\Database::connect();
	}

	public function index()
	{
        // return $this->fail("user_id required");
        $limit = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 20;
        $page = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

        if ($page == 1) {
            $start = 0;
        } else {
            $start = (($page - 1) * $limit);
        }

		if (!$this->request->getGet('user')) {
          return $this->fail("user_id required");
        }

        // if (!$this->request->getGet('admin')) {
        //     $where = [
        //         'user_id' => $userId,
        //     ];
        // } else {
        //     $where = [
        //         'user_id' => $userId
        //     ];
        // }

        $userId = htmlspecialchars($this->request->getGet('user'), true);
        $select = "a.id, a.fullname, a.nik as nipNik, a.email, a.no_hp as nohp, a.jabatan_id as jabatanId, b.jabatan, a.instansi_id as instansiId, c.instansi, a.profile_picture as imageProfil, a.player_id_onesignal as idOnesignal, a.role_user as roleUser, a.is_active as status, a.created_at as createdAt, a.updated_at as updatedAt";
      	// $where = "";
        $absens = $this->_db->table('_profil_users_tb a')->select($select)->join('_jabatan_tb b', 'b.id = a.jabatan_id', 'LEFT')->join('_instansi_tb c', 'c.id = a.instansi_id', 'LEFT')->where("a.instansi_induk = (SELECT instansi_induk FROM _profil_users_tb WHERE id = '$userId')")->orderBy('a.fullname', 'asc')->limit($limit, $start)->get()->getResult();

        $jumlahData = $this->_db->table('_profil_users_tb a')->where("a.instansi_induk = (SELECT instansi_induk FROM _profil_users_tb WHERE id = '$userId')")->countAllResults();
        if(count($absens) > 0) {
          $data['page'] = $page;
          $data['total_page'] = ceil($jumlahData / $limit);
          $data['total_result'] = $jumlahData;
          $data['result'] = $absens;
          return $this->respond($data);
        }else{
          return $this->respondNoContent('Tidak ada content.');
        }
	}

	public function add()
	{
        // return $this->fail("work");
		$rules = [
			'userId' => 'required',
            'fullname' => 'required',
            'nik' => 'required',
            'email' => 'required',
            'nohp' => 'required',
            'instansi' => 'required',
            'jabatan' => 'required',
		];

		if (!$this->validate($rules)) {
			return $this->fail($this->validator->getErrors());
		} else {
			$uuid = new Uuid();
          
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            $nik = htmlspecialchars($this->request->getVar('nik'), true);
            $fullname = htmlspecialchars($this->request->getVar('fullname'), true);
            $email = htmlspecialchars($this->request->getVar('email'), true);
            $nohp = htmlspecialchars($this->request->getVar('nohp'), true);
            
            $userLib = new Userlib();
            $user = $userLib->getUser($userId);

            if($user) {

                $userCekLib = new Userlib();
                $alreadyUser = $userCekLib->cekUser($user->instansi_induk, $nik, $email, $nohp);

                if((int)$alreadyUser > 0) {
                    return $this->respond("User sudah terdaftar.");
                }else {
                    $uuidStore = $uuid->v4();
                    $date = date('Y-m-d H:i:s');
                    $dataProfil = [
                        'id' => $uuidStore,
                        'fullname' => $fullname,
                        'nik' => $nik,
                        'email' => $email,
                        'no_hp' => $nohp,
                        'instansi_induk' => $user->instansi_induk,
                        'instansi_id' => htmlspecialchars($this->request->getVar('instansi'), true),
                        'jabatan_id' => htmlspecialchars($this->request->getVar('jabatan'), true),
                        'created_at' => $date
                    ];

                    $dataUser = [
                        'id' => $uuidStore,
                        'nik' => $nik,
                        'email' => $email,
                        'no_hp' => $nohp,
                        'password' => password_hash($nik, PASSWORD_DEFAULT),
                        'created_at' => $date,
                    ];
                
                    try {
                        $builder = $this->_db->table('_users_tb');
                        $builder->insert($dataUser);

                        $builderProfil = $this->_db->table('_profil_users_tb');
                        $user_id = $builderProfil->insert($dataProfil);

                        return $this->respondCreated($dataProfil);
                        
                    } catch (Exception $th) {
                        return $this->fail($th);
                    }
                    
                }
            } else {
                return $this->fail("user tidak ditemukan");
            }
		}
	}

	public function show($id = null)
	{
		$data = $this->model->find($id);
		if ($data) {
			return $this->respond($data);
		} else {
			return $this->failNotFound('Item not found');
		}
	}

	public function update($id = null)
	{
		$oldData = $this->model->find($id);
		$rules = [
			'firsname' => 'required|min_length[3]|max_length[50]',
			'lastname' => 'required|min_length[3]|max_length[50]',
			'email' => 'required|valid_email|is_unique[_users_tb.email]',
			'instansi' => 'required',
			'level' => 'required',
			// 'password' => 'required|min_length[6]',
			// 'password_confirm' => 'matches[password]',
		];

		if (!$this->validate($rules)) {
			return $this->failValidationError($this->validator->getError());
		} else {
			$data = [
				'id' => htmlspecialchars($id, true),
				'firsname' => htmlspecialchars($this->request->getVar('firsname'), true),
				'lastname' => htmlspecialchars($this->request->getVar('lastname'), true),
				'email' => htmlspecialchars($this->request->getVar('email'), true),
				// 'password' => htmlspecialchars($this->request->getVar('password'), true),
				'intansi_id' => htmlspecialchars($this->request->getVar('instansi'), true),
				'level' => htmlspecialchars($this->request->getVar('level'), true),
				'is_active' => htmlspecialchars($this->request->getVar('is_active'), true),
				'updated_at' => date('Y-m-d H:i:s'),
			];

			try {
				$this->model->save($data);
				// unset($data['password']);
			} catch (\Throwable $th) {
				return $this->fail($th);
				// return $this->failNotFound('gagal simpan database');
			}
			return $this->respond($data);
		}
	}

	public function delete($id = null)
	{
		$data = $this->model->find($id);
		if ($data) {
			try {
				$this->model->delete($id);
				$dat['status'] = "deleted";
				$dat['message'] = "Item data berhasil di hapus.";
				$dat['description'] = "User " . $data['email'] . " berhasil di hapus";
				$dat['data'] = $data;
				return $this->respondDeleted($dat);
			} catch (\Throwable $th) {
				return $this->fail($th);
			}
		} else {
			return $this->failNotFound('Item not found');
		}
	}
}
