<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;

class Berita extends ResourceController
{
	protected $modelName = 'App\Models\BeritaModel';
	protected $format = 'json';

	var $folderImage = 'berita';

	function __construct()
	{
		helper(['form', 'array', 'fotourl', 'filesystem']);
	}

	public function index()
	{
		$opd = htmlspecialchars($this->request->getGet('opd'), true);
		$per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
		$pag = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

		if ($pag == 1) {
			$start = 0;
		} else {
			$start = (($pag - 1) * $per_page);
		}


		if ($opd) {
			// $dataFirs = $this->model->where(['post_opd' => $opd])->findAll();
			// return $this->respond($dataFirs);
			// $filename = dot_array_search('image.name', $_FILES);

			if (!$this->request->getGet('keyword')) {
				$data['result'] = $this->model->where(['post_opd' => $opd])->findAll();
				// $data['result'] = $this->model->where(['post_opd' => $opd])->findAll($per_page, $start);
				$data['total_result'] = $this->model->where(['post_opd' => $opd])->countAllResults();
			} else {
				$keyword = htmlspecialchars($this->request->getGet('keyword'), true);
				// $keyword = '/' . htmlspecialchars($this->request->getGet('keyword'), true) . '/';
				// $searchOrWhere = [
				// 	'post_title' => $keyword,
				// 	'post_description' => $keyword,
				// 	'post_tag' => $keyword
				// ];
				// $dataFirs = $this->model->where(['post_opd' => $opd])->orLike($searchOrWhere)->findAll();
				// $fun = array_search($opd, array_column($dataFirs, 'post_opd'));
				// $fun = searchFromArray($dataFirs, 'post_opd', $opd);
				// $fun = _array_search_dot(['post_title' => $keyword, 'post_description' => $keyword], $dataFirs);
				// return $this->respond($fun);
				$where = "post_opd = $opd AND (post_title LIKE '%$keyword%' OR post_description LIKE '%$keyword%' OR post_tag LIKE '%$keyword%')";

				$data['result'] = $this->model->where($where)->findAll($per_page, $start);
				$data['total_result'] = $this->model->where($where)->countAllResults();
			}
		} else {
			if (!$this->request->getGet('keyword')) {
				$data['result'] = $this->model->findAll();
				// $data['result'] = $this->model->findAll($per_page, $start);
				$data['total_result'] = $this->model->countAllResults();
			} else {
				$keyword = htmlspecialchars($this->request->getGet('keyword'), true);
				$searchOrWhere = [
					'post_title' => $keyword,
					'post_description' => $keyword,
					'post_tag' => $keyword
				];
				// $where = "post_title LIKE '$keyword' OR post_description LIKE '$keyword' OR post_tags LIKE '$keyword'";
				// $where = "post_title LIKE '$keyword' OR post_description LIKE '$keyword' OR post_tags LIKE '$keyword'";
				// $where = "post_title LIKE '%.$keyword.%' ESCAPE '!'OR post_description LIKE '%testing%' ESCAPE '!'OR `post_tag` LIKE '%testing%' ESCAPE '!'";

				$data['result'] = $this->model->orLike($searchOrWhere)->findAll($per_page, $start);
				$data['total_result'] = $this->model->orLike($searchOrWhere)->countAllResults();
			}


			// $data['result'] = $this->model->findAll($per_page, $start);
			// $data['total_result'] = $this->model->countAllResults();
		}
		if ($data['total_result'] > 0) {
			$data['page'] = $pag;
			$data['total_page'] = ceil($data['total_result'] / $per_page);
			return $this->respond($data);
		} else {
			return $this->respondNoContent('Tidak ada content.');
		}
	}

	public function create()
	{
		$rules = [
			'opd' => 'required',
			// 'category' => 'required',
			'user_id' => 'required',
			'title' => 'required',
			'description' => 'required',
			'image' => 'uploaded[image]|max_size[image, 1024]|is_image[image]'
		];
		// $img = ['featured_image' => 'uploaded[featured_image]|mime_in[featured_image,image/jpg,image/png,image/gif,image/jpeg]|max_size[featured_image, 1024]'];

		if (!$this->validate($rules)) {
			return $this->fail($this->validator->getError());
		} else {
			//get the file
			$title = htmlspecialchars($this->request->getVar('title'), true);
			$opd = htmlspecialchars($this->request->getVar('opd'), true);

			$file = $this->request->getFile('image');
			$filesName = $file->getName();
			$newName = _create_name_foto($filesName);
			// if (!$file->isValid())
			// 	return $this->fail($file->getErrorString());

			// $file->move('./assets/uploads');

			if (!file_exists('./assets/uploads/' . $this->folderImage . '/' . $opd)) {
				mkdir('./assets/uploads/' . $this->folderImage . '/' . $opd, 0777);
				$dir = './assets/uploads/' . $this->folderImage . '/' . $opd;
			} else {
				$dir = './assets/uploads/' . $this->folderImage . '/' . $opd;
			}

			if ($file->isValid() && !$file->hasMoved()) {
				try {
					$file->move($dir, $newName);
				} catch (\Throwable $th) {
					return $this->fail($th);
				}
			} else {
				return $this->fail($file->getErrorString());
			}

			$tags = htmlspecialchars($this->request->getVar('tag'), true);

			$data = [
				'post_opd' => $opd,
				'post_category' => htmlspecialchars($this->request->getVar('category'), true),
				'post_user_id' => htmlspecialchars($this->request->getVar('user_id'), true),
				'post_title' => $title,
				'post_description' => $this->request->getVar('description'),
				'post_url' => _create_url($opd, $title),
				'post_trending' => htmlspecialchars($this->request->getVar('trending'), true),
				'post_tag' => $tags,
				'post_featured_image' => $newName,
				'post_is_active' => htmlspecialchars($this->request->getVar('is_active'), true),
				'post_created_at' => date('Y-m-d H:i:s'),
			];

			try {
				$post_id = $this->model->insert($data);
				$data['id'] = $post_id;

				$tag_array = explode(',', $tags);
				$db      = \Config\Database::connect();

				foreach ($tag_array as $tag_name) {
					$builder = $db->table('_tags_tb');
					$tag = strtolower(trim($tag_name));
					$data_tag = [
						'tag_name' => $tag,
						'tag_ori_name' => $tag_name
					];
					$builder->ignore(true)->insert($data_tag);
					$tag_ids = $builder->select('id')->where('tag_name', $tag)->get()->getRowObject();

					$tag_id = $tag_ids->id;

					$builders = $db->table('_tag_berita_target');
					$data_tag_berita = [
						'tag_id' => $tag_id,
						'berita_id' => $data['id'],
						'berita_url' => $data['post_url']
					];
					$builders->insert($data_tag_berita);
				}
			} catch (\Throwable $th) {
				unlink(FCPATH . './assets/uploads/' . $this->folderImage . '/' . $opd . '/' . $newName);
				return $this->fail($th);
			}

			return $this->respondCreated($data);
		}
	}

	public function show($id = null)
	{
		$data = $this->model->find($id);
		if ($data) {
			return $this->respond($data);
		} else {
			return $this->failNotFound('Item not found');
		}
	}

	public function update($id = null)
	{
		$oldData = $this->model->find($id);
		$rules = [
			'opd' => 'required',
			// 'category' => 'required',
			'user_id' => 'required',
			'title' => 'required',
			'description' => 'required'
		];


		$filename = dot_array_search('image.name', $_FILES);

		if ($filename != '') {
			$img = ['image' => 'uploaded[image]|max_size[image, 1024]|is_image[image]'];
			// $img = ['featured_image' => 'uploaded[featured_image]|mime_in[featured_image,image/jpg,image/png,image/gif,image/jpeg]|max_size[featured_image, 1024]'];
			$rules = array_merge($rules, $img);
		}



		if (!$this->validate($rules)) {
			return $this->failValidationError($this->validator->getError());
		} else {
			// $input = $this->request->getRawInput();
			$title = htmlspecialchars($this->request->getVar('title'), true);
			$opd = htmlspecialchars($this->request->getVar('opd'), true);
			$category = htmlspecialchars($this->request->getVar('category'), true);

			$tags = htmlspecialchars($this->request->getVar('tag'), true);


			$data = [
				'id' => htmlspecialchars($id, true),
				'post_opd' => $opd,
				'post_category' => $category,
				'post_title' => $title,
				'post_description' => $this->request->getVar('description'),
				'post_url' => _create_url($opd, $title),
				'post_trending' => htmlspecialchars($this->request->getVar('trending'), true),
				'post_tag' => $tags,
				'post_is_active' => htmlspecialchars($this->request->getVar('is_active'), true),
				'post_updated_at' => date('Y-m-d H:i:s'),
			];

			if ($filename != '') {


				$file = $this->request->getFile('image');
				$filesName = $file->getName();
				$newName = _create_name_foto($filesName);
				// if (!$file->isValid())
				// 	return $this->fail($file->getErrorString());

				// $file->move('./assets/uploads');

				// if (!file_exists('./assets/uploads/' . $this->folderImage . '/' . $opd)) {
				// 	mkdir('./assets/uploads/' . $this->folderImage . '/' . $opd, 0777);
				// 	$dir = './assets/uploads/' . $this->folderImage . '/' . $opd;
				// } else {
				$dir = './assets/uploads/' . $this->folderImage . '/' . $opd;
				// }



				// $file = $this->request->getFile('image');
				// $filesName = $file->getName();
				// $newName = _create_name_foto($filesName);
				// if (!$file->isValid())
				// 	return $this->fail($file->getErrorString());
				if ($file->isValid() && !$file->hasMoved()) {
					try {
						$file->move($dir, $newName);
						$oldFileName = $oldData['post_featured_image'];
						unlink(FCPATH . $dir . '/' . $oldFileName);
						$data['post_featured_image'] = $newName;
					} catch (\Throwable $th) {
						// return $this->fail($th);
						return $this->failNotFound('gagal upload');
					}
				} else {
					// return $this->fail($file->getErrorString());
					return $this->failNotFound('gagal valid file');
				}
			}
			try {
				$this->model->save($data);

				$tag_array = explode(',', $tags);
				$db      = \Config\Database::connect();

				$buildersDelete = $db->table('_tag_berita_target');
				$buildersDelete->delete(['berita_id', $id]);


				foreach ($tag_array as $tag_name) {
					$builder = $db->table('_tags_tb');
					$tag = strtolower(trim($tag_name));
					$data_tag = [
						'tag_name' => $tag,
						'tag_ori_name' => $tag_name
					];
					$builder->ignore(true)->insert($data_tag);
					$tag_ids = $builder->select('id')->where('tag_name', $tag)->get()->getRowObject();

					$tag_id = $tag_ids->id;

					$builders = $db->table('_tag_berita_target');
					$data_tag_berita = [
						'tag_id' => $tag_id,
						'berita_id' => $id,
						'berita_url' => $data['post_url']
					];
					$builders->insert($data_tag_berita);
				}
			} catch (\Throwable $th) {
				// return $this->fail($th);
				return $this->failNotFound('gagal simpan database');
			}

			return $this->respond($data);
		}
	}

	public function delete($id = null)
	{
		$data = $this->model->find($id);
		if ($data) {
			try {
				$fileName = $data['post_featured_image'];
				$opd = $data['post_opd'];
				// delete_files('./assets/uploads/' . $fileName);
				unlink(FCPATH . './assets/uploads/' . $this->folderImage . '/' . $opd . '/' . $fileName);

				$db      = \Config\Database::connect();

				$buildersDelete = $db->table('_tag_berita_target');
				$buildersDelete->delete(['berita_id', $id]);

				$this->model->delete($id);
				$dat['status'] = "deleted";
				$dat['message'] = "Item data berhasil di hapus.";
				$dat['description'] = "Item data " . $data['post_title'] . "berhasil di hapus";
				$dat['data'] = $data;
				return $this->respondDeleted($dat);
			} catch (\Throwable $th) {
				return $this->fail($th);
			}
		} else {
			return $this->failNotFound('Item not found');
		}
	}
}
