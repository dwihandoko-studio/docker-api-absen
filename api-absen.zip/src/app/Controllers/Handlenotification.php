<?php

namespace App\Controllers;

use App\Libraries\Veritrans;
use App\Libraries\Ppoblib;


class Handlenotification extends BaseController
{
  protected $modelName = 'App\Models\HandlenotificationModel';
  /*public function __construct()
    {
        parent::__construct();
        $params = array('server_key' => 'your_server_key', 'production' => false);
		//$this->load->library('veritrans');
		//$this->veritrans->config($params);
		//$this->load->helper('url');
		
    }*/


  public function addnotification()
  {
    echo 'test notification handler';
    $json_result = file_get_contents('php://input');

    $result = json_decode($json_result);

    //var_dump($result);die;

    $params = [
      'server_key' => 'SB-Mid-server-Z5_qVLbLWLippQNS6tEVW6kU',
      'production' => false,
    ];

    $midtrans = new Veritrans();

    $midtrans->config($params);



    if ($result) {
      $notif = $midtrans->status($result->order_id);



      $transaction = $notif->transaction_status;
      //var_dump($transaction);
      $type = $notif->payment_type;
      $order_id = $notif->order_id;
      $fraud = $notif->fraud_status;
      if ($transaction == 'capture') {
        // For credit card transaction, we need to check whether transaction is challenge by FDS or not
        if ($type == 'credit_card') {
          if ($fraud == 'challenge') {
            // TODO set payment status in merchant's database to 'Challenge by FDS'
            // TODO merchant should decide whether this transaction is authorized or not in MAP
            echo "Transaction order_id: " . $order_id . " is challenged by FDS";
          } else {
            // TODO set payment status in merchant's database to 'Success'
            echo "Transaction order_id: " . $order_id . " successfully captured using " . $type;
          }
        }
      } else if ($transaction == 'settlement') {
        // TODO set payment status in merchant's database to 'Settlement'
        $data = [
          'order_id' => $order_id,
          'status_transaksi' => $transaction,
          'keterangan' => $type,
          'created_at' => date('Y-m-d H:i:s')
        ];
        $db      = \Config\Database::connect();
        $builder = $db->table('_history_transaksi_pembayaran_tb_b');
        $builder->insert($data);

        //UPDATED PAYMENT
        $codePayment = explode('-', $order_id);
        if ($codePayment[1] == "ECOMPUB") {
            $builderUpdate = $db->table('_orders_tb_b');
            $dataUpdateOrder = [
              'status_order' => 1,
              'updated_at' => date('Y-m-d H:i:s')
            ];
            $builderUpdate->where('kode_transaksi', $order_id);
            $builderUpdate->update($dataUpdateOrder);
        }else if ($codePayment[1] == "TOPUPMERC") {
          	$builderUpdate = $db->table('_topup_merchan_tb_b');
          	$dataTopupMerchan = $builderUpdate->where('kode_transaksi', $order_id)->get()->getRowObject();
          	
          	if($dataTopupMerchan) {
              	$grossAmount = $notif->gross_amount;
              	if((int)$dataTopupMerchan->gross_amount == floatval($grossAmount)) {
                  	$dataUpdateTopup = [
                      'status_topup' => 1,
                      'updated_at' => date('Y-m-d H:i:s')
                    ];
                    $builderUpdate->where('kode_transaksi', $order_id);
                    $isUpdate = $builderUpdate->update($dataUpdateTopup);
                  	
                  	if($isUpdate) {
                      	$builderTopup = $db->table('_toko_tb_b');
                      	$dataMerchan = $builderTopup->where('user_id', $dataTopupMerchan->user_id)->get()->getRowObject();
                      	if($dataMerchan) {
                          	$oldSaldo = (int)$dataMerchan->toko_saldo;
                          	$upSaldo = (int)$dataTopupMerchan->nominal;
                          	$newSaldo = $oldSaldo + $upSaldo;
                          	
                          	$dataUpdateSaldo = [
                              'toko_saldo' => $newSaldo,
                              'updated_at' => date('Y-m-d H:i:s')
                            ];
                          	$builderTopup->where('user_id', $dataMerchan->user_id);
                    		$isUptedSaldo = $builderTopup->update($dataUpdateSaldo);
                          	if($isUptedSaldo) {
                              	$builderHistoryTopup = $db->table('_history_topup_merchan_tb_b');
                              	$dataHistoryTopupInsert = [
                                  	'user_id' => $dataMerchan->user_id,
                                  	'nominal' => (int)$dataTopupMerchan->nominal,
                                  	'keterangan' => "Topup berhasil. saldo bertambah ".$dataTopupMerchan->nominal,
                                  	'created_at' => date('Y-m-d H:i:s')
                                ];
                              	$builderHistoryTopup->insert($dataHistoryTopupInsert);
                            }
                        }
                    }
                }
            }
          	
        }else if ($codePayment[1] == "POBPUB") {
            $builderUpdate = $db->table('_orders_tb_b');
            $dataUpdateOrder = [
              'status_order' => 1,
              'updated_at' => date('Y-m-d H:i:s')
            ];
            $builderUpdate->where('kode_transaksi', $order_id);
            $builderUpdate->update($dataUpdateOrder);

            //SEND PPOB
            $builderPpob = $db->table('_orders_tb_b');
            $wherePpob = [
              'kode_transaksi' => $order_id
            ];
            $dataRequestPpob = $builderPpob->where($wherePpob)->get()->getRowObject();

            if ($dataRequestPpob) {
                $detailBuilderPpob = $db->table('_details_order_ppob_tb_b');
                $whereDetailPpob = [
                  'order_id' => $dataRequestPpob->id
                ];
                $detailBuilderPpob->select('_details_order_ppob_tb_b.product_id as productId, _daftar_produk_ppob_tb_b.nama_product as namaProduct, _daftar_produk_ppob_tb_b.kode_product as kodeProduct, _daftar_produk_ppob_tb_b.category_product as categoryProduct, _details_order_ppob_tb_b.no_pelanggan as noPelanggan');
                $detailBuilderPpob->join('_daftar_produk_ppob_tb_b', '_details_order_ppob_tb_b.product_id = _daftar_produk_ppob_tb_b.id');
                $detailOrderPpob = $detailBuilderPpob->where($whereDetailPpob)->get()->getRowObject();

                if ($detailOrderPpob) {
                    if ($detailOrderPpob->categoryProduct == "pulsa") {
                      	$newPpob = new Ppoblib();
                      	$responTransaksiPpob = $newPpob->pulsa($detailOrderPpob->kodeProduct, $detailOrderPpob->noPelanggan, $order_id);
                      	
                      	if ($responTransaksiPpob->STATUS == "00") {
                          	$dataInputHistoryPpob = [
                              'order_id' => $order_id,
                              'id_transaksi' => $responTransaksiPpob->REF2,
                              'kode_product' => $responTransaksiPpob->KODE_PRODUK,
                              'status_transaksi' => $responTransaksiPpob->STATUS_TRX,
                              'keterangan' => $responTransaksiPpob->KET,
                              'sn' => $responTransaksiPpob->SN,
                              'created_at' => date('Y-m-d H:i:s')
                            ];

                            $builderResponseTransaksiPpob = $db->table('_history_transaksi_ppob_tb_b');
                            $builderResponseTransaksiPpob->insert($dataInputHistoryPpob);
                        }else{
                          	$dataInputHistoryPpob = [
                              'order_id' => $order_id,
                              'id_transaksi' => $responTransaksiPpob->REF2,
                              'kode_product' => $responTransaksiPpob->KODE_PRODUK,
                              'status_transaksi' => $responTransaksiPpob->STATUS_TRX,
                              'keterangan' => $responTransaksiPpob->KET,
                              'sn' => $responTransaksiPpob->SN,
                              'created_at' => date('Y-m-d H:i:s')
                            ];

                            $builderResponseTransaksiPpob = $db->table('_history_transaksi_ppob_tb_b');
                            $builderResponseTransaksiPpob->insert($dataInputHistoryPpob);
                        }
                    }
                }
            }
        }
        

        echo "Transaction order_id: " . $order_id . " successfully transfered using " . $type;
      } else if ($transaction == 'pending') {
        // TODO set payment status in merchant's database to 'Pending'
        echo "Waiting customer to finish transaction order_id: " . $order_id . " using " . $type;
      } else if ($transaction == 'expire') {
        $data = [
          'order_id' => $order_id,
          'status_transaksi' => $transaction,
          'keterangan' => $type,
          'created_at' => date('Y-m-d H:i:s')
        ];
        $db      = \Config\Database::connect();
        $builder = $db->table('_history_transaksi_pembayaran_tb_b');
        $builder->insert($data);

        $builderUpdate = $db->table('_orders_tb_b');
        $dataUpdateOrder = [
          'status_order' => 2,
          'updated_at' => date('Y-m-d H:i:s')
        ];
        $builderUpdate->where('kode_transaksi', $order_id);
        $builderUpdate->update($dataUpdateOrder);
        // TODO set payment status in merchant's database to 'Pending'
        echo "Waiting customer to finish transaction order_id: " . $order_id . " using " . $type;
      } else if ($transaction == 'deny') {
        // TODO set payment status in merchant's database to 'Denied'
        echo "Payment using " . $type . " for transaction order_id: " . $order_id . " is denied.";
      }
    }

    error_log(print_r($result, TRUE));

    //notification handler sample

    /*
		*/
  }

  private function _send_json($data)
  {
    $api_url = "https://rajabiller.fastpay.co.id/transaksi/json.php";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_TIMEOUT, 0);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 500);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    // $result = curl_exec($ch);
    // return $result;
    return $ch;
  }
}
