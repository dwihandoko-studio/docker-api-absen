<?php
namespace App\Controllers;

header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Libraries\Uuid;

class Keranjang extends ResourceController
{
    protected $modelName = 'App\Models\KeranjangModel';
    protected $format = 'json';

    var $folderImage = 'profile';
  	private $_db;

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
      	$this->_db = \Config\Database::connect();
    }

    public function index()
    {

        // return $this->respondNoContent('Tidak ada content.');
        if (!$this->request->getGet('userId')) {
            return $this->respondNoContent('Tidak ada content.');
        } else {
          	
            $userId = htmlspecialchars($this->request->getGet('userId'), true);

            $builder = $this->_db->table('keranjang_view');
          	$select = "idToko, titleToko, imageToko, statusToko, idKecToko, idKabToko, alamatToko, originType, availablePengiriman, userId, kotaKabupaten, kotaKabupatenName";
            $hasil = $builder->select($select)->where('userId', $userId)->groupBy('idToko')->orderBy('createdAt', 'desc')->get()->getResult();
          
          	if(count($hasil) > 0) {
              	$data['result'] = [];
              	
              	foreach($hasil as $val){
                  $toko = [
                    'idToko' => $val->idToko,
                    'titleToko' => $val->titleToko,
                    'imageToko' => $val->imageToko,
                    'statusToko' => $val->statusToko,
                    'idKecToko' => $val->idKecToko,
                    'idKabToko' => $val->idKabToko,
                    'kotaKabupatenName' => $val->kotaKabupaten . " " . $val->kotaKabupatenName,
                    'alamatToko' => $val->alamatToko,
                    'originType' => $val->originType,
                    'availablePengiriman' => $val->availablePengiriman,
                  ];
                  $builderItem = $this->_db->table('keranjang_view');
                  $whereItem = [
                    	'userId' => $val->userId,
                    	'idToko' => $val->idToko,
                  ];
                  $toko['product'] = $builderItem->where($whereItem)->orderBy('createdAt', 'desc')->get()->getResult();
                  $data['result'][]=$toko;
                }
              	
              	$builderDefaultAlamat = $this->_db->table('_alamat_kiriman_users_tb');
                $whereDefaultAlamat = [
                  'user_id' => $userId,
                  'is_utama' => 1
                ];
                $hasilDefaultAlamat = $builderDefaultAlamat->where($whereDefaultAlamat)->orderBy('created_at', 'desc')->get()->getRowObject();

                $data['default_alamat'] = $hasilDefaultAlamat ?? "";
              
              	return $this->respond($data);
            } else {
              	return $this->respondNoContent('Tidak ada content.');
            }

            //$data['result'] = $hasil->getResult();
            //$data['total_result'] = count($data['result']);
          
          	

            // $where = [
            //     'userId' => $userId
            // ];
            // $data['result'] = $this->model->where($where)->orderBy('createdAt', 'desc')->findAll();
            // // $data['result'] = $this->model->findAll($per_page, $start);
            // $data['total_result'] = $this->model->where($where)->countAllResults();
        }

        //if ($data['total_result'] > 0) {
            
        //} else {
            
        //}
    }

    public function create()
    {
        $rules = [
            // 'userId' => 'required|min_length[3]|max_length[50]',
            'userId' => 'required',
            'idProduct' => 'required',
            'qty' => 'required',
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
          	$userId = htmlspecialchars($this->request->getVar('userId'), true);
          	$productId = htmlspecialchars($this->request->getVar('idProduct'), true);
          	
          	$dataPro = $this->_db->table('_product_tb_b')->getWhere(['id' => $productId])->getRowObject();
          	if($dataPro) {
              $cat = $this->_db->table('_keranjang_tb_b')->getWhere(['user_id' => $userId, 'product_id' => $productId])->getRowObject();

              if($cat) {
                $qty = ((int)$cat->qty + (int) htmlspecialchars($this->request->getVar('qty'), true));
                if($qty > (int)$dataPro->product_qty)
                  return $this->fail("Produk tidak mencukupi");
                $data = [
                  'id' => $cat->id,
                  'qty' => $qty,
                  'updated_at' => date('Y-m-d H:i:s'),
                ];

                $newData = $this->model->save($data);
                if($newData){
                  $data['user_id'] = $userId;
                  $data['product_id'] = $productId;

                  return $this->respondCreated($data);
                }else{
                  return $this->fail("Failed add item keranjang");
                }
              }
              if((int)htmlspecialchars($this->request->getVar('qty'), true) > (int)$dataPro->product_qty)
                return $this->fail("Produk tidak mencukupi");
              $uuid = new Uuid();

              $data = [
                  'id' => $uuid->v4(),
                  'user_id' => $userId,
                  'product_id' => $productId,
                  'qty' => htmlspecialchars($this->request->getVar('qty'), true),
                  'created_at' => date('Y-m-d H:i:s'),
              ];

              try {
                  $user_id = $this->model->insert($data);
              } catch (\Throwable $th) {
                  return $this->fail($th);
              }
              return $this->respondCreated($data);
            }else{
              return $this->fail("Produk tidak avaiable");
            }
        }
    }

    public function show($id = null)
    {
        $data = $this->model->find($id);
        if ($data) {
            return $this->respond($data);
        } else {
            return $this->failNotFound('Item not found');
        }
    }

    public function update($id = null)
    {
        $oldData = $this->model->find($id);
        $rules = [
            // 'id' => 'required|min_length[3]|max_length[50]',
            // 'lastname' => 'required|min_length[3]|max_length[50]',
            // 'email' => 'required|valid_email|is_unique[_users_tb.email]',
            'id' => 'required',
            'qty' => 'required',
            // 'password' => 'required|min_length[6]',
            // 'password_confirm' => 'matches[password]',
        ];

        if (!$this->validate($rules)) {
            return $this->failValidationError($this->validator->getError());
        } else {
            $data = [
                'id' => htmlspecialchars($id, true),
                'qty' => htmlspecialchars($this->request->getVar('qty'), true),
                'updated_at' => date('Y-m-d H:i:s'),
            ];

            try {
                $this->model->save($data);
                // unset($data['password']);
            } catch (\Throwable $th) {
                return $this->fail($th);
                // return $this->failNotFound('gagal simpan database');
            }
            return $this->respond($data);
        }
    }

    public function delete($id = null)
    {
        $data = $this->model->find($id);
        if ($data) {
            try {
                $this->model->delete($id);
                $dat['status'] = "deleted";
                $dat['message'] = "Item data berhasil di hapus.";
                $dat['description'] = "Product berhasil di hapus dari keranjang";
                $dat['data'] = $data;
                return $this->respondDeleted($dat);
            } catch (\Throwable $th) {
                return $this->fail($th);
            }
        } else {
            return $this->failNotFound('Item not found');
        }
    }
  
  	public function hapus(){
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            // 'userId' => 'required|min_length[3]|max_length[50]',
            'id' => 'required'
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
          $id = htmlspecialchars($this->request->getVar('id'), true);
          $data = $this->model->find($id);
          if ($data) {
              try {
                  $this->model->delete($id);
                  $dat['status'] = "deleted";
                  $dat['message'] = "Item data berhasil di hapus.";
                  $dat['description'] = "Product berhasil di hapus dari keranjang";
                  $dat['data'] = $data;
                  return $this->respondDeleted($dat);
              } catch (\Throwable $th) {
                  return $this->fail($th);
              }
          } else {
              return $this->failNotFound('Item not found');
          }
        }
    }
  
  	public function countcart(){
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            'userId' => 'required',
            //'id' => 'required'
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
          $userId = htmlspecialchars($this->request->getVar('userId'), true);
          
          $data = $this->model->where('user_id', $userId)->countAllResults();
          if ($data > 0) {
              $data['total_result'] = (string)$data;
              return $this->respond($data);
          } else {
              return $this->respondNoContent('Item not found');
          }
        }
    }
  
  	public function downup(){
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            // 'userId' => 'required|min_length[3]|max_length[50]',
            'id' => 'required',
          	'action' => 'required'
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
          $id = htmlspecialchars($this->request->getVar('id'), true);
          $data = $this->model->find($id);
          if ($data) {
            $cat = $this->_db->table('_product_tb_b')->getWhere(['id' => $data['product_id']])->getRowObject();
            if($cat) {
            	//echo "data lama: <br>";
            	//var_dump($data);
              $act = htmlspecialchars($this->request->getVar('action'), true);
              if($act == "down"){
                if((int)$data['qty'] == 1)
                  	return $this->fail("item cant decrease again");
                $dataupdate = [
                  'id' => $data['id'],
                  'qty' => ((int)$data['qty'] - 1),
                  'updated_at' => date('Y-m-d H:i:s')
                ];
                try {
                    $newData = $this->model->save($dataupdate);
                  	if($newData){
                      $callBackData = $this->model->find($id);
                      return $this->respond($callBackData);
                    }else{
                      return $this->fail("failed decrease item");
                    }
                    
                } catch (\Throwable $th) {
                    return $this->fail($th);
                    // return $this->failNotFound('gagal simpan database');
                }
                
              }else if($act == "up"){
                
                  if((int)$data['qty'] == (int)$cat->product_qty) 
                  	return $this->fail("item cant increase again");
                  
                
                
                $dataupdate = [
                  'id' => $data['id'],
                  'qty' => ((int)$data['qty'] + 1),
                  'updated_at' => date('Y-m-d H:i:s')
                ];
                try {
                    $newData = $this->model->save($dataupdate);
                  	if($newData){
                      $callBackData = $this->model->find($id);
                      return $this->respond($callBackData);
                    }else{
                      return $this->fail("failed increase item");
                    }
                } catch (\Throwable $th) {
                    return $this->fail($th);
                    // return $this->failNotFound('gagal simpan database');
                }
                
              }else{
                return $this->fail('Action not allowed');
              }
          	}else{
              return $this->fail("Product is not ready now.");
            }
              
          } else {
              return $this->failNotFound('Item not found');
          }
        }
    }
}
