<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;

class Produk extends ResourceController
{
    protected $modelName = 'App\Models\TokoModel';
    protected $format = 'json';

    var $folderImage = 'product';

    private $_db;

    function __construct()
    {
        helper(['text','file', 'form', 'array', 'fotourl', 'filesystem']);
        $this->_db      = \Config\Database::connect();
    }

    public function index()
    {
        
        $per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
        $pag = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

        if ($pag == 1) {
            $start = 0;
        } else {
            $start = (($pag - 1) * $per_page);
        }

		if (!$this->request->getGet('toko')) {
          $where = [
            '_product_tb_b.product_status' => 1
          ];
        }else{
          $tokoId = htmlspecialchars($this->request->getGet('toko'), true);
          $where = [
            '_product_tb_b.toko_id' => $tokoId,
          ];
        }
        $select = "_product_tb_b.id as productId, _product_tb_b.product_barcode as productBarcode, _product_tb_b.product_title as productTitle, _product_tb_b.product_description as productDescription, _product_tb_b.product_price_buy as productPriceBuy, _product_tb_b.product_price_sell as productPriceSell, _product_tb_b.product_weight as productWeight, _product_tb_b.product_qty as productQty, _product_tb_b.product_status as productStatus, _product_tb_b.product_unlimited as productUnlimited, _product_tb_b.product_thumb as productThumb, _product_tb_b.product_image as productImage, _product_tb_b.created_at as createdAt, _product_tb_b.updated_at as updatedAt, _category_tb_b.category_name as categoryName, _sub_category_tb_b.sub_category_name as subCategoryName";
      	
        $products = $this->_db->table('_product_tb_b')->select($select)->join('_category_tb_b', '_product_tb_b.category_id = _category_tb_b.id')->join('_sub_category_tb_b', '_product_tb_b.sub_category_id = _sub_category_tb_b.id')->where($where)->orderBy('_product_tb_b.created_at', 'desc')->get()->getResult();

        if(count($products) > 0) {
          $data['result'] = $products;
          $data['total_result'] = count($products);
          return $this->respond($data);
        }else{
          return $this->respondNoContent('Tidak ada content.');
        }
    }

    public function create()
    {
        $rules = [
            'userId' => 'required',
            'tokoId' => 'required',
            'barcode' => 'required',
            'namaProduk' => 'required',
            'deskripsiProduk' => 'required',
            'categoryProduk' => 'required',
            'subCategoryProduk' => 'required',
            'satuanProduk' => 'required',
            'qtyProduk' => 'required',
            'hargaBeliProduk' => 'required',
            'hargaJualProduk' => 'required',
            'diskonProduk' => 'required',
            'poinProduk' => 'required',
            'beratProduk' => 'required',
            'feeAdmin' => 'required',
          	'sendFrom' => 'required',
            //'files' => 'uploaded[files]|max_size[files, 1024]|is_image[files]'
        ];
        // $img = ['featured_image' => 'uploaded[featured_image]|mime_in[featured_image,image/jpg,image/png,image/gif,image/jpeg]|max_size[featured_image, 1024]'];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getError());
        } else {
            //get the file
            $userId = htmlspecialchars($this->request->getVar('userId'), true);
            $tokoId = htmlspecialchars($this->request->getVar('tokoId'), true);
            $barcode = htmlspecialchars($this->request->getVar('barcode'), true);
            $namaProduk = htmlspecialchars($this->request->getVar('namaProduk'), true);
            $deskripsiProduk = htmlspecialchars($this->request->getVar('deskripsiProduk'), true);
            $categoryProduk = htmlspecialchars($this->request->getVar('categoryProduk'), true);
            $subCategoryProduk = htmlspecialchars($this->request->getVar('subCategoryProduk'), true);
            $satuanProduk = htmlspecialchars($this->request->getVar('satuanProduk'), true);
            $qtyProduk = htmlspecialchars($this->request->getVar('qtyProduk'), true);
            $hargaBeliProduk = htmlspecialchars($this->request->getVar('hargaBeliProduk'), true);
            $hargaJualProduk = htmlspecialchars($this->request->getVar('hargaJualProduk'), true);
            $diskonProduk = htmlspecialchars($this->request->getVar('diskonProduk'), true);
            $poinProduk = htmlspecialchars($this->request->getVar('poinProduk'), true);
            $beratProduk = htmlspecialchars($this->request->getVar('beratProduk'), true);
            $feeAdmin = htmlspecialchars($this->request->getVar('feeAdmin'), true);
            $files = $this->request->getFiles();

            
            $imageThumb = "";

            if (!file_exists('./assets/uploads/' . $this->folderImage)) {
                mkdir('./assets/uploads/' . $this->folderImage, 0777);
                $dir = './assets/uploads/' . $this->folderImage;
            } else {
                $dir = './assets/uploads/' . $this->folderImage;
            }
          	$namesForStored = array();
			//var_dump($files);die;
          	if((int)htmlspecialchars($this->request->getVar('sendFrom'), true) == 1) {
              foreach ($files['images'] as $file) {
                $a = $file[0]->getClientMimeType();
                
                if ($a=="image/jpeg" || $a=="image/png" || $a=="image/jpg") {
                
                    $filesName = $file[0]->getName();
                    $newName = _create_name_foto($filesName);
                    if ($file[0]->isValid() && !$file[0]->hasMoved()) {

                        $file[0]->move($dir, $newName);

                        $namesForStored[] = $newName;
                    } else {
                      return $this->fail($file[0]->getErrorString());
                    }




                 } else {
                    return $this->fail("type file tidak diizinkan");
                 }

              }
            }else{
              foreach ($files['images'] as $file) {
                $a = $file->getClientMimeType();
                if ($a=="image/jpeg" || $a=="image/png" || $a=="image/jpg") {
                    $filesName = $file->getName();
                    $newName = _create_name_foto($filesName);
                    if ($file->isValid() && !$file->hasMoved()) {

                        $file->move($dir, $newName);

                        $namesForStored[] = $newName;
                    } else {
                      return $this->fail($file->getErrorString());
                    }




                 } else {
                    return $this->fail("type file tidak diizinkan");
                 }

              }
            }

            $uuid = new Uuid();

            $data = [
                'id' => $uuid->v4(),
                'product_barcode' => $barcode,
                'category_id' => $categoryProduk,
                'sub_category_id' => $subCategoryProduk,
                'product_title' => $namaProduk,
              	'product_satuan' => $satuanProduk,
                'product_description' => $deskripsiProduk,
                'product_price_buy' => $hargaBeliProduk,
                'product_price_sell' => $hargaJualProduk,
                'product_weight' => $beratProduk,
                'product_qty' => $qtyProduk,
                'product_status' => 1,
                'product_unlimited' => 0,
                'product_thumb' => $namesForStored[0],
                'product_image' => implode(",", $namesForStored),
                'fee_admin' => $feeAdmin,
                'toko_id' => $tokoId,
                'created_at' => date('Y-m-d H:i:s'),
            ];

            try {
                $post_id = $this->model->insert($data);
                $builder = $this->_db->table('_product_tb_b');
                $builder->insert($data);
            } catch (\Throwable $th) {
                foreach ($filesName as $name) {
                    unlink(FCPATH . './assets/uploads/' . $this->folderImage . '/' . $name);
                }
                return $this->fail($th);
            }

            return $this->respondCreated($data);
        }
    }
}
