<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
use App\Libraries\Notificationlib;
use App\Libraries\Orderslib;
use App\Libraries\Pesananlib;

class Transaksi extends ResourceController
{
    protected $modelName = 'App\Models\TransaksiModel';
    protected $format = 'json';

    var $folderImage = 'profile';
  	private $_db;

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
      	$this->_db = \Config\Database::connect();
    }

    public function index()
    {
      	if (!$this->request->getGet('userId')) {
            return $this->respondNoContent('Tidak ada content.');
        }else{
      		$per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
        	$start = (int) htmlspecialchars($this->request->getGet('start'), true) ? (int) htmlspecialchars($this->request->getGet('start'), true) : 0;
          	$userId = htmlspecialchars($this->request->getGet('userId'), true);
          
          	//var_dump($userId);die;
          	if(!$this->request->getGet('keyword')){
              	$where = [
                    'user_id' => $userId
                ];
                $dataOrdered = $this->model->where($where)->orderBy('created_at', 'desc')->findAll($per_page, $start);
                $data['total_result'] = $this->model->where($where)->countAllResults();

                if ($data['total_result'] > 0) {
                    $db      = \Config\Database::connect();
                    $itemOrder = [];
                    foreach($dataOrdered as $val) {
                      $orders = [];
                      if($val['jenis_order'] == "ppob"){
                        $builder = $this->_db->table('_details_order_ppob_tb_b');
                        $builder->select('_details_order_ppob_tb_b.product_id as productId, _daftar_produk_ppob_tb_b.nama_product as namaProduct, _details_order_ppob_tb_b.no_pelanggan as noPelanggan, _details_order_ppob_tb_b.jenis_ppob as jenisPpob');
                        $builder->join('_daftar_produk_ppob_tb_b', '_details_order_ppob_tb_b.product_id = _daftar_produk_ppob_tb_b.id');
                        $orders['itemOrderPpob'] = $builder->where('order_id', $val['id'])->get()->getResult();
                        $orders['jenisOrder'] = $val['jenis_order'];
                        $orders['kodeTransaksi'] = $val['kode_transaksi'];
                        $orders['totalHarga'] = $val['total_harga'];
                        $orders['totalQty'] = $val['total_qty'];
                        $orders['statusOrder'] = $val['status_order'];
                        $orders['createdAt'] = $val['created_at'];
                      }else{
                        $builder = $this->_db->table('_details_order_commerce_tb_b');
                        $builder->select('_details_order_commerce_tb_b.product_id as productId, _product_tb_b.product_title as namaProduct, _details_order_commerce_tb_b.qty_product as qtyProduct, _details_order_commerce_tb_b.harga_ongkir as hargaOngkir');
                        $builder->join('_product_tb_b', '_details_order_ppob_tb_b.product_id = _product_tb_b.id');
                        $orders['itemOrderEcom'] = $builder->where('order_id', $val->id)->get()->getResult();
                        $orders['jenisOrder'] = $val->jenis_order;
                        $orders['kodeTransaksi'] = $val->kode_transaksi;
                        $orders['totalHarga'] = $val->total_harga;
                        $orders['totalQty'] = $val->total_qty;
                        $orders['statusOrder'] = $val->status_order;
                        $orders['createdAt'] = $val['created_at'];
                      }
                      $itemOrder[] = $orders;
                    }
                    $data['result']= $itemOrder;


                    // $data['page'] = $pag;
                    $data['total_page'] = ceil($data['total_result'] / $per_page);
                    return $this->respond($data);
                } else {
                    return $this->respondNoContent('Tidak ada content.');
                }
            }else{
              	$keyword = htmlspecialchars($this->request->getGet('keyword'), true);
              	$where = [
                    'user_id' => $userId,
                  	'jenis_order' => $keyword
                ];
                $dataOrdered = $this->model->where($where)->orderBy('created_at', 'desc')->findAll($per_page, $start);
                $data['total_result'] = $this->model->where($where)->countAllResults();

                if ($data['total_result'] > 0) {
                    $db      = \Config\Database::connect();
                    $itemOrder = [];
                    foreach($dataOrdered as $val) {
                      $orders = [];
                      if($val['jenis_order'] == "ppob"){
                        $builder = $this->_db->table('_details_order_ppob_tb_b');
                        $builder->select('_details_order_ppob_tb_b.product_id as productId, _daftar_produk_ppob_tb_b.nama_product as namaProduct, _details_order_ppob_tb_b.no_pelanggan as noPelanggan, _details_order_ppob_tb_b.jenis_ppob as jenisPpob');
                        $builder->join('_daftar_produk_ppob_tb_b', '_details_order_ppob_tb_b.product_id = _daftar_produk_ppob_tb_b.id');
                        $itemPpob = $builder->where('order_id', $val['id'])->get()->getResult();
                        $orders['itemOrderPpob'] = $itemPpob;
                        $orders['jenisOrder'] = $val['jenis_order'];
                        $orders['jenisTransaksi'] = $itemPpob[0]->jenisPpob;
                        $orders['kodeTransaksi'] = $val['kode_transaksi'];
                        $orders['totalHarga'] = $val['total_harga'];
                        $orders['totalQty'] = $val['total_qty'];
                        $orders['statusOrder'] = $val['status_order'];
                        $orders['createdAt'] = $val['created_at'];
                      }else if($val['jenis_order'] == "tagihan"){
                        $builder = $this->_db->table('_details_order_tagihan_tb_b');
                        //$builder->select('_details_order_tagihan_tb_b.jenis_tagihan as jenisTagihan, ');
                        //$builder->join('_product_tb_b', '_details_order_ppob_tb_b.product_id = _product_tb_b.id');
                        $itemTagihan = $builder->where('order_id', $val['id'])->get()->getResult();
                        $orders['itemOrderTagihan'] = $itemTagihan;
                        $orders['jenisOrder'] = $val['jenis_order'];
                        $orders['jenisTransaksi'] = $itemTagihan[0]->jenis_tagihan;
                        $orders['kodeTransaksi'] = $val['kode_transaksi'];
                        $orders['totalHarga'] = $val['total_harga'];
                        $orders['totalQty'] = $val['total_qty'];
                        $orders['statusOrder'] = $val['status_order'];
                        $orders['createdAt'] = $val['created_at'];
                      }else if($val['jenis_order'] == "ecommerce"){
                        	$orderLib = new Orderslib();
                        	$detailOrder = $orderLib->getDataDetailTransaksi($val['kode_transaksi']);
                        	//var_dump($detailOrder);die;
                        	$orders['dataPesanan'] = $detailOrder;
                        	$orders['jenisOrder'] = $val['jenis_order'];
                            $orders['jenisTransaksi'] = "ecommerce";
                            $orders['kodeTransaksi'] = $val['kode_transaksi'];
                            $orders['totalHarga'] = $val['total_harga'];
                            $orders['totalQty'] = $val['total_qty'];
                            $orders['statusOrder'] = $val['status_order'];
                            $orders['createdAt'] = $val['created_at'];
                        
                        
                        
                        //$builder = $db->table('_pesanan_tb_b');
                        //$builder->select('_details_order_commerce_tb_b.product_id as productId, _product_tb_b.product_title as namaProduct, _details_order_commerce_tb_b.qty_product as qtyProduct, _details_order_commerce_tb_b.harga_ongkir as hargaOngkir');
                        //$builder->join('_product_tb_b', '_details_order_ppob_tb_b.product_id = _product_tb_b.id');
                        //$orders['itemOrderEcom'] = $builder->where('order_id', $val['id'])->get()->getResult();
                        //$orders['jenisOrder'] = $val['jenis_order'];
                        //$orders['jenisTransaksi'] = "ecommerce";
                        //$orders['kodeTransaksi'] = $val['kode_transaksi'];
                        //$orders['totalHarga'] = $val['total_harga'];
                        //$orders['totalQty'] = $val['total_qty'];
                        //$orders['statusOrder'] = $val['status_order'];
                        //$orders['createdAt'] = $val['created_at'];
                      }else{
                        return $this->respondNoContent('Tidak ada content.');
                      }
                      
                      $itemOrder[] = $orders;
                      
                    }
                    $data['result']= $itemOrder;


                    // $data['page'] = $pag;
                    $data['total_page'] = ceil($data['total_result'] / $per_page);
                    return $this->respond($data);
                } else {
                    return $this->respondNoContent('Tidak ada content.');
                }
            }

        	
        }

        // return $this->respondNoContent('Tidak ada content.');
       // if (!$this->request->getGet('userId')) {
         //   return $this->respondNoContent('Tidak ada content.');
       // } else {
          //  $userId = htmlspecialchars($this->request->getGet('userId'), true);

           // $db      = \Config\Database::connect();
           // $builder = $db->table('_orders_tb_b');
          //  $hasil = $builder->where('user_id', $userId)->orderBy('created_at', 'desc')->get();

          //  $data['result'] = $hasil->getResult();
         //   $data['total_result'] = count($data['result']);

            // $where = [
            //     'userId' => $userId
            // ];
            // $data['result'] = $this->model->where($where)->orderBy('createdAt', 'desc')->findAll();
            // // $data['result'] = $this->model->findAll($per_page, $start);
            // $data['total_result'] = $this->model->where($where)->countAllResults();
       // }

       // if ($data['total_result'] > 0) {
        //    return $this->respond($data);
        //} else {
        //    return $this->respondNoContent('Tidak ada content.');
        //}
    }
  
  	public function detail() {
      if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $rules = [
            'kodeTransaksi' => 'required'
        ];
      	
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          $kodeTransaksi = htmlspecialchars($this->request->getVar('kodeTransaksi'), true);
          $userId = htmlspecialchars($this->request->getVar('userId'), true)??"";
          if($userId == "" || $userId == null) {
            	$user="";
          }else{
            	$user=$userId;
          }
          
          $transaksis = explode("-", $kodeTransaksi);
          if($transaksis[1] == "POBPUB"){
            	$builderGetTransaksi = $this->_db->table('_orders_tb_b');
                $where = "kode_transaksi ='$kodeTransaksi'";
                //$where = [
                //  'user_id' => $userId
                //];
                $select = "_orders_tb_b.id, _orders_tb_b.kode_transaksi as kodeTransaksi, _orders_tb_b.jenis_order as jenisOrder, _orders_tb_b.total_harga as totalHarga, _orders_tb_b.total_qty as totalQty, _orders_tb_b.status_order as statusOrder, _orders_tb_b.user_id as userId, _orders_tb_b.created_at as createdAt, _orders_tb_b.updated_at as updatedAt";
            	
            	$detailTransaksi = $builderGetTransaksi->select($select)->where($where)->get()->getRowObject();
            	
            	if($detailTransaksi) {
                  //var_dump($detailTransaksi);
                  	if($user != "") {
                        $notification = new Notificationlib();
                        $notification->read($user, $detailTransaksi->kodeTransaksi);
                      //$notification->read($detailTransaksi->userId, $detailTransaksi->kodeTransaksi);
                    }
                  	
                  	$builderGetItemTransaksi = $this->_db->table('_details_order_ppob_tb_b');
                  	
                  	$selectItem = "_details_order_ppob_tb_b.product_id as productId, _details_order_ppob_tb_b.harga_product as hargaProduct, _details_order_ppob_tb_b.no_pelanggan as noPelanggan, _details_order_ppob_tb_b.jenis_ppob as jenisPpob, _details_order_ppob_tb_b.order_telah_selesai as orderTelahSelesai, _details_order_ppob_tb_b.created_at as createdAt, _details_order_ppob_tb_b.updated_at as updatedAt, _daftar_produk_ppob_tb_b.group_product as groupProduct, _daftar_produk_ppob_tb_b.category_product as categoryProduct, _daftar_produk_ppob_tb_b.nama_product as namaProduct, _daftar_produk_ppob_tb_b.title_product as titleProduct, _daftar_produk_ppob_tb_b.nominal as nominal, _daftar_produk_ppob_tb_b.poin as poin, _orders_tb_b.kode_transaksi as kodeTransaksi, _orders_tb_b.total_harga as totalHarga, _orders_tb_b.status_order as statusOrder";
                    //, _riwayat_struk_pembeli_pembayaran.noResi as strukNoResi, _riwayat_struk_pembeli_pembayaran.biayaAdmin as strukBiayaAdmin, _riwayat_struk_pembeli_pembayaran.kuota as strukKuota, _riwayat_struk_pembeli_pembayaran.produk as strukProduk, _riwayat_struk_pembeli_pembayaran.jenisProduk as strukJenisProduk, _riwayat_struk_pembeli_pembayaran.sisaSaldo as strukSisaSaldo, _riwayat_struk_pembeli_pembayaran.sn as strukSn, _riwayat_struk_pembeli_pembayaran.keterangan as strukKeterangan, _riwayat_struk_pembeli_pembayaran.jenisTransaksi as strukJenisTransaksi, _riwayat_struk_pembeli_pembayaran.paketData as strukPaketData, _riwayat_struk_pembeli_pembayaran.namaPelanggan as strukNamaPelanggan, _riwayat_struk_pembeli_pembayaran.urlStruk as strukUrlStruk, _riwayat_struk_pembeli_pembayaran.tegangan as strukTegangan, _orders_tb_b.kode_transaksi as kodeTransaksi";
                  	
                  	$whereItem = [
                      	'_details_order_ppob_tb_b.order_id' => $detailTransaksi->id
                    ];
                  	$builderGetItemTransaksi->select($selectItem);
                  	$builderGetItemTransaksi->join('_orders_tb_b', '_orders_tb_b.id = _details_order_ppob_tb_b.order_id');
                  	$builderGetItemTransaksi->join('_daftar_produk_ppob_tb_b', '_daftar_produk_ppob_tb_b.id = _details_order_ppob_tb_b.product_id');
                  	//$builderGetItemTransaksi->join('_riwayat_struk_pembeli_pembayaran', '_riwayat_struk_pembeli_pembayaran.orderId = _orders_tb_b.kode_transaksi');
                  	$dataDetailItemTransaksi = $builderGetItemTransaksi->where($whereItem)->get()->getRowObject();
                  	
                  	if($dataDetailItemTransaksi) {
                      	return $this->respond($dataDetailItemTransaksi);
                    } else {
                      	return $this->respondNoContent('Transaksi tidak ditemukan.');
                    }
                } else {
                  	return $this->respondNoContent('Transaksi tidak ditemukan.');
                }
                //, _history_transaksi_ppob_tb_b.status_transaksi as statusTransaksi, _history_transaksi_ppob_tb_b.keterangan as keterangan, _history_transaksi_ppob_tb_b.sn as sn, _daftar_produk_ppob_tb_b.nama_product as namaProduct, _daftar_produk_ppob_tb_b.category_product as categoryProduct, _daftar_produk_ppob_tb_b.group_product as groupProduct, _daftar_produk_ppob_tb_b.nominal as nominal";
                //$builderGetTransaksi->select($select);
                //$builderGetTransaksi->join('_history_transaksi_ppob_tb_b','_history_transaksi_ppob_tb_b.order_id = _orders_ppob_merchan_tb_b.kode_transaksi');
                //$builderGetTransaksi->join('_daftar_produk_ppob_tb_b','_daftar_produk_ppob_tb_b.id = _orders_ppob_merchan_tb_b.product_id');
                //$dataTransaksi = $builderGetTransaksi->where($where)->get()->getRowObject();
                //if ($dataTransaksi) {
                //      $notification = new Notificationlib();
                //      $notification->read($dataTransaksi->userId, $dataTransaksi->kodeTransaksi);
                //      return $this->respond($dataTransaksi);
                //}else{
                //      return $this->respondNoContent('Tidak ada content.');
                //}
          } else {
            	//transaksi lainnya
            	return $this->respondNoContent('Transaksi tidak ditemukan.');
          }

          
        }
    }
  
  	public function belumbayar(){
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
      
        $rules = [
            'userId' => 'required'
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          	$userId = htmlspecialchars($this->request->getVar('userId'), true);
          	$builder = $this->_db->table('_orders_tb_b');
          	$where = [
              	'user_id' => $userId,
              	'status_order' => 0,
            ];
          
          	$dataOrdered = $builder->where($where)->orderBy('created_at', 'desc')->get()->getResult();
          
          	if(!(count($dataOrdered) > 0))
              	return $this->respondNoContent("Tidak ada Content");
          
          	$itemOrder = [];
          
            foreach($dataOrdered as $val) {
                $orders = [];
                if($val->jenis_order == "ppob"){
                    $builder = $this->_db->table('_details_order_ppob_tb_b');
                    $builder->select('_details_order_ppob_tb_b.product_id as productId, _daftar_produk_ppob_tb_b.nama_product as namaProduct, _details_order_ppob_tb_b.no_pelanggan as noPelanggan, _details_order_ppob_tb_b.jenis_ppob as jenisPpob');
                    $builder->join('_daftar_produk_ppob_tb_b', '_details_order_ppob_tb_b.product_id = _daftar_produk_ppob_tb_b.id');
                    $itemPpob = $builder->where('order_id', $val->id)->get()->getResult();
                    $orders['itemOrderPpob'] = $itemPpob;
                    $orders['jenisOrder'] = $val->jenis_order;
                    $orders['jenisTransaksi'] = $itemPpob[0]->jenisPpob;
                    $orders['kodeTransaksi'] = $val->kode_transaksi;
                    $orders['totalHarga'] = $val->total_harga;
                    $orders['totalQty'] = $val->total_qty;
                    $orders['statusOrder'] = $val->status_order;
                    $orders['createdAt'] = $val->created_at;
                }else if($val->jenis_order == "tagihan"){
                    $builder = $this->_db->table('_details_order_tagihan_tb_b');
                    $itemTagihan = $builder->where('order_id', $val->id)->get()->getResult();
                    $orders['itemOrderTagihan'] = $itemTagihan;
                    $orders['jenisOrder'] = $val->jenis_order;
                    $orders['jenisTransaksi'] = $itemTagihan[0]->jenis_tagihan;
                    $orders['kodeTransaksi'] = $val->kode_transaksi;
                    $orders['totalHarga'] = $val->total_harga;
                    $orders['totalQty'] = $val->total_qty;
                    $orders['statusOrder'] = $val->status_order;
                    $orders['createdAt'] = $val->created_at;
                }else if($val->jenis_order == "ecommerce"){
                    $orderLib = new Orderslib();
                    $detailOrder = $orderLib->getDataDetailTransaksi($val->kode_transaksi);
                  
                  	//var_dump($detailOrder);die;

                    $orders['dataPesanan'] = $detailOrder;
                    $orders['jenisOrder'] = $val->jenis_order;
                    $orders['jenisTransaksi'] = "ecommerce";
                    $orders['kodeTransaksi'] = $val->kode_transaksi;
                    $orders['totalHarga'] = $val->total_harga;
                    $orders['totalQty'] = $val->total_qty;
                    $orders['statusOrder'] = $val->status_order;
                    $orders['createdAt'] = $val->created_at;

                }else{
                  return $this->respondNoContent('Tidak ada content.');
                }

                $itemOrder[] = $orders;

            }
          
            $data['result']= $itemOrder;
            return $this->respond($data);
        }
    }
  
  	public function ecomdiproses(){
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
      
        $rules = [
            'userId' => 'required'
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          	$userId = htmlspecialchars($this->request->getVar('userId'), true);
          	$builder = $this->_db->table('_orders_tb_b');
          	$where = [
              	'user_id' => $userId,
              	'jenis_order' => "ecommerce",
              	'status_order' => 1,
            ];
          
          	$dataOrdered = $builder->where($where)->orderBy('created_at', 'desc')->get()->getResult();
          
          	if(!(count($dataOrdered) > 0))
              	return $this->respondNoContent("Tidak ada Content");
          
          	$itemOrder = [];
          
            foreach($dataOrdered as $val) {
                $orders = [];
                $orderLib = new Orderslib();
                $detailOrder = $orderLib->getDataDetailEcomTransaksiDiproses($val->kode_transaksi);

                if(count($detailOrder) > 0) {
                    $orders['dataPesanan'] = $detailOrder;
                    $orders['jenisOrder'] = $val->jenis_order;
                    $orders['jenisTransaksi'] = "ecommerce";
                    $orders['kodeTransaksi'] = $val->kode_transaksi;
                    $orders['totalHarga'] = $val->total_harga;
                    $orders['totalQty'] = $val->total_qty;
                    $orders['statusOrder'] = $val->status_order;
                    $orders['createdAt'] = $val->created_at;

                    $itemOrder[] = $orders;
                }

            }
          
            $data['result']= $itemOrder;
            return $this->respond($data);
        }
    }
  
  	public function ecomdikirim(){
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
      
        $rules = [
            'userId' => 'required'
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          	$userId = htmlspecialchars($this->request->getVar('userId'), true);
          	$builder = $this->_db->table('_orders_tb_b');
          	$where = [
              	'user_id' => $userId,
              	'jenis_order' => "ecommerce",
              	'status_order' => 1,
            ];
          
          	$dataOrdered = $builder->where($where)->orderBy('created_at', 'desc')->get()->getResult();
          
          	if(!(count($dataOrdered) > 0))
              	return $this->respondNoContent("Tidak ada Content");
          
          	$itemOrder = [];
          
            foreach($dataOrdered as $val) {
                $orders = [];
                $orderLib = new Orderslib();
                $detailOrder = $orderLib->getDataDetailEcomTransaksiDikirim($val->kode_transaksi);

                if(count($detailOrder) > 0) {
                    $orders['dataPesanan'] = $detailOrder;
                    $orders['jenisOrder'] = $val->jenis_order;
                    $orders['jenisTransaksi'] = "ecommerce";
                    $orders['kodeTransaksi'] = $val->kode_transaksi;
                    $orders['totalHarga'] = $val->total_harga;
                    $orders['totalQty'] = $val->total_qty;
                    $orders['statusOrder'] = $val->status_order;
                    $orders['createdAt'] = $val->created_at;

                    $itemOrder[] = $orders;
                }

            }
          
            $data['result']= $itemOrder;
            return $this->respond($data);
        }
    }
  
  	public function ecomselesai(){
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
      
        $rules = [
            'userId' => 'required'
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          	$userId = htmlspecialchars($this->request->getVar('userId'), true);
          	$builder = $this->_db->table('_orders_tb_b');
          	$where = [
              	'user_id' => $userId,
              	'jenis_order' => "ecommerce",
              	'status_order' => 2,
            ];
          
          	$dataOrdered = $builder->where($where)->orderBy('created_at', 'desc')->get()->getResult();
          
          	if(!(count($dataOrdered) > 0))
              	return $this->respondNoContent("Tidak ada Content");
          
          	$itemOrder = [];
          
            foreach($dataOrdered as $val) {
                $orders = [];
                $orderLib = new Orderslib();
                $detailOrder = $orderLib->getDataDetailEcomTransaksiSelesai($val->kode_transaksi);

                if(count($detailOrder) > 0) {
                    $orders['dataPesanan'] = $detailOrder;
                    $orders['jenisOrder'] = $val->jenis_order;
                    $orders['jenisTransaksi'] = "ecommerce";
                    $orders['kodeTransaksi'] = $val->kode_transaksi;
                    $orders['totalHarga'] = $val->total_harga;
                    $orders['totalQty'] = $val->total_qty;
                    $orders['statusOrder'] = $val->status_order;
                    $orders['createdAt'] = $val->created_at;

                    $itemOrder[] = $orders;
                }

            }
          
            $data['result']= $itemOrder;
            return $this->respond($data);
        }
    }
  
  	public function dibatalkan(){
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
      
        $rules = [
            'userId' => 'required'
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          	$userId = htmlspecialchars($this->request->getVar('userId'), true);
          	$builder = $this->_db->table('_orders_tb_b');
          	$where = [
              	'user_id' => $userId,
              	'status_order' => 3,
              	'jenis_order' => "ecommerce"
            ];
          
          	$dataOrdered = $builder->where($where)->orderBy('created_at', 'desc')->get()->getResult();
          
          	if(!(count($dataOrdered) > 0))
              	return $this->respondNoContent("Tidak ada Content");
          
          	$itemOrder = [];
          
            foreach($dataOrdered as $val) {
                $orders = [];
                
                $orderLib = new Orderslib();
                $detailOrder = $orderLib->getDataDetailTransaksi($val->kode_transaksi);

                //var_dump($detailOrder);die;

                $orders['dataPesanan'] = $detailOrder;
                $orders['jenisOrder'] = $val->jenis_order;
                $orders['jenisTransaksi'] = "ecommerce";
                $orders['kodeTransaksi'] = $val->kode_transaksi;
                $orders['totalHarga'] = $val->total_harga;
                $orders['totalQty'] = $val->total_qty;
                $orders['statusOrder'] = $val->status_order;
                $orders['createdAt'] = $val->created_at;


                $itemOrder[] = $orders;

            }
          
            $data['result']= $itemOrder;
            return $this->respond($data);
        }
    }
  
  	public function ecomdetail(){
      	if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
      
        $rules = [
            'userId' => 'required',
          	'idPesanan' => 'required'
        ];
      
      	if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
          //return $this->fail("Required");
        } else {
          	$userId = htmlspecialchars($this->request->getVar('userId'), true);
          	$idPesanan = htmlspecialchars($this->request->getVar('idPesanan'), true);
          	
            $pesananLib = new Pesananlib();
            $dataPesanan = $pesananLib->getDataDetailEcomPesananDetail($idPesanan);

            if(!$dataPesanan) {
                return $this->respondNoContent("Tidak ada Content");
            }
          
            return $this->respond($dataPesanan);
        }
    }

}
