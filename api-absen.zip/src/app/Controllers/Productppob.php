<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;

class Productppob extends ResourceController
{
    protected $modelName = 'App\Models\ProductppobModel';
    protected $format = 'json';

    var $folderImage = 'profile';

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
    }

    public function index()
    {

        // return $this->respondNoContent('Tidak ada content.');
        // if (!$this->request->getGet('userId')) {
        //     return $this->respondNoContent('Tidak ada content.');
        // } else {
        //     $userId = htmlspecialchars($this->request->getGet('userId'), true);

        //     $db      = \Config\Database::connect();
        //     $builder = $db->table('keranjang_view');
        //     $hasil = $builder->where('userId', $userId)->orderBy('createdAt', 'desc')->get();

        //     $data['result'] = $hasil->getResult();
        //     $data['total_result'] = count($data['result']);

        if (!$this->request->getGet('group')) {
            $select = "id, poin, group_product as groupProduct, category_product as categoryProduct, kode_product as kodeProduct, nama_product as namaProduct, nominal, harga, no_urut as noUrut ,status_product as statusProduct, created_at as createdAt";

            $where = [
                'status_product' => 1,
            ];
            $data['result'] = $this->model->select($select)->where($where)->orderBy('nominal', 'asc')->findAll();
            // // $data['result'] = $this->model->findAll($per_page, $start);
            $data['total_result'] = $this->model->where($where)->countAllResults();
            // }

            if ($data['total_result'] > 0) {
                return $this->respond($data);
            } else {
                return $this->respondNoContent('Tidak ada content.');
            }
        } else {
            $group = htmlspecialchars($this->request->getGet('group'), true);
            $select = "id, poin, group_product as groupProduct, category_product as categoryProduct, kode_product as kodeProduct, nama_product as namaProduct, nominal, harga, no_urut as noUrut, status_product as statusProduct, created_at as createdAt";
			
          	$where = "status_product = 1 AND group_product LIKE '%$group%'";
            //$where = [
            //    'status_product' => 1,
            //    'group_product' => $group
            //];
            $data['result'] = $this->model->select($select)->where($where)->orderBy('nominal', 'asc')->findAll();
            // // $data['result'] = $this->model->findAll($per_page, $start);
            $data['total_result'] = $this->model->where($where)->countAllResults();
            // }

            if ($data['total_result'] > 0) {
                return $this->respond($data);
            } else {
                return $this->respondNoContent('Tidak ada content.');
            }
        }
    }

    // public function create()
    // {
    //     $rules = [
    //         // 'userId' => 'required|min_length[3]|max_length[50]',
    //         'userId' => 'required',
    //         'idProduct' => 'required',
    //         'qty' => 'required',
    //     ];

    //     if (!$this->validate($rules)) {
    //         return $this->fail($this->validator->getErrors());
    //     } else {
    //         $uuid = new Uuid();

    //         $data = [
    //             'id' => $uuid->v4(),
    //             'user_id' => htmlspecialchars($this->request->getVar('userId'), true),
    //             'product_id' => htmlspecialchars($this->request->getVar('idProduct'), true),
    //             'qty' => htmlspecialchars($this->request->getVar('qty'), true),
    //             'created_at' => date('Y-m-d H:i:s'),
    //         ];

    //         try {
    //             $user_id = $this->model->insert($data);
    //         } catch (\Throwable $th) {
    //             return $this->fail($th);
    //         }
    //         return $this->respondCreated($data);
    //     }
    // }

    // public function show($id = null)
    // {
    //     $data = $this->model->find($id);
    //     if ($data) {
    //         return $this->respond($data);
    //     } else {
    //         return $this->failNotFound('Item not found');
    //     }
    // }

    // public function update($id = null)
    // {
    //     $oldData = $this->model->find($id);
    //     $rules = [
    //         // 'id' => 'required|min_length[3]|max_length[50]',
    //         // 'lastname' => 'required|min_length[3]|max_length[50]',
    //         // 'email' => 'required|valid_email|is_unique[_users_tb.email]',
    //         'id' => 'required',
    //         'qty' => 'required',
    //         // 'password' => 'required|min_length[6]',
    //         // 'password_confirm' => 'matches[password]',
    //     ];

    //     if (!$this->validate($rules)) {
    //         return $this->failValidationError($this->validator->getError());
    //     } else {
    //         $data = [
    //             'id' => htmlspecialchars($id, true),
    //             'qty' => htmlspecialchars($this->request->getVar('qty'), true),
    //             'updated_at' => date('Y-m-d H:i:s'),
    //         ];

    //         try {
    //             $this->model->save($data);
    //             // unset($data['password']);
    //         } catch (\Throwable $th) {
    //             return $this->fail($th);
    //             // return $this->failNotFound('gagal simpan database');
    //         }
    //         return $this->respond($data);
    //     }
    // }

    // public function delete($id = null)
    // {
    //     $data = $this->model->find($id);
    //     if ($data) {
    //         try {
    //             $this->model->delete($id);
    //             $dat['status'] = "deleted";
    //             $dat['message'] = "Item data berhasil di hapus.";
    //             $dat['description'] = "Product berhasil di hapus dari keranjang";
    //             $dat['data'] = $data;
    //             return $this->respondDeleted($dat);
    //         } catch (\Throwable $th) {
    //             return $this->fail($th);
    //         }
    //     } else {
    //         return $this->failNotFound('Item not found');
    //     }
    // }
}
