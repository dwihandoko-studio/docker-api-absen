<?php

namespace App\Controllers;
use App\Libraries\Uuid;
//use App\Libraries\PhpSpreadsheet\Render\Xlsx;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Writer\Xls;

class Productimport extends BaseController
{
	public function index()
	{
		// $data['testing'] = _create_name_foto('WhatsApp Image 2020-05-05 at 22.05.57.jpeg');
		return view('import/formimport');
	}

	public function upload()
    {
      	$session = \Config\Services::session();
    	$validation = \Config\Services::validation();
      
      	$valid= $this->validate(
          [
            'fileimport' => [
              'label' => 'Inputan File',
              'rules' => 'uploaded[fileimport]|ext_in[fileimport,xls,xlsx]',
              'errors' => [
                'uploaded' => '{field} wajib diisi',
                'ext_in' => '{field} harus ekstensi xls & xlsx'
              ]
            ]
          ]
        );
      
      	if(!$valid) {
          $pesan = [
            'pesan' => $validation->getError('fileimport'),
          ];
          
          $session->setFlashdata($pesan);
          
          return redirect()->to('/productimport/index');
        }else{
          $file_excel = $this->request->getFile('fileimport');
          
          $ext = $file_excel->getClientExtension();
          
          if($ext=='xls'){
            $render = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
          } else {
            $render = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
          }
          
          $spreadsheet = $render->load($file_excel);
          
          $data = $spreadsheet->getActiveSheet()->toArray();
          
          $pesan_error = [];
          $jumlahEror = 0;
          $jumlahSucces = 0;
          
          foreach($data as $x => $row) {
            if($x == 0) {
              continue;
            }
            
            $cat_id = $this->getCategoryId($row[2]);
            $cat_name = $row[1];
            $sub_cat_id = $this->getSubCategoryId($row[3]);
            $satuan = $row[7];
            $stok = $row[17];
            $hpp = $row[18];
            $hargaToko = $row[19];
            $hargaToko2 = $row[20];
            $hargaToko3 = $row[21];
            $discount_rp = $row[22];
            $point_rp = $row[23];
            $jenis = $row[25];
            $stok_min = $row[27];
            $jenis_point = $row[30];
            $gambar = $row[31];
            $gambar2 = $row[32];
            $gambar3 = $row[33];
            $berat = $row[34];
            $panjang = $row[35];
            $lebar = $row[36];
            $supplier = $row[37];
            $kode_barcode = $row[39];
            $margin_toko = $row[42];
            $tgl_terakhir_beli = "2020-09-01";
            $tgl_terakhir_jual = "2020-09-01";
            $sudah_ppn = $row[47];
            $nilai_ppn = $row[48];
            $expired = "2020-09-01";
            $ket = $row[50];
            $harga_terakhir = $row[54];
            $stok_rusak = $row[55];
            $minimal_margin = $row[56];
            $rak = $row[57];
            $shelving = $row[58];
            $max_panjang = $row[59];
            
            //echo "$product";
            
            $db = \config\Database::connect();
            $cekProduct = $db->table('product_gudang_tb_b')->getWhere(['kode_barcode' => $kode_barcode])->getResult();
            
            if(count($cekProduct) > 0) {
              $pesan_error[] = "Product: $cat_name, sudah ada";
              $jumlahEror++;
            }else{
              $uuid = new Uuid();
              $dataSimpan = [
                'id' => $uuid->v4(),
                'category_id ' => $cat_id,
                'sub_category_id' => $sub_cat_id,
                'nama' => $cat_name,
                'satuan' => $satuan,
                'stok' => $stok,
                'hpp' => $hpp,
                'harga_toko' => $hargaToko,
                'harga_toko_2' => $hargaToko2,
                'harga_toko_3' => $hargaToko3,
                'discount_rp' => $discount_rp,
                'point_rp' => $point_rp,
                'jenis' => $jenis,
                'stok_min' => $stok_min,
                'jenis_point' => $jenis_point,
                'gambar' => $gambar,
                'gambar2' => $gambar2,
                'gambar3' => $gambar3,
                'berat' => $berat,
                'panjang' => $panjang,
                'lebar' => $lebar,
                'supplier' => $supplier,
                'kode_barcode' => $kode_barcode,
                'margin_toko' => $margin_toko,
                'tgl_terakhir_beli' => $tgl_terakhir_beli,
                'tgl_terakhir_jual' => $tgl_terakhir_jual,
                'sudah_ppn' => $sudah_ppn,
                'nilai_ppn' => $nilai_ppn,
                'expired' => $expired,
                'ket' => $ket,
                'harga_terakhir' => $harga_terakhir,
                'stok_rusak' => $stok_rusak,
                'minimal_margin' => $minimal_margin,
                'rak' => $rak,
                'shelving' => $shelving,
                'max_panjang' => $max_panjang,
                'created_at' => date('Y-m-d H:i:s')
              ];

              $db->table('product_gudang_tb_b')->insert($dataSimpan);
              $jumlahSucces++;
            }
          }
          
          $session->setFlashdata('import', "$jumlahEror Data tidak bisa disimpan <br> $jumlahSucces Data berhasil disimpan.");
          
          return redirect()->to('/productimport/index');
        }
    }
  
  	private function getCategoryId($string) {
      $db = \config\Database::connect();
      $category = $db->table('_category_tb_b')->getWhere(['category_name' => $string])->getRowObject();
      if($category) {
        return $category->id;
      }else{
        return null;
      }
    }
  
  	private function getSubCategoryId($string) {
      $db = \config\Database::connect();
      $subcategory = $db->table('_sub_category_tb_b')->getWhere(['sub_category_name' => $string])->getRowObject();
      if($subcategory) {
        return $subcategory->id;
      }else{
        return null;
      }
    }

}
