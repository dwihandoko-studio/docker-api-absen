<?php

namespace App\Controllers;

//use App\Libraries\Veritrans;
use App\Libraries\Notificationlib;
use App\Libraries\Uuid;
use App\Libraries\Onesignallib;


class Handlesmsotp extends BaseController
{
  protected $modelName = 'App\Models\HandlenotificationModel';
  
  private $_db;

    function __construct()
    {
        helper(['form', 'text', 'array', 'fotourl', 'filesystem']);
      	$this->_db = \Config\Database::connect();
    }
  
  	public function adsmedia() {
      	$respondata=json_decode(file_get_contents('php://input'),TRUE);
        if (!empty($respondata))
        {
            foreach($respondata['status_respon'] as $data) 
                {
                    $sendingid          = $data['sendingid'];
                    $number             = $data['number'];
                    $deliverystatus     = $data['deliverystatus'];
                    $deliverystatustext = $data['deliverystatustext'];

                    $uuid = new Uuid();
                                            
              		$data = [
                      	'id' => $uuid->v4(), 
                      	'sendingid' => $sendingid,
                      	'number' => $number,
                      	'deliverystatus' => $deliverystatus,
                      	'deliverystatustext' => $deliverystatustext,
                      	'created_at' => date('Y-m-d H:i:s')
                    ];
              
              		$builder = $this->_db->table('riwayat_send_otp');
              		$builder->insert($data);

                }
        }
    }
}

