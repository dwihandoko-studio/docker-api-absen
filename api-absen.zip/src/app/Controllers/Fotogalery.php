<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;

class Fotogalery extends ResourceController
{
	protected $modelName = 'App\Models\FotogaleryModel';
	protected $format = 'json';

	var $folderImage = 'galery/foto';

	function __construct()
	{
		helper(['form', 'array', 'fotourl', 'filesystem']);
	}

	public function index()
	{
		$url = htmlspecialchars($this->request->getGet('urlalbum'), true);
		$per_page = (int) htmlspecialchars($this->request->getGet('limit'), true) ? (int) htmlspecialchars($this->request->getGet('limit'), true) : 10;
		$pag = (int) htmlspecialchars($this->request->getGet('page'), true) ? (int) htmlspecialchars($this->request->getGet('page'), true) : 1;

		if ($pag == 1) {
			$start = 0;
		} else {
			$start = (($pag - 1) * $per_page);
		}


		if ($url) {
			// $dataFirs = $this->model->where(['post_opd' => $opd])->findAll();
			// return $this->respond($dataFirs);
			// $filename = dot_array_search('image.name', $_FILES);

			if (!$this->request->getGet('keyword')) {
				$db      = \Config\Database::connect();
				$builder = $db->table('_album_tb_b');
				$album_ids = $builder->select(['id', 'album_opd'])->where('album_url', $url)->get()->getRowObject();
				$album_id = $album_ids->id;

				$where = ['foto_album_id' => $album_id];


				$data['result']['data_foto'] = $this->model->where($where)->findAll();
				$data['result']['album_opd'] = $album_ids->album_opd;
				// $data['result'] = $this->model->where(['post_opd' => $opd])->findAll($per_page, $start);
				$data['total_result'] = $this->model->where($where)->countAllResults();
			} else {
				$keyword = htmlspecialchars($this->request->getGet('keyword'), true);

				$db      = \Config\Database::connect();
				$builder = $db->table('_album_tb_b');
				$album_ids = $builder->select('id')->where('album_url', $url)->get()->getRowObject();
				$album_id = $album_ids->id;

				$where = "foto_album_id = $album_id AND (foto_title LIKE '%$keyword%' OR foto_description LIKE '%$keyword%')";

				$data['result']['data_foto'] = $this->model->where($where)->findAll($per_page, $start);
				$data['result']['album_opd'] = $album_ids->album_opd;

				$data['total_result'] = $this->model->where($where)->countAllResults();
			}
		} else {
			$data['total_result'] = 0;
		}
		if ($data['total_result'] > 0) {
			$data['page'] = $pag;
			$data['total_page'] = ceil($data['total_result'] / $per_page);
			return $this->respond($data);
		} else {
			return $this->respondNoContent('Tidak ada content.');
		}
	}

	public function create()
	{
		$rules = [
			'urlalbum' => 'required',
			'user_id' => 'required',
			'title' => 'required',
			'description' => 'required',
			'image' => 'uploaded[image]|max_size[image, 1024]|is_image[image]'
		];
		// $img = ['featured_image' => 'uploaded[featured_image]|mime_in[featured_image,image/jpg,image/png,image/gif,image/jpeg]|max_size[featured_image, 1024]'];

		if (!$this->validate($rules)) {
			return $this->fail($this->validator->getError());
		} else {
			//get the file
			$title = htmlspecialchars($this->request->getVar('title'), true);
			$urlalbum = htmlspecialchars($this->request->getVar('urlalbum'), true);

			$opd_array = explode('-', $urlalbum);
			$opd = $opd_array[0];

			$file = $this->request->getFile('image');
			$filesName = $file->getName();
			$newName = _create_name_foto($filesName);
			// if (!$file->isValid())
			// 	return $this->fail($file->getErrorString());

			// $file->move('./assets/uploads');

			if (!file_exists('./assets/uploads/' . $this->folderImage . '/' . $opd)) {
				mkdir('./assets/uploads/' . $this->folderImage . '/' . $opd, 0777);
				$dir = './assets/uploads/' . $this->folderImage . '/' . $opd;
			} else {
				$dir = './assets/uploads/' . $this->folderImage . '/' . $opd;
			}

			if ($file->isValid() && !$file->hasMoved()) {
				try {
					$file->move($dir, $newName);
				} catch (\Throwable $th) {
					return $this->fail($th);
				}
			} else {
				return $this->fail($file->getErrorString());
			}

			try {
				$db      = \Config\Database::connect();
				$builder = $db->table('_album_tb_b');
				$album_ids = $builder->select(['id', 'album_opd'])->where('album_url', $urlalbum)->get()->getRowObject();
				$album_id = $album_ids->id;
			} catch (\Throwable $th) {
				return $this->fail("error");
			}

			$data = [
				'foto_album_id' => $album_id,
				'foto_user_id' => htmlspecialchars($this->request->getVar('user_id'), true),
				'foto_title' => $title,
				'foto_description' => $this->request->getVar('description'),
				'foto_featured_image' => $newName,
				'foto_is_active' => htmlspecialchars($this->request->getVar('is_active'), true),
				'foto_created_at' => date('Y-m-d H:i:s'),
			];

			try {
				$post_id = $this->model->insert($data);
				$data['id'] = $post_id;
			} catch (\Throwable $th) {
				unlink(FCPATH . './assets/uploads/' . $this->folderImage . '/' . $opd . '/' . $newName);
				return $this->fail($th);
			}

			return $this->respondCreated($data);
		}
	}

	public function show($id = null)
	{
		$data = $this->model->find($id);
		if ($data) {
			$db      = \Config\Database::connect();
			try {
				$builder = $db->table('_album_tb_b');
				$album_ids = $builder->select(['album_opd'])->where('id', $data['foto_album_id'])->get()->getRowObject();
				$album_opd = $album_ids->album_opd;
				$data['album_opd'] = $album_opd;
			} catch (\Throwable $th) {
				return $this->failNotFound('Item not found');
			}
			return $this->respond($data);
		} else {
			return $this->failNotFound('Item not found');
		}
	}

	public function update($id = null)
	{
		$oldData = $this->model->find($id);
		$rules = [
			'album_id' => 'required',
			'user_id' => 'required',
			'title' => 'required',
			'description' => 'required',
		];


		$filename = dot_array_search('image.name', $_FILES);

		if ($filename != '') {
			$img = ['image' => 'uploaded[image]|max_size[image, 1024]|is_image[image]'];
			// $img = ['featured_image' => 'uploaded[featured_image]|mime_in[featured_image,image/jpg,image/png,image/gif,image/jpeg]|max_size[featured_image, 1024]'];
			$rules = array_merge($rules, $img);
		}



		if (!$this->validate($rules)) {
			return $this->failValidationError($this->validator->getError());
		} else {
			// $input = $this->request->getRawInput();
			$title = htmlspecialchars($this->request->getVar('title'), true);
			$album_id = htmlspecialchars($this->request->getVar('album_id'), true);
			$album_opd = htmlspecialchars($this->request->getVar('album_opd'), true);

			$data = [
				'id' => htmlspecialchars($id, true),
				'foto_album_id' => $album_id,
				'foto_user_id' => htmlspecialchars($this->request->getVar('user_id'), true),
				'foto_title' => $title,
				'foto_description' => $this->request->getVar('description'),
				'foto_is_active' => htmlspecialchars($this->request->getVar('is_active'), true),
				'foto_updated_at' => date('Y-m-d H:i:s'),
			];

			if ($filename != '') {


				$file = $this->request->getFile('image');
				$filesName = $file->getName();
				$newName = _create_name_foto($filesName);
				// if (!$file->isValid())
				// 	return $this->fail($file->getErrorString());

				// $file->move('./assets/uploads');

				// if (!file_exists('./assets/uploads/' . $this->folderImage . '/' . $opd)) {
				// 	mkdir('./assets/uploads/' . $this->folderImage . '/' . $opd, 0777);
				// 	$dir = './assets/uploads/' . $this->folderImage . '/' . $opd;
				// } else {
				$dir = './assets/uploads/' . $this->folderImage . '/' . $album_opd;
				// }



				// $file = $this->request->getFile('image');
				// $filesName = $file->getName();
				// $newName = _create_name_foto($filesName);
				// if (!$file->isValid())
				// 	return $this->fail($file->getErrorString());
				if ($file->isValid() && !$file->hasMoved()) {
					try {
						$file->move($dir, $newName);
						$oldFileName = $oldData['foto_featured_image'];
						unlink(FCPATH . $dir . '/' . $oldFileName);
						$data['foto_featured_image'] = $newName;
					} catch (\Throwable $th) {
						// return $this->fail($th);
						return $this->failNotFound('gagal upload');
					}
				} else {
					// return $this->fail($file->getErrorString());
					return $this->failNotFound('gagal valid file');
				}
			}
			try {
				$this->model->save($data);
			} catch (\Throwable $th) {
				// return $this->fail($th);
				return $this->failNotFound('gagal simpan database');
			}

			return $this->respond($data);
		}
	}

	public function delete($id = null)
	{
		$data = $this->model->find($id);
		if ($data) {
			$db      = \Config\Database::connect();
			$builder = $db->table('_album_tb_b');
			$album_ids = $builder->select(['album_opd'])->where('id', $data['foto_album_id'])->get()->getRowObject();
			$album_opd = $album_ids->album_opd;
			try {
				$fileName = $data['foto_featured_image'];
				// delete_files('./assets/uploads/' . $fileName);
				unlink(FCPATH . './assets/uploads/' . $this->folderImage . '/' . $album_opd . '/' . $fileName);

				$this->model->delete($id);
				$dat['status'] = "deleted";
				$dat['message'] = "Item data berhasil di hapus.";
				$dat['description'] = "Item data " . $data['foto_title'] . "berhasil di hapus";
				$dat['data'] = $data;
				return $this->respondDeleted($dat);
			} catch (\Throwable $th) {
				return $this->fail($th);
			}
		} else {
			return $this->failNotFound('Item not found');
		}
	}
}
