<?php

namespace App\Controllers;
use App\Libraries\Ppoblib;
use App\Libraries\Orderslib;
use App\Libraries\Poinlib;
use App\Libraries\Saldolib;
use App\Libraries\Notificationlib;
use App\Libraries\Uuid;
use App\Libraries\Onesignallib;

class Cronjobtransaksippob extends BaseController
{
  	private $_db;

    function __construct()
    {
        helper(['form', 'text', 'array', 'fotourl', 'filesystem']);
      	$this->_db = \Config\Database::connect();
    }
	public function index()
	{
      	$data = date('Y-m-d');
      	$string = str_replace('-','', $data);
      	$start = $string . "000000";
      	$end = $string. "235959";
      	//echo $start; die;
		$builder = $this->_db->table('_history_transaksi_ppob_tb_b');
      	$where = [
          	'status_transaksi' => "PENDING",
        ];
      	$dataTransaksi = $builder->where($where)->orderBy('created_at', 'desc')->get()->getResult();
      
      	//echo count($dataTransaksi) . "<br><br>";
      
      	if(count($dataTransaksi) > 0) {
          	foreach($dataTransaksi as $val){
              	$ppob = new Ppoblib();
              	$get = $ppob->datatransaksi($start, $end, $val->id_transaksi);
              
              	$gets = $get->RESULT_TRANSAKSI;
              
              	foreach ($gets as $g) {
                  	$data = explode("#",$g);
                  
                  	$orderlib = new Orderslib();
                  	$dataOrders = $orderlib->getDataDetailTransaksi($val->order_id);
                      
                    //var_dump($dataOrders);
                    //echo "<br>";
                  
                  	if($data[9] == "SUKSES") {
                      	$ket = $data[6];
                      	$sn = $data[8];
                      	$idTransaksi = $data[0];
                      	$titleProduct = $data[3];
                      
                        $builderTransaksi = $this->_db->table('_history_transaksi_ppob_tb_b');

                        $dataUpdate = [
                          'status_transaksi' => "SUKSES",
                          'sn' => $sn,
                          'keterangan' => $ket,
                          'updated_at' => date('Y-m-d H:i:s')
                        ];
                      	$builderTransaksi->where('id_transaksi', $idTransaksi)->update($dataUpdate);
                      
                      
                      	if(count($dataOrders) > 0) {
                      
                            //var_dump($dataOrders);die;

                            $codePayment = explode('-', $val->order_id);
                            if ($codePayment[1] == "POBPUB") {
                                $orderlib->updateOrderToSukses($val->order_id);

                                //if ($dataOrders > 0) {
                                $dataOrder = $dataOrders[0];

                                $oldPointReward = (int) $dataOrder->userPoinReward;
                                $newPointReward = $oldPointReward + (int) $dataOrder->poinProduct;

                                $poinLib = new Poinlib();
                                $cekRiwayatPointAlready = $poinLib->cekAlreadyRiwayatPoint($val->order_id, $dataOrder->userIdPembeli, "debit");

                                if(!(count($cekRiwayatPointAlready) > 0)) {

                                    if($dataOrder->categoryProduct == "plnprabayar") {

                                        $dataRiwayatPoin=[
                                          'user_id' => $dataOrder->userIdPembeli,
                                          'kode_transaksi' => $val->order_id,
                                          'jenis_poin' => 'debit',
                                          'jenis_guna' => 'Pembayaran',
                                          'poin_old' => $oldPointReward,
                                          'poin_new' => $newPointReward,
                                          'poin_perubahan' => (int) $dataOrder->poinProduct,
                                          'keterangan' => "pembelian " . $dataOrder->namaProduct . " " . $dataOrder->noPelanggan . " " . " (" . $val->order_id . ")",
                                          'created_at' => date('Y-m-d H:i:s')
                                        ];
                                    } else {
                                        $dataRiwayatPoin=[
                                          'user_id' => $dataOrder->userIdPembeli,
                                          'kode_transaksi' => $val->order_id,
                                          'jenis_poin' => 'debit',
                                          'jenis_guna' => 'Pembayaran',
                                          'poin_old' => $oldPointReward,
                                          'poin_new' => $newPointReward,
                                          'poin_perubahan' => (int) $dataOrder->poinProduct,
                                          'keterangan' => "pembelian " . $dataOrder->categoryProduct . " " . $dataOrder->groupProduct . " " . $dataOrder->titleProduct . " (" . $val->order_id . ")",
                                          'created_at' => date('Y-m-d H:i:s')
                                        ];
                                    }

                                    if((int) $dataOrder->poinProduct > 0){
                                        $poinUpdate = new Poinlib();
                                        $poinUpdate->updatePoin($newPointReward, $dataOrder->userIdPembeli);

                                        $poinUpdate->insertRiwayatPoin($dataRiwayatPoin);
                                    }
                                }
                                //}

                                $updatePpobCetakStruk = $this->_db->table('_riwayat_struk_pembeli_pembayaran');
                                $dataStrukUpdate = [
                                    'sn' => $sn,
                                    'keterangan' => "SUKSES",
                                    'noResi' => $idTransaksi,
                                    'statusTransaksi' => "SUKSES"
                                ];
                                $whereStruk = [
                                      'orderId' => $val->order_id
                                ];
                                $statusUpdateStruk = $updatePpobCetakStruk->where($whereStruk)->update($dataStrukUpdate);

                                $dataNotifSystem = [
                                    'kode_transaksi' => $val->order_id,
                                    'title' => $titleProduct,
                                    'description' => $ket,
                                    'send_from' => "system",
                                    'send_to' => $val->user_id,
                                    'action_page' => "detail_order",
                                    'action_api' => "ppobpub"
                                ];
                                $saveNotifSystem = new Notificationlib();
                                $saveNotifSystem->send($dataNotifSystem);

                                $dataNotif = [
                                    'send_to' => $val->user_id,
                                    'title' => $titleProduct,
                                    'content' => $ket,
                                    'app_url' => "ppobpub;".$val->order_id.";detail_order"
                                ];

                                $onesignal = new Onesignallib();
                                $send = $onesignal->pushNotifToUser($dataNotif);

                                //return $this->respond($send);

                                //}
                            }else if ($codePayment[1] == "POBTAG"){
                                $orderlib->updateOrderToSukses($val->order_id);

                                //if ($dataOrders > 0) {
                                $dataOrder = $dataOrders[0];

                                $oldPointReward = (int) $dataOrder->userPoinReward;
                                $newPointReward = $oldPointReward + (int) $dataOrder->poinTransaksi;

                                $poinLib = new Poinlib();
                                $cekRiwayatPointAlready = $poinLib->cekAlreadyRiwayatPoint($val->order_id, $dataOrder->userIdPembeli, "debit");

                                if(!(count($cekRiwayatPointAlready) > 0)) {

                                    $dataRiwayatPoin=[
                                        'user_id' => $dataOrder->userIdPembeli,
                                        'kode_transaksi' => $val->order_id,
                                        'jenis_poin' => 'debit',
                                        'jenis_guna' => 'Pembayaran',
                                        'poin_old' => $oldPointReward,
                                        'poin_new' => $newPointReward,
                                        'poin_perubahan' => (int) $dataOrder->poinTransaksi,
                                        'keterangan' => "pembayaran " . $dataOrder->jenisTagihan . " " . $dataOrder->noPelanggan . " " . $dataOrder->namaPelanggan . " (" . $val->order_id . ")",
                                        'created_at' => date('Y-m-d H:i:s')
                                    ];

                                    if((int) $dataOrder->poinTransaksi > 0){
                                        $poinUpdate = new Poinlib();
                                        $poinUpdate->updatePoin($newPointReward, $dataOrder->userIdPembeli);

                                        $poinUpdate->insertRiwayatPoin($dataRiwayatPoin);
                                    }
                                }
                                //}

                                $updatePpobCetakStruk = $this->_db->table('_riwayat_struk_pembeli_pembayaran');
                                $dataStrukUpdate = [
                                    'sn' => $sn,
                                    'keterangan' => "SUKSES",
                                    'noResi' => $idTransaksi,
                                    'statusTransaksi' => "SUKSES"
                                ];
                                $whereStruk = [
                                    'orderId' => $val->order_id
                                ];
                                $statusUpdateStruk = $updatePpobCetakStruk->where($whereStruk)->update($dataStrukUpdate);

                                //if(($statusUpdateOrderDetail > 0) && ($statusUpdateOrder > 0) && ($statusUpdateStruk > 0)) {
                                $dataNotifSystem = [
                                    'kode_transaksi' => $val->order_id,
                                    'title' => $titleProduct,
                                    'description' => $ket,
                                    'send_from' => "system",
                                    'send_to' => $val->user_id,
                                    'action_page' => "detail_order",
                                    'action_api' => "ppobpub"
                                ];
                                $saveNotifSystem = new Notificationlib();
                                $saveNotifSystem->send($dataNotifSystem);

                                $dataNotif = [
                                    'send_to' => $val->user_id,
                                    'title' => $titleProduct,
                                    'content' => $ket,
                                    'app_url' => "ppobpub;".$val->order_id.";detail_order"
                                ];

                                $onesignal = new Onesignallib();
                                $send = $onesignal->pushNotifToUser($dataNotif);
                            }
                        }
                      
                    } else if($data[9] == "GAGAL") {
                      
                      	$ket = $data[6];
                      	$sn = $data[8];
                      	$idTransaksi = $data[0];
                      	$titleProduct = $data[3];
                      
                        $builderTransaksi = $this->_db->table('_history_transaksi_ppob_tb_b');

                        $dataUpdate = [
                          'status_transaksi' => "GAGAL",
                          'sn' => $sn,
                          'keterangan' => $ket,
                          'updated_at' => date('Y-m-d H:i:s')
                        ];
                      	$builderTransaksi->where('id_transaksi', $idTransaksi)->update($dataUpdate);
                      
                      
                      	if(count($dataOrders) > 0) {
                      
                            //var_dump($dataOrders);die;

                            $codePayment = explode('-', $val->order_id);
                            if ($codePayment[1] == "POBPUB") {
                                $orderlib->updateOrderToGagal($val->order_id);

                                //if (count($dataOrders) > 0) {
                                $dataOrder = $dataOrders[0];

                                $oldSaldo = (int)$dataOrder->userSaldo;
                              	$newSaldo = $oldSaldo - (int)$dataOrder->totalHarga;

                                $updateSaldo = new Saldolib();
                                $cekRiwayatSaldoAlready = $updateSaldo->cekAlreadyRiwayatSaldo($val->order_id, $dataOrder->userIdPembeli, "debit");

                                if(!(count($cekRiwayatSaldoAlready) > 0)) {
                                  
                                  	$statusLib = new Orderslib();
                                    $statusLib->updateOrderToGagal($val->order_id);

                                  	
                                    $updateSaldo->refundSaldo($oldSaldo, $dataOrder->userIdPembeli);
                                  
                                  	if($dataOrder->categoryProduct == "plnprabayar") {
                                        $dataRiwayatRefundSaldo = [
                                            'user_id' => $dataOrder->userIdPembeli,
                                            'kode_transaksi' => $val->order_id,
                                            'jenis_saldo' => 'debit',
                                            'jenis_guna' => 'Refund Saldo',
                                            'saldo_old' => $newSaldo,
                                            'saldo_new' => $oldSaldo,
                                            'saldo_perubahan' => (int)$dataOrder->totalHarga,
                                            'keterangan' => "Pengembalian dari gagal transaksi " . $dataOrder->namaProduct . " " . $dataOrder->noPelanggan . " " . " (" . $val->order_id . ")",
                                            'created_at' => date('Y-m-d H:i:s')
                                        ];
                                    } else {
                                      	$dataRiwayatRefundSaldo = [
                                            'user_id' => $dataOrder->userIdPembeli,
                                            'kode_transaksi' => $val->order_id,
                                            'jenis_saldo' => 'debit',
                                            'jenis_guna' => 'Refund Saldo',
                                            'saldo_old' => $newSaldo,
                                            'saldo_new' => $oldSaldo,
                                            'saldo_perubahan' => (int)$dataOrder->totalHarga,
                                            'keterangan' => "Pengembalian dari gagal transaksi " . $dataOrder->categoryProduct . " " . $dataOrder->groupProduct . " " . $dataOrder->nominalProduct . " (" . $val->order_id . ")",
                                            'created_at' => date('Y-m-d H:i:s')
                                        ];
                                    }
                                    $updateSaldo->insertRiwayatSaldo($dataRiwayatRefundSaldo);

                                }
                                //}

                              	try {
                                    $updatePpobCetakStruk = $this->_db->table('_riwayat_struk_pembeli_pembayaran');
                                    $dataStrukUpdate = [
                                        'sn' => $sn,
                                        'keterangan' => "GAGAL",
                                        'noResi' => $idTransaksi,
                                        'statusTransaksi' => "GAGAL"
                                    ];
                                    $whereStruk = [
                                          'orderId' => $val->order_id
                                    ];
                                    $statusUpdateStruk = $updatePpobCetakStruk->where($whereStruk)->update($dataStrukUpdate);
                                } catch (\Throwable $th) {
                                  
                                }

                                $dataNotifSystem = [
                                    'kode_transaksi' => $val->order_id,
                                    'title' => "GAGAL " . $titleProduct,
                                    'description' => $ket,
                                    'send_from' => "system",
                                    'send_to' => $val->user_id,
                                    'action_page' => "detail_order",
                                    'action_api' => "ppobpub"
                                ];
                                $saveNotifSystem = new Notificationlib();
                                $saveNotifSystem->send($dataNotifSystem);

                                $dataNotif = [
                                    'send_to' => $val->user_id,
                                    'title' => "GAGAL " . $titleProduct,
                                    'content' => $ket,
                                    'app_url' => "ppobpub;".$val->order_id.";detail_order"
                                ];

                                $onesignal = new Onesignallib();
                                $send = $onesignal->pushNotifToUser($dataNotif);

                                //return $this->respond($send);

                                //}
                            }else if ($codePayment[1] == "POBTAG"){
                                $orderlib->updateOrderToGagal($val->order_id);

                                //if (count($dataOrders) > 0) {
                                $dataOrder = $dataOrders[0];

                                $oldSaldo = (int)$dataOrder->userSaldo;
                              	$newSaldo = $oldSaldo - (int)$dataOrder->totalHarga;

                                $updateSaldo = new Saldolib();
                                $cekRiwayatSaldoAlready = $updateSaldo->cekAlreadyRiwayatSaldo($val->order_id, $dataOrder->userIdPembeli, "debit");

                                if(!(count($cekRiwayatSaldoAlready) > 0)) {
                                  
                                  	$statusLib = new Orderslib();
                                    $statusLib->updateOrderToGagal($val->order_id);

                                  	
                                    $updateSaldo->refundSaldo($oldSaldo, $dataOrder->userIdPembeli);
                                  
                                    $dataRiwayatRefundSaldo = [
                                        'user_id' => $dataOrder->userIdPembeli,
                                        'kode_transaksi' => $val->order_id,
                                        'jenis_saldo' => 'debit',
                                        'jenis_guna' => 'Refund Saldo',
                                        'saldo_old' => $newSaldo,
                                        'saldo_new' => $oldSaldo,
                                        'saldo_perubahan' => (int)$dataOrder->totalHarga,
                                        'keterangan' => "pembayaran " . $dataOrder->jenisTagihan . " " . $dataOrder->noPelanggan . " " . $dataOrder->namaPelanggan . " (" . $val->order_id . ")",
                                        'created_at' => date('Y-m-d H:i:s')
                                    ];
                                    
                                    $updateSaldo->insertRiwayatSaldo($dataRiwayatRefundSaldo);

                                }
                                //}

                              	try {
                                    $updatePpobCetakStruk = $this->_db->table('_riwayat_struk_pembeli_pembayaran');
                                    $dataStrukUpdate = [
                                        'sn' => $sn,
                                        'keterangan' => "GAGAL",
                                        'noResi' => $idTransaksi,
                                        'statusTransaksi' => "GAGAL"
                                    ];
                                    $whereStruk = [
                                          'orderId' => $val->order_id
                                    ];
                                    $statusUpdateStruk = $updatePpobCetakStruk->where($whereStruk)->update($dataStrukUpdate);
                                } catch (\Throwable $th) {
                                  
                                }

                                $dataNotifSystem = [
                                    'kode_transaksi' => $val->order_id,
                                    'title' => "GAGAL " . $titleProduct,
                                    'description' => $ket,
                                    'send_from' => "system",
                                    'send_to' => $val->user_id,
                                    'action_page' => "detail_order",
                                    'action_api' => "ppobpub"
                                ];
                                $saveNotifSystem = new Notificationlib();
                                $saveNotifSystem->send($dataNotifSystem);

                                $dataNotif = [
                                    'send_to' => $val->user_id,
                                    'title' => "GAGAL " . $titleProduct,
                                    'content' => $ket,
                                    'app_url' => "ppobpub;".$val->order_id.";detail_order"
                                ];

                                $onesignal = new Onesignallib();
                                $send = $onesignal->pushNotifToUser($dataNotif);
                            }
                        }
                    } else {
                      
                    }
                  	
                  	//var_dump($data); echo "<br><br><br>";
                }
              
              	
            }
        }else{
          	//echo "tidak ada data";
        }
	}

	//--------------------------------------------------------------------

}
