<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Libraries\Uuid;
// use CodeIgniter\HTTP\Response;


class Ppob extends ResourceController
{
    protected $modelName = 'App\Models\PpobModel';
    protected $format = 'json';

    var $folderImage = 'profile';

    function __construct()
    {
        helper(['form', 'array', 'fotourl', 'filesystem']);
    }

    private function _send_json($data)
    {
        $api_url = "https://rajabiller.fastpay.co.id/transaksi/json.php";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $api_url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 0);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 500);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        // $result = curl_exec($ch);
        // return $result;
        return $ch;
    }

    public function productstatus()
    {
        if ($this->request->getMethod() != 'post')
            return $this->fail('Only post request is allowed');
        $methode = htmlspecialchars($this->request->getVar('methode'), true);
        if ($methode == null || $methode == "")
            return $this->fail('need field');

        if ($methode == "group_produk") {
            $request_data = [
                'method' => 'rajabiller.' . $methode,
                'uid' => 'SP27505',
                'pin' => '885294',
                'group' => htmlspecialchars($this->request->getVar('group'), true)
            ];
            $add         = $this->_send_json($request_data);
            $send_data         = curl_exec($add);
            $respon         = json_decode($send_data);
            
          
          	if ($respon->STATUS == "00" && $respon->KET == "Data ditemukan") {
              	$data["status"] = $respon->STATUS;
                $data["ket"] = $respon->KET;
                for ($i = 0; $i < count($respon->DATA); $i++) {
                    $arValue[$i] = explode("#", $respon->DATA[$i]);
                    $data["data"][$i]["kode_product"] = $arValue[$i][0];
                    $data["data"][$i]["nama_product"] = $arValue[$i][1];
                    $data["data"][$i]["harga_product"] = $arValue[$i][2];
                    $data["data"][$i]["field1"] = $arValue[$i][3];
                    $data["data"][$i]["field2"] = $arValue[$i][4];
                    $data["data"][$i]["status_produk"] = $arValue[$i][5];
                }
                return $this->respond($data);
            } else {
                return $this->failNotFound();
            }
        } else if ($methode == "cekip") {
            $request_data = [
                'method' => 'rajabiller.' . $methode
            ];
            $add         = $this->_send_json($request_data);
            $send_data         = curl_exec($add);
            $respon         = json_decode($send_data);

            //var_dump($respon);

            return $this->respond($respon);
        } else if ($methode == "balance") {
            $request_data = [
                'method' => 'rajabiller.' . $methode,
              	'uid' => 'SP27505',
                'pin' => '885294',
            ];
            $add         = $this->_send_json($request_data);
            $send_data         = curl_exec($add);
            $respon         = json_decode($send_data);

            
			
            if ($respon->STATUS == "00") {
                $data["status"] = $respon->STATUS;
                $data["saldo"] = (int)$respon->SALDO;
                $data["ket"] = $respon->KET;
                return $this->respond($data);
            } else {
                return $this->failNotFound();
            }
        } else if ($methode == "harga") {
            $request_data = [
                'method' => 'rajabiller.' . $methode,
                'uid' => 'SP27505',
                'pin' => '885294',
                'produk' => htmlspecialchars($this->request->getVar('produk'), true)
            ];
            $add         = $this->_send_json($request_data);
            $send_data         = curl_exec($add);
            $respon         = json_decode($send_data);
          	var_dump($respon);die;
            $data["status"] = $respon->STATUS;
            $data["ket"] = $respon->KET;
            for ($i = 0; $i < count($respon->DATA); $i++) {
                $arValue[$i] = explode("#", $respon->DATA[$i]);
                $data["data"][$i]["kode_product"] = $arValue[$i][0];
                $data["data"][$i]["nama_product"] = $arValue[$i][1];
                $data["data"][$i]["harga_product"] = $arValue[$i][2];
                $data["data"][$i]["field1"] = $arValue[$i][3];
                $data["data"][$i]["field2"] = $arValue[$i][4];
                $data["data"][$i]["status_produk"] = $arValue[$i][5];
            }
          
          	if ($data["status"] == "00" && $data["ket"] == "Data ditemukan") {
                return $this->respond($data);
            } else {
                return $this->failNotFound();
            }
        } else if ($methode == "info_produk") {
            $request_data = [
                'method' => 'rajabiller.' . $methode,
              	'uid' => 'SP27505',
                'pin' => '885294',
              	'kode_produk' => htmlspecialchars($this->request->getVar('kode_produk'), true)
            ];
            $add         = $this->_send_json($request_data);
            $send_data         = curl_exec($add);
            $respon         = json_decode($send_data);
			
            if ($respon->STATUS == "00") {
                $data["status"] = $respon->STATUS;
                $data["harga"] = (int)$respon->HARGA;
                $data["admin"] = (int)$respon->ADMIN;
                $data["komisi"] = (int)$respon->KOMISI;
                $data["produk"] = (int)$respon->PRODUK;
                $data["status_produk"] = (int)$respon->STATUS_PRODUK;
                $data["ket"] = $respon->KET;
                return $this->respond($data);
            } else {
                return $this->failNotFound();
            }
        } else if ($methode == "pulsa") {
            $request_data = [
                'method' => 'rajabiller.' . $methode,
              	'uid' => 'SP27505',
                'pin' => '885294',
              	'no_hp' => htmlspecialchars($this->request->getVar('no_hp'), true),
              	'kode_produk' => htmlspecialchars($this->request->getVar('kode_produk'), true),
              	'ref1' => htmlspecialchars($this->request->getVar('id_transaksi'), true),
            ];
            $add         = $this->_send_json($request_data);
            $send_data         = curl_exec($add);
          
          	var_dump($send_data);
          
            $respon         = json_decode($send_data);

            
            if ($respon->STATUS == "00") {
                $data["kode_produk"] = $respon->KODE_PRODUK;
                $data["waktu"] = $respon->WAKTU;
                $data["no_hp"] = $respon->NO_HP;
                $data["sn"] = $respon->SN;
                $data["nominal"] = $respon->NOMINAL;
                $data["ref1"] = $respon->REF1;
                $data["ref2"] = $respon->REF2;
                $data["status"] = $respon->STATUS;
                $data["ket"] = $respon->KET;
                $data["status_trx"] = $respon->STATUS_TRX;

                return $this->respond($data);
            } else {
                return $this->failNotFound();
            }
        } else if ($methode == "beli") {
            $request_data = [
                'method' => 'rajabiller.' . $methode,
              	'uid' => 'SP27505',
                'pin' => '885294',
              	'idpel' => htmlspecialchars($this->request->getVar('idpel'), true),
                'kode_produk' => htmlspecialchars($this->request->getVar('kode_produk'), true),
                'ref1'        => htmlspecialchars($this->request->getVar('ref1'), true),
                'nominal'     => htmlspecialchars($this->request->getVar('nominal'), true),
            ];
            $add         = $this->_send_json($request_data);
            $send_data         = curl_exec($add);
            $respon         = json_decode($send_data);
          
          	//var_dump($send_data);

            
            if ($respon->STATUS == "00") {
                $data["kode_produk"] = $respon->KODE_PRODUK;
                $data["waktu"] = $respon->WAKTU;
                $data["idpel1"] = $respon->IDPEL1;
                $data["idpel2"] = $respon->IDPEL2;
                $data["idpel3"] = $respon->IDPEL3;
                $data["nama_pelanggan"] = $respon->NAMA_PELANGGAN;
                $data["periode"] = $respon->PERIODE;
                $data["nominal"] = $respon->NOMINAL;
                $data["admin"] = $respon->ADMIN;
                $data["ref1"] = $respon->REF1;
                $data["ref2"] = $respon->REF2;
                $data["ref3"] = $respon->REF3;
                $data["status"] = $respon->STATUS;
                $data["ket"] = $respon->KET;
                $data["url_struk"] = $respon->URL_STRUK;
                //$data["detail"] = [
                    $data["detail"]["catatan"] = $respon->DETAIL->CATATAN;
                    $data["detail"]["token"] = $respon->DETAIL->TOKEN;
                    $data["detail"]["subsribesegmentation"] = $respon->DETAIL->SUBSCRIBERSEGMENTATION;
                    $data["detail"]["powerconsumingcategory"] = $respon->DETAIL->POWERCONSUMINGCATEGORY;
                    $data["detail"]["powerpurchase"] = $respon->DETAIL->POWERPURCHASE;
                    $data["detail"]["minorunitofpowerpurchase"] = $respon->DETAIL->MINORUNITOFPOWERPURCHASE;
                    $data["detail"]["purchasedkwhunit"] = $respon->DETAIL->PURCHASEDKWHUNIT;
                    $data["detail"]["minorunitofpurchasedkwhunit"] = $respon->DETAIL->MINORUNITOFPURCHASEDKWHUNIT;
                //];

                return $this->respond($data);
            } else {
                return $this->failNotFound();
            }
        }

    }





    public function index()
    {
        if (!$this->request->getGet('userId')) {
            return $this->respondNoContent('Tidak ada content.');
        } else {
            $userId = htmlspecialchars($this->request->getGet('userId'), true);

            if (!$this->request->getGet('default')) {
                $where = [
                    'user_id' => $userId
                ];
                //$orderBy = [
                //  	'is_utama' => 'asc',
                //  	'label_alamat' => 'asc',
                //  	'created_at' => 'desc'
                //];
                $data['result'] = $this->model->where($where)->orderBy('is_utama', 'asc')->orderBy('label_alamat', 'asc')->orderBy('created_at', 'asc')->findAll();
                // // $data['result'] = $this->model->findAll($per_page, $start);
                $data['total_result'] = $this->model->where($where)->countAllResults();
            } else {
                $db      = \Config\Database::connect();
                $builder = $db->table('_alamat_kiriman_users_tb');
                $where = [
                    'user_id' => $userId,
                    'is_utama' => 1
                ];
                $hasil = $builder->where($where)->orderBy('created_at', 'desc')->get();

                $data = $hasil->getRow();
                if ($data) {
                    return $this->respond($data);
                } else {
                    return $this->respondNoContent('Tidak ada content.');
                }
                //$data['total_result'] = count($data['result']);
            }

            //$db      = \Config\Database::connect();
            //$builder = $db->table('keranjang_view');
            //$hasil = $builder->where('userId', $userId)->orderBy('createdAt', 'desc')->get();

            //$data['result'] = $hasil->getResult();
            //$data['total_result'] = count($data['result']);

            //$where = [
            //    'user_id' => $userId
            //];
            //$data['result'] = $this->model->where($where)->orderBy('createdAt', 'desc')->findAll();
            // // $data['result'] = $this->model->findAll($per_page, $start);
            //$data['total_result'] = $this->model->where($where)->countAllResults();
        }

        if ($data['total_result'] > 0) {
            return $this->respond($data);
        } else {
            return $this->respondNoContent('Tidak ada content.');
        }
    }

    public function create()
    {
        $rules = [
            // 'userId' => 'required|min_length[3]|max_length[50]',
            'userId' => 'required',
            'provId' => 'required',
            'kabId' => 'required',
            'kecId' => 'required',
            'detailAlamat' => 'required',
            'kodePos' => 'required',
            'labelAlamat' => 'required',
            'namaPenerima' => 'required',
            'nohpPenerima' => 'required',
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        } else {
            $uuid = new Uuid();

            $data = [
                'id' => $uuid->v4(),
                'user_id' => htmlspecialchars($this->request->getVar('userId'), true),
                'provinsi_id' => htmlspecialchars($this->request->getVar('provId'), true),
                'kabupaten_id' => htmlspecialchars($this->request->getVar('kabId'), true),
                'kecamatan_id' => htmlspecialchars($this->request->getVar('kecId'), true),
                'detail_alamat' => htmlspecialchars($this->request->getVar('detailAlamat'), true),
                'kode_pos' => htmlspecialchars($this->request->getVar('kodePos'), true),
                'label_alamat' => htmlspecialchars($this->request->getVar('labelAlamat'), true),
                'nama_penerima' => htmlspecialchars($this->request->getVar('namaPenerima'), true),
                'nohp_penerima' => htmlspecialchars($this->request->getVar('nohpPenerima'), true),
                'is_utama' => htmlspecialchars($this->request->getVar('is_utama'), true),
                'is_penjual' => htmlspecialchars($this->request->getVar('isPenjual'), true),
                'created_at' => date('Y-m-d H:i:s'),
            ];

            try {
                $user_id = $this->model->insert($data);
                if ($data['is_utama'] == 1) {
                    $db      = \Config\Database::connect();
                    $builder = $db->table('_alamat_kiriman_users_tb');
                    $idAlamat = $data['id'];
                    $where = "id != '$idAlamat'";
                    $hasil = $builder->set('is_utama', 0)->where($where)->update();
                }
            } catch (\Throwable $th) {
                return $this->fail($th);
            }
            return $this->respondCreated($data);
        }
    }

    public function show($id = null)
    {
        $data = $this->model->find($id);
        if ($data) {
            return $this->respond($data);
        } else {
            return $this->failNotFound('Item not found');
        }
    }

    public function update($id = null)
    {
        $oldData = $this->model->find($id);
        $rules = [
            'firsname' => 'required|min_length[3]|max_length[50]',
            'lastname' => 'required|min_length[3]|max_length[50]',
            'email' => 'required|valid_email|is_unique[_users_tb.email]',
            'instansi' => 'required',
            'level' => 'required',
            // 'password' => 'required|min_length[6]',
            // 'password_confirm' => 'matches[password]',
        ];

        if (!$this->validate($rules)) {
            return $this->failValidationError($this->validator->getError());
        } else {
            $data = [
                'id' => htmlspecialchars($id, true),
                'firsname' => htmlspecialchars($this->request->getVar('firsname'), true),
                'lastname' => htmlspecialchars($this->request->getVar('lastname'), true),
                'email' => htmlspecialchars($this->request->getVar('email'), true),
                // 'password' => htmlspecialchars($this->request->getVar('password'), true),
                'intansi_id' => htmlspecialchars($this->request->getVar('instansi'), true),
                'level' => htmlspecialchars($this->request->getVar('level'), true),
                'is_active' => htmlspecialchars($this->request->getVar('is_active'), true),
                'updated_at' => date('Y-m-d H:i:s'),
            ];

            try {
                $this->model->save($data);
                // unset($data['password']);
            } catch (\Throwable $th) {
                return $this->fail($th);
                // return $this->failNotFound('gagal simpan database');
            }
            return $this->respond($data);
        }
    }

    public function delete($id = null)
    {
        $data = $this->model->find($id);
        if ($data) {
            try {
                $this->model->delete($id);
                $dat['status'] = "deleted";
                $dat['message'] = "Item data berhasil di hapus.";
                $dat['description'] = "User " . $data['email'] . " berhasil di hapus";
                $dat['data'] = $data;
                return $this->respondDeleted($dat);
            } catch (\Throwable $th) {
                return $this->fail($th);
            }
        } else {
            return $this->failNotFound('Item not found');
        }
    }
}
